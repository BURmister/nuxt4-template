import { defineEventHandler, setResponseHeader, getRequestURL } from 'h3';
export default defineEventHandler(event => {
  setResponseHeader(event, 'Referrer-Policy', 'no-referrer');
  const url = getRequestURL(event);
  if (!url.searchParams.has('wishesKey')) return;
  setResponseHeader(event, 'Cache-Control', 'private, no-store');
  setResponseHeader(event, 'X-Robots-Tag', 'noindex, nofollow, noarchive');
  url.searchParams.delete('wishesKey');
  const clean = url.pathname + url.search;
  event.node.req.url = clean;
  event.node.req.originalUrl = clean;
  event._path = clean;
});
