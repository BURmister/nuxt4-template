var i3=Object.create;var c1=Object.defineProperty;var r3=Object.getOwnPropertyDescriptor;var c3=Object.getOwnPropertyNames;var u3=Object.getPrototypeOf,d3=Object.prototype.hasOwnProperty;var al=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var _3=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let l of c3(t))!d3.call(e,l)&&l!==n&&c1(e,l,{get:()=>t[l],enumerable:!(o=r3(t,l))||o.enumerable});return e};var c0=(e,t,n)=>(n=e!=null?i3(u3(e)):{},_3(t||!e||!e.__esModule?c1(n,"default",{value:e,enumerable:!0}):n,e));var w1=al(Ze=>{"use strict";var _0=Symbol.for("react.transitional.element"),f3=Symbol.for("react.portal"),m3=Symbol.for("react.fragment"),h3=Symbol.for("react.strict_mode"),g3=Symbol.for("react.profiler"),p3=Symbol.for("react.consumer"),y3=Symbol.for("react.context"),x3=Symbol.for("react.forward_ref"),b3=Symbol.for("react.suspense"),v3=Symbol.for("react.memo"),m1=Symbol.for("react.lazy"),w3=Symbol.for("react.activity"),S3=Symbol.for("react.view_transition"),u1=Symbol.iterator;function k3(e){return e===null||typeof e!="object"?null:(e=u1&&e[u1]||e["@@iterator"],typeof e=="function"?e:null)}var h1={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},g1=Object.assign,p1={};function ci(e,t,n){this.props=e,this.context=t,this.refs=p1,this.updater=n||h1}ci.prototype.isReactComponent={};ci.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};ci.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function y1(){}y1.prototype=ci.prototype;function f0(e,t,n){this.props=e,this.context=t,this.refs=p1,this.updater=n||h1}var m0=f0.prototype=new y1;m0.constructor=f0;g1(m0,ci.prototype);m0.isPureReactComponent=!0;var d1=Array.isArray;function d0(){}var en={H:null,A:null,T:null,S:null},x1=Object.prototype.hasOwnProperty;function h0(e,t,n){var o=n.ref;return{$$typeof:_0,type:e,key:t,ref:o!==void 0?o:null,props:n}}function C3(e,t){return h0(e.type,t,e.props)}function g0(e){return typeof e=="object"&&e!==null&&e.$$typeof===_0}function j3(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var _1=/\/+/g;function u0(e,t){return typeof e=="object"&&e!==null&&e.key!=null?j3(""+e.key):t.toString(36)}function E3(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch(typeof e.status=="string"?e.then(d0,d0):(e.status="pending",e.then(function(t){e.status==="pending"&&(e.status="fulfilled",e.value=t)},function(t){e.status==="pending"&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}function ri(e,t,n,o,l){var a=typeof e;(a==="undefined"||a==="boolean")&&(e=null);var c=!1;if(e===null)c=!0;else switch(a){case"bigint":case"string":case"number":c=!0;break;case"object":switch(e.$$typeof){case _0:case f3:c=!0;break;case m1:return c=e._init,ri(c(e._payload),t,n,o,l)}}if(c)return l=l(e),c=o===""?"."+u0(e,0):o,d1(l)?(n="",c!=null&&(n=c.replace(_1,"$&/")+"/"),ri(l,t,n,"",function(N){return N})):l!=null&&(g0(l)&&(l=C3(l,n+(l.key==null||e&&e.key===l.key?"":(""+l.key).replace(_1,"$&/")+"/")+c)),t.push(l)),1;c=0;var f=o===""?".":o+":";if(d1(e))for(var v=0;v<e.length;v++)o=e[v],a=f+u0(o,v),c+=ri(o,t,n,a,l);else if(v=k3(e),typeof v=="function")for(e=v.call(e),v=0;!(o=e.next()).done;)o=o.value,a=f+u0(o,v++),c+=ri(o,t,n,a,l);else if(a==="object"){if(typeof e.then=="function")return ri(E3(e),t,n,o,l);throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return c}function Mu(e,t,n){if(e==null)return e;var o=[],l=0;return ri(e,o,"","",function(a){return t.call(n,a,l++)}),o}function M3(e){if(e._status===-1){var t=e._result,n=t();n.then(function(o){(e._status===0||e._status===-1)&&(e._status=1,e._result=o,n.status===void 0&&(n.status="fulfilled",n.value=o))},function(o){(e._status===0||e._status===-1)&&(e._status=2,e._result=o,n.status===void 0&&(n.status="rejected",n.reason=o))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var f1=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)};function b1(e){var t=en.T,n={};n.types=t!==null?t.types:null,en.T=n;try{var o=e(),l=en.S;l!==null&&l(n,o),typeof o=="object"&&o!==null&&typeof o.then=="function"&&o.then(d0,f1)}catch(a){f1(a)}finally{t!==null&&n.types!==null&&(t.types=n.types),en.T=t}}function v1(e){var t=en.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else b1(v1.bind(null,e))}var T3={map:Mu,forEach:function(e,t,n){Mu(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return Mu(e,function(){t++}),t},toArray:function(e){return Mu(e,function(t){return t})||[]},only:function(e){if(!g0(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};Ze.Activity=w3;Ze.Children=T3;Ze.Component=ci;Ze.Fragment=m3;Ze.Profiler=g3;Ze.PureComponent=f0;Ze.StrictMode=h3;Ze.Suspense=b3;Ze.ViewTransition=S3;Ze.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=en;Ze.__COMPILER_RUNTIME={__proto__:null,c:function(e){return en.H.useMemoCache(e)}};Ze.addTransitionType=v1;Ze.cache=function(e){return function(){return e.apply(null,arguments)}};Ze.cacheSignal=function(){return null};Ze.cloneElement=function(e,t,n){if(e==null)throw Error("The argument must be a React element, but you passed "+e+".");var o=g1({},e.props),l=e.key;if(t!=null)for(a in t.key!==void 0&&(l=""+t.key),t)!x1.call(t,a)||a==="key"||a==="__self"||a==="__source"||a==="ref"&&t.ref===void 0||(o[a]=t[a]);var a=arguments.length-2;if(a===1)o.children=n;else if(1<a){for(var c=Array(a),f=0;f<a;f++)c[f]=arguments[f+2];o.children=c}return h0(e.type,l,o)};Ze.createContext=function(e){return e={$$typeof:y3,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:p3,_context:e},e};Ze.createElement=function(e,t,n){var o,l={},a=null;if(t!=null)for(o in t.key!==void 0&&(a=""+t.key),t)x1.call(t,o)&&o!=="key"&&o!=="__self"&&o!=="__source"&&(l[o]=t[o]);var c=arguments.length-2;if(c===1)l.children=n;else if(1<c){for(var f=Array(c),v=0;v<c;v++)f[v]=arguments[v+2];l.children=f}if(e&&e.defaultProps)for(o in c=e.defaultProps,c)l[o]===void 0&&(l[o]=c[o]);return h0(e,a,l)};Ze.createRef=function(){return{current:null}};Ze.forwardRef=function(e){return{$$typeof:x3,render:e}};Ze.isValidElement=g0;Ze.lazy=function(e){return{$$typeof:m1,_payload:{_status:-1,_result:e},_init:M3}};Ze.memo=function(e,t){return{$$typeof:v3,type:e,compare:t===void 0?null:t}};Ze.startTransition=b1;Ze.unstable_useCacheRefresh=function(){return en.H.useCacheRefresh()};Ze.use=function(e){return en.H.use(e)};Ze.useActionState=function(e,t,n){return en.H.useActionState(e,t,n)};Ze.useCallback=function(e,t){return en.H.useCallback(e,t)};Ze.useContext=function(e){return en.H.useContext(e)};Ze.useDebugValue=function(){};Ze.useDeferredValue=function(e,t){return en.H.useDeferredValue(e,t)};Ze.useEffect=function(e,t){return en.H.useEffect(e,t)};Ze.useEffectEvent=function(e){return en.H.useEffectEvent(e)};Ze.useId=function(){return en.H.useId()};Ze.useImperativeHandle=function(e,t,n){return en.H.useImperativeHandle(e,t,n)};Ze.useInsertionEffect=function(e,t){return en.H.useInsertionEffect(e,t)};Ze.useLayoutEffect=function(e,t){return en.H.useLayoutEffect(e,t)};Ze.useMemo=function(e,t){return en.H.useMemo(e,t)};Ze.useOptimistic=function(e,t){return en.H.useOptimistic(e,t)};Ze.useReducer=function(e,t,n){return en.H.useReducer(e,t,n)};Ze.useRef=function(e){return en.H.useRef(e)};Ze.useState=function(e){return en.H.useState(e)};Ze.useSyncExternalStore=function(e,t,n){return en.H.useSyncExternalStore(e,t,n)};Ze.useTransition=function(){return en.H.useTransition()};Ze.version="19.3.0"});var tn=al((o9,S1)=>{"use strict";S1.exports=w1()});var D1=al(_n=>{"use strict";function b0(e,t){var n=e.length;e.push(t);e:for(;0<n;){var o=n-1>>>1,l=e[o];if(0<Tu(l,t))e[o]=t,e[n]=l,n=o;else break e}}function wl(e){return e.length===0?null:e[0]}function Ru(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;e:for(var o=0,l=e.length,a=l>>>1;o<a;){var c=2*(o+1)-1,f=e[c],v=c+1,N=e[v];if(0>Tu(f,n))v<l&&0>Tu(N,f)?(e[o]=N,e[v]=n,o=v):(e[o]=f,e[c]=n,o=c);else if(v<l&&0>Tu(N,n))e[o]=N,e[v]=n,o=v;else break e}}return t}function Tu(e,t){var n=e.sortIndex-t.sortIndex;return n!==0?n:e.id-t.id}_n.unstable_now=void 0;typeof performance=="object"&&typeof performance.now=="function"?(k1=performance,_n.unstable_now=function(){return k1.now()}):(p0=Date,C1=p0.now(),_n.unstable_now=function(){return p0.now()-C1});var k1,p0,C1,Kl=[],va=[],N3=1,Xo=null,oo=3,v0=!1,Dr=!1,Or=!1,w0=!1,M1=typeof setTimeout=="function"?setTimeout:null,T1=typeof clearTimeout=="function"?clearTimeout:null,j1=typeof setImmediate<"u"?setImmediate:null;function Nu(e){for(var t=wl(va);t!==null;){if(t.callback===null)Ru(va);else if(t.startTime<=e)Ru(va),t.sortIndex=t.expirationTime,b0(Kl,t);else break;t=wl(va)}}function S0(e){if(Or=!1,Nu(e),!Dr)if(wl(Kl)!==null)Dr=!0,di||(di=!0,ui());else{var t=wl(va);t!==null&&k0(S0,t.startTime-e)}}var di=!1,zr=-1,N1=5,R1=-1;function A1(){return w0?!0:!(_n.unstable_now()-R1<N1)}function y0(){if(w0=!1,di){var e=_n.unstable_now();R1=e;var t=!0;try{e:{Dr=!1,Or&&(Or=!1,T1(zr),zr=-1),v0=!0;var n=oo;try{t:{for(Nu(e),Xo=wl(Kl);Xo!==null&&!(Xo.expirationTime>e&&A1());){var o=Xo.callback;if(typeof o=="function"){Xo.callback=null,oo=Xo.priorityLevel;var l=o(Xo.expirationTime<=e);if(e=_n.unstable_now(),typeof l=="function"){Xo.callback=l,Nu(e),t=!0;break t}Xo===wl(Kl)&&Ru(Kl),Nu(e)}else Ru(Kl);Xo=wl(Kl)}if(Xo!==null)t=!0;else{var a=wl(va);a!==null&&k0(S0,a.startTime-e),t=!1}}break e}finally{Xo=null,oo=n,v0=!1}t=void 0}}finally{t?ui():di=!1}}}var ui;typeof j1=="function"?ui=function(){j1(y0)}:typeof MessageChannel<"u"?(x0=new MessageChannel,E1=x0.port2,x0.port1.onmessage=y0,ui=function(){E1.postMessage(null)}):ui=function(){M1(y0,0)};var x0,E1;function k0(e,t){zr=M1(function(){e(_n.unstable_now())},t)}_n.unstable_IdlePriority=5;_n.unstable_ImmediatePriority=1;_n.unstable_LowPriority=4;_n.unstable_NormalPriority=3;_n.unstable_Profiling=null;_n.unstable_UserBlockingPriority=2;_n.unstable_cancelCallback=function(e){e.callback=null};_n.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):N1=0<e?Math.floor(1e3/e):5};_n.unstable_getCurrentPriorityLevel=function(){return oo};_n.unstable_next=function(e){switch(oo){case 1:case 2:case 3:var t=3;break;default:t=oo}var n=oo;oo=t;try{return e()}finally{oo=n}};_n.unstable_requestPaint=function(){w0=!0};_n.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=oo;oo=e;try{return t()}finally{oo=n}};_n.unstable_scheduleCallback=function(e,t,n){var o=_n.unstable_now();switch(typeof n=="object"&&n!==null?(n=n.delay,n=typeof n=="number"&&0<n?o+n:o):n=o,e){case 1:var l=-1;break;case 2:l=250;break;case 5:l=1073741823;break;case 4:l=1e4;break;default:l=5e3}return l=n+l,e={id:N3++,callback:t,priorityLevel:e,startTime:n,expirationTime:l,sortIndex:-1},n>o?(e.sortIndex=n,b0(va,e),wl(Kl)===null&&e===wl(va)&&(Or?(T1(zr),zr=-1):Or=!0,k0(S0,n-o))):(e.sortIndex=l,b0(Kl,e),Dr||v0||(Dr=!0,di||(di=!0,ui()))),e};_n.unstable_shouldYield=A1;_n.unstable_wrapCallback=function(e){var t=oo;return function(){var n=oo;oo=t;try{return e.apply(this,arguments)}finally{oo=n}}}});var z1=al((a9,O1)=>{"use strict";O1.exports=D1()});var H1=al(lo=>{"use strict";var R3=tn();function B1(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function wa(){}var co={d:{f:wa,r:function(){throw Error(B1(522))},D:wa,C:wa,L:wa,m:wa,X:wa,S:wa,M:wa},p:0,findDOMNode:null},A3=Symbol.for("react.portal"),D3=Symbol.for("react.recoverable"),L1=Symbol.for("react.optimistic_key");function O3(e,t,n){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:A3,key:o==null?null:o===L1?L1:""+o,children:e,containerInfo:t,implementation:n}}var Lr=R3.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function Au(e,t){if(e==="font")return"";if(typeof t=="string")return t==="use-credentials"?t:""}lo.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=co;lo.browser=function(e){return{$$typeof:D3,_reason:e}};lo.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(B1(299));return O3(e,t,null,n)};lo.flushSync=function(e){var t=Lr.T,n=co.p;try{if(Lr.T=null,co.p=2,e)return e()}finally{Lr.T=t,co.p=n,co.d.f()}};lo.preconnect=function(e,t){typeof e=="string"&&(t?(t=t.crossOrigin,t=typeof t=="string"?t==="use-credentials"?t:"":void 0):t=null,co.d.C(e,t))};lo.prefetchDNS=function(e){typeof e=="string"&&co.d.D(e)};lo.preinit=function(e,t){if(typeof e=="string"&&t&&typeof t.as=="string"){var n=t.as,o=Au(n,t.crossOrigin),l=typeof t.integrity=="string"?t.integrity:void 0,a=typeof t.fetchPriority=="string"?t.fetchPriority:void 0;n==="style"?co.d.S(e,typeof t.precedence=="string"?t.precedence:void 0,{crossOrigin:o,integrity:l,fetchPriority:a}):n==="script"&&co.d.X(e,{crossOrigin:o,integrity:l,fetchPriority:a,nonce:typeof t.nonce=="string"?t.nonce:void 0})}};lo.preinitModule=function(e,t){if(typeof e=="string")if(typeof t=="object"&&t!==null){if(t.as==null||t.as==="script"){var n=Au(t.as,t.crossOrigin);co.d.M(e,{crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}}else t==null&&co.d.M(e)};lo.preload=function(e,t){if(typeof e=="string"&&typeof t=="object"&&t!==null&&typeof t.as=="string"){var n=t.as,o=Au(n,t.crossOrigin);co.d.L(e,n,{crossOrigin:o,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,type:typeof t.type=="string"?t.type:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy=="string"?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet=="string"?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes=="string"?t.imageSizes:void 0,media:typeof t.media=="string"?t.media:void 0})}};lo.preloadModule=function(e,t){if(typeof e=="string")if(t){var n=Au(t.as,t.crossOrigin);co.d.m(e,{as:typeof t.as=="string"&&t.as!=="script"?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity=="string"?t.integrity:void 0,nonce:typeof t.nonce=="string"?t.nonce:void 0,fetchPriority:typeof t.fetchPriority=="string"?t.fetchPriority:void 0})}else co.d.m(e)};lo.requestFormReset=function(e){co.d.r(e)};lo.unstable_batchedUpdates=function(e,t){return e(t)};lo.useFormState=function(e,t,n){return Lr.H.useFormState(e,t,n)};lo.useFormStatus=function(){return Lr.H.useHostTransitionStatus()};lo.version="19.3.0"});var Br=al((i9,$1)=>{"use strict";function U1(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(U1)}catch(e){console.error(e)}}U1(),$1.exports=H1()});var j2=al(f_=>{"use strict";var Dn=z1(),Cy=tn(),z3=Br();function J(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function jy(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function kc(e){for(var t=e,n=t;n&&!n.alternate;)t=n,(t.flags&4098)!==0&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function Ey(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function My(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function I1(e){if(kc(e)!==e)throw Error(J(188))}function L3(e){var t=e.alternate;if(!t){if(t=kc(e),t===null)throw Error(J(188));return t!==e?null:e}for(var n=e,o=t;;){var l=n.return;if(l===null)break;var a=l.alternate;if(a===null){if(o=l.return,o!==null){n=o;continue}break}if(l.child===a.child){for(a=l.child;a;){if(a===n)return I1(l),e;if(a===o)return I1(l),t;a=a.sibling}throw Error(J(188))}if(n.return!==o.return)n=l,o=a;else{for(var c=!1,f=l.child;f;){if(f===n){c=!0,n=l,o=a;break}if(f===o){c=!0,o=l,n=a;break}f=f.sibling}if(!c){for(f=a.child;f;){if(f===n){c=!0,n=a,o=l;break}if(f===o){c=!0,o=a,n=l;break}f=f.sibling}if(!c)throw Error(J(189))}}if(n.alternate!==o)throw Error(J(190))}if(n.tag!==3)throw Error(J(188));return n.stateNode.current===n?e:t}function Ty(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=Ty(e),t!==null)return t;e=e.sibling}return null}function ko(e,t,n,o,l,a){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,o,l,a)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&ko(e.child,t,n,o,l,a))return!0;e=e.sibling}return!1}function Us(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function Y1(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),!(e.tag===3||e.tag===5||e.tag===27));)e=e.return;return t}function Ny(e){var t=[null,null],n=Us(e);return n===null||Ry(t,e,n.child,{foundSelf:!1}),t}function Ry(e,t,n,o){for(;n!==null;){if(n===t)o.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(o.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&Ry(e,t,n.child,o))return!0;n=n.sibling}return!1}function An(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(J(559))}}var yi=null,nf=null;function B3(e,t,n){return e===n?!0:e===t?(yi=e,!0):!1}function H3(e,t,n){return e===n?(nf=e,!1):e===t?(nf!==null&&(yi=e),!0):!1}function q1(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function of(e,t,n){for(var o=0,l=e;l;l=n(l))o++;l=0;for(var a=t;a;a=n(a))l++;for(;0<o-l;)e=n(e),o--;for(;0<l-o;)t=n(t),l--;for(;o--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var Jt=Object.assign,U3=Symbol.for("react.element"),Du=Symbol.for("react.transitional.element"),Xr=Symbol.for("react.portal"),xi=Symbol.for("react.fragment"),Ay=Symbol.for("react.strict_mode"),lf=Symbol.for("react.profiler"),Dy=Symbol.for("react.consumer"),Ml=Symbol.for("react.context"),mm=Symbol.for("react.forward_ref"),af=Symbol.for("react.suspense"),sf=Symbol.for("react.suspense_list"),hm=Symbol.for("react.memo"),ja=Symbol.for("react.lazy");Symbol.for("react.scope");var rf=Symbol.for("react.activity"),$3=Symbol.for("react.legacy_hidden");Symbol.for("react.tracing_marker");var I3=Symbol.for("react.memo_cache_sentinel"),cf=Symbol.for("react.view_transition"),Y3=Symbol.for("react.recoverable"),X1=Symbol.iterator;function Hr(e){return e===null||typeof e!="object"?null:(e=X1&&e[X1]||e["@@iterator"],typeof e=="function"?e:null)}var q3=Symbol.for("react.client.reference");function uf(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===q3?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case xi:return"Fragment";case lf:return"Profiler";case Ay:return"StrictMode";case af:return"Suspense";case sf:return"SuspenseList";case rf:return"Activity";case cf:return"ViewTransition"}if(typeof e=="object")switch(e.$$typeof){case Xr:return"Portal";case Ml:return e.displayName||"Context";case Dy:return(e._context.displayName||"Context")+".Consumer";case mm:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case hm:return t=e.displayName||null,t!==null?t:uf(e.type)||"Memo";case ja:t=e._payload,e=e._init;try{return uf(e(t))}catch{}}return null}var Qr=Array.isArray,qe=Cy.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Bt=z3.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,js={pending:!1,data:null,method:null,action:null},df=[],bi=-1;function zl(e){return{current:e}}function Fn(e){0>bi||(e.current=df[bi],df[bi]=null,bi--)}function ln(e,t){bi++,df[bi]=e.current,e.current=t}var Al=zl(null),rc=zl(null),za=zl(null),xd=zl(null);function bd(e,t){switch(ln(za,t),ln(rc,e),ln(Al,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?ly(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=ly(t),e=t2(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}Fn(Al),ln(Al,e)}function $i(){Fn(Al),Fn(rc),Fn(za)}function _f(e){var t=e.memoizedState;t!==null&&(Zi._currentValue=t.memoizedState,ln(xd,e)),t=Al.current;var n=t2(t,e.type);t!==n&&(ln(rc,e),ln(Al,n))}function vd(e){rc.current===e&&(Fn(Al),Fn(rc)),xd.current===e&&(Fn(xd),Zi._currentValue=js)}var C0,Q1;function ka(e){if(C0===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);C0=t&&t[1]||"",Q1=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+C0+e+Q1}var j0=!1;function E0(e,t){if(!e||j0)return"";j0=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(t){var V=function(){throw Error()};if(Object.defineProperty(V.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(V,[])}catch(ce){var A=ce}Reflect.construct(e,[],V)}else{try{V.call()}catch(ce){A=ce}V=!1;try{var U=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),V=!0,new e}finally{V&&(U!==void 0?Object.defineProperty(e.prototype,"props",U):delete e.prototype.props)}}}else{try{throw Error()}catch(ce){A=ce}(V=e())&&typeof V.catch=="function"&&V.catch(function(){})}}catch(ce){if(ce&&A&&typeof ce.stack=="string")return[ce.stack,A.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var l=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");l&&l.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var a=o.DetermineComponentFrameRoot(),c=a[0],f=a[1];if(c&&f){var v=c.split(`
`),N=f.split(`
`);for(l=o=0;o<v.length&&!v[o].includes("DetermineComponentFrameRoot");)o++;for(;l<N.length&&!N[l].includes("DetermineComponentFrameRoot");)l++;if(o===v.length||l===N.length)for(o=v.length-1,l=N.length-1;1<=o&&0<=l&&v[o]!==N[l];)l--;for(;1<=o&&0<=l;o--,l--)if(v[o]!==N[l]){if(o!==1||l!==1)do if(o--,l--,0>l||v[o]!==N[l]){var $=`
`+v[o].replace(" at new "," at ");return e.displayName&&$.includes("<anonymous>")&&($=$.replace("<anonymous>",e.displayName)),$}while(1<=o&&0<=l);break}}}finally{j0=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?ka(n):""}function X3(e,t){switch(e.tag){case 26:case 27:case 5:return ka(e.type);case 16:return ka("Lazy");case 13:return e.child!==t&&t!==null?ka("Suspense Fallback"):ka("Suspense");case 19:return ka("SuspenseList");case 0:case 15:return E0(e.type,!1);case 11:return E0(e.type.render,!1);case 1:return E0(e.type,!0);case 31:return ka("Activity");case 30:return ka("ViewTransition");default:return""}}function G1(e){try{var t="",n=null;do t+=X3(e,n),n=e,e=e.return;while(e);return t}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var ff=Object.prototype.hasOwnProperty,gm=Dn.unstable_scheduleCallback,M0=Dn.unstable_cancelCallback,Q3=Dn.unstable_shouldYield,G3=Dn.unstable_requestPaint,Ao=Dn.unstable_now,V3=Dn.unstable_getCurrentPriorityLevel,Oy=Dn.unstable_ImmediatePriority,zy=Dn.unstable_UserBlockingPriority,wd=Dn.unstable_NormalPriority,W3=Dn.unstable_LowPriority,Ly=Dn.unstable_IdlePriority,F3=Dn.log,Z3=Dn.unstable_setDisableYieldValue,Cc=null,Do=null;function Ta(e){if(typeof F3=="function"&&Z3(e),Do&&typeof Do.setStrictMode=="function")try{Do.setStrictMode(Cc,e)}catch{}}var Oo=Math.clz32?Math.clz32:P3,K3=Math.log,J3=Math.LN2;function P3(e){return e>>>=0,e===0?32:31-(K3(e)/J3|0)|0}var Ou=256,zu=262144,Lu=4194304;function vs(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Wd(e,t,n){var o=e.pendingLanes;if(o===0)return 0;var l=0,a=e.suspendedLanes,c=e.pingedLanes;e=e.warmLanes;var f=o&134217727;return f!==0?(o=f&~a,o!==0?l=vs(o):(c&=f,c!==0?l=vs(c):n||(n=f&~e,n!==0&&(l=vs(n))))):(f=o&~a,f!==0?l=vs(f):c!==0?l=vs(c):n||(n=o&~e,n!==0&&(l=vs(n)))),l===0?0:t!==0&&t!==l&&(t&a)===0&&(a=l&-l,n=t&-t,a>=n||a===32&&(n&4194048)!==0)?t:l}function jc(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function By(e,t){(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var o=31-Oo(n),l=1<<o;t|=e[o],n&=~l}return t}function e6(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Hy(){var e=Lu;return Lu<<=1,(Lu&62914560)===0&&(Lu=4194304),e}function T0(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Ec(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function t6(e,t,n,o,l,a){var c=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var f=e.entanglements,v=e.expirationTimes,N=e.hiddenUpdates;for(n=c&~n;0<n;){var $=31-Oo(n),V=1<<$;f[$]=0,v[$]=-1;var A=N[$];if(A!==null)for(N[$]=null,$=0;$<A.length;$++){var U=A[$];U!==null&&(U.lane&=-536870913)}n&=~V}o!==0&&Uy(e,o,0),a!==0&&l===0&&e.tag!==0&&(e.suspendedLanes|=a&~(c&~t))}function Uy(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var o=31-Oo(t);e.entangledLanes|=t,e.entanglements[o]=e.entanglements[o]|1073741824|n&261930}function $y(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var o=31-Oo(n),l=1<<o;l&t|e[o]&t&&(e[o]|=t),n&=~l}}function Iy(e,t){var n=t&-t;return n=(n&42)!==0?1:pm(n),(n&(e.suspendedLanes|t))!==0?0:n}function pm(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function ym(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Yy(){var e=Bt.p;return e!==0?e:(e=window.event,e===void 0?32:S2(e.type))}function V1(e,t){var n=Bt.p;try{return Bt.p=e,t()}finally{Bt.p=n}}var ua=Math.random().toString(36).slice(2),Vn="__reactFiber$"+ua,Co="__reactProps$"+ua,Pi="__reactContainer$"+ua,W1="__reactEvents$"+ua,n6="__reactListeners$"+ua,o6="__reactHandles$"+ua,F1="__reactResources$"+ua,Mc="__reactMarker$"+ua,Sd="__reactLoad$"+ua;function Fd(e){delete e[Vn],delete e[Co],delete e[n6],delete e[o6]}function ks(e){var t;if(t=e[Vn])return t;for(var n=e.parentNode;n;){if(t=n[Pi]||n[Vn]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=_y(e);e!==null;){if(n=e[Vn])return n;e=_y(e)}return t}e=n,n=e.parentNode}return null}function er(e){if(e=e[Vn]||e[Pi]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function Gr(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(J(33))}function Ni(e){var t=e[F1];return t||(t=e[F1]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Hn(e){e[Mc]=!0}function qy(e){e[Sd]=void 0}var Xy=new Set,Qy={};function $s(e,t){Ii(e,t),Ii(e+"Capture",t)}function Ii(e,t){for(Qy[e]=t,e=0;e<t.length;e++)Xy.add(t[e])}var l6=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Z1={},K1={};function a6(e){return ff.call(K1,e)?!0:ff.call(Z1,e)?!1:l6.test(e)?K1[e]=!0:(Z1[e]=!0,!1)}var Nt=!1;function J1(){var e=Nt;return Nt=!1,e}function ed(e,t,n){if(a6(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var o=t.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,n)}}function Bu(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,n)}}function Jl(e,t,n,o){if(o===null)e.removeAttribute(n);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,o)}}function Mo(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Gy(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function s6(e,t,n){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var l=o.get,a=o.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return l.call(this)},set:function(c){n=""+c,a.call(this,c)}}),Object.defineProperty(e,t,{enumerable:o.enumerable}),{getValue:function(){return n},setValue:function(c){n=""+c},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function mf(e){if(!e._valueTracker){var t=Gy(e)?"checked":"value";e._valueTracker=s6(e,t,""+e[t])}}function Vy(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),o="";return e&&(o=Gy(e)?e.checked?"true":"false":e.value),e=o,e!==n?(t.setValue(e),!0):!1}var i6=/[\n"\\]/g;function Fo(e){return e.replace(i6,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function hf(e,t,n,o,l,a,c,f){e.name="",c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"?e.type=c:e.removeAttribute("type"),t!=null?c==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+Mo(t)):e.value!==""+Mo(t)&&(e.value=""+Mo(t)):c!=="submit"&&c!=="reset"||e.removeAttribute("value"),t!=null?c==="number"&&e.value==t?N0(e,Mo(e.value)):N0(e,Mo(t)):n!=null?N0(e,Mo(n)):o!=null&&e.removeAttribute("value"),l==null&&a!=null&&(e.defaultChecked=!!a),l!=null&&(e.checked=l&&typeof l!="function"&&typeof l!="symbol"),f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"?e.name=""+Mo(f):e.removeAttribute("name")}function Wy(e,t,n,o,l,a,c,f){if(a!=null&&typeof a!="function"&&typeof a!="symbol"&&typeof a!="boolean"&&(e.type=a),t!=null||n!=null){if(!(a!=="submit"&&a!=="reset"||t!=null)){mf(e);return}n=n!=null?""+Mo(n):"",t=t!=null?""+Mo(t):n,f||t===e.value||(e.value=t),e.defaultValue=t}o=o??l,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=f?e.checked:!!o,e.defaultChecked=!!o,c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"&&(e.name=c),mf(e)}function N0(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function Ri(e,t,n,o){if(e=e.options,t){t={};for(var l=0;l<n.length;l++)t["$"+n[l]]=!0;for(n=0;n<e.length;n++)l=t.hasOwnProperty("$"+e[n].value),e[n].selected!==l&&(e[n].selected=l),l&&o&&(e[n].defaultSelected=!0)}else{for(n=""+Mo(n),t=null,l=0;l<e.length;l++){if(e[l].value===n){e[l].selected=!0,o&&(e[l].defaultSelected=!0);return}t!==null||e[l].disabled||(t=e[l])}t!==null&&(t.selected=!0)}}function Fy(e,t,n){if(t!=null&&(t=""+Mo(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+Mo(n):""}function Zy(e,t,n,o){if(t==null){if(o!=null){if(n!=null)throw Error(J(92));if(Qr(o)){if(1<o.length)throw Error(J(93));o=o[0]}n=o}n==null&&(n=""),t=n}n=Mo(t),e.defaultValue=n,o=e.textContent,o===n&&o!==""&&o!==null&&(e.value=o),mf(e)}function Yi(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var r6=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function P1(e,t,n){var o=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?o?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":o?e.setProperty(t,n):typeof n!="number"||n===0||r6.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function Ky(e,t,n){if(t!=null&&typeof t!="object")throw Error(J(62));if(e=e.style,n!=null){for(var o in n)!n.hasOwnProperty(o)||t!=null&&t.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="",Nt=!0);for(var l in t)o=t[l],t.hasOwnProperty(l)&&n[l]!==o&&(P1(e,l,o),Nt=!0)}else for(var a in t)t.hasOwnProperty(a)&&P1(e,a,t[a])}function xm(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var c6=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),u6=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function td(e){return u6.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Tl(){}var gf=null;function bm(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var vi=null,Ai=null;function ep(e){var t=er(e);if(t&&(e=t.stateNode)){var n=e[Co]||null;e:switch(e=t.stateNode,t.type){case"input":if(hf(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+Fo(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var o=n[t];if(o!==e&&o.form===e.form){var l=o[Co]||null;if(!l)throw Error(J(90));hf(o,l.value,l.defaultValue,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name)}}for(t=0;t<n.length;t++)o=n[t],o.form===e.form&&Vy(o)}break e;case"textarea":Fy(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&Ri(e,!!n.multiple,t,!1)}}}var R0=!1;function Jy(e,t,n){if(R0)return e(t,n);R0=!0;try{var o=e(t);return o}finally{if(R0=!1,(vi!==null||Ai!==null)&&(c_(),vi&&(t=vi,e=Ai,Ai=vi=null,ep(t),e)))for(t=0;t<e.length;t++)ep(e[t])}}function cc(e,t){var n=e.stateNode;if(n===null)return null;var o=n[Co]||null;if(o===null)return null;n=o[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(J(231,t,typeof n));return n}var la=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),pf=!1;if(la)try{_i={},Object.defineProperty(_i,"passive",{get:function(){pf=!0}}),window.addEventListener("test",_i,_i),window.removeEventListener("test",_i,_i)}catch{pf=!1}var _i,Na=null,vm=null,nd=null;function Py(){if(nd)return nd;var e,t=vm,n=t.length,o,l="value"in Na?Na.value:Na.textContent,a=l.length;for(e=0;e<n&&t[e]===l[e];e++);var c=n-e;for(o=1;o<=c&&t[n-o]===l[a-o];o++);return nd=l.slice(e,1<o?1-o:void 0)}function od(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Hu(){return!0}function tp(){return!1}function mo(e){function t(n,o,l,a,c){this._reactName=n,this._targetInst=l,this.type=o,this.nativeEvent=a,this.target=c,this.currentTarget=null;for(var f in e)e.hasOwnProperty(f)&&(n=e[f],this[f]=n?n(a):a[f]);return this.isDefaultPrevented=(a.defaultPrevented!=null?a.defaultPrevented:a.returnValue===!1)?Hu:tp,this.isPropagationStopped=tp,this}return Jt(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=Hu)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=Hu)},persist:function(){},isPersistent:Hu}),t}var Za={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Zd=mo(Za),Tc=Jt({},Za,{view:0,detail:0}),d6=mo(Tc),A0,D0,Ur,Kd=Jt({},Tc,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:wm,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Ur&&(Ur&&e.type==="mousemove"?(A0=e.screenX-Ur.screenX,D0=e.screenY-Ur.screenY):D0=A0=0,Ur=e),A0)},movementY:function(e){return"movementY"in e?e.movementY:D0}}),np=mo(Kd),_6=Jt({},Kd,{dataTransfer:0}),f6=mo(_6),m6=Jt({},Tc,{relatedTarget:0}),O0=mo(m6),h6=Jt({},Za,{animationName:0,elapsedTime:0,pseudoElement:0}),g6=mo(h6),p6=Jt({},Za,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),y6=mo(p6),x6=Jt({},Za,{data:0}),op=mo(x6),b6={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},v6={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},w6={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function S6(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=w6[e])?!!t[e]:!1}function wm(){return S6}var k6=Jt({},Tc,{key:function(e){if(e.key){var t=b6[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=od(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?v6[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:wm,charCode:function(e){return e.type==="keypress"?od(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?od(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),C6=mo(k6),j6=Jt({},Kd,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),lp=mo(j6),E6=Jt({},Za,{submitter:0}),M6=mo(E6),T6=Jt({},Tc,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:wm}),N6=mo(T6),R6=Jt({},Za,{propertyName:0,elapsedTime:0,pseudoElement:0}),A6=mo(R6),D6=Jt({},Kd,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),O6=mo(D6),z6=Jt({},Za,{newState:0,oldState:0,source:0}),L6=mo(z6),B6=[9,13,27,32],Sm=la&&"CompositionEvent"in window,Fr=null;la&&"documentMode"in document&&(Fr=document.documentMode);var H6=la&&"TextEvent"in window&&!Fr,e5=la&&(!Sm||Fr&&8<Fr&&11>=Fr),ap=" ",sp=!1;function t5(e,t){switch(e){case"keyup":return B6.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function n5(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var wi=!1;function U6(e,t){switch(e){case"compositionend":return n5(t);case"keypress":return t.which!==32?null:(sp=!0,ap);case"textInput":return e=t.data,e===ap&&sp?null:e;default:return null}}function $6(e,t){if(wi)return e==="compositionend"||!Sm&&t5(e,t)?(e=Py(),nd=vm=Na=null,wi=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return e5&&t.locale!=="ko"?null:t.data;default:return null}}var I6={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function ip(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!I6[e.type]:t==="textarea"}function o5(e,t,n,o){vi?Ai?Ai.push(o):Ai=[o]:vi=o,t=Qd(t,"onChange"),0<t.length&&(n=new Zd("onChange","change",null,n,o),e.push({event:n,listeners:t}))}var Zr=null,uc=null;function Y6(e){Jx(e,0)}function Jd(e){var t=Gr(e);if(Vy(t))return e}function rp(e,t){if(e==="change")return t}var l5=!1;la&&(la?($u="oninput"in document,$u||(z0=document.createElement("div"),z0.setAttribute("oninput","return;"),$u=typeof z0.oninput=="function"),Uu=$u):Uu=!1,l5=Uu&&(!document.documentMode||9<document.documentMode));var Uu,$u,z0;function cp(){Zr&&(Zr.detachEvent("onpropertychange",a5),uc=Zr=null)}function a5(e){if(e.propertyName==="value"&&Jd(uc)){var t=[];o5(t,uc,e,bm(e)),Jy(Y6,t)}}function q6(e,t,n){e==="focusin"?(cp(),Zr=t,uc=n,Zr.attachEvent("onpropertychange",a5)):e==="focusout"&&cp()}function X6(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Jd(uc)}function Q6(e,t){if(e==="click")return Jd(t)}function G6(e,t){if(e==="input"||e==="change")return Jd(t)}function V6(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Lo=typeof Object.is=="function"?Object.is:V6;function dc(e,t){if(Lo(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),o=Object.keys(t);if(n.length!==o.length)return!1;for(o=0;o<n.length;o++){var l=n[o];if(!ff.call(t,l)||!Lo(e[l],t[l]))return!1}return!0}function yf(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function up(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function dp(e,t){var n=up(e);e=0;for(var o;n;){if(n.nodeType===3){if(o=e+n.textContent.length,e<=t&&o>=t)return{node:n,offset:t-e};e=o}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=up(n)}}function s5(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?s5(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function i5(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=yf(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=yf(e.document)}return t}function km(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var W6=la&&"documentMode"in document&&11>=document.documentMode,Si=null,xf=null,Kr=null,bf=!1;function _p(e,t,n){var o=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;bf||Si==null||Si!==yf(o)||(o=Si,"selectionStart"in o&&km(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),Kr&&dc(Kr,o)||(Kr=o,o=Qd(xf,"onSelect"),0<o.length&&(t=new Zd("onSelect","select",null,t,n),e.push({event:t,listeners:o}),t.target=Si)))}function xs(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var ki={animationend:xs("Animation","AnimationEnd"),animationiteration:xs("Animation","AnimationIteration"),animationstart:xs("Animation","AnimationStart"),transitionrun:xs("Transition","TransitionRun"),transitionstart:xs("Transition","TransitionStart"),transitioncancel:xs("Transition","TransitionCancel"),transitionend:xs("Transition","TransitionEnd")},L0={},r5={};la&&(r5=document.createElement("div").style,"AnimationEvent"in window||(delete ki.animationend.animation,delete ki.animationiteration.animation,delete ki.animationstart.animation),"TransitionEvent"in window||delete ki.transitionend.transition);function Is(e){if(L0[e])return L0[e];if(!ki[e])return e;var t=ki[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in r5)return L0[e]=t[n];return e}var c5=Is("animationend"),u5=Is("animationiteration"),d5=Is("animationstart"),F6=Is("transitionrun"),Z6=Is("transitionstart"),K6=Is("transitioncancel"),_5=Is("transitionend"),f5=new Map,vf="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");vf.push("scrollEnd");function dl(e,t){f5.set(e,t),$s(t,[e])}var J6=0;function aa(e,t){if(e.name!=null&&e.name!=="auto")return e.name;if(t.autoName!==null)return t.autoName;e=ul.identifierPrefix;var n=J6++;return e="_"+e+"t_"+n.toString(32)+"_",t.autoName=e}function fp(e){if(e==null||typeof e=="string")return e;var t=null,n=Ui;if(n!==null)for(var o=0;o<n.length;o++){var l=e[n[o]];if(l!=null){if(l==="none")return"none";t=t==null?l:t+(" "+l)}}return t??e.default}function da(e,t){return e=fp(e),t=fp(t),t==null?e==="auto"?null:e:t==="auto"?null:t}var kd=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Go=[],Ci=0,Cm=0;function Pd(){for(var e=Ci,t=Cm=Ci=0;t<e;){var n=Go[t];Go[t++]=null;var o=Go[t];Go[t++]=null;var l=Go[t];Go[t++]=null;var a=Go[t];if(Go[t++]=null,o!==null&&l!==null){var c=o.pending;c===null?l.next=l:(l.next=c.next,c.next=l),o.pending=l}a!==0&&m5(n,l,a)}}function e_(e,t,n,o){Go[Ci++]=e,Go[Ci++]=t,Go[Ci++]=n,Go[Ci++]=o,Cm|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function jm(e,t,n,o){return e_(e,t,n,o),Cd(e)}function Ys(e,t){return e_(e,null,null,t),Cd(e)}function m5(e,t,n){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n);for(var l=!1,a=e.return;a!==null;)a.childLanes|=n,o=a.alternate,o!==null&&(o.childLanes|=n),a.tag===22&&(e=a.stateNode,e===null||e._visibility&1||(l=!0)),e=a,a=a.return;return e.tag===3?(a=e.stateNode,l&&t!==null&&(l=31-Oo(n),e=a.hiddenUpdates,o=e[l],o===null?e[l]=[t]:o.push(t),t.lane=n|536870912),a):null}function Cd(e){if(50<ic)throw ic=0,fd=null,Error(J(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var ji={};function P6(e,t,n,o){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function wo(e,t,n,o){return new P6(e,t,n,o)}function Em(e){return e=e.prototype,!(!e||!e.isReactComponent)}function na(e,t){var n=e.alternate;return n===null?(n=wo(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function h5(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function ld(e,t,n,o,l,a){var c=0;if(o=e,typeof o=="function")Em(o)&&(c=1);else if(typeof o=="string")c=C7(e,n,Al.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(o){case rf:return e=wo(31,n,t,l),e.elementType=rf,e.lanes=a,e;case xi:return Es(n.children,l,a,t);case Ay:c=8,l|=24;break;case lf:return e=wo(12,n,t,l|2),e.elementType=lf,e.lanes=a,e;case af:return e=wo(13,n,t,l),e.elementType=af,e.lanes=a,e;case sf:return e=wo(19,n,t,l),e.elementType=sf,e.lanes=a,e;case $3:case cf:return e=l|32,e=wo(30,n,t,e),e.elementType=cf,e.lanes=a,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof o=="object"&&o!==null)switch(o.$$typeof){case Ml:c=10;break e;case Dy:c=9;break e;case mm:c=11;break e;case hm:c=14;break e;case ja:c=16,o=null;break e}c=29,n=Error(J(130,e===null?"null":typeof e,"")),o=null}return t=wo(c,n,t,l),t.elementType=e,t.type=o,t.lanes=a,t}function Es(e,t,n,o){return e=wo(7,e,o,t),e.lanes=n,e}function B0(e,t,n){return e=wo(6,e,null,t),e.lanes=n,e}function g5(e){var t=wo(18,null,null,0);return t.stateNode=e,t}function H0(e,t,n){return t=wo(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var mp=new WeakMap;function Zo(e,t){if(typeof e=="object"&&e!==null){var n=mp.get(e);return n!==void 0?n:(t={value:e,source:t,stack:G1(t)},mp.set(e,t),t)}return{value:e,source:t,stack:G1(t)}}var Ei=[],Mi=0,jd=null,_c=0,Vo=[],Wo=0,Qa=null,Nl=1,Rl="";function ea(e,t){Ei[Mi++]=_c,Ei[Mi++]=jd,jd=e,_c=t}function p5(e,t,n){Vo[Wo++]=Nl,Vo[Wo++]=Rl,Vo[Wo++]=Qa,Qa=e;var o=Nl;e=Rl;var l=32-Oo(o)-1;o&=~(1<<l),n+=1;var a=32-Oo(t)+l;if(30<a){var c=l-l%5;a=(o&(1<<c)-1).toString(32),o>>=c,l-=c,Nl=1<<32-Oo(t)+l|n<<l|o,Rl=a+e}else Nl=1<<a|n<<l|o,Rl=e}function t_(e){e.return!==null&&(ea(e,1),p5(e,1,0))}function Mm(e){for(;e===jd;)jd=Ei[--Mi],Ei[Mi]=null,_c=Ei[--Mi],Ei[Mi]=null;for(;e===Qa;)Qa=Vo[--Wo],Vo[Wo]=null,Rl=Vo[--Wo],Vo[Wo]=null,Nl=Vo[--Wo],Vo[Wo]=null}function y5(e,t){Vo[Wo++]=Nl,Vo[Wo++]=Rl,Vo[Wo++]=Qa,Nl=t.id,Rl=t.overflow,Qa=e}var Un=null,on=null,dt=!1,La=null,Ko=!1,wf=Error(J(519));function Ga(e){var t=Error(J(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw fc(Zo(t,e)),wf}function hp(e){var t=e.stateNode,n=e.type,o=e.memoizedProps;switch(t[Vn]=e,t[Co]=o,n){case"dialog":gt("cancel",t),gt("close",t);break;case"iframe":case"object":case"embed":gt("load",t);break;case"video":case"audio":for(n=0;n<pc.length;n++)gt(pc[n],t);break;case"source":gt("error",t);break;case"img":case"image":case"link":gt("error",t),gt("load",t);break;case"details":gt("toggle",t);break;case"input":gt("invalid",t),Wy(t,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":gt("invalid",t);break;case"textarea":gt("invalid",t),Zy(t,o.value,o.defaultValue,o.children)}n=o.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||o.suppressHydrationWarning===!0||e2(t.textContent,n)?(o.popover!=null&&(gt("beforetoggle",t),gt("toggle",t)),o.onScroll!=null&&gt("scroll",t),o.onScrollEnd!=null&&gt("scrollend",t),o.onClick!=null&&(t.onclick=Tl),t=!0):t=!1,t||Ga(e,!0)}function Ed(e){for(Un=e.return;Un;)switch(Un.tag){case 5:case 31:case 13:Ko=!1;return;case 27:case 3:Ko=!0;return;default:Un=Un.return}}function fi(e){if(e!==Un)return!1;if(!dt)return Ed(e),dt=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||sm(e.type,e.memoizedProps)),n=!n),n&&on&&Ga(e),Ed(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(J(317));on=dy(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(J(317));on=dy(e)}else t===27?(t=on,Ka(e.type)?(e=um,um=null,on=e):on=t):on=Un?Jo(e.stateNode.nextSibling):null;return!0}function Rs(){on=Un=null,dt=!1}function U0(){var e=La;return e!==null&&(bo===null?bo=e:bo.push.apply(bo,e),La=null),e}function fc(e){La===null?La=[e]:La.push(e)}var Sf=zl(null),qs=null,ta=null;function Ra(e,t,n){ln(Sf,t._currentValue),t._currentValue=n}function oa(e){e._currentValue=Sf.current,Fn(Sf)}function ad(e,t,n){for(;e!==null;){var o=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,o!==null&&(o.childLanes|=t)):o!==null&&(o.childLanes&t)!==t&&(o.childLanes|=t),e===n)break;e=e.return}}function kf(e,t,n,o){var l=e.child;for(l!==null&&(l.return=e);l!==null;){var a=l.dependencies;if(a!==null){var c=l.child;a=a.firstContext;e:for(;a!==null;){var f=a;a=l;for(var v=0;v<t.length;v++)if(f.context===t[v]){a.lanes|=n,f=a.alternate,f!==null&&(f.lanes|=n),ad(a.return,n,e),o||(c=null);break e}a=f.next}}else if(l.tag===18){if(c=l.return,c===null)throw Error(J(341));c.lanes|=n,a=c.alternate,a!==null&&(a.lanes|=n),ad(c,n,e),c=null}else l.tag===13&&l.memoizedState!==null&&l.memoizedState.dehydrated===null?(l.lanes|=n,c=l.alternate,c!==null&&(c.lanes|=n),ad(l.return,n,e),c=l.child,c=c!==null?c.sibling:null):c=l.child;if(c!==null)c.return=l;else for(c=l;c!==null;){if(c===e){c=null;break}if(l=c.sibling,l!==null){l.return=c.return,c=l;break}c=c.return}l=c}}function As(e,t,n,o){e=null;for(var l=t,a=!1;l!==null;){if(!a){if((l.flags&524288)!==0)a=!0;else if((l.flags&262144)!==0)break}if(l.tag===10){var c=l.alternate;if(c===null)throw Error(J(387));if(c=c.memoizedProps,c!==null){var f=l.type;Lo(l.pendingProps.value,c.value)||(e!==null?e.push(f):e=[f])}}else if(l===xd.current){if(c=l.alternate,c===null)throw Error(J(387));c.memoizedState.memoizedState!==l.memoizedState.memoizedState&&(e!==null?e.push(Zi):e=[Zi])}l=l.return}return e!==null&&kf(t,e,n,o),t.flags|=262144,e!==null}function Md(e){for(e=e.firstContext;e!==null;){if(!Lo(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Ds(e){qs=e,ta=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function Wn(e){return x5(qs,e)}function Iu(e,t){return qs===null&&Ds(e),x5(e,t)}function x5(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},ta===null){if(e===null)throw Error(J(308));ta=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else ta=ta.next=t;return n}var e8=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,o){e.push(o)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},t8=Dn.unstable_scheduleCallback,n8=Dn.unstable_NormalPriority,En={$$typeof:Ml,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Tm(){return{controller:new e8,data:new Map,refCount:0}}function Nc(e){e.refCount--,e.refCount===0&&t8(n8,function(){e.controller.abort()})}function gp(e,t){if((e.pendingLanes&4194048)!==0){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var o=t[e];n.indexOf(o)===-1&&n.push(o)}}}var Vr=null;function o8(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var Jr=null,Cf=0,Os=0,Di=null;function l8(e,t){if(Jr===null){var n=Jr=[];Cf=0,Os=oh(),Di={status:"pending",value:void 0,then:function(o){n.push(o)}}}return Cf++,t.then(pp,pp),t}function pp(){if(--Cf===0&&(Vr=null,Jr!==null)){Di!==null&&(Di.status="fulfilled");var e=Jr;Jr=null,Os=0,Di=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function a8(e,t){var n=[],o={status:"pending",value:null,reason:null,then:function(l){n.push(l)}};return e.then(function(){o.status="fulfilled",o.value=t;for(var l=0;l<n.length;l++)(0,n[l])(t)},function(l){for(o.status="rejected",o.reason=l,l=0;l<n.length;l++)(0,n[l])(void 0)}),o}var yp=qe.S;qe.S=function(e,t){if(Bx=Ao(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&l8(e,t),Vr!==null)for(var n=Vi;n!==null;)gp(n,Vr),n=n.next;if(n=e.types,n!==null){for(var o=Vi;o!==null;)gp(o,n),o=o.next;if(Os!==0){o=Vr,o===null&&(o=Vr=[]);for(var l=0;l<n.length;l++){var a=n[l];o.indexOf(a)===-1&&o.push(a)}}}yp!==null&&yp(e,t)};var Ms=zl(null);function Nm(){var e=Ms.current;return e!==null?e:Kt.pooledCache}function sd(e,t){t===null?ln(Ms,Ms.current):ln(Ms,t.pool)}function b5(){var e=Nm();return e===null?null:{parent:En._currentValue,pool:e}}var tr=Error(J(460)),Rm=Error(J(474)),n_=Error(J(542)),Td={then:function(){}};function xp(e){return e=e.status,e==="fulfilled"||e==="rejected"}function v5(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(Tl,Tl),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,vp(e),e===void 0&&!("reason"in t)?Error(J(600)):e;default:if(typeof t.status=="string")t.then(Tl,Tl);else{if(e=Kt,e!==null&&100<e.shellSuspendCounter)throw Error(J(482));e=t,e.status="pending",e.then(function(o){if(t.status==="pending"){var l=t;l.status="fulfilled",l.value=o}},function(o){if(t.status==="pending"){var l=t;l.status="rejected",l.reason=o}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,vp(e),e}throw Ts=t,tr}}function ws(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(Ts=n,tr):n}}var Ts=null;function bp(){if(Ts===null)throw Error(J(459));var e=Ts;return Ts=null,e}function vp(e){if(e===tr||e===n_)throw Error(J(483))}var Oi=null,mc=0;function Yu(e){var t=mc;return mc+=1,Oi===null&&(Oi=[]),v5(Oi,e,t)}function Sa(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function qu(e,t){throw t.$$typeof===U3?Error(J(525)):(e=Object.prototype.toString.call(t),Error(J(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function w5(e){function t(T,C){if(e){var z=T.deletions;z===null?(T.deletions=[C],T.flags|=16):z.push(C)}}function n(T,C){if(!e)return null;for(;C!==null;)t(T,C),C=C.sibling;return null}function o(T){for(var C=new Map;T!==null;)T.key===null?C.set(T.index,T):C.set(T.key,T),T=T.sibling;return C}function l(T,C){return T=na(T,C),T.index=0,T.sibling=null,T}function a(T,C,z){return T.index=z,e?(z=T.alternate,z!==null?(z=z.index,z<C?(T.flags|=2,C):z):(T.flags|=134217730,C)):(T.flags|=1048576,C)}function c(T){return e&&T.alternate===null&&(T.flags|=134217730),T}function f(T,C,z,L){return C===null||C.tag!==6?(C=B0(z,T.mode,L),C.return=T,C):(C=l(C,z),C.return=T,C)}function v(T,C,z,L){var de=z.type;return de===xi?(T=$(T,C,z.props.children,L,z.key),Sa(T,z),T):C!==null&&(C.elementType===de||typeof de=="object"&&de!==null&&de.$$typeof===ja&&ws(de)===C.type)?(C=l(C,z.props),Sa(C,z),C.return=T,C):(C=ld(z.type,z.key,z.props,null,T.mode,L),Sa(C,z),C.return=T,C)}function N(T,C,z,L){return C===null||C.tag!==4||C.stateNode.containerInfo!==z.containerInfo||C.stateNode.implementation!==z.implementation?(C=H0(z,T.mode,L),C.return=T,C):(C=l(C,z.children||[]),C.return=T,C)}function $(T,C,z,L,de){return C===null||C.tag!==7?(C=Es(z,T.mode,L,de),C.return=T,C):(C=l(C,z),C.return=T,C)}function V(T,C,z){if(typeof C=="string"&&C!==""||typeof C=="number"||typeof C=="bigint")return C=B0(""+C,T.mode,z),C.return=T,C;if(typeof C=="object"&&C!==null){switch(C.$$typeof){case Du:return z=ld(C.type,C.key,C.props,null,T.mode,z),Sa(z,C),z.return=T,z;case Xr:return C=H0(C,T.mode,z),C.return=T,C;case ja:return C=ws(C),V(T,C,z)}if(Qr(C)||Hr(C))return C=Es(C,T.mode,z,null),C.return=T,C;if(typeof C.then=="function")return V(T,Yu(C),z);if(C.$$typeof===Ml)return V(T,Iu(T,C),z);qu(T,C)}return null}function A(T,C,z,L){var de=C!==null?C.key:null;if(typeof z=="string"&&z!==""||typeof z=="number"||typeof z=="bigint")return de!==null?null:f(T,C,""+z,L);if(typeof z=="object"&&z!==null){switch(z.$$typeof){case Du:return z.key===de?v(T,C,z,L):null;case Xr:return z.key===de?N(T,C,z,L):null;case ja:return z=ws(z),A(T,C,z,L)}if(Qr(z)||Hr(z))return de!==null?null:$(T,C,z,L,null);if(typeof z.then=="function")return A(T,C,Yu(z),L);if(z.$$typeof===Ml)return A(T,C,Iu(T,z),L);qu(T,z)}return null}function U(T,C,z,L,de){if(typeof L=="string"&&L!==""||typeof L=="number"||typeof L=="bigint")return T=T.get(z)||null,f(C,T,""+L,de);if(typeof L=="object"&&L!==null){switch(L.$$typeof){case Du:return T=T.get(L.key===null?z:L.key)||null,v(C,T,L,de);case Xr:return T=T.get(L.key===null?z:L.key)||null,N(C,T,L,de);case ja:return L=ws(L),U(T,C,z,L,de)}if(Qr(L)||Hr(L))return T=T.get(z)||null,$(C,T,L,de,null);if(typeof L.then=="function")return U(T,C,z,Yu(L),de);if(L.$$typeof===Ml)return U(T,C,z,Iu(C,L),de);qu(C,L)}return null}function ce(T,C,z,L){for(var de=null,_e=null,be=C,Ce=C=0,an=null;be!==null&&Ce<z.length;Ce++){be.index>Ce?(an=be,be=null):an=be.sibling;var st=A(T,be,z[Ce],L);if(st===null){be===null&&(be=an);break}e&&be&&st.alternate===null&&t(T,be),C=a(st,C,Ce),_e===null?de=st:_e.sibling=st,_e=st,be=an}if(Ce===z.length)return n(T,be),dt&&ea(T,Ce),de;if(be===null){for(;Ce<z.length;Ce++)be=V(T,z[Ce],L),be!==null&&(C=a(be,C,Ce),_e===null?de=be:_e.sibling=be,_e=be);return dt&&ea(T,Ce),de}for(be=o(be);Ce<z.length;Ce++)an=U(be,T,Ce,z[Ce],L),an!==null&&(e&&(st=an.alternate,st!==null&&be.delete(st.key===null?Ce:st.key)),C=a(an,C,Ce),_e===null?de=an:_e.sibling=an,_e=an);return e&&be.forEach(function(ho){return t(T,ho)}),dt&&ea(T,Ce),de}function he(T,C,z,L){if(z==null)throw Error(J(151));for(var de=null,_e=null,be=C,Ce=C=0,an=null,st=z.next();be!==null&&!st.done;Ce++,st=z.next()){be.index>Ce?(an=be,be=null):an=be.sibling;var ho=A(T,be,st.value,L);if(ho===null){be===null&&(be=an);break}e&&be&&ho.alternate===null&&t(T,be),C=a(ho,C,Ce),_e===null?de=ho:_e.sibling=ho,_e=ho,be=an}if(st.done)return n(T,be),dt&&ea(T,Ce),de;if(be===null){for(;!st.done;Ce++,st=z.next())st=V(T,st.value,L),st!==null&&(C=a(st,C,Ce),_e===null?de=st:_e.sibling=st,_e=st);return dt&&ea(T,Ce),de}for(be=o(be);!st.done;Ce++,st=z.next())st=U(be,T,Ce,st.value,L),st!==null&&(e&&(an=st.alternate,an!==null&&be.delete(an.key===null?Ce:an.key)),C=a(st,C,Ce),_e===null?de=st:_e.sibling=st,_e=st);return e&&be.forEach(function(Ja){return t(T,Ja)}),dt&&ea(T,Ce),de}function Ne(T,C,z,L){if(typeof z=="object"&&z!==null&&z.type===xi&&z.key===null&&z.props.ref===void 0&&(z=z.props.children),typeof z=="object"&&z!==null){switch(z.$$typeof){case Du:e:{for(var de=z.key;C!==null;){if(C.key===de){if(de=z.type,de===xi){if(C.tag===7){n(T,C.sibling),L=l(C,z.props.children),Sa(L,z),L.return=T,T=L;break e}}else if(C.elementType===de||typeof de=="object"&&de!==null&&de.$$typeof===ja&&ws(de)===C.type){n(T,C.sibling),L=l(C,z.props),Sa(L,z),L.return=T,T=L;break e}n(T,C);break}else t(T,C);C=C.sibling}z.type===xi?(L=Es(z.props.children,T.mode,L,z.key),Sa(L,z),L.return=T,T=L):(L=ld(z.type,z.key,z.props,null,T.mode,L),Sa(L,z),L.return=T,T=L)}return c(T);case Xr:e:{for(de=z.key;C!==null;){if(C.key===de)if(C.tag===4&&C.stateNode.containerInfo===z.containerInfo&&C.stateNode.implementation===z.implementation){n(T,C.sibling),L=l(C,z.children||[]),L.return=T,T=L;break e}else{n(T,C);break}else t(T,C);C=C.sibling}L=H0(z,T.mode,L),L.return=T,T=L}return c(T);case ja:return z=ws(z),Ne(T,C,z,L)}if(Qr(z))return ce(T,C,z,L);if(Hr(z)){if(de=Hr(z),typeof de!="function")throw Error(J(150));return z=de.call(z),he(T,C,z,L)}if(typeof z.then=="function")return Ne(T,C,Yu(z),L);if(z.$$typeof===Ml)return Ne(T,C,Iu(T,z),L);qu(T,z)}return typeof z=="string"&&z!==""||typeof z=="number"||typeof z=="bigint"?(z=""+z,C!==null&&C.tag===6?(n(T,C.sibling),L=l(C,z),L.return=T,T=L):(n(T,C),L=B0(z,T.mode,L),L.return=T,T=L),c(T)):n(T,C)}return function(T,C,z,L){try{mc=0;var de=Ne(T,C,z,L);return Oi=null,de}catch(be){if(be===tr||be===n_)throw be;var _e=wo(29,be,null,T.mode);return _e.lanes=L,_e.return=T,_e}finally{}}}var zs=w5(!0),S5=w5(!1),Ea=!1;function Am(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function jf(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Ba(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ha(e,t,n){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(Lt&2)!==0){var l=o.pending;return l===null?t.next=t:(t.next=l.next,l.next=t),o.pending=t,t=Cd(e),m5(e,null,n),t}return e_(e,o,t,n),Cd(e)}function Pr(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,$y(e,n)}}function $0(e,t){var n=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,n===o)){var l=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var c={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};a===null?l=a=c:a=a.next=c,n=n.next}while(n!==null);a===null?l=a=t:a=a.next=t}else l=a=t;n={baseState:o.baseState,firstBaseUpdate:l,lastBaseUpdate:a,shared:o.shared,callbacks:o.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var Ef=!1;function ec(){if(Ef){var e=Di;if(e!==null)throw e}}function tc(e,t,n,o){Ef=!1;var l=e.updateQueue;Ea=!1;var a=l.firstBaseUpdate,c=l.lastBaseUpdate,f=l.shared.pending;if(f!==null){l.shared.pending=null;var v=f,N=v.next;v.next=null,c===null?a=N:c.next=N,c=v;var $=e.alternate;$!==null&&($=$.updateQueue,f=$.lastBaseUpdate,f!==c&&(f===null?$.firstBaseUpdate=N:f.next=N,$.lastBaseUpdate=v))}if(a!==null){var V=l.baseState;c=0,$=N=v=null,f=a;do{var A=f.lane&-536870913,U=A!==f.lane;if(U?(yt&A)===A:(o&A)===A){A!==0&&A===Os&&(Ef=!0),$!==null&&($=$.next={lane:0,tag:f.tag,payload:f.payload,callback:null,next:null});e:{var ce=e,he=f;A=t;var Ne=n;switch(he.tag){case 1:if(ce=he.payload,typeof ce=="function"){V=ce.call(Ne,V,A);break e}V=ce;break e;case 3:ce.flags=ce.flags&-65537|128;case 0:if(ce=he.payload,A=typeof ce=="function"?ce.call(Ne,V,A):ce,A==null)break e;V=Jt({},V,A);break e;case 2:Ea=!0}}A=f.callback,A!==null&&(e.flags|=64,U&&(e.flags|=8192),U=l.callbacks,U===null?l.callbacks=[A]:U.push(A))}else U={lane:A,tag:f.tag,payload:f.payload,callback:f.callback,next:null},$===null?(N=$=U,v=V):$=$.next=U,c|=A;if(f=f.next,f===null){if(f=l.shared.pending,f===null)break;U=f,f=U.next,U.next=null,l.lastBaseUpdate=U,l.shared.pending=null}}while(!0);$===null&&(v=V),l.baseState=v,l.firstBaseUpdate=N,l.lastBaseUpdate=$,a===null&&(l.shared.lanes=0),Fa|=c,e.lanes=c,e.memoizedState=V}}function k5(e,t){if(typeof e!="function")throw Error(J(191,e));e.call(t)}function C5(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)k5(n[e],t)}var Va=zl(null),Nd=zl(0);function wp(e,t){e=ca,ln(Nd,e),ln(Va,t),ca=e|t.baseLanes}function Mf(){ln(Nd,ca),ln(Va,Va.current)}function Dm(){ca=Nd.current,Fn(Va),Fn(Nd)}var Jn=zl(null),ao=null;function Ua(e){var t=e.alternate;ln(Zn,Zn.current&1),ln(Jn,e),ao===null&&(t===null||Va.current!==null||t.memoizedState!==null)&&(ao=e)}function Tf(e){ln(Zn,Zn.current),ln(Jn,e),ao===null&&(ao=e)}function j5(e){e.tag===22?(ln(Zn,Zn.current),ln(Jn,e),ao===null&&(ao=e)):$a()}function $a(){ln(Zn,Zn.current),ln(Jn,Jn.current)}function To(e){Fn(Jn),ao===e&&(ao=null),Fn(Zn)}var Zn=zl(0);function hc(e,t){ln(Jn,Jn.current),ln(Zn,t)}function Om(e){Fn(Zn),Fn(Jn),ao===e&&(ao=null)}function Rd(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||cm(n)||ih(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!=="independent"){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var sa=0,at=null,Ft=null,jn=null,Ad=!1,zi=!1,Ls=!1,Dd=0,gc=0,Li=null,s8=0;function yn(){throw Error(J(321))}function zm(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Lo(e[n],t[n]))return!1;return!0}function Lm(e,t,n,o,l,a){return sa=a,at=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,qe.H=e===null||e.memoizedState===null?ox:lx,Ls=!1,a=n(o,l),Ls=!1,zi&&(a=M5(t,n,o,l)),E5(e),a}function E5(e){qe.H=Od;var t=Ft!==null&&Ft.next!==null;if(sa=0,jn=Ft=at=null,Ad=!1,gc=0,Li=null,t)throw Error(J(300));e===null||Mn||(e=e.dependencies,e!==null&&Md(e)&&(Mn=!0))}function M5(e,t,n,o){at=e;var l=0;do{if(zi&&(Li=null),gc=0,zi=!1,25<=l)throw Error(J(301));if(l+=1,jn=Ft=null,e.updateQueue!=null){var a=e.updateQueue;a.lastEffect=null,a.events=null,a.stores=null,a.memoCache!=null&&(a.memoCache.index=0)}qe.H=m8,a=t(n,o)}while(zi);return a}function i8(){var e=qe.H,t=e.useState()[0];return t=typeof t.then=="function"?Rc(t):t,e=e.useState()[0],(Ft!==null?Ft.memoizedState:null)!==e&&(at.flags|=1024),t}function Bm(){var e=Dd!==0;return Dd=0,e}function Hm(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function Um(e){if(Ad){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Ad=!1}sa=0,jn=Ft=at=null,zi=!1,gc=Dd=0,Li=null}function fo(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return jn===null?at.memoizedState=jn=e:jn=jn.next=e,jn}function Sn(){if(Ft===null){var e=at.alternate;e=e!==null?e.memoizedState:null}else e=Ft.next;var t=jn===null?at.memoizedState:jn.next;if(t!==null)jn=t,Ft=e;else{if(e===null)throw at.alternate===null?Error(J(467)):Error(J(310));Ft=e,e={memoizedState:Ft.memoizedState,baseState:Ft.baseState,baseQueue:Ft.baseQueue,queue:Ft.queue,next:null},jn===null?at.memoizedState=jn=e:jn=jn.next=e}return jn}function o_(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Rc(e){var t=gc;return gc+=1,Li===null&&(Li=[]),e=v5(Li,e,t),t=at,(jn===null?t.memoizedState:jn.next)===null&&(t=t.alternate,qe.H=t===null||t.memoizedState===null?ox:lx),e}function l_(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Rc(e);if(e.$$typeof===Y3)return;if(e.$$typeof===Ml)return Wn(e)}throw Error(J(438,String(e)))}function $m(e){var t=null,n=at.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var o=at.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(t={data:o.data.map(function(l){return l.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=o_(),at.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),o=0;o<e;o++)n[o]=I3;return t.index++,n}function ia(e,t){return typeof t=="function"?t(e):t}function id(e){var t=Sn();return Im(t,Ft,e)}function Im(e,t,n){var o=e.queue;if(o===null)throw Error(J(311));o.lastRenderedReducer=n;var l=e.baseQueue,a=o.pending;if(a!==null){if(l!==null){var c=l.next;l.next=a.next,a.next=c}t.baseQueue=l=a,o.pending=null}if(a=e.baseState,l===null)e.memoizedState=a;else{t=l.next;var f=c=null,v=null,N=t,$=!1;do{var V=N.lane&-536870913;if(V!==N.lane?(yt&V)===V:(sa&V)===V){var A=N.revertLane;if(A===0)v!==null&&(v=v.next={lane:0,revertLane:0,gesture:null,action:N.action,hasEagerState:N.hasEagerState,eagerState:N.eagerState,next:null}),V===Os&&($=!0);else if((sa&A)===A){N=N.next,A===Os&&($=!0);continue}else V={lane:0,revertLane:N.revertLane,gesture:null,action:N.action,hasEagerState:N.hasEagerState,eagerState:N.eagerState,next:null},v===null?(f=v=V,c=a):v=v.next=V,at.lanes|=A,Fa|=A;V=N.action,Ls&&n(a,V),a=N.hasEagerState?N.eagerState:n(a,V)}else A={lane:V,revertLane:N.revertLane,gesture:N.gesture,action:N.action,hasEagerState:N.hasEagerState,eagerState:N.eagerState,next:null},v===null?(f=v=A,c=a):v=v.next=A,at.lanes|=V,Fa|=V;N=N.next}while(N!==null&&N!==t);if(v===null?c=a:v.next=f,!Lo(a,e.memoizedState)&&(Mn=!0,$&&(n=Di,n!==null)))throw n;e.memoizedState=a,e.baseState=c,e.baseQueue=v,o.lastRenderedState=a}return l===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function I0(e){var t=Sn(),n=t.queue;if(n===null)throw Error(J(311));n.lastRenderedReducer=e;var o=n.dispatch,l=n.pending,a=t.memoizedState;if(l!==null){n.pending=null;var c=l=l.next;do a=e(a,c.action),c=c.next;while(c!==l);Lo(a,t.memoizedState)||(Mn=!0),t.memoizedState=a,t.baseQueue===null&&(t.baseState=a),n.lastRenderedState=a}return[a,o]}function T5(e,t,n){var o=at,l=Sn(),a=dt;if(a){if(n===void 0)throw Error(J(407));n=n()}else n=t();var c=!Lo((Ft||l).memoizedState,n);if(c&&(l.memoizedState=n,Mn=!0),l=l.queue,Ym(A5.bind(null,o,l,e),[e]),e=l.getSnapshot!==t||c||jn!==null&&(jn.memoizedState.tag&1)!==0,qi(e?9:8,{destroy:void 0},R5.bind(null,o,l,n,t),null),e){if(o.flags|=2048,Kt===null)throw Error(J(349));a||(sa&127)!==0||N5(o,t,n)}return n}function N5(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=at.updateQueue,t===null?(t=o_(),at.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function R5(e,t,n,o){t.value=n,t.getSnapshot=o,D5(t)&&O5(e)}function A5(e,t,n){return n(function(){D5(t)&&O5(e)})}function D5(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Lo(e,n)}catch{return!0}}function O5(e){var t=Ys(e,2);t!==null&&So(t,e,2)}function Nf(e){var t=fo();if(typeof e=="function"){var n=e;if(e=n(),Ls){Ta(!0);try{n()}finally{Ta(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ia,lastRenderedState:e},t}function z5(e,t,n,o){return e.baseState=n,Im(e,Ft,typeof o=="function"?o:ia)}function r8(e,t,n,o,l){if(s_(e))throw Error(J(485));if(e=t.action,e!==null){var a={payload:l,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(c){a.listeners.push(c)}};qe.T!==null?n(!0):a.isTransition=!1,o(a),n=t.pending,n===null?(a.next=t.pending=a,L5(t,a)):(a.next=n.next,t.pending=n.next=a)}}function L5(e,t){var n=t.action,o=t.payload,l=e.state;if(t.isTransition){var a=qe.T,c={};c.types=a!==null?a.types:null,qe.T=c;try{var f=n(l,o),v=qe.S;v!==null&&v(c,f),Sp(e,t,f)}catch(N){Rf(e,t,N)}finally{a!==null&&c.types!==null&&(a.types=c.types),qe.T=a}}else try{a=n(l,o),Sp(e,t,a)}catch(N){Rf(e,t,N)}}function Sp(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(o){kp(e,t,o)},function(o){return Rf(e,t,o)}):kp(e,t,n)}function kp(e,t,n){t.status="fulfilled",t.value=n,B5(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,L5(e,n)))}function Rf(e,t,n){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do t.status="rejected",t.reason=n,B5(t),t=t.next;while(t!==o)}e.action=null}function B5(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function H5(e,t){return t}function Cp(e,t){if(dt){var n=Kt.formState;if(n!==null){e:{var o=at;if(dt){if(on){t:{for(var l=on,a=Ko;l.nodeType!==8;){if(!a){l=null;break t}if(l=Jo(l.nextSibling),l===null){l=null;break t}}a=l.data,l=a==="F!"||a==="F"?l:null}if(l){on=Jo(l.nextSibling),o=l.data==="F!";break e}}Ga(o)}o=!1}o&&(t=n[0])}}return n=fo(),n.memoizedState=n.baseState=t,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:H5,lastRenderedState:t},n.queue=o,n=ex.bind(null,at,o),o.dispatch=n,o=Nf(!1),a=Gm.bind(null,at,!1,o.queue),o=fo(),l={state:t,dispatch:null,action:e,pending:null},o.queue=l,n=r8.bind(null,at,l,a,n),l.dispatch=n,o.memoizedState=e,[t,n,!1]}function jp(e){var t=Sn();return U5(t,Ft,e)}function U5(e,t,n){if(t=Im(e,t,H5)[0],e=id(ia)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var o=Rc(t)}catch(c){throw c===tr?n_:c}else o=t;t=Sn();var l=t.queue,a=l.dispatch;return n!==t.memoizedState&&(at.flags|=2048,qi(9,{destroy:void 0},c8.bind(null,l,n),null)),[o,a,e]}function c8(e,t){e.action=t}function Ep(e){var t=Sn(),n=Ft;if(n!==null)return U5(t,n,e);Sn(),t=t.memoizedState,n=Sn();var o=n.queue.dispatch;return n.memoizedState=e,[t,o,!1]}function qi(e,t,n,o){return e={tag:e,create:n,deps:o,inst:t,next:null},t=at.updateQueue,t===null&&(t=o_(),at.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(o=n.next,n.next=e,e.next=o,t.lastEffect=e),e}function $5(){return Sn().memoizedState}function rd(e,t,n,o){var l=fo();at.flags|=e,l.memoizedState=qi(1|t,{destroy:void 0},n,o===void 0?null:o)}function a_(e,t,n,o){var l=Sn();o=o===void 0?null:o;var a=l.memoizedState.inst;Ft!==null&&o!==null&&zm(o,Ft.memoizedState.deps)?l.memoizedState=qi(t,a,n,o):(at.flags|=e,l.memoizedState=qi(1|t,a,n,o))}function Mp(e,t){rd(8390656,8,e,t)}function Ym(e,t){a_(2048,8,e,t)}function u8(e){at.flags|=4;var t=at.updateQueue;if(t===null)t=o_(),at.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function I5(e){var t=Sn().memoizedState;return u8({ref:t,nextImpl:e}),function(){if((Lt&2)!==0)throw Error(J(440));return t.impl.apply(void 0,arguments)}}function Y5(e,t){return a_(4,2,e,t)}function q5(e,t){return a_(4,4,e,t)}function X5(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Q5(e,t,n){n=n!=null?n.concat([e]):null,a_(4,4,X5.bind(null,t,e),n)}function qm(){}function G5(e,t){var n=Sn();t=t===void 0?null:t;var o=n.memoizedState;return t!==null&&zm(t,o[1])?o[0]:(n.memoizedState=[e,t],e)}function V5(e,t){var n=Sn();t=t===void 0?null:t;var o=n.memoizedState;if(t!==null&&zm(t,o[1]))return o[0];if(o=e(),Ls){Ta(!0);try{e()}finally{Ta(!1)}}return n.memoizedState=[o,t],o}function Xm(e,t,n){return n===void 0||(sa&1073741824)!==0&&(yt&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=Ux(),at.lanes|=e,Fa|=e,n)}function W5(e,t,n,o){return Lo(n,t)?n:Va.current!==null?(e=Xm(e,n,o),Lo(e,t)||(Mn=!0),e):(sa&106)===0||(sa&1073741824)!==0&&(yt&261930)===0?(Mn=!0,e.memoizedState=n):(e=Ux(),at.lanes|=e,Fa|=e,t)}function F5(e,t,n,o,l){var a=Bt.p;Bt.p=a!==0&&8>a?a:8;var c=qe.T,f={};f.types=c!==null?c.types:null,qe.T=f,Gm(e,!1,t,n);try{var v=l(),N=qe.S;if(N!==null&&N(f,v),v!==null&&typeof v=="object"&&typeof v.then=="function"){var $=a8(v,o);nc(e,t,$,zo(e))}else nc(e,t,o,zo(e))}catch(V){nc(e,t,{then:function(){},status:"rejected",reason:V},zo())}finally{Bt.p=a,c!==null&&f.types!==null&&(c.types=f.types),qe.T=c}}function d8(){}function Af(e,t,n,o){if(e.tag!==5)throw Error(J(476));var l=Z5(e).queue;F5(e,l,t,js,n===null?d8:function(){return K5(e),n(o)})}function Z5(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:js,baseState:js,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ia,lastRenderedState:js},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ia,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function K5(e){var t=Z5(e);t.next===null&&(t=e.alternate.memoizedState),nc(e,t.next.queue,{},zo())}function Qm(){return Wn(Zi)}function J5(){return Sn().memoizedState}function P5(){return Sn().memoizedState}function _8(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=zo();e=Ba(n);var o=Ha(t,e,n);o!==null&&(So(o,t,n),Pr(o,t,n)),t={cache:Tm()},e.payload=t;return}t=t.return}}function f8(e,t,n){var o=zo();n={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},s_(e)?tx(t,n):(n=jm(e,t,n,o),n!==null&&(So(n,e,o),nx(n,t,o)))}function ex(e,t,n){var o=zo();nc(e,t,n,o)}function nc(e,t,n,o){var l={lane:o,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(s_(e))tx(t,l);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var c=t.lastRenderedState,f=a(c,n);if(l.hasEagerState=!0,l.eagerState=f,Lo(f,c))return e_(e,t,l,0),Kt===null&&Pd(),!1}catch{}finally{}if(n=jm(e,t,l,o),n!==null)return So(n,e,o),nx(n,t,o),!0}return!1}function Gm(e,t,n,o){if(o={lane:2,revertLane:oh(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},s_(e)){if(t)throw Error(J(479))}else t=jm(e,n,o,2),t!==null&&So(t,e,2)}function s_(e){var t=e.alternate;return e===at||t!==null&&t===at}function tx(e,t){zi=Ad=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function nx(e,t,n){if((n&4194048)!==0){var o=t.lanes;o&=e.pendingLanes,n|=o,t.lanes=n,$y(e,n)}}var Od={readContext:Wn,use:l_,useCallback:yn,useContext:yn,useEffect:yn,useImperativeHandle:yn,useLayoutEffect:yn,useInsertionEffect:yn,useMemo:yn,useReducer:yn,useRef:yn,useState:yn,useDebugValue:yn,useDeferredValue:yn,useTransition:yn,useSyncExternalStore:yn,useId:yn,useHostTransitionStatus:yn,useFormState:yn,useActionState:yn,useOptimistic:yn,useMemoCache:yn,useCacheRefresh:yn,useEffectEvent:yn},ox={readContext:Wn,use:l_,useCallback:function(e,t){return fo().memoizedState=[e,t===void 0?null:t],e},useContext:Wn,useEffect:Mp,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,rd(4194308,4,X5.bind(null,t,e),n)},useLayoutEffect:function(e,t){return rd(4194308,4,e,t)},useInsertionEffect:function(e,t){rd(4,2,e,t)},useMemo:function(e,t){var n=fo();t=t===void 0?null:t;var o=e();if(Ls){Ta(!0);try{e()}finally{Ta(!1)}}return n.memoizedState=[o,t],o},useReducer:function(e,t,n){var o=fo();if(n!==void 0){var l=n(t);if(Ls){Ta(!0);try{n(t)}finally{Ta(!1)}}}else l=t;return o.memoizedState=o.baseState=l,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:l},o.queue=e,e=e.dispatch=f8.bind(null,at,e),[o.memoizedState,e]},useRef:function(e){var t=fo();return e={current:e},t.memoizedState=e},useState:function(e){e=Nf(e);var t=e.queue,n=ex.bind(null,at,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:qm,useDeferredValue:function(e,t){var n=fo();return Xm(n,e,t)},useTransition:function(){var e=Nf(!1);return e=F5.bind(null,at,e.queue,!0,!1),fo().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var o=at,l=fo();if(dt){if(n===void 0)throw Error(J(407));n=n()}else{if(n=t(),Kt===null)throw Error(J(349));(yt&127)!==0||N5(o,t,n)}l.memoizedState=n;var a={value:n,getSnapshot:t};return l.queue=a,Mp(A5.bind(null,o,a,e),[e]),o.flags|=2048,qi(9,{destroy:void 0},R5.bind(null,o,a,n,t),null),n},useId:function(){var e=fo(),t=Kt.identifierPrefix;if(dt){var n=Rl,o=Nl;n=(o&~(1<<32-Oo(o)-1)).toString(32)+n,t="_"+t+"R_"+n,n=Dd++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=s8++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:Qm,useFormState:Cp,useActionState:Cp,useOptimistic:function(e){var t=fo();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Gm.bind(null,at,!0,n),n.dispatch=t,[e,t]},useMemoCache:$m,useCacheRefresh:function(){return fo().memoizedState=_8.bind(null,at)},useEffectEvent:function(e){var t=fo(),n={impl:e};return t.memoizedState=n,function(){if((Lt&2)!==0)throw Error(J(440));return n.impl.apply(void 0,arguments)}}},lx={readContext:Wn,use:l_,useCallback:G5,useContext:Wn,useEffect:Ym,useImperativeHandle:Q5,useInsertionEffect:Y5,useLayoutEffect:q5,useMemo:V5,useReducer:id,useRef:$5,useState:function(){return id(ia)},useDebugValue:qm,useDeferredValue:function(e,t){var n=Sn();return W5(n,Ft.memoizedState,e,t)},useTransition:function(){var e=id(ia)[0],t=Sn().memoizedState;return[typeof e=="boolean"?e:Rc(e),t]},useSyncExternalStore:T5,useId:J5,useHostTransitionStatus:Qm,useFormState:jp,useActionState:jp,useOptimistic:function(e,t){var n=Sn();return z5(n,Ft,e,t)},useMemoCache:$m,useCacheRefresh:P5,useEffectEvent:I5},m8={readContext:Wn,use:l_,useCallback:G5,useContext:Wn,useEffect:Ym,useImperativeHandle:Q5,useInsertionEffect:Y5,useLayoutEffect:q5,useMemo:V5,useReducer:I0,useRef:$5,useState:function(){return I0(ia)},useDebugValue:qm,useDeferredValue:function(e,t){var n=Sn();return Ft===null?Xm(n,e,t):W5(n,Ft.memoizedState,e,t)},useTransition:function(){var e=I0(ia)[0],t=Sn().memoizedState;return[typeof e=="boolean"?e:Rc(e),t]},useSyncExternalStore:T5,useId:J5,useHostTransitionStatus:Qm,useFormState:Ep,useActionState:Ep,useOptimistic:function(e,t){var n=Sn();return Ft!==null?z5(n,Ft,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:$m,useCacheRefresh:P5,useEffectEvent:I5};function Y0(e,t,n,o){t=e.memoizedState,n=n(o,t),n=n==null?t:Jt({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var Df={enqueueSetState:function(e,t,n){e=e._reactInternals;var o=zo(),l=Ba(o);l.payload=t,n!=null&&(l.callback=n),t=Ha(e,l,o),t!==null&&(So(t,e,o),Pr(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var o=zo(),l=Ba(o);l.tag=1,l.payload=t,n!=null&&(l.callback=n),t=Ha(e,l,o),t!==null&&(So(t,e,o),Pr(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=zo(),o=Ba(n);o.tag=2,t!=null&&(o.callback=t),t=Ha(e,o,n),t!==null&&(So(t,e,n),Pr(t,e,n))}};function Tp(e,t,n,o,l,a,c){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,a,c):t.prototype&&t.prototype.isPureReactComponent?!dc(n,o)||!dc(l,a):!0}function Np(e,t,n,o){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,o),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,o),t.state!==e&&Df.enqueueReplaceState(t,t.state,null)}function Bs(e,t){var n=t;if("ref"in t){n={};for(var o in t)o!=="ref"&&(n[o]=t[o])}if(e=e.defaultProps){n===t&&(n=Jt({},n));for(var l in e)n[l]===void 0&&(n[l]=e[l])}return n}function ax(e){kd(e)}function sx(e){console.error(e)}function ix(e){kd(e)}function zd(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(o){setTimeout(function(){throw o})}}function Rp(e,t,n){try{var o=e.onCaughtError;o(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(l){setTimeout(function(){throw l})}}function Of(e,t,n){return n=Ba(n),n.tag=3,n.payload={element:null},n.callback=function(){zd(e,t)},n}function rx(e){return e=Ba(e),e.tag=3,e}function cx(e,t,n,o){var l=n.type.getDerivedStateFromError;if(typeof l=="function"){var a=o.value;e.payload=function(){return l(a)},e.callback=function(){Rp(t,n,o)}}var c=n.stateNode;c!==null&&typeof c.componentDidCatch=="function"&&(e.callback=function(){Rp(t,n,o),typeof l!="function"&&(Ia===null?Ia=new Set([this]):Ia.add(this));var f=o.stack;this.componentDidCatch(o.value,{componentStack:f!==null?f:""})})}function h8(e,t,n,o,l){if(n.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(t=n.alternate,t!==null&&As(t,n,l,!0),n=Jn.current,n!==null){switch(n.tag){case 31:case 13:case 19:return ao===null?qd():n.alternate===null&&xn===0&&(xn=3),n.flags&=-257,n.flags|=65536,n.lanes=l,o===Td?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([o]):t.add(o),F0(e,o,l)),!1;case 22:return n.flags|=65536,o===Td?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([o])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([o]):n.add(o)),F0(e,o,l)),!1}throw Error(J(435,n.tag))}return F0(e,o,l),qd(),!1}if(dt)return t=Jn.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=l,o!==wf&&(e=Error(J(422),{cause:o}),fc(Zo(e,n)))):(o!==wf&&(t=Error(J(423),{cause:o}),fc(Zo(t,n))),e=e.current.alternate,e.flags|=65536,l&=-l,e.lanes|=l,o=Zo(o,n),l=Of(e.stateNode,o,l),$0(e,l),xn!==4&&(xn=2)),!1;var a=Error(J(520),{cause:o});if(a=Zo(a,n),sc===null?sc=[a]:sc.push(a),xn!==4&&(xn=2),t===null)return!0;o=Zo(o,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=l&-l,n.lanes|=e,e=Of(n.stateNode,o,e),$0(n,e),!1;case 1:if(t=n.type,a=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||a!==null&&typeof a.componentDidCatch=="function"&&(Ia===null||!Ia.has(a))))return n.flags|=65536,l&=-l,n.lanes|=l,l=rx(l),cx(l,e,n,o),$0(n,l),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var Vm=Error(J(461)),Mn=!1;function Rn(e,t,n,o){t.child=e===null?S5(t,null,n,o):zs(t,e.child,n,o)}function Ap(e,t,n,o,l){n=n.render;var a=t.ref;if("ref"in o){var c={};for(var f in o)f!=="ref"&&(c[f]=o[f])}else c=o;return Ds(t),o=Lm(e,t,n,c,a,l),f=Bm(),e!==null&&!Mn?(Hm(e,t,l),ra(e,t,l)):(dt&&f&&t_(t),t.flags|=1,Rn(e,t,o,l),t.child)}function Dp(e,t,n,o,l){if(e===null){var a=n.type;return typeof a=="function"&&!Em(a)&&a.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=a,ux(e,t,a,o,l)):(e=ld(n.type,null,o,t,t.mode,l),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,!Fm(e,l)){var c=a.memoizedProps;if(n=n.compare,n=n!==null?n:dc,n(c,o)&&e.ref===t.ref)return ra(e,t,l)}return t.flags|=1,e=na(a,o),e.ref=t.ref,e.return=t,t.child=e}function ux(e,t,n,o,l){if(e!==null){var a=e.memoizedProps;if(dc(a,o)&&e.ref===t.ref)if(Mn=!1,t.pendingProps=o=a,Fm(e,l))(e.flags&131072)!==0&&(Mn=!0);else return t.lanes=e.lanes,ra(e,t,l)}return zf(e,t,n,o,l)}function dx(e,t,n,o){var l=o.children,a=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((t.flags&128)!==0){if(a=a!==null?a.baseLanes|n:n,e!==null){for(o=t.child=e.child,l=0;o!==null;)l=l|o.lanes|o.childLanes,o=o.sibling;o=l&~a}else o=0,t.child=null;return Op(e,t,a,n,o)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&sd(t,a!==null?a.cachePool:null),a!==null?wp(t,a):Mf(),j5(t);else return o=t.lanes=536870912,Op(e,t,a!==null?a.baseLanes|n:n,n,o)}else a!==null?(sd(t,a.cachePool),wp(t,a),$a(),t.memoizedState=null):(e!==null&&sd(t,null),Mf(),$a());return Rn(e,t,l,n),t.child}function oc(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Op(e,t,n,o,l){var a=Nm();return a=a===null?null:{parent:En._currentValue,pool:a},t.memoizedState={baseLanes:n,cachePool:a},e!==null&&sd(t,null),Mf(),j5(t),e!==null&&As(e,t,o,!0),t.childLanes=l,null}function cd(e,t){return t=i_({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function zp(e,t,n){return zs(t,e.child,null,n),e=cd(t,t.pendingProps),e.flags|=2,To(t),t.memoizedState=null,e}function g8(e,t,n){var o=t.pendingProps,l=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(dt){if(o.mode==="hidden")return e=cd(t,o),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},oc(null,e);if(Tf(t),(e=on)?(e=d2(e,Ko),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Qa!==null?{id:Nl,overflow:Rl}:null,retryLane:536870912,hydrationErrors:null},n=g5(e),n.return=t,t.child=n,Un=t,on=null)):e=null,e===null)throw Ga(t);return t.lanes=536870912,null}return cd(t,o)}var a=e.memoizedState;if(a!==null){var c=a.dehydrated;if(Tf(t),l)if(t.flags&256)t.flags&=-257,t=zp(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(J(558));else if(Mn||As(e,t,n,!1),l=(n&e.childLanes)!==0,Mn||l){if(Va.current===null){if(o=Kt,o!==null&&(c=Iy(o,n),c!==0&&c!==a.retryLane))throw a.retryLane=c,Ys(e,c),So(o,e,c),Vm;qd()}t=zp(e,t,n)}else e=a.treeContext,on=Jo(c.nextSibling),Un=t,dt=!0,La=null,Ko=!1,e!==null&&y5(t,e),t=cd(t,o),t.flags|=134221824;return t}return e=na(e.child,{mode:o.mode,children:o.children}),e.ref=t.ref,t.child=e,e.return=t,e}function hi(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(J(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function zf(e,t,n,o,l){return Ds(t),n=Lm(e,t,n,o,void 0,l),o=Bm(),e!==null&&!Mn?(Hm(e,t,l),ra(e,t,l)):(dt&&o&&t_(t),t.flags|=1,Rn(e,t,n,l),t.child)}function Lp(e,t,n,o,l,a){return Ds(t),t.updateQueue=null,n=M5(t,o,n,l),E5(e),o=Bm(),e!==null&&!Mn?(Hm(e,t,a),ra(e,t,a)):(dt&&o&&t_(t),t.flags|=1,Rn(e,t,n,a),t.child)}function Bp(e,t,n,o,l){if(Ds(t),t.stateNode===null){var a=ji,c=n.contextType;typeof c=="object"&&c!==null&&(a=Wn(c)),a=new n(o,a),t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,a.updater=Df,t.stateNode=a,a._reactInternals=t,a=t.stateNode,a.props=o,a.state=t.memoizedState,a.refs={},Am(t),c=n.contextType,a.context=typeof c=="object"&&c!==null?Wn(c):ji,a.state=t.memoizedState,c=n.getDerivedStateFromProps,typeof c=="function"&&(Y0(t,n,c,o),a.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof a.getSnapshotBeforeUpdate=="function"||typeof a.UNSAFE_componentWillMount!="function"&&typeof a.componentWillMount!="function"||(c=a.state,typeof a.componentWillMount=="function"&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount=="function"&&a.UNSAFE_componentWillMount(),c!==a.state&&Df.enqueueReplaceState(a,a.state,null),tc(t,o,a,l),ec(),a.state=t.memoizedState),typeof a.componentDidMount=="function"&&(t.flags|=4194308),o=!0}else if(e===null){a=t.stateNode;var f=t.memoizedProps,v=Bs(n,f);a.props=v;var N=a.context,$=n.contextType;c=ji,typeof $=="object"&&$!==null&&(c=Wn($));var V=n.getDerivedStateFromProps;$=typeof V=="function"||typeof a.getSnapshotBeforeUpdate=="function",f=t.pendingProps!==f,$||typeof a.UNSAFE_componentWillReceiveProps!="function"&&typeof a.componentWillReceiveProps!="function"||(f||N!==c)&&Np(t,a,o,c),Ea=!1;var A=t.memoizedState;a.state=A,tc(t,o,a,l),ec(),N=t.memoizedState,f||A!==N||Ea?(typeof V=="function"&&(Y0(t,n,V,o),N=t.memoizedState),(v=Ea||Tp(t,n,v,o,A,N,c))?($||typeof a.UNSAFE_componentWillMount!="function"&&typeof a.componentWillMount!="function"||(typeof a.componentWillMount=="function"&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount=="function"&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount=="function"&&(t.flags|=4194308)):(typeof a.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=o,t.memoizedState=N),a.props=o,a.state=N,a.context=c,o=v):(typeof a.componentDidMount=="function"&&(t.flags|=4194308),o=!1)}else{a=t.stateNode,jf(e,t),c=t.memoizedProps,$=Bs(n,c),a.props=$,V=t.pendingProps,A=a.context,N=n.contextType,v=ji,typeof N=="object"&&N!==null&&(v=Wn(N)),f=n.getDerivedStateFromProps,(N=typeof f=="function"||typeof a.getSnapshotBeforeUpdate=="function")||typeof a.UNSAFE_componentWillReceiveProps!="function"&&typeof a.componentWillReceiveProps!="function"||(c!==V||A!==v)&&Np(t,a,o,v),Ea=!1,A=t.memoizedState,a.state=A,tc(t,o,a,l),ec();var U=t.memoizedState;c!==V||A!==U||Ea||e!==null&&e.dependencies!==null&&Md(e.dependencies)?(typeof f=="function"&&(Y0(t,n,f,o),U=t.memoizedState),($=Ea||Tp(t,n,$,o,A,U,v)||e!==null&&e.dependencies!==null&&Md(e.dependencies))?(N||typeof a.UNSAFE_componentWillUpdate!="function"&&typeof a.componentWillUpdate!="function"||(typeof a.componentWillUpdate=="function"&&a.componentWillUpdate(o,U,v),typeof a.UNSAFE_componentWillUpdate=="function"&&a.UNSAFE_componentWillUpdate(o,U,v)),typeof a.componentDidUpdate=="function"&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof a.componentDidUpdate!="function"||c===e.memoizedProps&&A===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!="function"||c===e.memoizedProps&&A===e.memoizedState||(t.flags|=1024),t.memoizedProps=o,t.memoizedState=U),a.props=o,a.state=U,a.context=v,o=$):(typeof a.componentDidUpdate!="function"||c===e.memoizedProps&&A===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!="function"||c===e.memoizedProps&&A===e.memoizedState||(t.flags|=1024),o=!1)}return a=o,hi(e,t),o=(t.flags&128)!==0,a||o?(a=t.stateNode,n=o&&typeof n.getDerivedStateFromError!="function"?null:a.render(),t.flags|=1,e!==null&&o?(t.child=zs(t,e.child,null,l),t.child=zs(t,null,n,l)):Rn(e,t,n,l),t.memoizedState=a.state,e=t.child):e=ra(e,t,l),e}function Hp(e,t,n,o){return Rs(),t.flags|=256,Rn(e,t,n,o),t.child}var Lf={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Bf(e){return{baseLanes:e,cachePool:b5()}}function Hf(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=Ro),e}function _x(e,t,n){var o=t.pendingProps,l=!1,a=(t.flags&128)!==0,c;if((c=a)||(c=e!==null&&e.memoizedState===null?!1:(Zn.current&2)!==0),c&&(l=!0,t.flags&=-129),c=(t.flags&32)!==0,t.flags&=-33,e===null){if(dt){if(l?Ua(t):$a(),(e=on)?(e=d2(e,Ko),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Qa!==null?{id:Nl,overflow:Rl}:null,retryLane:536870912,hydrationErrors:null},n=g5(e),n.return=t,t.child=n,Un=t,on=null)):e=null,e===null)throw Ga(t);return ih(e)?t.lanes=32:t.lanes=536870912,null}return a=o.children,o=o.fallback,l?($a(),l=t.mode,a=i_({mode:"hidden",children:a},l),o=Es(o,l,n,null),a.return=t,o.return=t,a.sibling=o,t.child=a,o=t.child,o.memoizedState=Bf(n),o.childLanes=Hf(e,c,n),t.memoizedState=Lf,oc(null,o)):(Ua(t),Wm(t,a))}var f=e.memoizedState;if(f!==null){var v=f.dehydrated;if(v!==null)return p8(e,t,a,c,o,v,f,n)}return l?($a(),l=o.fallback,a=t.mode,f=e.child,v=f.sibling,o=na(f,{mode:"hidden",children:o.children}),o.subtreeFlags=f.subtreeFlags&1206910976,v!==null?l=na(v,l):(l=Es(l,a,n,null),l.flags|=2),l.return=t,o.return=t,o.sibling=l,t.child=o,oc(null,o),o=t.child,l=e.child.memoizedState,l===null?l=Bf(n):(a=l.cachePool,a!==null?(f=En._currentValue,a=a.parent!==f?{parent:f,pool:f}:a):a=b5(),l={baseLanes:l.baseLanes|n,cachePool:a}),o.memoizedState=l,o.childLanes=Hf(e,c,n),t.memoizedState=Lf,oc(e.child,o)):(Ua(t),n=e.child,e=n.sibling,n=na(n,{mode:"visible",children:o.children}),n.return=t,n.sibling=null,e!==null&&(c=t.deletions,c===null?(t.deletions=[e],t.flags|=16):c.push(e)),t.child=n,t.memoizedState=null,n)}function Wm(e,t){return t=i_({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function i_(e,t){return e=wo(22,e,null,t),e.lanes=0,e}function Xu(e,t,n){return zs(t,e.child,null,n),e=Wm(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function p8(e,t,n,o,l,a,c,f){if(n)return t.flags&256?(Ua(t),t.flags&=-257,Xu(e,t,f)):t.memoizedState!==null?($a(),t.child=e.child,t.flags|=128,null):($a(),a=l.fallback,c=t.mode,l=i_({mode:"visible",children:l.children},c),a=Es(a,c,f,null),a.flags|=2,l.return=t,a.return=t,l.sibling=a,t.child=l,zs(t,e.child,null,f),l=t.child,l.memoizedState=Bf(f),l.childLanes=Hf(e,o,f),t.memoizedState=Lf,oc(null,l));if(Ua(t),ih(a)){if(o=a.nextSibling&&a.nextSibling.dataset,o)var v=o.dgst;return o=v,o!==""&&(l=Error(J(419)),l.stack="",l.digest=o,fc({value:l,source:null,stack:null})),Xu(e,t,f)}if(Mn||As(e,t,f,!1),o=(f&e.childLanes)!==0,Mn||o){if(Va.current!==null)return Xu(e,t,f);if(o=Kt,o!==null&&(l=Iy(o,f),l!==0&&l!==c.retryLane))throw c.retryLane=l,Ys(e,l),So(o,e,l),Vm;return cm(a)||qd(),Xu(e,t,f)}return cm(a)?(t.flags|=192,t.child=e.child,null):(e=c.treeContext,on=Jo(a.nextSibling),Un=t,dt=!0,La=null,Ko=!1,e!==null&&y5(t,e),t=Wm(t,l.children),t.flags|=134221824,t)}function Up(e,t,n){e.lanes|=t;var o=e.alternate;o!==null&&(o.lanes|=t),ad(e.return,t,n)}function $p(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&Rd(n)===null&&(t=e),e=e.sibling}return t}function Qu(e,t,n,o,l,a){var c=e.memoizedState;c===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:o,tail:n,tailMode:l,treeForkCount:a}:(c.isBackwards=t,c.rendering=null,c.renderingStartTime=0,c.last=o,c.tail=n,c.tailMode=l,c.treeForkCount=a)}function q0(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function Uf(e,t,n){var o=t.pendingProps,l=o.revealOrder,a=o.tail;o=o.children;var c=Zn.current;if(t.flags&128)return hc(t,c),null;var f=(c&2)!==0;if(f?(c=c&1|2,t.flags|=128):c&=1,hc(t,c),l==="backwards"&&e!==null?(q0(e),Rn(e,t,o,n),q0(e)):Rn(e,t,o,n),o=dt?_c:0,!f&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Up(e,n,t);else if(e.tag===19)Up(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(l){case"backwards":n=$p(t.child),n===null?(l=t.child,t.child=null):(l=n.sibling,n.sibling=null,q0(t)),Qu(t,!0,l,null,a,o);break;case"unstable_legacy-backwards":for(n=null,l=t.child,t.child=null;l!==null;){if(e=l.alternate,e!==null&&Rd(e)===null){t.child=l;break}e=l.sibling,l.sibling=n,n=l,l=e}Qu(t,!0,n,null,a,o);break;case"together":Qu(t,!1,null,null,void 0,o);break;case"independent":t.memoizedState=null;break;default:n=$p(t.child),n===null?(l=t.child,t.child=null):(l=n.sibling,n.sibling=null),Qu(t,!1,l,n,a,o)}return t.child}function Ip(e,t,n){var o=t.pendingProps;return Ra(t,t.type,o.value),Rn(e,t,o.children,n),t.child}function ra(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Fa|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(As(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(J(153));if(t.child!==null){for(e=t.child,n=na(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=na(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Fm(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&Md(e)))}function y8(e,t,n){switch(t.tag){case 3:bd(t,t.stateNode.containerInfo),Ra(t,En,e.memoizedState.cache),Rs();break;case 27:case 5:_f(t);break;case 4:bd(t,t.stateNode.containerInfo);break;case 10:Ra(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,Tf(t),null;break;case 13:var o=t.memoizedState;if(o!==null){if(o.dehydrated!==null)return Ua(t),t.flags|=128,null;o=As(e,t,n,!1);var l=t.child.childLanes;return o||(n&l)!==0?_x(e,t,n):(Ua(t),e=ra(e,t,n),e!==null?e.sibling:null)}Ua(t);break;case 19:if(t.flags&128)return Uf(e,t,n);if(l=(e.flags&128)!==0,o=(n&t.childLanes)!==0,o||(As(e,t,n,!1),o=(n&t.childLanes)!==0),l){if(o)return Uf(e,t,n);t.flags|=128}if(l=t.memoizedState,l!==null&&(l.rendering=null,l.tail=null,l.lastEffect=null),hc(t,Zn.current),o)break;return null;case 22:return t.lanes=0,dx(e,t,n,t.pendingProps);case 24:Ra(t,En,e.memoizedState.cache)}return ra(e,t,n)}function fx(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)Mn=!0;else{if(!Fm(e,n)&&(t.flags&128)===0)return Mn=!1,y8(e,t,n);Mn=(e.flags&131072)!==0}else Mn=!1,dt&&(t.flags&1048576)!==0&&p5(t,_c,t.index);switch(t.lanes=0,t.tag){case 16:e:{var o=t.pendingProps;if(e=ws(t.elementType),t.type=e,typeof e=="function")Em(e)?(o=Bs(e,o),t.tag=1,t=Bp(null,t,e,o,n)):(t.tag=0,t=zf(null,t,e,o,n));else{if(e!=null){var l=e.$$typeof;if(l===mm){t.tag=11,t=Ap(null,t,e,o,n);break e}else if(l===hm){t.tag=14,t=Dp(null,t,e,o,n);break e}else if(l===Ml){t.tag=10,t.type=e,t=Ip(null,t,n);break e}}throw t=uf(e)||e,Error(J(306,t,""))}}return t;case 0:return zf(e,t,t.type,t.pendingProps,n);case 1:return o=t.type,l=Bs(o,t.pendingProps),Bp(e,t,o,l,n);case 3:e:{if(bd(t,t.stateNode.containerInfo),e===null)throw Error(J(387));o=t.pendingProps;var a=t.memoizedState;l=a.element,jf(e,t),tc(t,o,null,n);var c=t.memoizedState;if(o=c.cache,Ra(t,En,o),o!==a.cache&&kf(t,[En],n,!0),ec(),o=c.element,a.isDehydrated)if(a={element:o,isDehydrated:!1,cache:c.cache},t.updateQueue.baseState=a,t.memoizedState=a,t.flags&256){t=Hp(e,t,o,n);break e}else if(o!==l){l=Zo(Error(J(424)),t),fc(l),t=Hp(e,t,o,n);break e}else{switch(e=t.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName==="HTML"?e.ownerDocument.body:e}for(on=Jo(e.firstChild),Un=t,dt=!0,La=null,Ko=!0,n=S5(t,null,o,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling}else{if(Rs(),o===l){t=ra(e,t,n);break e}Rn(e,t,o,n)}t=t.child}return t;case 26:return hi(e,t),e===null?(n=my(t.type,null,t.pendingProps,null))?t.memoizedState=n:dt||(t.stateNode=n2(t.type,t.pendingProps,za.current,t)):t.memoizedState=my(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return _f(t),e===null&&dt&&(o=t.stateNode=_2(t.type,t.pendingProps,za.current),Un=t,Ko=!0,l=on,Ka(t.type)?(um=l,on=Jo(o.firstChild)):on=l),Rn(e,t,t.pendingProps.children,n),hi(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&dt&&((l=o=on)&&(o=u7(o,t.type,t.pendingProps,Ko),o!==null?(t.stateNode=o,Un=t,on=Jo(o.firstChild),Ko=!1,l=!0):l=!1),l||Ga(t)),_f(t),l=t.type,a=t.pendingProps,c=e!==null?e.memoizedProps:null,o=a.children,sm(l,a)?o=null:c!==null&&sm(l,c)&&(t.flags|=32),t.memoizedState!==null&&(l=Lm(e,t,i8,null,null,n),Zi._currentValue=l),hi(e,t),Rn(e,t,o,n),t.child;case 6:return e===null&&dt&&((e=n=on)&&(n=d7(n,t.pendingProps,Ko),n!==null?(t.stateNode=n,Un=t,on=null,e=!0):e=!1),e||Ga(t)),null;case 13:return _x(e,t,n);case 4:return bd(t,t.stateNode.containerInfo),o=t.pendingProps,e===null?t.child=zs(t,null,o,n):Rn(e,t,o,n),t.child;case 11:return Ap(e,t,t.type,t.pendingProps,n);case 7:return o=t.pendingProps,hi(e,t),Rn(e,t,o,n),t.child;case 8:return Rn(e,t,t.pendingProps.children,n),t.child;case 12:return Rn(e,t,t.pendingProps.children,n),t.child;case 10:return Ip(e,t,n);case 9:return l=t.type._context,o=t.pendingProps.children,Ds(t),l=Wn(l),o=o(l),t.flags|=1,Rn(e,t,o,n),t.child;case 14:return Dp(e,t,t.type,t.pendingProps,n);case 15:return ux(e,t,t.type,t.pendingProps,n);case 19:return Uf(e,t,n);case 31:return g8(e,t,n);case 22:return dx(e,t,n,t.pendingProps);case 24:return Ds(t),o=Wn(En),e===null?(l=Nm(),l===null&&(l=Kt,a=Tm(),l.pooledCache=a,a.refCount++,a!==null&&(l.pooledCacheLanes|=n),l=a),t.memoizedState={parent:o,cache:l},Am(t),Ra(t,En,l)):((e.lanes&n)!==0&&(jf(e,t),tc(t,null,null,n),ec()),l=e.memoizedState,a=t.memoizedState,l.parent!==o?(l={parent:o,cache:o},t.memoizedState=l,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=l),Ra(t,En,o)):(o=a.cache,Ra(t,En,o),o!==l.cache&&kf(t,[En],n,!0))),Rn(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),o=t.pendingProps,o.name!=null&&o.name!=="auto"?t.flags|=e===null?18882560:18874368:dt&&t_(t),e!==null&&e.memoizedProps.name!==o.name?t.flags|=4194816:hi(e,t),Rn(e,t,o.children,n),t.child;case 29:throw t.pendingProps}throw Error(J(156,t.tag))}function Pl(e){e.flags|=4}function X0(e,t,n,o,l){var a;if((a=(e.mode&32)!==0)&&(a=n===null?py(t,o):py(t,o)&&(o.src!==n.src||o.srcSet!==n.srcSet)),a){if(e.flags|=16777216,(l&335544128)===l)if(e.stateNode.complete)e.flags|=8192;else if(Yx())e.flags|=8192;else throw Ts=Td,Rm}else e.flags&=-16777217}function Yp(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!g2(t))if(Yx())e.flags|=8192;else throw Ts=Td,Rm}function Gu(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?Hy():536870912,e.lanes|=t,Xi|=t)}function $r(e,t){if(!dt)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,o=null;n!==null;)n.alternate!==null&&(o=n),n=n.sibling;o===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function nn(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,o=0;if(t)for(var l=e.child;l!==null;)n|=l.lanes|l.childLanes,o|=l.subtreeFlags&1206910976,o|=l.flags&1206910976,l.return=e,l=l.sibling;else for(l=e.child;l!==null;)n|=l.lanes|l.childLanes,o|=l.subtreeFlags,o|=l.flags,l.return=e,l=l.sibling;return e.subtreeFlags|=o,e.childLanes=n,t}function x8(e,t,n){var o=t.pendingProps;switch(Mm(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return nn(t),null;case 1:return nn(t),null;case 3:return n=t.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),t.memoizedState.cache!==o&&(t.flags|=2048),oa(En),$i(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(fi(t)?Pl(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,U0())),nn(t),null;case 26:var l=t.type,a=t.memoizedState;return e===null?(Pl(t),a!==null?(nn(t),Yp(t,a)):(nn(t),X0(t,l,null,o,n))):a?a!==e.memoizedState?(Pl(t),nn(t),Yp(t,a)):(nn(t),t.flags&=-16777217):(e=e.memoizedProps,e!==o&&Pl(t),nn(t),X0(t,l,e,o,n)),null;case 27:if(vd(t),n=za.current,l=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&Pl(t);else{if(!o){if(t.stateNode===null)throw Error(J(166));return nn(t),t.subtreeFlags&=-33554433,null}e=Al.current,fi(t)?hp(t,e):(e=_2(l,o,n),t.stateNode=e,Pl(t))}return nn(t),t.subtreeFlags&=-33554433,null;case 5:if(vd(t),l=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&Pl(t);else{if(!o){if(t.stateNode===null)throw Error(J(166));return nn(t),t.subtreeFlags&=-33554433,null}if(a=Al.current,fi(t))hp(t,a);else{var c=xc(za.current);switch(a){case 1:a=c.createElementNS("http://www.w3.org/2000/svg",l);break;case 2:a=c.createElementNS("http://www.w3.org/1998/Math/MathML",l);break;default:switch(l){case"svg":a=c.createElementNS("http://www.w3.org/2000/svg",l);break;case"math":a=c.createElementNS("http://www.w3.org/1998/Math/MathML",l);break;case"script":a=c.createElement("div"),a.innerHTML="<script><\/script>",a=a.removeChild(a.firstChild);break;case"select":a=typeof o.is=="string"?c.createElement("select",{is:o.is}):c.createElement("select"),o.multiple?a.multiple=!0:o.size&&(a.size=o.size);break;default:a=typeof o.is=="string"?c.createElement(l,{is:o.is}):c.createElement(l)}}a[Vn]=t,a[Co]=o;e:for(c=t.child;c!==null;){if(c.tag===5||c.tag===6)a.appendChild(c.stateNode);else if(c.tag!==4&&c.tag!==27&&c.child!==null){c.child.return=c,c=c.child;continue}if(c===t)break e;for(;c.sibling===null;){if(c.return===null||c.return===t)break e;c=c.return}c.sibling.return=c.return,c=c.sibling}t.stateNode=a;e:switch(Kn(a,l,o),l){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&Pl(t)}}return nn(t),t.subtreeFlags&=-33554433,X0(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==o&&Pl(t);else{if(typeof o!="string"&&t.stateNode===null)throw Error(J(166));if(e=za.current,fi(t)){if(e=t.stateNode,n=t.memoizedProps,o=null,l=Un,l!==null)switch(l.tag){case 27:case 5:o=l.memoizedProps}e[Vn]=t,e=!!(e.nodeValue===n||o!==null&&o.suppressHydrationWarning===!0||e2(e.nodeValue,n)),e||Ga(t,!0)}else e=xc(e).createTextNode(o),e[Vn]=t,t.stateNode=e}return nn(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(o=fi(t),n!==null){if(e===null){if(!o)throw Error(J(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(J(557));e[Vn]=t}else Rs(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;nn(t),e=!1}else n=U0(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(To(t),t):(To(t),null);if((t.flags&128)!==0)throw Error(J(558))}return nn(t),null;case 13:if(o=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(l=fi(t),o!==null&&o.dehydrated!==null){if(e===null){if(!l)throw Error(J(318));if(l=t.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(J(317));l[Vn]=t}else Rs(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;nn(t),l=!1}else l=U0(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=l),l=!0;if(!l)return t.flags&256?(To(t),t):(To(t),null)}return To(t),(t.flags&128)!==0?(t.lanes=n,t):(n=o!==null,e=e!==null&&e.memoizedState!==null,n&&(o=t.child,l=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(l=o.alternate.memoizedState.cachePool.pool),a=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(a=o.memoizedState.cachePool.pool),a!==l&&(o.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),Gu(t,t.updateQueue),nn(t),null);case 4:return $i(),e===null&&lh(t.stateNode.containerInfo),t.flags|=67108864,nn(t),null;case 10:return oa(t.type),nn(t),null;case 19:if(Om(t),o=t.memoizedState,o===null)return nn(t),null;if(l=(t.flags&128)!==0,a=o.rendering,a===null)if(l)$r(o,!1);else{if(xn!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(a=Rd(e),a!==null){for(t.flags|=128,$r(o,!1),e=a.updateQueue,t.updateQueue=e,Gu(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)h5(n,e),n=n.sibling;return hc(t,Zn.current&1|2),dt&&ea(t,o.treeForkCount),t.child}e=e.sibling}o.tail!==null&&Ao()>Id&&(t.flags|=128,l=!0,$r(o,!1),t.lanes=4194304)}else{if(!l)if(e=Rd(a),e!==null){if(t.flags|=128,l=!0,e=e.updateQueue,t.updateQueue=e,Gu(t,e),$r(o,!0),o.tail===null&&o.tailMode!=="collapsed"&&o.tailMode!=="visible"&&!a.alternate&&!dt)return nn(t),null}else 2*Ao()-o.renderingStartTime>Id&&n!==536870912&&(t.flags|=128,l=!0,$r(o,!1),t.lanes=4194304);o.isBackwards?(a.sibling=t.child,t.child=a):(e=o.last,e!==null?e.sibling=a:t.child=a,o.last=a)}if(o.tail!==null){e=o.tail;e:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break e}n=n.sibling}n=!0}return o.rendering=e,o.tail=e.sibling,o.renderingStartTime=Ao(),e.sibling=null,a=Zn.current,a=l?a&1|2:a&1,o.tailMode==="visible"||o.tailMode==="collapsed"||!n||dt?hc(t,a):(n=a,ln(Jn,t),ln(Zn,n),ao===null&&(ao=t)),dt&&ea(t,o.treeForkCount),e}return nn(t),null;case 22:case 23:return To(t),Dm(),o=t.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(t.flags|=8192):o&&(t.flags|=8192),o?(n&536870912)!==0&&(t.flags&128)===0&&(nn(t),t.subtreeFlags&6&&(t.flags|=8192)):nn(t),n=t.updateQueue,n!==null&&Gu(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),o=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),o!==n&&(t.flags|=2048),e!==null&&Fn(Ms),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),oa(En),nn(t),null;case 25:return null;case 30:return t.flags|=33554432,nn(t),null}throw Error(J(156,t.tag))}function b8(e,t){switch(Mm(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return oa(En),$i(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return vd(t),null;case 31:if(t.memoizedState!==null){if(To(t),t.alternate===null)throw Error(J(340));Rs()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(To(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(J(340));Rs()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return Om(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return $i(),null;case 10:return oa(t.type),null;case 22:case 23:return To(t),Dm(),e!==null&&Fn(Ms),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return oa(En),null;case 25:return null;default:return null}}function mx(e,t){switch(Mm(t),t.tag){case 3:oa(En),$i();break;case 26:case 27:case 5:vd(t);break;case 4:$i();break;case 31:t.memoizedState!==null&&To(t);break;case 13:To(t);break;case 19:Om(t);break;case 10:oa(t.type);break;case 22:case 23:To(t),Dm(),e!==null&&Fn(Ms);break;case 24:oa(En)}}function Ac(e,t){try{var n=t.updateQueue,o=n!==null?n.lastEffect:null;if(o!==null){var l=o.next;n=l;do{if((n.tag&e)===e){o=void 0;var a=n.create,c=n.inst;o=a(),c.destroy=o}n=n.next}while(n!==l)}}catch(f){Qt(t,t.return,f)}}function Wa(e,t,n){try{var o=t.updateQueue,l=o!==null?o.lastEffect:null;if(l!==null){var a=l.next;o=a;do{if((o.tag&e)===e){var c=o.inst,f=c.destroy;if(f!==void 0){c.destroy=void 0,l=t;var v=n,N=f;try{N()}catch($){Qt(l,v,$)}}}o=o.next}while(o!==a)}}catch($){Qt(t,t.return,$)}}function hx(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{C5(t,n)}catch(o){Qt(e,e.return,o)}}}function gx(e,t,n){n.props=Bs(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(o){Qt(e,t,o)}}function jl(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:var l=e.stateNode,a=aa(e.memoizedProps,l);(l.ref===null||l.ref.name!==a)&&(l.ref=s2(a)),o=l.ref;break;case 7:if(e.stateNode===null){var c=new Bo(e);ko(e.child,!1,r7,c,void 0,void 0),e.stateNode=c}o=e.stateNode;break;default:o=e.stateNode}typeof n=="function"?e.refCleanup=n(o):n.current=o}}catch(f){Qt(e,t,f)}}function Gn(e,t){var n=e.ref,o=e.refCleanup;if(n!==null)if(typeof o=="function")try{o()}catch(l){Qt(e,t,l)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(l){Qt(e,t,l)}else n.current=null}function Ld(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)u2(e.stateNode,t[n])}function qp(e){for(var t=e.return;t!==null&&(Km(t)&&u2(e.stateNode,t.stateNode),!Zm(t));)t=t.return}function lc(e){for(var t=e.return;t!==null&&(Km(t)&&c7(e.stateNode,t.stateNode),!Zm(t));)t=t.return}function Zm(e){return e.tag===5||e.tag===3||e.tag===27}function Km(e){return e&&e.tag===7&&e.stateNode!==null}function $f(e){var t=e.type,n=e.memoizedProps,o=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&o.focus();break e;case"img":n.src?o.src=n.src:n.srcSet&&(o.srcset=n.srcSet)}}catch(l){Qt(e,e.return,l)}}function Q0(e,t,n){try{var o=e.stateNode;X8(o,e.type,n,t),o[Co]=t}catch(l){Qt(e,e.return,l)}}function px(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Ka(e.type)||e.tag===4}function G0(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||px(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Ka(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function If(e,t,n,o){var l=e.tag;if(l===5||l===6)l=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(l,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(l),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=Tl)),Ld(e,o),Nt=!0;else if(l!==4&&(l===27&&(Ld(e,o),o=null,Ka(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(If(e,t,n,o),e=e.sibling;e!==null;)If(e,t,n,o),e=e.sibling}function Bd(e,t,n,o){var l=e.tag;if(l===5||l===6)l=e.stateNode,t?n.insertBefore(l,t):n.appendChild(l),Ld(e,o),Nt=!0;else if(l!==4&&(l===27&&(Ld(e,o),o=null,Ka(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(Bd(e,t,n,o),e=e.sibling;e!==null;)Bd(e,t,n,o),e=e.sibling}function yx(e){var t=e.stateNode,n=e.memoizedProps;try{for(var o=e.type,l=t.attributes;l.length;)t.removeAttributeNode(l[0]);Kn(t,o,n),t[Vn]=e,t[Co]=n}catch(a){Qt(e,e.return,a)}}var Hd=!1,No=null;function Xp(e){(e.tag===30||(e.subtreeFlags&33554432)!==0)&&(Hd=!0)}var El=null;function Qp(){var e=El;return El=null,e}var vo=0;function nr(e,t,n,o,l){return vo=0,xx(e.child,t,n,o,l)}function xx(e,t,n,o,l){for(var a=!1;e!==null;){if(e.tag===5){var c=e.stateNode;if(o!==null){var f=im(c);o.push(f),f.view&&(a=!0)}else a||im(c).view&&(a=!0);Hd=!0,o2(c,vo===0?t:t+"_"+vo,n),vo++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&l||xx(e.child,t,n,o,l)&&(a=!0));e=e.sibling}return a}function Ol(e,t){for(;e!==null;)e.tag===5?l2(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Ol(e.child,t)),e=e.sibling}function ud(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(ud(e),e.tag===30&&(e.flags&18874368)!==0&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name==="auto")throw Error(J(544));var n=t.name;t=da(t.default,t.share),t!=="none"&&(nr(e,n,t,null,!1)||Ol(e.child,!1))}e=e.sibling}}function Yf(e,t){if(e.tag===30){var n=e.stateNode,o=e.memoizedProps,l=aa(o,n),a=da(o.default,n.paired?o.share:o.enter);a!=="none"?nr(e,l,a,null,!1)?(ud(e),n.paired||t||Qi(e,o.onEnter)):Ol(e.child,!1):ud(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Yf(e,t),e=e.sibling;else ud(e)}function qf(e){if(No!==null&&No.size!==0){var t=No;if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var n=e.memoizedProps,o=n.name;if(o!=null&&o!=="auto"){var l=t.get(o);if(l!==void 0){var a=da(n.default,n.share);if(a!=="none"&&(nr(e,o,a,null,!1)?(a=e.stateNode,l.paired=a,a.paired=l,Qi(e,n.onShare)):Ol(e.child,!1)),t.delete(o),t.size===0)break}}}qf(e)}e=e.sibling}}}function Xf(e){if(e.tag===30){var t=e.memoizedProps,n=aa(t,e.stateNode),o=No!==null?No.get(n):void 0,l=da(t.default,o!==void 0?t.share:t.exit);l!=="none"&&(nr(e,n,l,null,!1)?o!==void 0?(l=e.stateNode,o.paired=l,l.paired=o,No.delete(n),Qi(e,t.onShare)):Qi(e,t.onExit):Ol(e.child,!1)),No!==null&&qf(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Xf(e),e=e.sibling;else No!==null&&qf(e)}function bx(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=aa(t,e.stateNode);t=da(t.default,t.update),e.flags&=-5,t!=="none"&&nr(e,n,t,e.memoizedState=[],!1)}else(e.subtreeFlags&33554432)!==0&&bx(e);e=e.sibling}}function Qf(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var t=e.stateNode;t.paired!==null&&(t.paired=null,Ol(e.child,!1))}Qf(e)}e=e.sibling}}function dd(e){if(e.tag===30)e.stateNode.paired=null,Ol(e.child,!1),Qf(e);else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)dd(e),e=e.sibling;else Qf(e)}function vx(e){for(e=e.child;e!==null;)e.tag===30?Ol(e.child,!1):(e.subtreeFlags&33554432)!==0&&vx(e),e=e.sibling}function Jm(e,t,n,o,l,a,c){for(var f=!1;t!==null;){if(t.tag===5){var v=t.stateNode;if(a!==null&&vo<a.length){var N=a[vo],$=im(v);(N.view||$.view)&&(f=!0);var V;if(V=(e.flags&4)===0)if($.clip)V=!0;else{V=N.rect;var A=$.rect;V=V.y!==A.y||V.x!==A.x||V.height!==A.height||V.width!==A.width}V&&(e.flags|=4),$.abs?$=!N.abs:(N=N.rect,$=$.rect,$=N.height!==$.height||N.width!==$.width),$&&(e.flags|=32)}else e.flags|=32;(e.flags&4)!==0&&o2(v,vo===0?n:n+"_"+vo,l),f&&(e.flags&4)!==0||(El===null&&(El=[]),El.push(v,vo===0?o:o+"_"+vo,t.memoizedProps)),vo++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&c?e.flags|=t.flags&32:Jm(e,t.child,n,o,l,a,c)&&(f=!0));t=t.sibling}return f}function wx(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,o=e.stateNode,l=aa(n,o),a=da(n.default,n.update);if(t){o=o.clones;var c=o===null?null:o.map(Z8)}else c=e.memoizedState,e.memoizedState=null;o=e;var f=e.child;vo=0,l=Jm(o,f,l,l,a,c,!1),(e.flags&4)!==0&&l&&(t||Qi(e,n.onUpdate))}else(e.subtreeFlags&33554432)!==0&&wx(e,t);e=e.sibling}}var Ln=!1,$t=!1,Sl=!1,V0=!1,Gp=typeof WeakSet=="function"?WeakSet:Set,Bn=null,kl=!1,Wr=!1,Ud=!1,Gf=!1;function v8(e,t,n){if(e=e.containerInfo,lm=Ki,e=i5(e),km(e)){if("selectionStart"in e)var o={start:e.selectionStart,end:e.selectionEnd};else e:{o=(o=e.ownerDocument)&&o.defaultView||window;var l=o.getSelection&&o.getSelection();if(l&&l.rangeCount!==0){o=l.anchorNode;var a=l.anchorOffset,c=l.focusNode;l=l.focusOffset;try{o.nodeType,c.nodeType}catch{o=null;break e}var f=0,v=-1,N=-1,$=0,V=0,A=e,U=null;t:for(;;){for(var ce;A!==o||a!==0&&A.nodeType!==3||(v=f+a),A!==c||l!==0&&A.nodeType!==3||(N=f+l),A.nodeType===3&&(f+=A.nodeValue.length),(ce=A.firstChild)!==null;)U=A,A=ce;for(;;){if(A===e)break t;if(U===o&&++$===a&&(v=f),U===c&&++V===l&&(N=f),(ce=A.nextSibling)!==null)break;A=U,U=A.parentNode}A=ce}o=v===-1||N===-1?null:{start:v,end:N}}else o=null}o=o||{start:0,end:0}}else o=null;for(am={focusedElem:e,selectionRange:o},Ki=!1,n=(n&335544064)===n,Bn=t,t=n?9270:1024;Bn!==null;){if(e=Bn,n&&(o=e.deletions,o!==null))for(a=0;a<o.length;a++)n&&Xf(o[a]);if(e.alternate===null&&(e.flags&2)!==0)n&&Xp(e),Vu(n);else{if(e.tag===22){if(o=e.alternate,e.memoizedState!==null){o!==null&&o.memoizedState===null&&n&&Xf(o),Vu(n);continue}else if(o!==null&&o.memoizedState!==null){n&&Xp(e),Vu(n);continue}}o=e.child,(e.subtreeFlags&t)!==0&&o!==null?(o.return=e,Bn=o):(n&&bx(e),Vu(n))}}No=null}function Vu(e){for(;Bn!==null;){var t=Bn,n=e,o=t.alternate,l=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if((l&1024)!==0&&o!==null){n=void 0,l=o.memoizedProps,o=o.memoizedState;var a=t.stateNode;try{var c=Bs(t.type,l);n=a.getSnapshotBeforeUpdate(c,o),a.__reactInternalSnapshotBeforeUpdate=n}catch(f){Qt(t,t.return,f)}}break;case 3:if((l&1024)!==0){if(o=t.stateNode.containerInfo,n=o.nodeType,n===9)rm(o);else if(n===1)switch(o.nodeName){case"HEAD":case"HTML":case"BODY":rm(o);break;default:o.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&o!==null&&(n=aa(o.memoizedProps,o.stateNode),l=t.memoizedProps,l=da(l.default,l.update),l!=="none"&&nr(o,n,l,o.memoizedState=[],!0));break;default:if((l&1024)!==0)throw Error(J(163))}if(o=t.sibling,o!==null){o.return=t.return,Bn=o;break}Bn=t.return}}function Sx(e,t,n){var o=n.flags;switch(n.tag){case 0:case 11:case 15:Cl(e,n),o&4&&Ac(5,n);break;case 1:if(Cl(e,n),o&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(c){Qt(n,n.return,c)}else{var l=Bs(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(l,t,e.__reactInternalSnapshotBeforeUpdate)}catch(c){Qt(n,n.return,c)}}o&64&&hx(n),o&512&&jl(n,n.return);break;case 3:if(Cl(e,n),o&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{C5(e,t)}catch(c){Qt(n,n.return,c)}}break;case 27:t===null&&o&4&&yx(n);case 26:case 5:Cl(e,n),t===null&&o&4&&$f(n),o&512&&jl(n,n.return);break;case 12:Cl(e,n);break;case 31:Cl(e,n),o&4&&Ex(e,n);break;case 13:Cl(e,n),o&4&&Mx(e,n),o&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=D8.bind(null,n),_7(e,n))));break;case 22:if(o=n.memoizedState!==null||Ln,!o){var a=t!==null&&t.memoizedState!==null||$t;t=Ln,l=$t,Ln=o,($t=a)&&!l?(o=2,(n.subtreeFlags&8772)!==0&&(o|=1),il(e,n,o)):Cl(e,n),Ln=t,$t=l}break;case 30:Cl(e,n),o&512&&jl(n,n.return);break;case 7:o&512&&jl(n,n.return);default:Cl(e,n)}}function Vf(e,t){for(e=e.child;e!==null;)kx(e,t),e=e.sibling}function kx(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var o=n.style;typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"}else{var l=e.stateNode,a=e.memoizedProps.style,c=a!=null&&a.hasOwnProperty("display")?a.display:null;l.style.display=c==null||typeof c=="boolean"?"":(""+c).trim()}}catch(v){Qt(e,e.return,v)}Wf(e,t);break;case 6:try{e.stateNode.nodeValue=t?"":e.memoizedProps,Nt=!0}catch(v){Qt(e,e.return,v)}break;case 18:try{var f=e.stateNode;t?ry(f,!0):ry(e.stateNode,!1)}catch(v){Qt(e,e.return,v)}break;case 22:case 23:e.memoizedState===null&&Vf(e,t);break;default:Vf(e,t)}}function Wf(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){e:{var n=e,o=t;switch(n.tag){case 4:kx(n,o);break e;case 22:n.memoizedState===null&&Wf(n,o);break e;default:Wf(n,o)}}e=e.sibling}}function Cx(e){var t=e.alternate;t!==null&&(e.alternate=null,Cx(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&Fd(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var fn=null,xo=!1;function sl(e,t,n){for(n=n.child;n!==null;)jx(e,t,n),n=n.sibling}function jx(e,t,n){if(Do&&typeof Do.onCommitFiberUnmount=="function")try{Do.onCommitFiberUnmount(Cc,n)}catch{}switch(n.tag){case 26:$t||Gn(n,t),sl(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!$t&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:$t||Gn(n,t),lc(n);var o=fn,l=xo;Ka(n.type)&&(fn=n.stateNode,xo=!1),sl(e,t,n),f2(n.stateNode,n.type,n.memoizedProps),fn=o,xo=l;break;case 5:$t||Gn(n,t),lc(n);case 6:if(n.tag===6&&lc(n),o=fn,l=xo,fn=null,sl(e,t,n),fn=o,xo=l,fn!==null)if(xo)try{(fn.nodeType===9?fn.body:fn.nodeName==="HTML"?fn.ownerDocument.body:fn).removeChild(n.stateNode),Nt=!0}catch(a){Qt(n,t,a)}else try{fn.removeChild(n.stateNode),Nt=!0}catch(a){Qt(n,t,a)}break;case 18:fn!==null&&(xo?(e=fn,iy(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),Ji(e)):iy(fn,n.stateNode));break;case 4:o=fn,l=xo,fn=n.stateNode.containerInfo,xo=!0,sl(e,t,n),fn=o,xo=l;break;case 0:case 11:case 14:case 15:Wa(2,n,t),$t||Wa(4,n,t),sl(e,t,n);break;case 1:$t||(Gn(n,t),o=n.stateNode,typeof o.componentWillUnmount=="function"&&gx(n,t,o)),sl(e,t,n);break;case 21:sl(e,t,n);break;case 22:$t=(o=$t)||n.memoizedState!==null,sl(e,t,n),$t=o;break;case 30:Gn(n,t),sl(e,t,n);break;case 7:$t||Gn(n,t),sl(e,t,n);break;default:sl(e,t,n)}}function Ex(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Ji(e)}catch(n){Qt(t,t.return,n)}}}function Mx(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Ji(e)}catch(n){Qt(t,t.return,n)}}function w8(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Gp),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Gp),t;default:throw Error(J(435,e.tag))}}function Wu(e,t){var n=w8(e);t.forEach(function(o){if(!n.has(o)){n.add(o);var l=O8.bind(null,e,o);o.then(l,l)}})}function uo(e,t,n){var o=t.deletions;if(o!==null)for(var l=0;l<o.length;l++){var a=o[l],c=e,f=t,v=f;e:for(;v!==null;){switch(v.tag){case 27:if(Ka(v.type)){fn=v.stateNode,xo=!1;break e}break;case 5:fn=v.stateNode,xo=!1;break e;case 3:case 4:fn=v.stateNode.containerInfo,xo=!0;break e}v=v.return}if(fn===null)throw Error(J(160));jx(c,f,a),fn=null,xo=!1,c=a.alternate,c!==null&&(c.return=null),a.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Tx(t,e,n),t=t.sibling}var rl=null;function Tx(e,t,n){var o=e.alternate,l=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(l&4&&(o=e.updateQueue,o=o!==null?o.events:null,o!==null))for(var a=0;a<o.length;a++){var c=o[a];c.ref.impl=c.nextImpl}uo(t,e,n),_o(e),l&4&&(Wa(3,e,e.return),Ac(3,e),Wa(5,e,e.return));break;case 1:uo(t,e,n),_o(e),l&512&&($t||o===null||Gn(o,o.return)),l&64&&Ln&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(a=rl,uo(t,e,n),_o(e),l&512&&($t||o===null||Gn(o,o.return)),l&4)if(l=o!==null?o.memoizedState:null,n=e.memoizedState,o===null)if(n===null)if(e.stateNode===null)if(Ln)e.stateNode=n2(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,n=e.memoizedProps,l=a.ownerDocument||a;t:switch(t){case"title":o=l.getElementsByTagName("title")[0],(!o||o[Mc]||o[Vn]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=l.createElement(t),l.head.insertBefore(o,l.querySelector("head > title"))),Kn(o,t,n),o[Vn]=e,Hn(o),t=o;break e;case"link":if(a=gy("link","href",l).get(t+(n.href||""))){for(c=0;c<a.length;c++)if(o=a[c],o.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&o.getAttribute("rel")===(n.rel==null?null:n.rel)&&o.getAttribute("title")===(n.title==null?null:n.title)&&o.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){a.splice(c,1);break t}}o=l.createElement(t),Kn(o,t,n),l.head.appendChild(o);break;case"meta":if(a=gy("meta","content",l).get(t+(n.content||""))){for(c=0;c<a.length;c++)if(o=a[c],o.getAttribute("content")===(n.content==null?null:""+n.content)&&o.getAttribute("name")===(n.name==null?null:n.name)&&o.getAttribute("property")===(n.property==null?null:n.property)&&o.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&o.getAttribute("charset")===(n.charSet==null?null:n.charSet)){a.splice(c,1);break t}}o=l.createElement(t),Kn(o,t,n),l.head.appendChild(o);break;default:throw Error(J(468,t))}o[Vn]=e,Hn(o),t=o}e.stateNode=t}else Ln||dm(a,e.type,e.stateNode);else e.stateNode=hy(a,n,e.memoizedProps);else l!==n?(l===null?(t=o.stateNode,t===null||$t||t.parentNode.removeChild(t)):l.count--,n===null?Ln||dm(a,e.type,e.stateNode):hy(a,n,e.memoizedProps)):n===null&&e.stateNode!==null&&Q0(e,e.memoizedProps,o.memoizedProps);break;case 27:uo(t,e,n),_o(e),l&512&&($t||o===null||Gn(o,o.return)),o!==null&&l&4&&Q0(e,e.memoizedProps,o.memoizedProps);break;case 5:if(a=Sl,Sl=!1,uo(t,e,n),Sl=a,_o(e),l&512&&($t||o===null||Gn(o,o.return)),e.flags&32){t=e.stateNode;try{Yi(t,""),Nt=!0}catch($){Qt(e,e.return,$)}}l&4&&e.stateNode!=null&&(t=e.memoizedProps,Q0(e,t,o!==null?o.memoizedProps:t)),l&1024&&(V0=!0);break;case 6:if(uo(t,e,n),_o(e),l&4){if(e.stateNode===null)throw Error(J(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,Nt=!0}catch($){Qt(e,e.return,$)}}break;case 3:if(Nt=!1,hd=null,a=rl,rl=bc(t.containerInfo),uo(t,e,n),rl=a,_o(e),l&4&&o!==null&&o.memoizedState.isDehydrated)try{Ji(t.containerInfo)}catch($){Qt(e,e.return,$)}V0&&(V0=!1,Nx(e)),Nt=!1;break;case 4:l=Sl,Sl=Ln,o=J1(),a=rl,rl=bc(e.stateNode.containerInfo),uo(t,e,n),_o(e),rl=a,Nt&&Wr&&(Ud=!0),Nt=o,Sl=l;break;case 12:uo(t,e,n),_o(e);break;case 31:uo(t,e,n),_o(e),l&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Wu(e,t)));break;case 13:uo(t,e,n),_o(e),e.child.flags&8192&&e.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(r_=Ao()),l&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Wu(e,t)));break;case 22:a=e.memoizedState!==null,c=o!==null&&o.memoizedState!==null;var f=Ln,v=$t,N=Sl;Ln=f||a,Sl=N||a,$t=v||c,uo(t,e,n),$t=v,Sl=N,Ln=f,_o(e),l&8192&&(t=e.stateNode,t._visibility=a?t._visibility&-2:t._visibility|1,!a||o===null||c||Ln||$t||(t=c||$t,n=Ln,o=$t,Ln=a||Ln,$t=t,Ca(e,2),Ln=n,$t=o),!a&&Sl||Vf(e,a)),l&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,Wu(e,n))));break;case 19:uo(t,e,n),_o(e),l&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Wu(e,t)));break;case 30:l&512&&($t||o===null||Gn(o,o.return)),l=J1(),a=Wr,c=(n&335544064)===n,f=e.memoizedProps,Wr=c&&da(f.default,f.update)!=="none",uo(t,e,n),_o(e),c&&o!==null&&Nt&&(e.flags|=4),Wr=a,Nt=l;break;case 21:break;case 7:l&512&&($t||o===null||Gn(o,o.return)),o&&o.stateNode!==null&&(o.stateNode._fragmentFiber=e);default:uo(t,e,n),_o(e)}}function _o(e){var t=e.flags;if(t&2){try{for(var n,o=e.return;o!==null;){if(px(o)){n=o;break}o=o.return}o=null;for(var l=e.return;l!==null;){if(Km(l)){var a=l.stateNode;o===null?o=[a]:o.push(a)}if(Zm(l))break;l=l.return}var c=o;if(n==null)throw Error(J(160));switch(n.tag){case 27:var f=n.stateNode,v=G0(e);Bd(e,v,f,c);break;case 5:var N=n.stateNode;n.flags&32&&(Yi(N,""),n.flags&=-33);var $=G0(e);Bd(e,$,N,c);break;case 3:case 4:var V=n.stateNode.containerInfo,A=G0(e);If(e,A,V,c);break;default:throw Error(J(161))}}catch(U){Qt(e,e.return,U)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Nx(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Nx(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,Ki=!0,t.reset(),Ki=!1),e=e.sibling}}function mi(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)Rx(t,e),t=t.sibling;else wx(t,!1)}function Rx(e,t){var n=e.alternate;if(n===null)Yf(e,!1);else switch(e.tag){case 3:if(Gf=kl=!1,Qp(),mi(t,e),!kl&&!Ud){if(e=El,e!==null)for(var o=0;o<e.length;o+=3){n=e[o];var l=e[o+1];l2(n,e[o+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+l+")"})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===""&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),Gf=!0}El=null;break;case 5:mi(t,e);break;case 4:o=kl,kl=!1,mi(t,e),kl&&(Ud=!0),kl=o;break;case 22:e.memoizedState===null&&(n.memoizedState!==null?Yf(e,!1):mi(t,e));break;case 30:o=kl,l=Qp(),kl=!1,mi(t,e),kl&&(e.flags|=4);var a=e.memoizedProps,c=e.stateNode;t=aa(a,c),c=aa(n.memoizedProps,c);var f=da(a.default,a.update);f==="none"?t=!1:(a=n.memoizedState,n.memoizedState=null,n=e.child,vo=0,t=Jm(e,n,t,c,f,a,!0),vo!==(a===null?0:a.length)&&(e.flags|=32)),(e.flags&4)!==0&&t?(Qi(e,e.memoizedProps.onUpdate),El=l):l!==null&&(l.push.apply(l,El),El=l),kl=(e.flags&32)!==0?!0:o;break;default:mi(t,e)}}function Cl(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Sx(e,t.alternate,t),t=t.sibling}function Ca(e,t){for(e=e.child;e!==null;){var n=e,o=t;switch(n.tag){case 0:case 11:case 14:case 15:Wa(4,n,n.return),Ca(n,o);break;case 1:Gn(n,n.return);var l=n.stateNode;typeof l.componentWillUnmount=="function"&&gx(n,n.return,l),Ca(n,o);break;case 27:(o&2)!==0&&f2(n.stateNode,n.type,n.memoizedProps);case 5:Gn(n,n.return),n.tag!==5&&n.tag!==27||lc(n),Ca(n,o);break;case 6:lc(n);break;case 26:Gn(n,n.return),l=n.stateNode,n.memoizedState!==null||l===null||$t||l.parentNode.removeChild(l),Ca(n,o);break;case 22:n.memoizedState===null&&Ca(n,o);break;case 30:Gn(n,n.return),Ca(n,o);break;case 7:Gn(n,n.return);default:Ca(n,o)}e=e.sibling}}function il(e,t,n){for(n=(t.subtreeFlags&8772)!==0?n:n&-2,t=t.child;t!==null;){var o=t.alternate,l=e,a=t,c=a.flags,f=(n&1)!==0;switch(a.tag){case 0:case 11:case 15:il(l,a,n),Ac(4,a);break;case 1:if(il(l,a,n),o=a,l=o.stateNode,typeof l.componentDidMount=="function")try{l.componentDidMount()}catch($){Qt(o,o.return,$)}if(o=a,l=o.updateQueue,l!==null){var v=o.stateNode;try{var N=l.shared.hiddenCallbacks;if(N!==null)for(l.shared.hiddenCallbacks=null,l=0;l<N.length;l++)k5(N[l],v)}catch($){Qt(o,o.return,$)}}f&&c&64&&hx(a),jl(a,a.return);break;case 27:(n&2)!==0&&yx(a);case 5:a.tag!==5&&a.tag!==27||qp(a),il(l,a,n),f&&o===null&&c&4&&$f(a),jl(a,a.return);break;case 6:qp(a);break;case 26:v=a.stateNode,a.memoizedState!==null||v===null||Ln||dm(bc(v.ownerDocument),a.type,v),il(l,a,n),f&&o===null&&c&4&&$f(a),jl(a,a.return);break;case 12:il(l,a,n);break;case 31:il(l,a,n),f&&c&4&&Ex(l,a);break;case 13:il(l,a,n),f&&c&4&&Mx(l,a);break;case 22:a.memoizedState===null&&il(l,a,n),jl(a,a.return);break;case 30:il(l,a,n),jl(a,a.return);break;case 7:jl(a,a.return);default:il(l,a,n)}t=t.sibling}}function Pm(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&Nc(n))}function eh(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Nc(e))}function Qo(e,t,n,o){var l=(n&335544064)===n;if(t.subtreeFlags&(l?10262:10256))for(t=t.child;t!==null;)Ax(e,t,n,o),t=t.sibling;else l&&vx(t)}function Ax(e,t,n,o){var l=(n&335544064)===n;l&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&dd(t);var a=t.flags;switch(t.tag){case 0:case 11:case 15:Qo(e,t,n,o),a&2048&&Ac(9,t);break;case 1:Qo(e,t,n,o);break;case 3:Qo(e,t,n,o),l&&Gf&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,e.style.viewTransitionName==="root"&&(e.style.viewTransitionName=""),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName==="none"&&(e.style.viewTransitionName="")),a&2048&&(a=null,t.alternate!==null&&(a=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==a&&(t.refCount++,a!=null&&Nc(a)));break;case 12:if(a&2048){Qo(e,t,n,o),a=t.stateNode;try{var c=t.memoizedProps,f=c.id,v=c.onPostCommit;typeof v=="function"&&v(f,t.alternate===null?"mount":"update",a.passiveEffectDuration,-0)}catch(N){Qt(t,t.return,N)}}else Qo(e,t,n,o);break;case 31:Qo(e,t,n,o);break;case 13:Qo(e,t,n,o);break;case 23:break;case 22:c=t.stateNode,f=t.alternate,t.memoizedState!==null?(l&&f!==null&&f.memoizedState===null&&dd(f),c._visibility&2?Qo(e,t,n,o):ac(e,t)):(l&&f!==null&&f.memoizedState!==null&&dd(t),c._visibility&2?Qo(e,t,n,o):(c._visibility|=2,gi(e,t,n,o,(t.subtreeFlags&10256)!==0||!1))),a&2048&&Pm(f,t);break;case 24:Qo(e,t,n,o),a&2048&&eh(t.alternate,t);break;case 30:l&&(a=t.alternate,a!==null&&(Ol(a.child,!0),Ol(t.child,!0))),Qo(e,t,n,o);break;default:Qo(e,t,n,o)}}function gi(e,t,n,o,l){for(l=l&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var a=e,c=t,f=n,v=o,N=c.flags;switch(c.tag){case 0:case 11:case 15:gi(a,c,f,v,l),Ac(8,c);break;case 23:break;case 22:var $=c.stateNode;c.memoizedState!==null?$._visibility&2?gi(a,c,f,v,l):ac(a,c):($._visibility|=2,gi(a,c,f,v,l)),l&&N&2048&&Pm(c.alternate,c);break;case 24:gi(a,c,f,v,l),l&&N&2048&&eh(c.alternate,c);break;default:gi(a,c,f,v,l)}t=t.sibling}}function ac(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,o=t,l=o.flags;switch(o.tag){case 22:ac(n,o),l&2048&&Pm(o.alternate,o);break;case 24:ac(n,o),l&2048&&eh(o.alternate,o);break;default:ac(n,o)}t=t.sibling}}var Ss=8192;function bs(e,t,n){if(e.subtreeFlags&Ss)for(e=e.child;e!==null;)Dx(e,t,n),e=e.sibling}function Dx(e,t,n){switch(e.tag){case 26:bs(e,t,n),e.flags&Ss&&(e.memoizedState!==null?j7(n,rl,e.memoizedState,e.memoizedProps):(e=e.stateNode,(t&335544128)===t&&yy(n,e)));break;case 5:bs(e,t,n),e.flags&Ss&&(e=e.stateNode,(t&335544128)===t&&yy(n,e));break;case 3:case 4:var o=rl;rl=bc(e.stateNode.containerInfo),bs(e,t,n),rl=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=Ss,Ss=16777216,bs(e,t,n),Ss=o):bs(e,t,n));break;case 30:if((e.flags&Ss)!==0&&(o=e.memoizedProps.name,o!=null&&o!=="auto")){var l=e.stateNode;l.paired=null,No===null&&(No=new Map),No.set(o,l)}bs(e,t,n);break;default:bs(e,t,n)}}function Ox(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Ir(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];Bn=o,Lx(o,e)}Ox(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)zx(e),e=e.sibling}function zx(e){switch(e.tag){case 0:case 11:case 15:Ir(e),e.flags&2048&&Wa(9,e,e.return);break;case 3:Ir(e);break;case 12:Ir(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,_d(e)):Ir(e);break;default:Ir(e)}}function _d(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var o=t[n];Bn=o,Lx(o,e)}Ox(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Wa(8,t,t.return),_d(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,_d(t));break;default:_d(t)}e=e.sibling}}function Lx(e,t){for(;Bn!==null;){var n=Bn;switch(n.tag){case 0:case 11:case 15:Wa(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var o=n.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:Nc(n.memoizedState.cache)}if(o=n.child,o!==null)o.return=n,Bn=o;else e:for(n=e;Bn!==null;){o=Bn;var l=o.sibling,a=o.return;if(Cx(o),o===n){Bn=null;break e}if(l!==null){l.return=a,Bn=l;break e}Bn=a}}}var S8={getCacheForType:function(e){var t=Wn(En),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return Wn(En).controller.signal}},k8=typeof WeakMap=="function"?WeakMap:Map,Lt=0,Kt=null,pt=null,yt=0,qt=0,Eo=null,Aa=!1,or=!1,th=!1,ca=0,xn=0,Fa=0,Ns=0,$d=0,Ro=0,Xi=0,sc=null,bo=null,Ff=!1,r_=0,Bx=0,Id=1/0,Yd=null,Ia=null,hn=0,ul=null,Hs=null,Dl=0,Zf=0,Kf=null,Hx=null,Bi=null,Hi=null,Ui=null,ic=0,fd=null;function zo(){return(Lt&2)!==0&&yt!==0?yt&-yt:qe.T!==null?oh():Yy()}function Ux(){if(Ro===0)if((yt&536870912)===0||dt){var e=zu;zu<<=1,(zu&3932160)===0&&(zu=262144),Ro=e}else Ro=536870912;return e=Jn.current,e!==null&&(e.flags|=32),Ro}function Qi(e,t){if(t!=null){var n=e.stateNode,o=n.ref;o===null&&(o=n.ref=s2(aa(e.memoizedProps,n))),Hi===null&&(Hi=[]),Hi.push(t.bind(null,o))}}function So(e,t,n){(e===Kt&&(qt===2||qt===9)||e.cancelPendingCommit!==null)&&(Gi(e,0),Da(e,yt,Ro,!1)),Ec(e,n),((Lt&2)===0||e!==Kt)&&(e===Kt&&((Lt&2)===0&&(Ns|=n),xn===4&&Da(e,yt,Ro,!1)),Ll(e))}function $x(e,t,n){if((Lt&6)!==0)throw Error(J(327));var o=!n&&(t&127)===0&&(t&e.expiredLanes)===0||jc(e,t),l=o?E8(e,t):W0(e,t,!0),a=o;do{if(l===0){or&&!o&&Da(e,t,0,!1);break}else{if(n=e.current.alternate,a&&!C8(n)){l=W0(e,t,!1),a=!1;continue}if(l===2){if(a=t,e.errorRecoveryDisabledLanes&a)var c=0;else c=e.pendingLanes&-536870913,c=c!==0?c:c&536870912?536870912:0;if(c!==0){t=c;e:{var f=e;l=sc;var v=f.current.memoizedState.isDehydrated;if(v&&(Gi(f,c).flags|=256),c=W0(f,c,!1),c!==2&&c!==6){if(th&&!v){f.errorRecoveryDisabledLanes|=a,Ns|=a,l=4;break e}a=bo,bo=l,a!==null&&(bo===null?bo=a:bo.push.apply(bo,a))}l=c}if(a=!1,l!==2)continue}}if(l===1){Gi(e,0),Da(e,t,0,!0);break}e:{switch(o=e,a=l,a){case 0:case 1:throw Error(J(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:Da(o,t,Ro,!Aa);break e;case 2:bo=null;break;case 3:case 5:break;default:throw Error(J(329))}if((t&62914560)===t&&(l=r_+300-Ao(),10<l)){if(Da(o,t,Ro,!Aa),Wd(o,0,!0)!==0)break e;Dl=t,o.timeoutHandle=ah(Vp.bind(null,o,n,bo,Yd,Ff,t,Ro,Ns,Xi,Aa,a,"Throttled",-0,0),l);break e}Vp(o,n,bo,Yd,Ff,t,Ro,Ns,Xi,Aa,a,null,-0,0)}}break}while(!0);Ll(e)}function Vp(e,t,n,o,l,a,c,f,v,N,$,V,A,U){e.timeoutHandle=-1;var ce=t.subtreeFlags,he=(a&335544064)===a;if(V=null,(he||ce&8192||(ce&16785408)===16785408)&&(V={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Tl},No=null,Dx(t,a,V),he&&(ce=V,he=e.containerInfo,he=(he.nodeType===9?he:he.ownerDocument).__reactViewTransition,he!=null&&(ce.count++,ce.waitingForViewTransition=!0,ce=vc.bind(ce),he.finished.then(ce,ce))),ce=(a&62914560)===a?r_-Ao():(a&4194048)===a?Bx-Ao():0,ce=E7(V,ce),ce!==null)){Dl=a,e.cancelPendingCommit=ce(Fp.bind(null,e,t,a,n,o,l,c,f,v,N,$,V,null,A,U)),Da(e,a,c,!N);return}Fp(e,t,a,n,o,l,c,f,v,N,$,V)}function C8(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var o=0;o<n.length;o++){var l=n[o],a=l.getSnapshot;l=l.value;try{if(!Lo(a(),l))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Da(e,t,n,o){t=By(e,t),t&=~$d,t&=~Ns,e.suspendedLanes|=t,e.pingedLanes&=~t,o&&(e.warmLanes|=t),o=e.expirationTimes;for(var l=t;0<l;){var a=31-Oo(l),c=1<<a;o[a]=-1,l&=~c}n!==0&&Uy(e,n,t)}function c_(){return(Lt&6)===0?(Dc(0,!1),!1):!0}function nh(){if(pt!==null){if(qt===0)var e=pt.return;else e=pt,ta=qs=null,Um(e),Oi=null,mc=0,e=pt;for(;e!==null;)mx(e.alternate,e),e=e.return;pt=null}}function Gi(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,V8(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),Dl=0,nh(),Kt=e,pt=n=na(e.current,null),yt=t,qt=0,Eo=null,Aa=!1,or=jc(e,t),th=!1,Xi=Ro=$d=Ns=Fa=xn=0,bo=sc=null,Ff=!1,ca=By(e,t),Pd(),n}function Ix(e,t){at=null,qe.H=Od,t===tr||t===n_?(t=bp(),qt=3):t===Rm?(t=bp(),qt=4):qt=t===Vm?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,Eo=t,pt===null&&(xn=1,zd(e,Zo(t,e.current)))}function Yx(){var e=Jn.current;return e===null?!0:(yt&4194048)===yt?ao===null:(yt&62914560)===yt||(yt&536870912)!==0?e===ao:!1}function qx(){var e=qe.H;return qe.H=Od,e===null?Od:e}function Xx(){var e=qe.A;return qe.A=S8,e}function qd(){xn=4,Aa||(yt&4194048)!==yt&&Jn.current!==null||(or=!0),(Fa&134217727)===0&&(Ns&134217727)===0||Kt===null||Da(Kt,yt,Ro,!1)}function W0(e,t,n){var o=Lt;Lt|=2;var l=qx(),a=Xx();(Kt!==e||yt!==t)&&(Yd=null,Gi(e,t)),t=!1;var c=xn;e:do try{if(qt!==0&&pt!==null){var f=pt,v=Eo;switch(qt){case 8:nh(),c=6;break e;case 3:case 2:case 9:case 6:Jn.current===null&&(t=!0);var N=qt;if(qt=0,Eo=null,Ti(e,f,v,N),n&&or){c=0;break e}break;default:N=qt,qt=0,Eo=null,Ti(e,f,v,N)}}j8(),c=xn;break}catch($){Ix(e,$)}while(!0);return t&&e.shellSuspendCounter++,ta=qs=null,Lt=o,qe.H=l,qe.A=a,pt===null&&(Kt=null,yt=0,Pd()),c}function j8(){for(;pt!==null;)Qx(pt)}function E8(e,t){var n=Lt;Lt|=2;var o=qx(),l=Xx();Kt!==e||yt!==t?(Yd=null,Id=Ao()+500,Gi(e,t)):or=jc(e,t);e:do try{if(qt!==0&&pt!==null){t=pt;var a=Eo;t:switch(qt){case 1:qt=0,Eo=null,Ti(e,t,a,1);break;case 2:case 9:if(xp(a)){qt=0,Eo=null,Wp(t);break}t=function(){qt!==2&&qt!==9||Kt!==e||(qt=7),Ll(e)},a.then(t,t);break e;case 3:qt=7;break e;case 4:qt=5;break e;case 7:xp(a)?(qt=0,Eo=null,Wp(t)):(qt=0,Eo=null,Ti(e,t,a,7));break;case 5:var c=null;switch(pt.tag){case 26:c=pt.memoizedState;case 5:case 27:var f=pt;if(c?g2(c):f.stateNode.complete){qt=0,Eo=null;var v=f.sibling;if(v!==null)pt=v;else{var N=f.return;N!==null?(pt=N,u_(N)):pt=null}break t}}qt=0,Eo=null,Ti(e,t,a,5);break;case 6:qt=0,Eo=null,Ti(e,t,a,6);break;case 8:nh(),xn=6;break e;default:throw Error(J(462))}}M8();break}catch($){Ix(e,$)}while(!0);return ta=qs=null,qe.H=o,qe.A=l,Lt=n,pt!==null?0:(Kt=null,yt=0,Pd(),xn)}function M8(){for(;pt!==null&&!Q3();)Qx(pt)}function Qx(e){var t=fx(e.alternate,e,ca);e.memoizedProps=e.pendingProps,t===null?u_(e):pt=t}function Wp(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Lp(n,t,t.pendingProps,t.type,void 0,yt);break;case 11:t=Lp(n,t,t.pendingProps,t.type.render,t.ref,yt);break;case 5:Um(t);var o=t;o===Un&&(dt?(Ed(o),o.tag===5&&o.stateNode!=null&&(on=o.stateNode)):(Ed(o),dt=!0));default:mx(n,t),t=pt=h5(t,ca),t=fx(n,t,ca)}e.memoizedProps=e.pendingProps,t===null?u_(e):pt=t}function Ti(e,t,n,o){ta=qs=null,Um(t),Oi=null,mc=0;var l=t.return;try{if(h8(e,l,t,n,yt)){xn=1,zd(e,Zo(n,e.current)),pt=null;return}}catch(a){if(l!==null)throw pt=l,a;xn=1,zd(e,Zo(n,e.current)),pt=null;return}t.flags&32768?(dt||o===1?e=!0:or||(yt&536870912)!==0?e=!1:(Aa=e=!0,(o===2||o===9||o===3||o===6)&&(o=Jn.current,o!==null&&o.tag===13&&(o.flags|=16384))),Gx(t,e)):u_(t)}function u_(e){var t=e;do{if((t.flags&32768)!==0){Gx(t,Aa);return}e=t.return;var n=x8(t.alternate,t,ca);if(n!==null){pt=n;return}if(t=t.sibling,t!==null){pt=t;return}pt=t=e}while(t!==null);xn===0&&(xn=5)}function Gx(e,t){do{var n=b8(e.alternate,e);if(n!==null){n.flags&=32767,pt=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){pt=e;return}pt=e=n}while(e!==null);xn=6,pt=null}function Fp(e,t,n,o,l,a,c,f,v,N,$,V){e.cancelPendingCommit=null;do d_();while(hn!==0);if((Lt&6)!==0)throw Error(J(327));if(t!==null){if(t===e.current)throw Error(J(177));e===Kt&&(pt=Kt=null,yt=0),Hs=t,ul=e,Dl=n,Kf=l,Hx=o,T8(e,t,n,c,f,v,V)}}function T8(e,t,n,o,l,a,c){var f=t.lanes|t.childLanes;if(Zf=f,f|=Cm,t6(e,n,f,o,l,a),Hi=null,(n&335544064)===n?(Ui=o8(e),o=10262):(Ui=null,o=10256),(t.subtreeFlags&o)!==0||(t.flags&o)!==0?(e.callbackNode=null,e.callbackPriority=0,z8(wd,function(){return tm(),null})):(e.callbackNode=null,e.callbackPriority=0),Hd=!1,o=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||o){o=qe.T,qe.T=null,l=Bt.p,Bt.p=2,a=Lt,Lt|=4;try{v8(e,t,n)}finally{Lt=a,Bt.p=l,qe.T=o}}hn=1,Hd?Bi=P8(c,e.containerInfo,Ui,Jf,Pf,R8,em,tm,N8,null,null):(Jf(),Pf(),em())}function N8(e){if(hn!==0){var t=ul.onRecoverableError;t(e,{componentStack:null})}}function R8(){hn===3&&(hn=0,Rx(Hs,ul),hn=4)}function Jf(){if(hn===1){hn=0;var e=ul,t=Hs,n=Dl,o=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||o){o=qe.T,qe.T=null;var l=Bt.p;Bt.p=2;var a=Lt;Lt|=4;try{Wr=Ud=!1,Tx(t,e,n),n=am;var c=i5(e.containerInfo),f=n.focusedElem,v=n.selectionRange;if(c!==f&&f&&f.ownerDocument&&s5(f.ownerDocument.documentElement,f)){if(v!==null&&km(f)){var N=v.start,$=v.end;if($===void 0&&($=N),"selectionStart"in f)f.selectionStart=N,f.selectionEnd=Math.min($,f.value.length);else{var V=f.ownerDocument||document,A=V&&V.defaultView||window;if(A.getSelection){var U=A.getSelection(),ce=f.textContent.length,he=Math.min(v.start,ce),Ne=v.end===void 0?he:Math.min(v.end,ce);!U.extend&&he>Ne&&(c=Ne,Ne=he,he=c);var T=dp(f,he),C=dp(f,Ne);if(T&&C&&(U.rangeCount!==1||U.anchorNode!==T.node||U.anchorOffset!==T.offset||U.focusNode!==C.node||U.focusOffset!==C.offset)){var z=V.createRange();z.setStart(T.node,T.offset),U.removeAllRanges(),he>Ne?(U.addRange(z),U.extend(C.node,C.offset)):(z.setEnd(C.node,C.offset),U.addRange(z))}}}}for(V=[],U=f;U=U.parentNode;)U.nodeType===1&&V.push({element:U,left:U.scrollLeft,top:U.scrollTop});for(typeof f.focus=="function"&&f.focus(),f=0;f<V.length;f++){var L=V[f];L.element.scrollLeft=L.left,L.element.scrollTop=L.top}}Ki=!!lm,am=lm=null}finally{Lt=a,Bt.p=l,qe.T=o}}e.current=t,hn=2}}function Pf(){if(hn===2){hn=0;var e=ul,t=Hs,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=qe.T,qe.T=null;var o=Bt.p;Bt.p=2;var l=Lt;Lt|=4;try{Sx(e,t.alternate,t)}finally{Lt=l,Bt.p=o,qe.T=n}}hn=3}}function em(){if(hn===4||hn===3){hn=0;var e=Bi;Bi=null,G3();var t=ul,n=Hs,o=Dl,l=Hx,a=(o&335544064)===o?10262:10256;if((n.subtreeFlags&a)!==0||(n.flags&a)!==0?hn=5:(hn=0,Hs=ul=null,Vx(t,t.pendingLanes)),a=t.pendingLanes,a===0&&(Ia=null),ym(o),n=n.stateNode,Do&&typeof Do.onCommitFiberRoot=="function")try{Do.onCommitFiberRoot(Cc,n,void 0,(n.current.flags&128)===128)}catch{}if(l!==null){n=qe.T,a=Bt.p,Bt.p=2,qe.T=null;try{for(var c=t.onRecoverableError,f=0;f<l.length;f++){var v=l[f];c(v.value,{componentStack:v.stack})}}finally{qe.T=n,Bt.p=a}}if(l=Hi,c=Ui,Ui=null,l!==null&&(Hi=null,c===null&&(c=[]),e!==null))for(v=0;v<l.length;v++)n=(0,l[v])(c),n!==void 0&&e.finished.finally(n);(Dl&3)!==0&&d_(),Ll(t),a=t.pendingLanes,(o&261930)!==0&&(a&42)!==0?t===fd?ic++:(ic=0,fd=t):(ic=0,fd=null),Dc(0,!1)}}function Vx(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Nc(t)))}function d_(){return Bi!==null&&(Bi.skipTransition(),Bi=null),Jf(),Pf(),em(),tm()}function tm(){if(hn!==5)return!1;var e=ul,t=Zf;Zf=0;var n=ym(Dl),o=qe.T,l=Bt.p;try{Bt.p=32>n?32:n,qe.T=null,n=Kf,Kf=null;var a=ul,c=Dl;if(hn=0,Hs=ul=null,Dl=0,(Lt&6)!==0)throw Error(J(331));var f=Lt;if(Lt|=4,zx(a.current),Ax(a,a.current,c,n),Lt=f,Dc(0,!1),Do&&typeof Do.onPostCommitFiberRoot=="function")try{Do.onPostCommitFiberRoot(Cc,a)}catch{}return!0}finally{Bt.p=l,qe.T=o,Vx(e,t)}}function Zp(e,t,n){t=Zo(n,t),t=Of(e.stateNode,t,2),e=Ha(e,t,2),e!==null&&(Ec(e,2),Ll(e))}function Qt(e,t,n){if(e.tag===3)Zp(e,e,n);else for(;t!==null;){if(t.tag===3){Zp(t,e,n);break}else if(t.tag===1){var o=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Ia===null||!Ia.has(o))){e=Zo(n,e),n=rx(2),o=Ha(t,n,2),o!==null&&(cx(n,o,t,e),Ec(o,2),Ll(o));break}}t=t.return}}function F0(e,t,n){var o=e.pingCache;if(o===null){o=e.pingCache=new k8;var l=new Set;o.set(t,l)}else l=o.get(t),l===void 0&&(l=new Set,o.set(t,l));l.has(n)||(th=!0,l.add(n),e=A8.bind(null,e,t,n),t.then(e,e))}function A8(e,t,n){var o=e.pingCache;o!==null&&o.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,Kt===e&&(yt&n)===n&&((xn===4||xn===3&&(yt&62914560)===yt&&300>Ao()-r_)&&(Lt&2)===0?Gi(e,0):$d|=n,Xi===yt&&(Xi=0)),Ll(e)}function Wx(e,t){t===0&&(t=Hy()),e=Ys(e,t),e!==null&&(Ec(e,t),Ll(e))}function D8(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Wx(e,n)}function O8(e,t){var n=0;switch(e.tag){case 31:case 13:var o=e.stateNode,l=e.memoizedState;l!==null&&(n=l.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(J(314))}o!==null&&o.delete(t),Wx(e,n)}function z8(e,t){return gm(e,t)}var Vi=null,pi=null,nm=!1,Xd=!1,Z0=!1,Oa=0;function Ll(e){e!==pi&&e.next===null&&(pi===null?Vi=pi=e:pi=pi.next=e),Xd=!0,nm||(nm=!0,B8())}function Dc(e,t){if(!Z0&&Xd){Z0=!0;do for(var n=!1,o=Vi;o!==null;){if(!t)if(e!==0){var l=o.pendingLanes;if(l===0)var a=0;else{var c=o.suspendedLanes,f=o.pingedLanes;a=(1<<31-Oo(42|e)+1)-1,a&=l&~(c&~f),a=a&201326741?a&201326741|1:a?a|2:0}a!==0&&(n=!0,Kp(o,a))}else a=yt,a=Wd(o,o===Kt?a:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(a&3)===0||jc(o,a)||(n=!0,Kp(o,a));o=o.next}while(n);Z0=!1}}function L8(){Fx()}function Fx(){Xd=nm=!1;var e=0;Oa!==0&&G8()&&(e=Oa);for(var t=Ao(),n=null,o=Vi;o!==null;){var l=o.next,a=Zx(o,t);a===0?(o.next=null,n===null?Vi=l:n.next=l,l===null&&(pi=n)):(n=o,(e!==0||(a&3)!==0)&&(Xd=!0)),o=l}hn!==0&&hn!==5||Dc(e,!1),Oa!==0&&(Oa=0)}function Zx(e,t){for(var n=e.suspendedLanes,o=e.pingedLanes,l=e.expirationTimes,a=e.pendingLanes&-62914561;0<a;){var c=31-Oo(a),f=1<<c,v=l[c];v===-1?((f&n)===0||(f&o)!==0)&&(l[c]=e6(f,t)):v<=t&&(e.expiredLanes|=f),a&=~f}if(t=Kt,n=yt,n=Wd(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,n===0||e===t&&(qt===2||qt===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&M0(o),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||jc(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(o!==null&&M0(o),ym(n)){case 2:case 8:n=zy;break;case 32:n=wd;break;case 268435456:n=Ly;break;default:n=wd}return o=Kx.bind(null,e),n=gm(n,o),e.callbackPriority=t,e.callbackNode=n,t}return o!==null&&o!==null&&M0(o),e.callbackPriority=2,e.callbackNode=null,2}function Kx(e,t){if(hn!==0&&hn!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(d_()&&e.callbackNode!==n)return null;var o=yt;return o=Wd(e,e===Kt?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:($x(e,o,t),Zx(e,Ao()),e.callbackNode!=null&&e.callbackNode===n?Kx.bind(null,e):null)}function Kp(e,t){if(d_())return null;$x(e,t,!0)}function B8(){W8(function(){(Lt&6)!==0?gm(Oy,L8):Fx()})}function oh(){if(Oa===0){var e=Os;e===0&&(e=Ou,Ou<<=1,(Ou&261888)===0&&(Ou=256)),Oa=e}return Oa}function Jp(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:td(e)}function H8(e,t,n,o,l){if(t==="submit"&&n&&n.stateNode===l){var a=Jp((l[Co]||null).action),c=o.submitter;c&&(t=(t=c[Co]||null)?Jp(t.formAction):c.getAttribute("formAction"),t!==null&&(a=t,c=null));var f=new Zd("action","action",null,o,l);e.push({event:f,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(Oa!==0){var v=new FormData(l,c);Af(n,{pending:!0,data:v,method:l.method,action:a},null,v)}}else typeof a=="function"&&(f.preventDefault(),v=new FormData(l,c),Af(n,{pending:!0,data:v,method:l.method,action:a},a,v))},currentTarget:l}]})}}for(Fu=0;Fu<vf.length;Fu++)Zu=vf[Fu],Pp=Zu.toLowerCase(),ey=Zu[0].toUpperCase()+Zu.slice(1),dl(Pp,"on"+ey);var Zu,Pp,ey,Fu;dl(c5,"onAnimationEnd");dl(u5,"onAnimationIteration");dl(d5,"onAnimationStart");dl("dblclick","onDoubleClick");dl("focusin","onFocus");dl("focusout","onBlur");dl(F6,"onTransitionRun");dl(Z6,"onTransitionStart");dl(K6,"onTransitionCancel");dl(_5,"onTransitionEnd");Ii("onMouseEnter",["mouseout","mouseover"]);Ii("onMouseLeave",["mouseout","mouseover"]);Ii("onPointerEnter",["pointerout","pointerover"]);Ii("onPointerLeave",["pointerout","pointerover"]);$s("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));$s("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));$s("onBeforeInput",["compositionend","keypress","textInput","paste"]);$s("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));$s("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));$s("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var pc="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),U8=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(pc));function Jx(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var o=e[n],l=o.event;o=o.listeners;e:{var a=void 0;if(t)for(var c=o.length-1;0<=c;c--){var f=o[c],v=f.instance,N=f.currentTarget;if(f=f.listener,v!==a&&l.isPropagationStopped())break e;a=f,l.currentTarget=N;try{a(l)}catch($){kd($)}l.currentTarget=null,a=v}else for(c=0;c<o.length;c++){if(f=o[c],v=f.instance,N=f.currentTarget,f=f.listener,v!==a&&l.isPropagationStopped())break e;a=f,l.currentTarget=N;try{a(l)}catch($){kd($)}l.currentTarget=null,a=v}}}}function gt(e,t){var n=t[W1];n===void 0&&(n=t[W1]=new Set);var o=e+"__bubble";n.has(o)||(Px(t,e,2,!1),n.add(o))}function K0(e,t,n){var o=0;t&&(o|=4),Px(n,e,o,t)}var Ku="_reactListening"+Math.random().toString(36).slice(2);function lh(e){if(!e[Ku]){e[Ku]=!0,Xy.forEach(function(n){n!=="selectionchange"&&(U8.has(n)||K0(n,!1,e),K0(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Ku]||(t[Ku]=!0,K0("selectionchange",!1,t))}}function Px(e,t,n,o){switch(S2(t)){case 2:var l=R7;break;case 8:l=A7;break;default:l=dh}n=l.bind(null,t,n,e),l=void 0,!pf||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(l=!0),o?l!==void 0?e.addEventListener(t,n,{capture:!0,passive:l}):e.addEventListener(t,n,!0):l!==void 0?e.addEventListener(t,n,{passive:l}):e.addEventListener(t,n,!1)}function J0(e,t,n,o,l){var a=o;if((t&1)===0&&(t&2)===0&&o!==null)e:for(;;){if(o===null)return;var c=o.tag;if(c===3||c===4){var f=o.stateNode.containerInfo;if(f===l)break;if(c===4)for(c=o.return;c!==null;){var v=c.tag;if((v===3||v===4)&&c.stateNode.containerInfo===l)return;c=c.return}for(;f!==null;){if(c=ks(f),c===null)return;if(v=c.tag,v===5||v===6||v===26||v===27){o=a=c;continue e}f=f.parentNode}}o=o.return}Jy(function(){var N=a,$=bm(n),V=[];e:{var A=f5.get(e);if(A!==void 0){var U=Zd,ce=e;switch(e){case"keypress":if(od(n)===0)break e;case"keydown":case"keyup":U=C6;break;case"focusin":ce="focus",U=O0;break;case"focusout":ce="blur",U=O0;break;case"beforeblur":case"afterblur":U=O0;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":U=np;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":U=f6;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":U=N6;break;case c5:case u5:case d5:U=g6;break;case _5:U=A6;break;case"scroll":case"scrollend":U=d6;break;case"wheel":U=O6;break;case"copy":case"cut":case"paste":U=y6;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":U=lp;break;case"submit":U=M6;break;case"toggle":case"beforetoggle":U=L6}var he=(t&4)!==0,Ne=!he&&(e==="scroll"||e==="scrollend"),T=he?A!==null?A+"Capture":null:A;he=[];for(var C=N,z;C!==null;){var L=C;if(z=L.stateNode,L=L.tag,L!==5&&L!==26&&L!==27||z===null||T===null||(L=cc(C,T),L!=null&&he.push(yc(C,L,z))),Ne)break;C=C.return}0<he.length&&(A=new U(A,ce,null,n,$),V.push({event:A,listeners:he}))}}if((t&7)===0){e:{if(U=e==="mouseover"||e==="pointerover",A=e==="mouseout"||e==="pointerout",U&&n!==gf&&(ce=n.relatedTarget||n.fromElement)&&(ks(ce)||ce[Pi]))break e;(A||U)&&(ce=$.window===$?$:(U=$.ownerDocument)?U.defaultView||U.parentWindow:window,A?(U=n.relatedTarget||n.toElement,A=N,U=U?ks(U):null,U!==null&&(Ne=kc(U),he=U.tag,U!==Ne||he!==5&&he!==27&&he!==6)&&(U=null)):(A=null,U=N),A!==U&&(he=np,L="onMouseLeave",T="onMouseEnter",C="mouse",(e==="pointerout"||e==="pointerover")&&(he=lp,L="onPointerLeave",T="onPointerEnter",C="pointer"),Ne=A==null?ce:Gr(A),z=U==null?ce:Gr(U),ce=new he(L,C+"leave",A,n,$),ce.target=Ne,ce.relatedTarget=z,L=null,ks($)===N&&(he=new he(T,C+"enter",U,n,$),he.target=z,he.relatedTarget=Ne,L=he),Ne=L,he=A&&U?of(A,U,$8):null,A!==null&&ty(V,ce,A,he,!1),U!==null&&Ne!==null&&ty(V,Ne,U,he,!0)))}e:{if(A=N?Gr(N):window,U=A.nodeName&&A.nodeName.toLowerCase(),U==="select"||U==="input"&&A.type==="file")var de=rp;else if(ip(A))if(l5)de=G6;else{de=X6;var _e=q6}else U=A.nodeName,!U||U.toLowerCase()!=="input"||A.type!=="checkbox"&&A.type!=="radio"?N&&xm(N.elementType)&&(de=rp):de=Q6;if(de&&(de=de(e,N))){o5(V,de,n,$);break e}_e&&_e(e,A,N)}switch(_e=N?Gr(N):window,e){case"focusin":(ip(_e)||_e.contentEditable==="true")&&(Si=_e,xf=N,Kr=null);break;case"focusout":Kr=xf=Si=null;break;case"mousedown":bf=!0;break;case"contextmenu":case"mouseup":case"dragend":bf=!1,_p(V,n,$);break;case"selectionchange":if(W6)break;case"keydown":case"keyup":_p(V,n,$)}var be;if(Sm)e:{switch(e){case"compositionstart":var Ce="onCompositionStart";break e;case"compositionend":Ce="onCompositionEnd";break e;case"compositionupdate":Ce="onCompositionUpdate";break e}Ce=void 0}else wi?t5(e,n)&&(Ce="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(Ce="onCompositionStart");Ce&&(e5&&n.locale!=="ko"&&(wi||Ce!=="onCompositionStart"?Ce==="onCompositionEnd"&&wi&&(be=Py()):(Na=$,vm="value"in Na?Na.value:Na.textContent,wi=!0)),_e=Qd(N,Ce),0<_e.length&&(Ce=new op(Ce,e,null,n,$),V.push({event:Ce,listeners:_e}),be?Ce.data=be:(be=n5(n),be!==null&&(Ce.data=be)))),(be=H6?U6(e,n):$6(e,n))&&(Ce=Qd(N,"onBeforeInput"),0<Ce.length&&(_e=new op("onBeforeInput","beforeinput",null,n,$),V.push({event:_e,listeners:Ce}),_e.data=be)),H8(V,e,N,n,$)}Jx(V,t)})}function yc(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Qd(e,t){for(var n=t+"Capture",o=[];e!==null;){var l=e,a=l.stateNode;if(l=l.tag,l!==5&&l!==26&&l!==27||a===null||(l=cc(e,n),l!=null&&o.unshift(yc(e,l,a)),l=cc(e,t),l!=null&&o.push(yc(e,l,a))),e.tag===3)return o;e=e.return}return[]}function $8(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function ty(e,t,n,o,l){for(var a=t._reactName,c=[];n!==null&&n!==o;){var f=n,v=f.alternate,N=f.stateNode;if(f=f.tag,v!==null&&v===o)break;f!==5&&f!==26&&f!==27||N===null||(v=N,l?(N=cc(n,a),N!=null&&c.unshift(yc(n,N,v))):l||(N=cc(n,a),N!=null&&c.push(yc(n,N,v)))),n=n.return}c.length!==0&&e.push({event:t,listeners:c})}var I8=/\r\n?/g,Y8=/\u0000|\uFFFD/g;function ny(e){return(typeof e=="string"?e:""+e).replace(I8,`
`).replace(Y8,"")}function e2(e,t){return t=ny(t),ny(e)===t}function Xt(e,t,n,o,l,a){switch(n){case"children":if(typeof o=="string")t==="body"||t==="textarea"&&o===""||Yi(e,o);else if(typeof o=="number"||typeof o=="bigint")t!=="body"&&Yi(e,""+o);else return;break;case"className":Bu(e,"class",o);break;case"tabIndex":Bu(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":Bu(e,n,o);break;case"style":Ky(e,o,a);return;case"data":if(t!=="object"){Bu(e,"data",o);break}case"src":case"href":if(o===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=td(o),e.setAttribute(n,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof a=="function"&&(n==="formAction"?(t!=="input"&&Xt(e,t,"name",l.name,l,null),Xt(e,t,"formEncType",l.formEncType,l,null),Xt(e,t,"formMethod",l.formMethod,l,null),Xt(e,t,"formTarget",l.formTarget,l,null)):(Xt(e,t,"encType",l.encType,l,null),Xt(e,t,"method",l.method,l,null),Xt(e,t,"target",l.target,l,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(n);break}o=td(o),e.setAttribute(n,o);break;case"onClick":o!=null&&(e.onclick=Tl);return;case"onScroll":o!=null&&gt("scroll",e);return;case"onScrollEnd":o!=null&&gt("scrollend",e);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(J(61));if(n=o.__html,n!=null){if(l.children!=null)throw Error(J(60));a?.__html!==n&&(e.innerHTML=n)}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}n=td(o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":o===!0?e.setAttribute(n,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(n,o):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(n,o):e.removeAttribute(n);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(n):e.setAttribute(n,o);break;case"popover":gt("beforetoggle",e),gt("toggle",e),ed(e,"popover",o);break;case"xlinkActuate":Jl(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Jl(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Jl(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Jl(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Jl(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Jl(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Jl(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Jl(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Jl(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":ed(e,"is",o);break;case"innerText":case"textContent":return;default:if(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")n=c6.get(n)||n,ed(e,n,o);else return}Nt=!0}function om(e,t,n,o,l,a){switch(n){case"style":Ky(e,o,a);return;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(J(61));if(n=o.__html,n!=null){if(l.children!=null)throw Error(J(60));a?.__html!==n&&(e.innerHTML=n)}}break;case"children":if(typeof o=="string")Yi(e,o);else if(typeof o=="number"||typeof o=="bigint")Yi(e,""+o);else return;break;case"onScroll":o!=null&&gt("scroll",e);return;case"onScrollEnd":o!=null&&gt("scrollend",e);return;case"onClick":o!=null&&(e.onclick=Tl);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!Qy.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(l=n.endsWith("Capture"),a=n.slice(2,l?n.length-7:void 0),t=e[Co]||null,t=t!=null?t[n]:null,typeof t=="function"&&e.removeEventListener(a,t,l),typeof o=="function")){typeof t!="function"&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(a,o,l);break e}Nt=!0,n in e?e[n]=o:o===!0?e.setAttribute(n,""):ed(e,n,o)}return}Nt=!0}function Kn(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":gt("error",e),gt("load",e);var o=!1,l=!1,a;for(a in n)if(n.hasOwnProperty(a)){var c=n[a];if(c!=null)switch(a){case"src":o=!0;break;case"srcSet":l=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(J(137,t));default:Xt(e,t,a,c,n,null)}}l&&Xt(e,t,"srcSet",n.srcSet,n,null),o&&Xt(e,t,"src",n.src,n,null);return;case"input":gt("invalid",e);var f=a=c=l=null,v=null,N=null;for(o in n)if(n.hasOwnProperty(o)){var $=n[o];if($!=null)switch(o){case"name":l=$;break;case"type":c=$;break;case"checked":v=$;break;case"defaultChecked":N=$;break;case"value":a=$;break;case"defaultValue":f=$;break;case"children":case"dangerouslySetInnerHTML":if($!=null)throw Error(J(137,t));break;default:Xt(e,t,o,$,n,null)}}Wy(e,a,f,v,N,c,l,!1);return;case"select":gt("invalid",e),o=c=a=null;for(l in n)if(n.hasOwnProperty(l)&&(f=n[l],f!=null))switch(l){case"value":a=f;break;case"defaultValue":c=f;break;case"multiple":o=f;default:Xt(e,t,l,f,n,null)}t=a,n=c,e.multiple=!!o,t!=null?Ri(e,!!o,t,!1):n!=null&&Ri(e,!!o,n,!0);return;case"textarea":gt("invalid",e),a=l=o=null;for(c in n)if(n.hasOwnProperty(c)&&(f=n[c],f!=null))switch(c){case"value":o=f;break;case"defaultValue":l=f;break;case"children":a=f;break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(J(91));break;default:Xt(e,t,c,f,n,null)}Zy(e,o,l,a);return;case"option":for(v in n)if(n.hasOwnProperty(v)&&(o=n[v],o!=null))switch(v){case"selected":e.selected=o&&typeof o!="function"&&typeof o!="symbol";break;default:Xt(e,t,v,o,n,null)}return;case"dialog":gt("beforetoggle",e),gt("toggle",e),gt("cancel",e),gt("close",e);break;case"iframe":case"object":gt("load",e);break;case"video":case"audio":for(o=0;o<pc.length;o++)gt(pc[o],e);break;case"image":gt("error",e),gt("load",e);break;case"details":gt("toggle",e);break;case"embed":case"source":case"link":gt("error",e),gt("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(N in n)if(n.hasOwnProperty(N)&&(o=n[N],o!=null))switch(N){case"children":case"dangerouslySetInnerHTML":throw Error(J(137,t));default:Xt(e,t,N,o,n,null)}return;default:if(xm(t)){for($ in n)n.hasOwnProperty($)&&(o=n[$],o!==void 0&&om(e,t,$,o,n,void 0));return}}for(f in n)n.hasOwnProperty(f)&&(o=n[f],o!=null&&Xt(e,t,f,o,n,null))}var q8={};function X8(e,t,n,o){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var l=null,a=null,c=null,f=null,v=null,N=null,$=null;for(U in n){var V=n[U];if(n.hasOwnProperty(U)&&V!=null)switch(U){case"checked":break;case"value":break;case"defaultValue":v=V;default:o.hasOwnProperty(U)||Xt(e,t,U,null,o,V)}}for(var A in o){var U=o[A];if(V=n[A],o.hasOwnProperty(A)&&(U!=null||V!=null))switch(A){case"type":U!==V&&(Nt=!0),a=U;break;case"name":U!==V&&(Nt=!0),l=U;break;case"checked":U!==V&&(Nt=!0),N=U;break;case"defaultChecked":U!==V&&(Nt=!0),$=U;break;case"value":U!==V&&(Nt=!0),c=U;break;case"defaultValue":U!==V&&(Nt=!0),f=U;break;case"children":case"dangerouslySetInnerHTML":if(U!=null)throw Error(J(137,t));break;default:U!==V&&Xt(e,t,A,U,o,V)}}hf(e,c,f,v,N,$,a,l);return;case"select":U=c=f=A=null;for(a in n)if(v=n[a],n.hasOwnProperty(a)&&v!=null)switch(a){case"value":break;case"multiple":U=v;default:o.hasOwnProperty(a)||Xt(e,t,a,null,o,v)}for(l in o)if(a=o[l],v=n[l],o.hasOwnProperty(l)&&(a!=null||v!=null))switch(l){case"value":a!==v&&(Nt=!0),A=a;break;case"defaultValue":a!==v&&(Nt=!0),f=a;break;case"multiple":a!==v&&(Nt=!0),c=a;default:a!==v&&Xt(e,t,l,a,o,v)}t=f,n=c,o=U,A!=null?Ri(e,!!n,A,!1):!!o!=!!n&&(t!=null?Ri(e,!!n,t,!0):Ri(e,!!n,n?[]:"",!1));return;case"textarea":U=A=null;for(f in n)if(l=n[f],n.hasOwnProperty(f)&&l!=null&&!o.hasOwnProperty(f))switch(f){case"value":break;case"children":break;default:Xt(e,t,f,null,o,l)}for(c in o)if(l=o[c],a=n[c],o.hasOwnProperty(c)&&(l!=null||a!=null))switch(c){case"value":l!==a&&(Nt=!0),A=l;break;case"defaultValue":l!==a&&(Nt=!0),U=l;break;case"children":break;case"dangerouslySetInnerHTML":if(l!=null)throw Error(J(91));break;default:l!==a&&Xt(e,t,c,l,o,a)}Fy(e,A,U);return;case"option":for(var ce in n)if(A=n[ce],n.hasOwnProperty(ce)&&A!=null&&!o.hasOwnProperty(ce))switch(ce){case"selected":e.selected=!1;break;default:Xt(e,t,ce,null,o,A)}for(v in o)if(A=o[v],U=n[v],o.hasOwnProperty(v)&&A!==U&&(A!=null||U!=null))switch(v){case"selected":A!==U&&(Nt=!0),e.selected=A&&typeof A!="function"&&typeof A!="symbol";break;default:Xt(e,t,v,A,o,U)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var he in n)A=n[he],n.hasOwnProperty(he)&&A!=null&&!o.hasOwnProperty(he)&&Xt(e,t,he,null,o,A);for(N in o)if(A=o[N],U=n[N],o.hasOwnProperty(N)&&A!==U&&(A!=null||U!=null))switch(N){case"children":case"dangerouslySetInnerHTML":if(A!=null)throw Error(J(137,t));break;default:Xt(e,t,N,A,o,U)}return;default:if(xm(t)){for(var Ne in n)A=n[Ne],n.hasOwnProperty(Ne)&&A!==void 0&&!o.hasOwnProperty(Ne)&&om(e,t,Ne,void 0,o,A);for($ in o)A=o[$],U=n[$],!o.hasOwnProperty($)||A===U||A===void 0&&U===void 0||om(e,t,$,A,o,U);return}}for(var T in n)A=n[T],n.hasOwnProperty(T)&&A!=null&&!o.hasOwnProperty(T)&&Xt(e,t,T,null,o,A);for(V in o)A=o[V],U=n[V],!o.hasOwnProperty(V)||A===U||A==null&&U==null||Xt(e,t,V,A,o,U)}function oy(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function Q8(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),o=0;o<n.length;o++){var l=n[o],a=l.transferSize,c=l.initiatorType,f=l.duration;if(a&&f&&oy(c)){for(c=0,f=l.responseEnd,o+=1;o<n.length;o++){var v=n[o],N=v.startTime;if(N>f)break;var $=v.transferSize,V=v.initiatorType;$&&oy(V)&&(v=v.responseEnd,c+=$*(v<f?1:(f-N)/(v-N)))}if(--o,t+=8*(a+c)/(l.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var lm=null,am=null;function xc(e){return e.nodeType===9?e:e.ownerDocument}function ly(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function t2(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function n2(e,t,n,o){return n=xc(n).createElement(e),n[Vn]=o,n[Co]=t,Kn(n,e,t),Hn(n),n}function sm(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var P0=null;function G8(){var e=window.event;return e&&e.type==="popstate"?e===P0?!1:(P0=e,!0):(P0=null,!1)}var ah=typeof setTimeout=="function"?setTimeout:void 0,V8=typeof clearTimeout=="function"?clearTimeout:void 0,ay=typeof Promise=="function"?Promise:void 0,sy=typeof requestAnimationFrame=="function"?requestAnimationFrame:ah,W8=typeof queueMicrotask=="function"?queueMicrotask:typeof ay<"u"?function(e){return ay.resolve(null).then(e).catch(F8)}:ah;function F8(e){setTimeout(function(){throw e})}function Ka(e){return e==="head"}function iy(e,t){var n=t,o=0;do{var l=n.nextSibling;if(e.removeChild(n),l&&l.nodeType===8)if(n=l.data,n==="/$"||n==="/&"){if(o===0){e.removeChild(l),Ji(t);return}o--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")o++;else if(n==="html")tf(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,tf(n);for(var a=n.firstChild;a;){var c=a.nextSibling,f=a.nodeName;a[Mc]||f==="SCRIPT"||f==="STYLE"||f==="LINK"&&a.rel.toLowerCase()==="stylesheet"||n.removeChild(a),a=c}}else n==="body"&&tf(e.ownerDocument.body);n=l}while(n);Ji(t)}function ry(e,t){var n=e;e=0;do{var o=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=o}while(n)}function o2(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display==="inline"){if(t=e.getClientRects(),t.length===1)var o=1;else for(var l=o=0;l<t.length;l++){var a=t[l];0<a.width&&0<a.height&&o++}o===1&&(e=e.style,e.display=t.length===1?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function l2(e,t){e=e.style,t=t.style;var n=t!=null?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=n==null||typeof n=="boolean"?"":(""+n).trim(),n=t!=null?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=n==null||typeof n=="boolean"?"":(""+n).trim(),e.display==="inline-block"&&(t==null?e.display=e.margin="":(n=t.display,e.display=n==null||typeof n=="boolean"?"":n,n=t.margin,n!=null?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=n==null||typeof n=="boolean"?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=t==null||typeof t=="boolean"?"":t)))}function a2(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position==="absolute"||t.position==="fixed",clip:t.clipPath!=="none"||t.overflow!=="visible"||t.filter!=="none"||t.mask!=="none"||t.mask!=="none"||t.borderRadius!=="0px",view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function im(e){var t=e.getBoundingClientRect(),n=getComputedStyle(e);return a2(t,n,e)}function Z8(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return a2(t,n,e)}function K8(e){return e.documentElement.clientHeight}function J8(e){this.addEventListener("load",e),this.addEventListener("error",e)}function P8(e,t,n,o,l,a,c,f,v){var N=t.nodeType===9?t:t.ownerDocument;try{var $=N.startViewTransition({update:function(){var A=N.defaultView,U=A.navigation&&A.navigation.transition,ce=N.fonts.status;o();var he=[];if(ce==="loaded"&&(K8(N),N.fonts.status==="loading"&&he.push(N.fonts.ready)),ce=he.length,e!==null)for(var Ne=e.suspenseyImages,T=0,C=0;C<Ne.length;C++){var z=Ne[C];if(!z.complete){var L=z.getBoundingClientRect();if(0<L.bottom&&0<L.right&&L.top<A.innerHeight&&L.left<A.innerWidth){if(T+=p2(z),T>gd){he.length=ce;break}z=new Promise(J8.bind(z)),he.push(z)}}}if(0<he.length)return A=Promise.race([Promise.all(he),new Promise(function(de){return setTimeout(de,500)})]).then(l,l),(U?Promise.allSettled([U.finished,A]):A).then(a,a);if(l(),U)return U.finished.then(a,a);a()},types:n});N.__reactViewTransition=$;var V=[];return $.ready.then(function(){for(var A=N.documentElement.getAnimations({subtree:!0}),U=0;U<A.length;U++){var ce=A[U],he=ce.effect,Ne=he.pseudoElement;if(Ne!=null&&Ne.startsWith("::view-transition")){V.push(ce),ce=he.getKeyframes();for(var T=Ne=void 0,C=!0,z=0;z<ce.length;z++){var L=ce[z],de=L.width;if(Ne===void 0)Ne=de;else if(Ne!==de){C=!1;break}if(de=L.height,T===void 0)T=de;else if(T!==de){C=!1;break}delete L.width,delete L.height,L.transform==="none"&&delete L.transform}C&&Ne!==void 0&&T!==void 0&&(he.setKeyframes(ce),C=getComputedStyle(he.target,he.pseudoElement),C.width!==Ne||C.height!==T)&&(C=ce[0],C.width=Ne,C.height=T,C=ce[ce.length-1],C.width=Ne,C.height=T,he.setKeyframes(ce))}}c()},function(A){N.__reactViewTransition===$&&(N.__reactViewTransition=null);try{if(typeof A=="object"&&A!==null)switch(A.name){case"InvalidStateError":(A.message==="View transition was skipped because document visibility state is hidden."||A.message==="Skipping view transition because document visibility state has become hidden."||A.message==="Skipping view transition because viewport size changed."||A.message==="Transition was aborted because of invalid state")&&(A=null)}A!==null&&v(A)}finally{o(),l(),c()}}),$.finished.finally(function(){for(var A=0;A<V.length;A++)V[A].cancel();N.__reactViewTransition===$&&(N.__reactViewTransition=null),f()}),$}catch{return o(),l(),c(),null}}function Cs(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}Cs.prototype.animate=function(e,t){return t=typeof t=="number"?{duration:t}:Jt({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)};Cs.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),o=[],l=0;l<n.length;l++){var a=n[l].effect;a!==null&&a.target===e&&a.pseudoElement===t&&o.push(n[l])}return o};Cs.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function s2(e){return{name:e,group:new Cs("group",e),imagePair:new Cs("image-pair",e),old:new Cs("old",e),new:new Cs("new",e)}}function Bo(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}Bo.prototype.addEventListener=function(e,t,n){var o=null,l=null;if(!(n!=null&&typeof n!="boolean"&&(o=n.signal||null,o!==null&&o.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var a=this._eventListeners;if(i2(a,e,t,n)===-1){var c=this,f=t;n!=null&&typeof n!="boolean"&&n.once===!0&&(f=function(v){c.removeEventListener(e,t,n),typeof t=="function"?t.call(this,v):t.handleEvent(v)}),o!==null&&(l=c.removeEventListener.bind(c,e,t,n),o.addEventListener("abort",l,{once:!0}),l=o.removeEventListener.bind(o,"abort",l)),o=Wi(n),a.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:f,cleanup:l}),ko(this._fragmentFiber.child,!1,e7,e,f,o)}this._eventListeners=a}};function e7(e,t,n,o){return An(e).addEventListener(t,n,o),!1}Bo.prototype.removeEventListener=function(e,t,n){var o=this._eventListeners;if(o!==null&&(t=i2(o,e,t,n),t!==-1)){var l=o[t];n=l.attachedListener;var a=l.cleanup;l=Wi(l.optionsOrUseCapture),ko(this._fragmentFiber.child,!1,t7,e,n,l),o.splice(t,1),a!==null&&a()}};function t7(e,t,n,o){return An(e).removeEventListener(t,n,o),!1}function Wi(e){return e!=null&&typeof e!="boolean"&&(e.once===!0||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function cy(e){return e==null?"c=0":typeof e=="boolean"?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function i2(e,t,n,o){if(e.length===0)return-1;o=cy(o);for(var l=0;l<e.length;l++){var a=e[l];if(a.type===t&&a.listener===n&&cy(a.optionsOrUseCapture)===o)return l}return-1}Bo.prototype.dispatchEvent=function(e){var t=Us(this._fragmentFiber);if(t===null)return!0;t=An(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var o=t.nodeType===9?t.createComment(""):document.createTextNode("");if(n)for(var l=0;l<n.length;l++){var a=n[l];o.addEventListener(a.type,a.attachedListener,Wi(a.optionsOrUseCapture))}if(t.appendChild(o),e=o.dispatchEvent(e),n)for(l=0;l<n.length;l++)a=n[l],o.removeEventListener(a.type,a.attachedListener,Wi(a.optionsOrUseCapture));return t.removeChild(o),e}return t.dispatchEvent(e)};Bo.prototype.focus=function(e){ko(this._fragmentFiber.child,!0,r2,e,void 0,void 0)};function r2(e,t){return e.tag===6?!1:(e=An(e),f7(e,t))}Bo.prototype.focusLast=function(e){var t=[];ko(this._fragmentFiber.child,!0,sh,t,void 0,void 0);for(var n=t.length-1;0<=n&&!r2(t[n],e);n--);};function sh(e,t){return t.push(e),!1}Bo.prototype.blur=function(){var e=Us(this._fragmentFiber);e!==null&&(e=An(e),e=xc(e).activeElement,e!==null&&ko(this._fragmentFiber.child,!1,n7,e,void 0,void 0))};function n7(e,t){return e.tag===6?!1:(e=An(e),e===t||e.contains(t)?(t.blur(),!0):!1)}Bo.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),ko(this._fragmentFiber.child,!1,o7,e,void 0,void 0)};function o7(e,t){return e.tag===6||(e=An(e),t.observe(e)),!1}Bo.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),ko(this._fragmentFiber.child,!1,l7,e,void 0,void 0);for(var n=t=0;n<cl.length;n++){var o=cl[n];o.fragmentInstance===this&&o.observer===e?e.unobserve(o.instance):cl[t++]=o}cl.length=t}};function l7(e,t){return e.tag===6||(e=An(e),t.unobserve(e)),!1}var cl=[],ef=!1;function a7(e,t,n){cl.push({fragmentInstance:e,observer:t,instance:n}),ef||(ef=!0,m7(function(){ef=!1;var o=cl;cl=[];for(var l=0;l<o.length;l++){var a=o[l];a.observer.unobserve(a.instance)}}))}Bo.prototype.getClientRects=function(){var e=[];return ko(this._fragmentFiber.child,!1,s7,e,void 0,void 0),e};function s7(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=An(e),t.push.apply(t,e.getClientRects());return!1}Bo.prototype.getRootNode=function(e){var t=Us(this._fragmentFiber);return t===null?this:An(t).getRootNode(e)};Bo.prototype.compareDocumentPosition=function(e){var t=Us(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];ko(this._fragmentFiber.child,!1,sh,n,void 0,void 0);var o=An(t);if(n.length===0){if(n=o,Y1(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break e}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var l=o=n.compareDocumentPosition(e);return n===e?l=Node.DOCUMENT_POSITION_CONTAINS:o&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=Ny(t)[1],n===null?l=Node.DOCUMENT_POSITION_PRECEDING:(e=An(n).compareDocumentPosition(e),l=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),l|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=An(n[0]),l=An(n[n.length-1]);var a=Y1(this._fragmentFiber)?t.parentElement:o;if(a==null)return Node.DOCUMENT_POSITION_DISCONNECTED;o=a.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,a=a.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_CONTAINED_BY;var c=t.compareDocumentPosition(e),f=l.compareDocumentPosition(e),v=c&Node.DOCUMENT_POSITION_CONTAINED_BY||f&Node.DOCUMENT_POSITION_CONTAINED_BY;return f=o&&a&&c&Node.DOCUMENT_POSITION_FOLLOWING&&f&Node.DOCUMENT_POSITION_PRECEDING,t=o&&t===e||a&&l===e||v||f?Node.DOCUMENT_POSITION_CONTAINED_BY:!o&&t===e||!a&&l===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:c,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||i7(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function i7(e,t,n,o,l){var a=ks(l);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!a)e:{for(;a!==null;){if(a.tag===7&&(a===t||a.alternate===t)){n=!0;break e}a=a.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(a===null)return a=l.ownerDocument,l===a||l===a.documentElement||l===a.body;e:{for(a=t,t=Us(t);a!==null;){if(!(a.tag!==5&&a.tag!==3&&a.tag!==27||a!==t&&a.alternate!==t)){a=!0;break e}a=a.return}a=!1}return a}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!a)&&!(t=a===n)&&(t=of(n,a,q1),t===null?t=!1:(ko(t,!0,B3,a,n),a=yi,yi=null,t=a!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!a)&&!(t=a===o)&&(t=of(o,a,q1),t===null?t=!1:(ko(t,!0,H3,a,o),a=yi,nf=yi=null,t=a!==null)),t):!1}function uy(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}Bo.prototype.scrollIntoView=function(e){if(typeof e=="object")throw Error(J(566));var t=[];ko(this._fragmentFiber.child,!1,sh,t,void 0,void 0);var n=e!==!1;if(t.length===0){var o=Ny(this._fragmentFiber);if(o=n?o[1]||o[0]||Us(this._fragmentFiber):o[0]||o[1],o===null)return;if(o.tag===6){e=An(o),uy(e,n);return}if(o=An(o),o.nodeType!==9){if(o.nodeType===11){n="host"in o?o.host:null,n!==null&&n.scrollIntoView(e);return}o.scrollIntoView(e)}}for(o=n?t.length-1:0;o!==(n?-1:t.length);){var l=t[o];l.tag===6?(l=An(l),uy(l,n)):An(l).scrollIntoView(e),o+=n?-1:1}};function r7(e,t){return e=An(e),c2(e,t),!1}function c2(e,t){e.reactFragments==null&&(e.reactFragments=new Set),e.reactFragments.add(t)}function u2(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var l=n[o];e.addEventListener(l.type,l.attachedListener,Wi(l.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(a){for(var c=0,f=0;f<cl.length;f++){var v=cl[f];(v.fragmentInstance!==t||v.observer!==a||v.instance!==e)&&(cl[c++]=v)}cl.length=c,a.observe(e)}),c2(e,t))}function c7(e,t){var n=t._eventListeners;if(n!==null)for(var o=0;o<n.length;o++){var l=n[o];e.removeEventListener(l.type,l.attachedListener,Wi(l.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(a){typeof a.rootMargin=="string"?a7(t,a,e):a.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function rm(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":rm(n),Fd(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function u7(e,t,n,o){for(;e.nodeType===1;){var l=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[Mc])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(a=e.getAttribute("rel"),a==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(a!==l.rel||e.getAttribute("href")!==(l.href==null||l.href===""?null:l.href)||e.getAttribute("crossorigin")!==(l.crossOrigin==null?null:l.crossOrigin)||e.getAttribute("title")!==(l.title==null?null:l.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(a=e.getAttribute("src"),(a!==(l.src==null?null:l.src)||e.getAttribute("type")!==(l.type==null?null:l.type)||e.getAttribute("crossorigin")!==(l.crossOrigin==null?null:l.crossOrigin))&&a&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var a=l.name==null?null:""+l.name;if(l.type==="hidden"&&e.getAttribute("name")===a)return e}else return e;if(e=Jo(e.nextSibling),e===null)break}return null}function d7(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=Jo(e.nextSibling),e===null))return null;return e}function d2(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Jo(e.nextSibling),e===null))return null;return e}function cm(e){return e.data==="$?"||e.data==="$~"}function ih(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function _7(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var o=function(){t(),n.removeEventListener("DOMContentLoaded",o)};n.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function Jo(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var um=null;function dy(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return Jo(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function _y(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function f7(e,t){function n(){o=!0}if(e.ownerDocument.activeElement===e)return!0;var o=!1;try{e.ownerDocument.addEventListener("focus",n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",n,!0)}return o}function m7(e){sy(function(){sy(function(t){return e(t)})})}function _2(e,t,n){switch(t=xc(n),e){case"html":if(e=t.documentElement,!e)throw Error(J(452));return e;case"head":if(e=t.head,!e)throw Error(J(453));return e;case"body":if(e=t.body,!e)throw Error(J(454));return e;default:throw Error(J(451))}}function f2(e,t,n){for(var o in n){var l=n[o];n.hasOwnProperty(o)&&l!=null&&Xt(e,t,o,null,q8,l)}n.dangerouslySetInnerHTML!=null&&(e.textContent=""),e.onclick===Tl&&(e.onclick=null),Fd(e)}function tf(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Fd(e)}var Po=new Map,fy=new Set;function bc(e){if(typeof e.getRootNode=="function"){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var _a=Bt.d;Bt.d={f:h7,r:g7,D:p7,C:y7,L:x7,m:b7,X:w7,S:v7,M:S7};function h7(){var e=_a.f(),t=c_();return e||t}function g7(e){var t=er(e);t!==null&&t.tag===5&&t.type==="form"?K5(t):_a.r(e)}var lr=typeof document>"u"?null:document;function m2(e,t,n){var o=lr;if(o&&typeof t=="string"&&t){var l=Fo(t);l='link[rel="'+e+'"][href="'+l+'"]',typeof n=="string"&&(l+='[crossorigin="'+n+'"]'),fy.has(l)||(fy.add(l),e={rel:e,crossOrigin:n,href:t},o.querySelector(l)===null&&(t=o.createElement("link"),Kn(t,"link",e),Hn(t),o.head.appendChild(t)))}}function p7(e){_a.D(e),m2("dns-prefetch",e,null)}function y7(e,t){_a.C(e,t),m2("preconnect",e,t)}function x7(e,t,n){_a.L(e,t,n);var o=lr;if(o&&e&&t){var l='link[rel="preload"][as="'+Fo(t)+'"]';t==="image"&&n&&n.imageSrcSet?(l+='[imagesrcset="'+Fo(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(l+='[imagesizes="'+Fo(n.imageSizes)+'"]')):l+='[href="'+Fo(e)+'"]';var a=l;switch(t){case"style":a=Fi(e);break;case"script":a=ar(e)}if(!(Po.has(a)||(e=Jt({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),Po.set(a,e),o.querySelector(l)!==null||t==="style"&&o.querySelector(Oc(a))||t==="script"&&o.querySelector(zc(a))))){var c=o.createElement("link");Kn(c,"link",e),t==="style"&&(c[Sd]=!0,c.onload=c.onerror=function(){qy(c)}),Hn(c),o.head.appendChild(c)}}}function b7(e,t){_a.m(e,t);var n=lr;if(n&&e){var o=t&&typeof t.as=="string"?t.as:"script",l='link[rel="modulepreload"][as="'+Fo(o)+'"][href="'+Fo(e)+'"]',a=l;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":a=ar(e)}if(!Po.has(a)&&(e=Jt({rel:"modulepreload",href:e},t),Po.set(a,e),n.querySelector(l)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(zc(a)))return}o=n.createElement("link"),Kn(o,"link",e),Hn(o),n.head.appendChild(o)}}}function v7(e,t,n){_a.S(e,t,n);var o=lr;if(o&&e){var l=Ni(o).hoistableStyles,a=Fi(e);t=t||"default";var c=l.get(a);if(!c){var f={loading:0,preload:null};if(c=o.querySelector(Oc(a)))f.loading=5;else{e=Jt({rel:"stylesheet",href:e,"data-precedence":t},n),(n=Po.get(a))&&rh(e,n);var v=c=o.createElement("link");Hn(v),Kn(v,"link",e),v._p=new Promise(function(N,$){v.onload=N,v.onerror=$}),v.addEventListener("load",function(){f.loading|=1}),v.addEventListener("error",function(){f.loading|=2}),f.loading|=4,md(c,t,o)}c={type:"stylesheet",instance:c,count:1,state:f},l.set(a,c)}}}function w7(e,t){_a.X(e,t);var n=lr;if(n&&e){var o=Ni(n).hoistableScripts,l=ar(e),a=o.get(l);a||(a=n.querySelector(zc(l)),a||(e=Jt({src:e,async:!0},t),(t=Po.get(l))&&ch(e,t),a=n.createElement("script"),Hn(a),Kn(a,"link",e),n.head.appendChild(a)),a={type:"script",instance:a,count:1,state:null},o.set(l,a))}}function S7(e,t){_a.M(e,t);var n=lr;if(n&&e){var o=Ni(n).hoistableScripts,l=ar(e),a=o.get(l);a||(a=n.querySelector(zc(l)),a||(e=Jt({src:e,async:!0,type:"module"},t),(t=Po.get(l))&&ch(e,t),a=n.createElement("script"),Hn(a),Kn(a,"link",e),n.head.appendChild(a)),a={type:"script",instance:a,count:1,state:null},o.set(l,a))}}function my(e,t,n,o){var l=(l=za.current)?bc(l):null;if(!l)throw Error(J(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(n=Fi(n.href),t=Ni(l).hoistableStyles,o=t.get(n),o||(o={type:"style",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=Fi(n.href);var a=Ni(l).hoistableStyles,c=a.get(e);if(c||(l=l.ownerDocument||l,c={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},a.set(e,c),(a=l.querySelector(Oc(e)))?a._p||(c.instance=a,c.state.loading=5):(a=Po.get(e),a||(a={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},Po.set(e,a)),k7(l,e,a,c.state))),t&&o===null)throw Error(J(528,""));return c}if(t&&o!==null)throw Error(J(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(n=ar(n),t=Ni(l).hoistableScripts,o=t.get(n),o||(o={type:"script",instance:null,count:0,state:null},t.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(J(444,e))}}function Fi(e){return'href="'+Fo(e)+'"'}function Oc(e){return'link[rel="stylesheet"]['+e+"]"}function h2(e){return Jt({},e,{"data-precedence":e.precedence,precedence:null})}function k7(e,t,n,o){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(t[Sd]!==!0){o.loading=1;return}}else t=e.createElement("link"),t[Sd]=!0,t.onload=t.onerror=qy.bind(null,t),Kn(t,"link",n),Hn(t),e.head.appendChild(t);o.preload=t,t.addEventListener("load",function(){return o.loading|=1}),t.addEventListener("error",function(){return o.loading|=2})}function ar(e){return'[src="'+Fo(e)+'"]'}function zc(e){return"script[async]"+e}function hy(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var o=e.querySelector('style[data-href~="'+Fo(n.href)+'"]');if(o)return t.instance=o,Hn(o),o;var l=Jt({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),Hn(o),Kn(o,"style",l),md(o,n.precedence,e),t.instance=o;case"stylesheet":l=Fi(n.href);var a=e.querySelector(Oc(l));if(a)return t.state.loading|=4,t.instance=a,Hn(a),a;o=h2(n),(l=Po.get(l))&&rh(o,l),a=(e.ownerDocument||e).createElement("link"),Hn(a);var c=a;return c._p=new Promise(function(f,v){c.onload=f,c.onerror=v}),Kn(a,"link",o),t.state.loading|=4,md(a,n.precedence,e),t.instance=a;case"script":return a=ar(n.src),(l=e.querySelector(zc(a)))?(t.instance=l,Hn(l),l):(o=n,(l=Po.get(a))&&(o=Jt({},n),ch(o,l)),e=e.ownerDocument||e,l=e.createElement("script"),Hn(l),Kn(l,"link",o),e.head.appendChild(l),t.instance=l);case"void":return null;default:throw Error(J(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(o=t.instance,t.state.loading|=4,md(o,n.precedence,e));return t.instance}function md(e,t,n){for(var o=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),l=o.length?o[o.length-1]:null,a=l,c=0;c<o.length;c++){var f=o[c];if(f.dataset.precedence===t)a=f;else if(a!==l)break}a?a.parentNode.insertBefore(e,a.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function rh(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function ch(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var hd=null;function gy(e,t,n){if(hd===null){var o=new Map,l=hd=new Map;l.set(n,o)}else l=hd,o=l.get(n),o||(o=new Map,l.set(n,o));if(o.has(e))return o;for(o.set(e,null),n=n.getElementsByTagName(e),l=0;l<n.length;l++){var a=n[l];if(!(a[Mc]||a[Vn]||e==="link"&&a.getAttribute("rel")==="stylesheet")&&a.namespaceURI!=="http://www.w3.org/2000/svg"){var c=a.getAttribute(t)||"";c=e+c;var f=o.get(c);f?f.push(a):o.set(c,[a])}}return o}function dm(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function C7(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;switch(t.rel){case"stylesheet":return e=t.disabled,typeof t.precedence=="string"&&e==null;default:return!0}case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function py(e,t){return e==="img"&&t.src!=null&&t.src!==""&&t.onLoad==null&&t.loading!=="lazy"}function g2(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function p2(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function yy(e,t){typeof t.decode=="function"&&(e.imgCount++,t.complete||(e.imgBytes+=p2(t),e.suspenseyImages.push(t)),e=M7.bind(e),t.decode().then(e,e))}function j7(e,t,n,o){if(n.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var l=Fi(o.href),a=t.querySelector(Oc(l));if(a){t=a._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=vc.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=a,Hn(a);return}a=t.ownerDocument||t,o=h2(o),(l=Po.get(l))&&rh(o,l),a=a.createElement("link"),Hn(a);var c=a;c._p=new Promise(function(f,v){c.onload=f,c.onerror=v}),Kn(a,"link",o),n.instance=a}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=vc.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var gd=0;function E7(e,t){return e.stylesheets&&e.count===0&&pd(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var o=setTimeout(function(){if(e.stylesheets&&pd(e,e.stylesheets),e.unsuspend){var a=e.unsuspend;e.unsuspend=null,a()}},6e4+t);0<e.imgBytes&&gd===0&&(gd=62500*Q8());var l=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&pd(e,e.stylesheets),e.unsuspend)){var a=e.unsuspend;e.unsuspend=null,a()}},(e.imgBytes>gd?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(l)}}:null}function y2(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)pd(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function vc(){this.count--,y2(this)}function M7(){this.imgCount--,y2(this)}var Gd=null;function pd(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Gd=new Map,t.forEach(T7,e),Gd=null,vc.call(e))}function T7(e,t){if(!(t.state.loading&4)){var n=Gd.get(e);if(n)var o=n.get(null);else{n=new Map,Gd.set(e,n);for(var l=e.querySelectorAll("link[data-precedence],style[data-precedence]"),a=0;a<l.length;a++){var c=l[a];(c.nodeName==="LINK"||c.getAttribute("media")!=="not all")&&(n.set(c.dataset.precedence,c),o=c)}o&&n.set(null,o)}l=t.instance,c=l.getAttribute("data-precedence"),a=n.get(c)||o,a===o&&n.set(null,l),n.set(c,l),this.count++,o=vc.bind(this),l.addEventListener("load",o),l.addEventListener("error",o),a?a.parentNode.insertBefore(l,a.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(l,e.firstChild)),t.state.loading|=4}}var Zi={$$typeof:Ml,Provider:null,Consumer:null,_currentValue:js,_currentValue2:js,_threadCount:0};function N7(e,t,n,o,l,a,c,f,v){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=T0(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=T0(0),this.hiddenUpdates=T0(null),this.identifierPrefix=o,this.onUncaughtError=l,this.onCaughtError=a,this.onRecoverableError=c,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=v,this.transitionTypes=null,this.incompleteTransitions=new Map}function x2(e,t,n,o,l,a,c,f,v,N,$,V){return e=new N7(e,t,n,c,v,N,$,V,f),t=1,a===!0&&(t|=24),a=wo(3,null,null,t),e.current=a,a.stateNode=e,t=Tm(),t.refCount++,e.pooledCache=t,t.refCount++,a.memoizedState={element:o,isDehydrated:n,cache:t},Am(a),e}function b2(e){return e?(e=ji,e):ji}function v2(e,t,n,o,l,a){l=b2(l),o.context===null?o.context=l:o.pendingContext=l,o=Ba(t),o.payload={element:n},a=a===void 0?null:a,a!==null&&(o.callback=a),n=Ha(e,o,t),n!==null&&(So(n,e,t),Pr(n,e,t))}function xy(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function uh(e,t){xy(e,t),(e=e.alternate)&&xy(e,t)}function w2(e){if(e.tag===13||e.tag===31){var t=Ys(e,67108864);t!==null&&So(t,e,67108864),uh(e,67108864)}}function by(e){if(e.tag===13||e.tag===31){var t=zo();t=pm(t);var n=Ys(e,t);n!==null&&So(n,e,t),uh(e,t)}}var Ki=!0;function R7(e,t,n,o){var l=qe.T;qe.T=null;var a=Bt.p;try{Bt.p=2,dh(e,t,n,o)}finally{Bt.p=a,qe.T=l}}function A7(e,t,n,o){var l=qe.T;qe.T=null;var a=Bt.p;try{Bt.p=8,dh(e,t,n,o)}finally{Bt.p=a,qe.T=l}}function dh(e,t,n,o){if(Ki){var l=_m(o);if(l===null)J0(e,t,o,Vd,n),vy(e,o);else if(O7(l,e,t,n,o))o.stopPropagation();else if(vy(e,o),t&4&&-1<D7.indexOf(e)){for(;l!==null;){var a=er(l);if(a!==null)switch(a.tag){case 3:if(a=a.stateNode,a.current.memoizedState.isDehydrated){var c=vs(a.pendingLanes);if(c!==0){var f=a;for(f.pendingLanes|=2,f.entangledLanes|=2;c;){var v=1<<31-Oo(c);f.entanglements[1]|=v,c&=~v}Ll(a),(Lt&6)===0&&(Id=Ao()+500,Dc(0,!1))}}break;case 31:case 13:f=Ys(a,2),f!==null&&So(f,a,2),c_(),uh(a,2)}if(a=_m(o),a===null&&J0(e,t,o,Vd,n),a===l)break;l=a}l!==null&&o.stopPropagation()}else J0(e,t,o,null,n)}}function _m(e){return e=bm(e),_h(e)}var Vd=null;function _h(e){if(Vd=null,e=ks(e),e!==null){var t=kc(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=Ey(t),e!==null)return e;e=null}else if(n===31){if(e=My(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return Vd=e,null}function S2(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(V3()){case Oy:return 2;case zy:return 8;case wd:case W3:return 32;case Ly:return 268435456;default:return 32}default:return 32}}var fm=!1,Ya=null,qa=null,Xa=null,wc=new Map,Sc=new Map,Ma=[],D7="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function vy(e,t){switch(e){case"focusin":case"focusout":Ya=null;break;case"dragenter":case"dragleave":qa=null;break;case"mouseover":case"mouseout":Xa=null;break;case"pointerover":case"pointerout":wc.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Sc.delete(t.pointerId)}}function Yr(e,t,n,o,l,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:o,nativeEvent:a,targetContainers:[l]},t!==null&&(t=er(t),t!==null&&w2(t)),e):(e.eventSystemFlags|=o,t=e.targetContainers,l!==null&&t.indexOf(l)===-1&&t.push(l),e)}function O7(e,t,n,o,l){switch(t){case"focusin":return Ya=Yr(Ya,e,t,n,o,l),!0;case"dragenter":return qa=Yr(qa,e,t,n,o,l),!0;case"mouseover":return Xa=Yr(Xa,e,t,n,o,l),!0;case"pointerover":var a=l.pointerId;return wc.set(a,Yr(wc.get(a)||null,e,t,n,o,l)),!0;case"gotpointercapture":return a=l.pointerId,Sc.set(a,Yr(Sc.get(a)||null,e,t,n,o,l)),!0}return!1}function k2(e){var t=ks(e.target);if(t!==null){var n=kc(t);if(n!==null){if(t=n.tag,t===13){if(t=Ey(n),t!==null){e.blockedOn=t,V1(e.priority,function(){by(n)});return}}else if(t===31){if(t=My(n),t!==null){e.blockedOn=t,V1(e.priority,function(){by(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function yd(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=_m(e.nativeEvent);if(n===null){n=e.nativeEvent;var o=new n.constructor(n.type,n);gf=o,n.target.dispatchEvent(o),gf=null}else return t=er(n),t!==null&&w2(t),e.blockedOn=n,!1;t.shift()}return!0}function wy(e,t,n){yd(e)&&n.delete(t)}function z7(){fm=!1,Ya!==null&&yd(Ya)&&(Ya=null),qa!==null&&yd(qa)&&(qa=null),Xa!==null&&yd(Xa)&&(Xa=null),wc.forEach(wy),Sc.forEach(wy)}function Ju(e,t){e.blockedOn===t&&(e.blockedOn=null,fm||(fm=!0,Dn.unstable_scheduleCallback(Dn.unstable_NormalPriority,z7)))}var Pu=null;function Sy(e){Pu!==e&&(Pu=e,Dn.unstable_scheduleCallback(Dn.unstable_NormalPriority,function(){Pu===e&&(Pu=null);for(var t=0;t<e.length;t+=3){var n=e[t],o=e[t+1],l=e[t+2];if(typeof o!="function"){if(_h(o||n)===null)continue;break}var a=er(n);a!==null&&(e.splice(t,3),t-=3,Af(a,{pending:!0,data:l,method:n.method,action:o},o,l))}}))}function Ji(e){function t(v){return Ju(v,e)}Ya!==null&&Ju(Ya,e),qa!==null&&Ju(qa,e),Xa!==null&&Ju(Xa,e),wc.forEach(t),Sc.forEach(t);for(var n=0;n<Ma.length;n++){var o=Ma[n];o.blockedOn===e&&(o.blockedOn=null)}for(;0<Ma.length&&(n=Ma[0],n.blockedOn===null);)k2(n),n.blockedOn===null&&Ma.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(o=0;o<n.length;o+=3){var l=n[o],a=n[o+1],c=l[Co]||null;if(typeof a=="function")c||Sy(n);else if(c){var f=null;if(a&&a.hasAttribute("formAction")){if(l=a,c=a[Co]||null)f=c.formAction;else if(_h(l)!==null)continue}else f=c.action;typeof f=="function"?n[o+1]=f:(n.splice(o,3),o-=3),Sy(n)}}}function C2(){function e(a){a.canIntercept&&a.info==="react-transition"&&a.intercept({handler:function(){return new Promise(function(c){return l=c})},focusReset:"manual",scroll:"manual"})}function t(){l!==null&&(l(),l=null),o||setTimeout(n,20)}function n(){if(!o&&!navigation.transition){var a=navigation.currentEntry;a&&a.url!=null&&navigation.navigate(a.url,{state:a.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,l=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),l!==null&&(l(),l=null)}}}function fh(e){this._internalRoot=e}__.prototype.render=fh.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(J(409));var n=t.current,o=zo();v2(n,o,e,t,null,null)};__.prototype.unmount=fh.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;v2(e.current,2,null,e,null,null),c_(),t[Pi]=null}};function __(e){this._internalRoot=e}__.prototype.unstable_scheduleHydration=function(e){if(e){var t=Yy();e={blockedOn:null,target:e,priority:t};for(var n=0;n<Ma.length&&t!==0&&t<Ma[n].priority;n++);Ma.splice(n,0,e),n===0&&k2(e)}};var ky=Cy.version;if(ky!=="19.3.0")throw Error(J(527,ky,"19.3.0"));Bt.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(J(188)):(e=Object.keys(e).join(","),Error(J(268,e)));return e=L3(t),e=e!==null?Ty(e):null,e=e===null?null:e.stateNode,e};var L7={bundleType:0,version:"19.3.0",rendererPackageName:"react-dom",currentDispatcherRef:qe,reconcilerVersion:"19.3.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(qr=__REACT_DEVTOOLS_GLOBAL_HOOK__,!qr.isDisabled&&qr.supportsFiber))try{Cc=qr.inject(L7),Do=qr}catch{}var qr;f_.createRoot=function(e,t){if(!jy(e))throw Error(J(299));var n=!1,o="",l=ax,a=sx,c=ix;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onUncaughtError!==void 0&&(l=t.onUncaughtError),t.onCaughtError!==void 0&&(a=t.onCaughtError),t.onRecoverableError!==void 0&&(c=t.onRecoverableError)),t=x2(e,1,!1,null,null,n,o,null,l,a,c,C2),e[Pi]=t.current,lh(e),new fh(t)};f_.hydrateRoot=function(e,t,n){if(!jy(e))throw Error(J(299));var o=!1,l="",a=ax,c=sx,f=ix,v=null;return n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(l=n.identifierPrefix),n.onUncaughtError!==void 0&&(a=n.onUncaughtError),n.onCaughtError!==void 0&&(c=n.onCaughtError),n.onRecoverableError!==void 0&&(f=n.onRecoverableError),n.formState!==void 0&&(v=n.formState)),t=x2(e,1,!0,t,n??null,o,l,v,a,c,f,C2),t.context=b2(null),n=t.current,o=zo(),o=pm(o),l=Ba(o),l.callback=null,Ha(n,l,o),n=o,t.current.lanes=n,Ec(t,n),Ll(t),e[Pi]=t.current,lh(e),new __(t)};f_.version="19.3.0"});var T2=al((c9,M2)=>{"use strict";function E2(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(E2)}catch(e){console.error(e)}}E2(),M2.exports=j2()});var R2=al(m_=>{"use strict";var B7=Symbol.for("react.transitional.element"),H7=Symbol.for("react.fragment");function N2(e,t,n){var o=null;if(n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),"key"in t){n={};for(var l in t)l!=="key"&&(n[l]=t[l])}else n=t;return t=n.ref,{$$typeof:B7,type:e,key:o,ref:t!==void 0?t:null,props:n}}m_.Fragment=H7;m_.jsx=N2;m_.jsxs=N2});var Tn=al((d9,A2)=>{"use strict";A2.exports=R2()});var O2=al((_9,D2)=>{D2.exports=function(t){let n={exports:{}};var o=Object.create,l=Object.defineProperty,a=Object.getOwnPropertyDescriptor,c=Object.getOwnPropertyNames,f=Object.getPrototypeOf,v=Object.prototype.hasOwnProperty,N=(s,i)=>{for(var r in i)l(s,r,{get:i[r],enumerable:!0})},$=(s,i,r,u)=>{if(i&&typeof i=="object"||typeof i=="function")for(let d of c(i))!v.call(s,d)&&d!==r&&l(s,d,{get:()=>i[d],enumerable:!(u=a(i,d))||u.enumerable});return s},V=(s,i,r)=>(r=s!=null?o(f(s)):{},$(i||!s||!s.__esModule?l(r,"default",{value:s,enumerable:!0}):r,s)),A=s=>$(l({},"__esModule",{value:!0}),s),U={};N(U,{Agentation:()=>bg,AnimatedBunny:()=>Lb,AnnotationPopupCSS:()=>Qc,IconChatEllipsis:()=>Tb,IconCheck:()=>ub,IconCheckSmall:()=>db,IconCheckSmallAnimated:()=>fb,IconCheckmark:()=>Nb,IconCheckmarkCircle:()=>Ab,IconCheckmarkLarge:()=>Rb,IconChevronLeft:()=>Rh,IconChevronRight:()=>zb,IconClose:()=>cb,IconCopyAlt:()=>mb,IconCopyAnimated:()=>hb,IconEdit:()=>Nh,IconEye:()=>yb,IconEyeAlt:()=>xb,IconEyeAnimated:()=>vb,IconEyeClosed:()=>bb,IconEyeMinus:()=>Sb,IconGear:()=>kb,IconHelp:()=>jh,IconLayout:()=>Bb,IconListSparkle:()=>_b,IconMoon:()=>Th,IconPause:()=>jb,IconPauseAlt:()=>Cb,IconPausePlayAnimated:()=>wb,IconPlayAlt:()=>Eb,IconPlus:()=>Ch,IconSendAnimated:()=>pb,IconSendArrow:()=>gb,IconSun:()=>Mh,IconTrash:()=>Ob,IconTrashAlt:()=>Mb,IconXmark:()=>Eh,IconXmarkLarge:()=>Db,PageFeedbackToolbarCSS:()=>bg,closestCrossingShadow:()=>zn,getElementClasses:()=>Gs,getElementPath:()=>g_,getNearbyText:()=>Qs,getShadowHost:()=>q2,getStorageKey:()=>Kc,identifyAnimationElement:()=>Q2,identifyElement:()=>os,isInShadowDOM:()=>Y2,loadAnnotations:()=>Hl,saveAnnotations:()=>dr}),n.exports=A(U);var ce=tn(),he=["data-feedback-toolbar","data-annotation-popup","data-annotation-marker"],Ne=he.flatMap(s=>[`:not([${s}])`,`:not([${s}] *)`]).join(""),T="feedback-freeze-styles",C="__agentation_freeze";function z(){return typeof window>"u"?{frozen:!1,installed:!0,origSetTimeout:setTimeout,origSetInterval:setInterval,origRAF:i=>0,pausedAnimations:[],frozenTimeoutQueue:[],frozenRAFQueue:[]}:window[C]??{frozen:!1,installed:!1,origSetTimeout:window.setTimeout.bind(window),origSetInterval:window.setInterval.bind(window),origRAF:window.requestAnimationFrame.bind(window),pausedAnimations:[],frozenTimeoutQueue:[],frozenRAFQueue:[]}}var L=z();function de(){if(typeof window>"u")return;let s=window;L=s[C]??(s[C]=L),!L.installed&&(window.setTimeout=(i,r,...u)=>typeof i=="string"?L.origSetTimeout(i,r):L.origSetTimeout((...d)=>{L.frozen?L.frozenTimeoutQueue.push(()=>i(...d)):i(...d)},r,...u),window.setInterval=(i,r,...u)=>typeof i=="string"?L.origSetInterval(i,r):L.origSetInterval((...d)=>{L.frozen||i(...d)},r,...u),window.requestAnimationFrame=i=>L.origRAF(r=>{L.frozen?L.frozenRAFQueue.push(i):i(r)}),L.installed=!0)}var _e=L.origSetTimeout,be=L.origSetInterval,Ce=L.origRAF;function an(s){return s?he.some(i=>!!s.closest?.(`[${i}]`)):!1}function st(){if(typeof document>"u"||(de(),L.frozen))return;L.frozen=!0,L.frozenTimeoutQueue=[],L.frozenRAFQueue=[];let s=document.getElementById(T);s||(s=document.createElement("style"),s.id=T),s.textContent=`
    *${Ne},
    *${Ne}::before,
    *${Ne}::after {
      animation-play-state: paused !important;
      transition: none !important;
    }
  `,document.head.appendChild(s),L.pausedAnimations=[];try{document.getAnimations().forEach(i=>{if(i.playState!=="running")return;let r=i.effect?.target;an(r)||(i.pause(),L.pausedAnimations.push(i))})}catch{}document.querySelectorAll("video").forEach(i=>{i.paused||(i.dataset.wasPaused="false",i.pause())})}function ho(){if(typeof document>"u"||!L.frozen)return;L.frozen=!1;let s=L.frozenTimeoutQueue;L.frozenTimeoutQueue=[];for(let r of s)L.origSetTimeout(()=>{if(L.frozen){L.frozenTimeoutQueue.push(r);return}try{r()}catch(u){console.warn("[agentation] Error replaying queued timeout:",u)}},0);let i=L.frozenRAFQueue;L.frozenRAFQueue=[];for(let r of i)L.origRAF(u=>{if(L.frozen){L.frozenRAFQueue.push(r);return}r(u)});for(let r of L.pausedAnimations)try{r.play()}catch(u){console.warn("[agentation] Error resuming animation:",u)}L.pausedAnimations=[],document.getElementById(T)?.remove(),document.querySelectorAll("video").forEach(r=>{r.dataset.wasPaused==="false"&&(r.play().catch(()=>{}),delete r.dataset.wasPaused)})}function Ja(){let s=(0,ce.useMemo)(()=>{let i=0,r=new Set,u=()=>(r.forEach(clearTimeout),r.clear(),++i),d=g=>g===i;return{start:u,isCurrent:d,schedule:(g,w,y)=>{if(!d(g))return;let E=_e(()=>{r.delete(E),d(g)&&w()},y);r.add(E)}}},[]);return(0,ce.useEffect)(()=>()=>{s.start()},[s]),s}function sr(s,i,r,u){let d=E=>u.get(E.id)??E.id,_=new Map(s.map(E=>[d(E),E])),g=new Map(i.map(E=>[d(E),E])),w=new Set(r.map(E=>E.id)),y=[];for(let E of r){let M=_.get(E.id),S=g.get(E.id);if(M&&!S)continue;let O=S&&M&&S.comment!==M.comment;y.push(O?{...E,comment:S.comment}:E)}for(let[E,M]of g)!_.has(E)&&!w.has(E)&&y.push(M);return y}function Pa(s){if(s.tagName!=="IFRAME")return null;try{return s.contentDocument}catch{return null}}function $n(s,i=document){if(s===i)return null;try{return s.defaultView?.frameElement}catch{return null}}function fa(s){return s.nodeType===11&&"host"in s}function Bl(s){let i=s.getBoundingClientRect(),r=s.offsetWidth?i.width/s.offsetWidth:1,u=s.offsetHeight?i.height/s.offsetHeight:1,d=s.ownerDocument.defaultView?.getComputedStyle(s),_=M=>parseFloat(M||"0")||0,g=_(d?.paddingLeft),w=_(d?.paddingTop),y=s.clientWidth-g-_(d?.paddingRight),E=s.clientHeight-w-_(d?.paddingBottom);return{x:i.left+(s.clientLeft+g)*r,y:i.top+(s.clientTop+w)*u,sx:r,sy:u,width:y*r,height:E*u}}function es(s){try{let i=new URL(s);return i.origin+i.pathname}catch{return s}}function ts(s,i,r,u=document){let d=$n(s,u);for(;d;){let _=Bl(d);i=_.x+i*_.sx,r=_.y+r*_.sy,d=$n(d.ownerDocument,u)}return{x:i,y:r}}function gn(s,i=document){let r=s.getBoundingClientRect();return Ie(s.ownerDocument,r,i)}function Ie(s,i,r){if(!$n(s,r))return i;let u=i.left,d=i.top,_=i.right,g=i.bottom,w=$n(s,r);for(;w;){let y=Bl(w);u=Math.max(y.x,y.x+u*y.sx),d=Math.max(y.y,y.y+d*y.sy),_=Math.min(y.x+y.width,y.x+_*y.sx),g=Math.min(y.y+y.height,y.y+g*y.sy),w=$n(w.ownerDocument,r)}return new DOMRect(u,d,Math.max(0,_-u),Math.max(0,g-d))}function sn(s){let i=[];for(let r of s.querySelectorAll("*"))r.tagName==="IFRAME"&&i.push(r),r.shadowRoot&&r.tagName!=="AGENTATION-TOOLBAR"&&i.push(...sn(r.shadowRoot));return i}function Pn(s,i,r,u=document){let d=[];for(let S=$n(s.ownerDocument,u);S;S=$n(S.ownerDocument,u))d.unshift(S);if(!d.length)return;let _=d.map(S=>{let O=Bl(S);return i=(i-O.x)/O.sx,r=(r-O.y)/O.sy,{index:sn(S.ownerDocument).indexOf(S),id:S.id||void 0,url:Pa(S)?.URL??""}}),g=s.ownerDocument.defaultView,w=!1;for(let S=s;S;S=S.parentElement)if(["fixed","sticky"].includes(g.getComputedStyle(S).position)){w=!0;break}let y=w?0:g.scrollX,E=w?0:g.scrollY,M=s.getBoundingClientRect();return{path:_,x:i+y,y:r+E,fixed:w,boundingBox:{x:M.left+y,y:M.top+E,width:M.width,height:M.height}}}function On(s=document){let i=new Map,r=u=>{let d=i.get(u);return d||(d=sn(u),i.set(u,d)),d};return u=>kn(u,s,r)}function kn(s,i=document,r=sn){let u=s.frame;if(!u)return s;let d=i;for(let W of u.path){let H=r(d),te=W.id?H.find(K=>K.id===W.id):H[W.index],B=te&&Pa(te);if(!B||es(B.URL)!==es(W.url))return null;d=B}let _=d.defaultView,g=u.fixed?0:_.scrollX,w=u.fixed?0:_.scrollY,y=u.x-g,E=u.y-w;for(let W=d,H=$n(d,i);H;H=$n(W,i)){let te=W.defaultView;if(y<0||E<0||y>te.innerWidth||E>te.innerHeight)return null;let B=Bl(H);if(B.width<=0||B.height<=0)return null;y=B.x+y*B.sx,E=B.y+E*B.sy,W=H.ownerDocument}let M=u.boundingBox,S=Ie(d,new DOMRect(M.x-g,M.y-w,M.width,M.height),i),O=i.defaultView;return{...s,x:y/O.innerWidth*100,y:E+(s.isFixed?0:O.scrollY),boundingBox:{x:S.x,y:S.y+(s.isFixed?0:O.scrollY),width:S.width,height:S.height}}}function bn(s,i,r){if(!("clientX"in s)||i===r)return s;let u=ts(i,s.clientX,s.clientY,r);return new Proxy(s,{get(d,_){if(_==="clientX")return u.x;if(_==="clientY")return u.y;let g=Reflect.get(d,_,d);return typeof g=="function"?g.bind(d):g}})}function In(s,i){let r=new Set([s]),u=new Set,d=[],_=new Set,g=!1,w=!1,y,E=(S,O)=>{let W=H=>S.listener(bn(H,O,s));S.handlers.set(O,W),O.addEventListener(S.type,W,S.options)},M=()=>{if(g=!1,!w)return;let S=new Set,O=new Set,W=[],H=te=>{W.push(te);for(let B of te.querySelectorAll("*"))if(!B.matches("agentation-toolbar, [data-agentation-portal]")&&(B.shadowRoot&&H(B.shadowRoot),B.tagName==="IFRAME")){O.add(B);let K=Pa(B);K&&!S.has(K)&&(S.add(K),H(K))}};S.add(s),H(s);for(let te of r)if(!S.has(te)){for(let B of u){let K=B.handlers.get(te);K&&te.removeEventListener(B.type,K,B.options),B.handlers.delete(te)}r.delete(te)}for(let te of S)if(!r.has(te)){r.add(te);for(let B of u)E(B,te)}for(let te of _)O.has(te)||te.removeEventListener("load",M);for(let te of O)_.has(te)||te.addEventListener("load",M);_=O,y?.disconnect(),_.forEach(te=>y?.observe(te)),d.forEach(te=>te.disconnect()),d=W.map(te=>{let B=new MutationObserver(K=>{K.some(G=>[...G.addedNodes,...G.removedNodes].some(P=>P.nodeType===1&&!P.closest("agentation-toolbar, [data-agentation-portal]")&&(P.tagName==="IFRAME"||!!P.shadowRoot||!!P.querySelector("iframe"))))&&!g&&(g=!0,queueMicrotask(M))});return B.observe(te,{childList:!0,subtree:!0}),B}),i?.()};return{start(){w||(w=!0,typeof ResizeObserver=="function"&&(y=new ResizeObserver(()=>i?.())),M())},stop(){w=!1,y?.disconnect(),y=void 0,d.forEach(S=>S.disconnect()),d=[];for(let S of _)S.removeEventListener("load",M);_.clear();for(let S of u)for(let[O,W]of S.handlers)O.removeEventListener(S.type,W,S.options);u.clear(),r.clear(),r.add(s)},addEventListener(S,O,W){let H={type:S,listener:O,options:W,handlers:new Map};u.add(H);for(let te of r)E(H,te)},removeEventListener(S,O,W){for(let H of u)if(H.type===S&&H.listener===O){for(let[te,B]of H.handlers)te.removeEventListener(S,B,H.options);u.delete(H)}},querySelectorAll(S){return[...r].flatMap(O=>[...O.querySelectorAll(S)])}}}var eo=["data-testid","data-test","data-qa","data-cy","data-component"];function ns(s,i=eo){if(s.matches?.("input, textarea, select, [data-wishes-private]"))return{};let r={};for(let u of[...new Set(i)].slice(0,16)){if(!/^[a-zA-Z_][\w:.-]*$/.test(u))continue;let d=s.getAttribute(u);d!=null&&d.length<=500&&Object.defineProperty(r,u,{value:d,enumerable:!0})}return r}function h_(s,i=eo){return Object.entries(ns(s,i)).filter(([r,u])=>/^data-[a-z0-9_-]+$/.test(r)&&u.length<=120).slice(0,2).map(([r,u])=>`[${r}="${u.replace(/[\\"\n\r\f\0]/g,d=>d==="\\"||d==='"'?`\\${d}`:`\\${d.charCodeAt(0).toString(16)} `)}"]`).join("")}function Xs(s){if(s.parentElement)return s.parentElement;let i=s.getRootNode();return fa(i)?i.host:null}function zn(s,i){let r=s;for(;r;){if(r.matches(i))return r;r=Xs(r)}return null}function Y2(s){return fa(s.getRootNode())}function q2(s){let i=s.getRootNode();return fa(i)?i.host:null}function g_(s,i=4,r){let u=[],d=s,_=0;for(;d&&_<i;){let w=d.tagName.toLowerCase();if(w==="html"||w==="body"){u.length===0&&u.push(w);break}let y=w;if(d.id)y=`#${d.id}`;else if(d.className&&typeof d.className=="string"){let S=d.className.split(/\s+/).find(O=>O.length>2&&!O.match(/^[a-z]{1,2}$/)&&!O.match(/[A-Z0-9]{5,}/));S&&(y=`${w}.${CSS.escape(S)}`)}y+=h_(d,r);let E=d.parentElement?Array.from(d.parentElement.children).filter(S=>S.tagName===d.tagName):[];E.length>1&&(y+=`:nth-of-type(${E.indexOf(d)+1})`);let M=Xs(d);!d.parentElement&&M&&(y=`\u27E8shadow\u27E9 ${y}`),u.unshift(y),d=M,_++}let g=$n(s.ownerDocument);return(g?g_(g,2)+" > \u27E8iframe\u27E9 ":"")+u.join(" > ")}function X2(s){let i="";for(let r of s.childNodes)if(r.nodeType===Node.TEXT_NODE){let u=r.textContent?.trim();u&&(i+=(i?" ":"")+u)}return i}function os(s,i){let r=g_(s,4,i);if(s.dataset.element)return{name:s.dataset.element,path:r};let u=s.tagName.toLowerCase();if(["path","circle","rect","line","g"].includes(u)){let d=zn(s,"svg");if(d){let _=Xs(d);if(_?.namespaceURI==="http://www.w3.org/1999/xhtml")return{name:`graphic in ${os(_).name}`,path:r}}return{name:"graphic element",path:r}}if(u==="svg"){let d=Xs(s);if(d?.tagName.toLowerCase()==="button"){let _=d.textContent?.trim();return{name:_?`icon in "${_}" button`:"button icon",path:r}}return{name:"icon",path:r}}if(u==="button"){let d=s.textContent?.trim(),_=s.getAttribute("aria-label");return _?{name:`button [${_}]`,path:r}:{name:d?`button "${d.slice(0,25)}"`:"button",path:r}}if(u==="a"){let d=s.textContent?.trim(),_=s.getAttribute("href");return d?{name:`link "${d.slice(0,25)}"`,path:r}:_?{name:`link to ${_.slice(0,30)}`,path:r}:{name:"link",path:r}}if(u==="input"){let d=s.getAttribute("type")||"text",_=s.getAttribute("placeholder"),g=s.getAttribute("name");return _?{name:`input "${_}"`,path:r}:g?{name:`input [${g}]`,path:r}:{name:`${d} input`,path:r}}if(["h1","h2","h3","h4","h5","h6"].includes(u)){let d=s.textContent?.trim();return{name:d?`${u} "${d.slice(0,35)}"`:u,path:r}}if(u==="p"){let d=s.textContent?.trim();return d?{name:`paragraph: "${d.slice(0,40)}${d.length>40?"...":""}"`,path:r}:{name:"paragraph",path:r}}if(u==="span"||u==="label"){let d=s.textContent?.trim();return d&&d.length<40?{name:`"${d}"`,path:r}:{name:u,path:r}}if(u==="li"){let d=s.textContent?.trim();return d&&d.length<40?{name:`list item: "${d.slice(0,35)}"`,path:r}:{name:"list item",path:r}}if(u==="blockquote")return{name:"blockquote",path:r};if(u==="code"){let d=s.textContent?.trim();return d&&d.length<30?{name:`code: \`${d}\``,path:r}:{name:"code",path:r}}if(u==="pre")return{name:"code block",path:r};if(u==="img"){let d=s.getAttribute("alt");return{name:d?`image "${d.slice(0,30)}"`:"image",path:r}}if(u==="video")return{name:"video",path:r};if(["div","section","article","nav","header","footer","aside","main"].includes(u)){let d=s.className,_=s.getAttribute("role"),g=s.getAttribute("aria-label");if(g)return{name:`${u} [${g}]`,path:r};if(_)return{name:`${_}`,path:r};let w=X2(s);if(w&&w.length<50)return{name:`"${w}"`,path:r};if(typeof d=="string"&&d){let y=d.split(/[\s_-]+/).map(E=>E.replace(/[A-Z0-9]{5,}.*$/,"")).filter(E=>E.length>2&&!/^[a-z]{1,2}$/.test(E)).slice(0,2);if(y.length>0)return{name:y.join(" "),path:r}}return{name:u==="div"?"container":u,path:r}}return{name:u,path:r}}function Qs(s){let i=[],r=s.textContent?.trim();r&&r.length<100&&i.push(r);let u=s.previousElementSibling;if(u){let _=u.textContent?.trim();_&&_.length<50&&i.unshift(`[before: "${_.slice(0,40)}"]`)}let d=s.nextElementSibling;if(d){let _=d.textContent?.trim();_&&_.length<50&&i.push(`[after: "${_.slice(0,40)}"]`)}return i.join(" ")}function Q2(s){if(s.dataset.element)return s.dataset.element;let i=s.tagName.toLowerCase();if(i==="path")return"path";if(i==="circle")return"circle";if(i==="rect")return"rectangle";if(i==="line")return"line";if(i==="ellipse")return"ellipse";if(i==="polygon")return"polygon";if(i==="g")return"group";if(i==="svg")return"svg";if(i==="button"){let r=s.textContent?.trim();return r?`button "${r}"`:"button"}if(i==="input")return`input (${s.getAttribute("type")||"text"})`;if(i==="span"||i==="p"||i==="label"){let r=s.textContent?.trim();return r&&r.length<30?`"${r}"`:"text"}if(i==="div"){let r=s.className;if(typeof r=="string"&&r){let u=r.split(/[\s_-]+/).map(d=>d.replace(/[A-Z0-9]{5,}.*$/,"")).filter(d=>d.length>2&&!/^[a-z]{1,2}$/.test(d)).slice(0,2);if(u.length>0)return u.join(" ")}return"container"}return i}function Bc(s){let i=Xs(s);if(!i)return"";let r=s.getRootNode(),d=(fa(r)&&s.parentElement?Array.from(s.parentElement.children):Array.from(i.children)).filter(M=>M!==s&&M.namespaceURI==="http://www.w3.org/1999/xhtml");if(d.length===0)return"";let _=d.slice(0,4).map(M=>{let S=M.tagName.toLowerCase(),O=M.className,W="";if(typeof O=="string"&&O){let H=O.split(/\s+/).map(te=>te.replace(/[_][a-zA-Z0-9]{5,}.*$/,"")).find(te=>te.length>2&&!/^[a-z]{1,2}$/.test(te));H&&(W=`.${H}`)}if(S==="button"||S==="a"){let H=M.textContent?.trim().slice(0,15);if(H)return`${S}${W} "${H}"`}return`${S}${W}`}),w=i.tagName.toLowerCase();if(typeof i.className=="string"&&i.className){let M=i.className.split(/\s+/).map(S=>S.replace(/[_][a-zA-Z0-9]{5,}.*$/,"")).find(S=>S.length>2&&!/^[a-z]{1,2}$/.test(S));M&&(w=`.${M}`)}let y=i.children.length,E=y>_.length+1?` (${y} total in ${w})`:"";return _.join(", ")+E}function Gs(s){let i=s.className;return typeof i!="string"||!i?"":i.split(/\s+/).filter(u=>u.length>0).map(u=>{let d=u.match(/^([a-zA-Z][a-zA-Z0-9_-]*?)(?:_[a-zA-Z0-9]{5,})?$/);return d?d[1]:u}).filter((u,d,_)=>_.indexOf(u)===d).join(", ")}var mh=new Set(["none","normal","auto","0px","rgba(0, 0, 0, 0)","transparent","static","visible"]),G2=new Set(["p","span","h1","h2","h3","h4","h5","h6","label","li","td","th","blockquote","figcaption","caption","legend","dt","dd","pre","code","em","strong","b","i","a","time","cite","q"]),V2=new Set(["input","textarea","select"]),W2=new Set(["img","video","canvas","svg"]),F2=new Set(["div","section","article","nav","header","footer","aside","main","ul","ol","form","fieldset"]);function Hc(s){if(typeof window>"u")return{};let i=(s.ownerDocument.defaultView??window).getComputedStyle(s),r={},u=s.tagName.toLowerCase(),d;G2.has(u)?d=["color","fontSize","fontWeight","fontFamily","lineHeight"]:u==="button"||u==="a"&&s.getAttribute("role")==="button"?d=["backgroundColor","color","padding","borderRadius","fontSize"]:V2.has(u)?d=["backgroundColor","color","padding","borderRadius","fontSize"]:W2.has(u)?d=["width","height","objectFit","borderRadius"]:F2.has(u)?d=["display","padding","margin","gap","backgroundColor"]:d=["color","fontSize","margin","padding","backgroundColor"];for(let _ of d){let g=_.replace(/([A-Z])/g,"-$1").toLowerCase(),w=i.getPropertyValue(g);w&&!mh.has(w)&&(r[_]=w)}return r}var Z2=["color","backgroundColor","borderColor","fontSize","fontWeight","fontFamily","lineHeight","letterSpacing","textAlign","width","height","padding","margin","border","borderRadius","display","position","top","right","bottom","left","zIndex","flexDirection","justifyContent","alignItems","gap","opacity","visibility","overflow","boxShadow","transform"];function Uc(s){if(typeof window>"u")return"";let i=(s.ownerDocument.defaultView??window).getComputedStyle(s),r=[];for(let u of Z2){let d=u.replace(/([A-Z])/g,"-$1").toLowerCase(),_=i.getPropertyValue(d);_&&!mh.has(_)&&r.push(`${d}: ${_}`)}return r.join("; ")}function K2(s){if(!s)return;let i={},r=s.split(";").map(u=>u.trim()).filter(Boolean);for(let u of r){let d=u.indexOf(":");if(d>0){let _=u.slice(0,d).trim(),g=u.slice(d+1).trim();_&&g&&(i[_]=g)}}return Object.keys(i).length>0?i:void 0}function $c(s){let i=[],r=s.getAttribute("role"),u=s.getAttribute("aria-label"),d=s.getAttribute("aria-describedby"),_=s.getAttribute("tabindex"),g=s.getAttribute("aria-hidden");return r&&i.push(`role="${r}"`),u&&i.push(`aria-label="${u}"`),d&&i.push(`aria-describedby="${d}"`),_&&i.push(`tabindex=${_}`),g==="true"&&i.push("aria-hidden"),s.matches("a, button, input, select, textarea, [tabindex]")&&i.push("focusable"),i.join(", ")}function ir(s){let i=[],r=s;for(;r&&r.tagName.toLowerCase()!=="html";){let d=r.tagName.toLowerCase(),_=d;if(r.id)_=`${d}#${r.id}`;else if(r.className&&typeof r.className=="string"){let y=r.className.split(/\s+/).find(E=>E.length>2);y&&(_=`${d}.${CSS.escape(y)}`)}let g=r.parentElement?Array.from(r.parentElement.children).filter(y=>y.tagName===r.tagName):[];g.length>1&&(_+=`:nth-of-type(${g.indexOf(r)+1})`);let w=Xs(r);!r.parentElement&&w&&(_=`\u27E8shadow\u27E9 ${_}`),i.unshift(_),r=w}let u=$n(s.ownerDocument);return(u?ir(u)+" > \u27E8iframe\u27E9 ":"")+i.join(" > ")}var hh="agentation-toolbar, [data-agentation-root], [data-feedback-toolbar], [data-annotation-popup], [data-annotation-marker]",J2=new Set(["DIV","SPAN","SECTION","ARTICLE","MAIN","ASIDE","HEADER","FOOTER","NAV"]);function Ic(s,i){let r=document.elementFromPoint(s,i),u=new Set;for(;r&&!u.has(r);){u.add(r);let d=Pa(r),_;if(d){let g=Bl(r);s=(s-g.x)/g.sx,i=(i-g.y)/g.sy,_=d.elementFromPoint?.(s,i)}else _=r.shadowRoot?.elementFromPoint?.(s,i);if(!_||_===r)break;r=_}return r?.closest?.('input[type="password"], [data-wishes-private], [autocomplete="current-password"], [autocomplete="new-password"]')?null:r}function P2(s){if(typeof s.checkVisibility=="function")return s.checkVisibility({checkOpacity:!0,checkVisibilityCSS:!0});let i=getComputedStyle(s);if(i.visibility==="hidden"||i.visibility==="collapse")return!1;let r=s;for(;r;){let u=getComputedStyle(r);if(u.opacity==="0"||u.display==="none"||u.contentVisibility==="hidden")return!1;let d=r.getRootNode();r=r.parentElement||(fa(d)?d.host:null)}return!0}function gh(s,i){let r=[],u=new Set,d=(_,g,w)=>{for(let y of _){if(u.has(y))continue;if(u.add(y),y.shadowRoot){let M=y.shadowRoot,S=M.elementsFromPoint?.(g,w)??[];d(S.length?S:[M.elementFromPoint?.(g,w)].filter(Boolean),g,w)}let E=Pa(y);if(E){let M=Bl(y),S=(g-M.x)/M.sx,O=(w-M.y)/M.sy;d(E.elementsFromPoint?.(S,O)??[E.elementFromPoint?.(S,O)].filter(Boolean),S,O)}y!==y.ownerDocument.body&&y!==y.ownerDocument.documentElement&&!zn(y,hh)&&P2(y)&&r.push(y)}};return d(document.elementsFromPoint?.(s,i)??[document.elementFromPoint(s,i)].filter(Boolean),s,i),r}function Yc(s,i,r){if(r.width<=0||r.height<=0)return null;let u=null,d=1/0;for(let _ of gh(s,i)){let g=gn(_),w=g.width/r.width,y=g.height/r.height;if(w<.5||w>2||y<.5||y>2)continue;let E=Math.abs(Math.log(w))+Math.abs(Math.log(y));E<d&&(u=_,d=E)}return u}function ph(s,i){let r=Ic(s,i);if(!r||zn(r,hh))return null;let u=gh(s,i);for(let g of u)if(!J2.has(g.tagName)&&!g.shadowRoot||Array.from(g.childNodes).some(w=>w.nodeType===Node.TEXT_NODE&&w.textContent?.trim()))return g;let d=null,_=1/0;for(let g of u){let w=gn(g),y=w.width*w.height;y>0&&y<_&&(d=g,_=y)}return d}var j=tn(),yh=tn();function eb(s){let i=(0,yh.useCallback)(r=>s?(window.addEventListener("hashchange",r),window.addEventListener("popstate",r),()=>{window.removeEventListener("hashchange",r),window.removeEventListener("popstate",r)}):()=>{},[s]);return(0,yh.useSyncExternalStore)(i,()=>window.location.pathname+(s?window.location.hash:""),()=>"/")}var qc=new Map;function tb(s,i){let r=(qc.get(s)??Promise.resolve()).then(i),u=r.then(()=>{},()=>{});return qc.set(s,u),u.then(()=>{qc.get(s)===u&&qc.delete(s)}),r}function nb(s,i,r){try{let u=new URL(s,r);return u.origin===r&&u.pathname+u.hash===i}catch{return!1}}var ob=Br(),p_=tn(),xh=typeof window>"u"?p_.useEffect:p_.useLayoutEffect;function lb(s){let[i,r]=(0,p_.useState)(null);return xh(()=>{let u=document.createElement("div");return u.setAttribute("data-agentation-portal",""),u.style.display="contents",r(u),()=>u.remove()},[]),xh(()=>{if(!i)return;let u=s??document.body;if(u.ownerDocument!==document){console.warn("[Agentation] portalContainer belongs to another document; the toolbar will not render.");return}let d=document.activeElement;for(;d?.shadowRoot?.activeElement;)d=d.shadowRoot.activeElement;let _=d&&i.contains(document.activeElement)?d:null;typeof i.hidePopover=="function"&&i.matches(":popover-open")&&i.hidePopover(),u.appendChild(i),s&&typeof i.showPopover=="function"?(i.setAttribute("popover","manual"),i.style.cssText="position:fixed;inset:0 auto auto 0;margin:0;padding:0;border:0;background:transparent;width:0;height:0;overflow:visible;pointer-events:none",i.showPopover()):(i.removeAttribute("popover"),i.style.cssText="display:contents"),_?.focus({preventScroll:!0})},[i,s]),i}var y_=tn(),ab=Br(),sb=Tn(),ib=({mode:s="open",delegatesFocus:i,slotAssignment:r,host:u="div",children:d,className:_,...g})=>{let w=(0,y_.useRef)(null),[y,E]=(0,y_.useState)(null);(0,y_.useLayoutEffect)(()=>{let S=w.current;if(!S||S.shadowRoot)return;let O=S.attachShadow({mode:s,delegatesFocus:i,slotAssignment:r});E(O)},[]);let M=u;return(0,sb.jsx)(M,{ref:w,...g,...u.includes("-")?{class:_}:{className:_},children:y&&(0,ab.createPortal)(d,y)})},Ho=tn(),x_=tn();function b_(s,i,r){let u=(0,x_.useRef)(r);(0,x_.useLayoutEffect)(()=>{u.current=r},[r]),(0,x_.useLayoutEffect)(()=>{let d=s.current;if(!i||!d)return;let _=!1,g=d.getAnimations?.()??[];return Promise.allSettled(g.map(w=>w.finished)).then(()=>{_||u.current()}),()=>{_=!0}},[s,i])}var bh=`@charset "UTF-8";
.styles-module__popup___IhzrD svg[fill=none] {
  fill: none !important;
}
.styles-module__popup___IhzrD svg[fill=none] :not([fill]) {
  fill: none !important;
}

@keyframes styles-module__popupEnter___AuQDN {
  from {
    opacity: 0;
    transform: translateX(-50%) scale(0.95) translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateX(-50%) scale(1) translateY(0);
  }
}
@keyframes styles-module__popupExit___JJKQX {
  from {
    opacity: 1;
    transform: translateX(-50%) scale(1) translateY(0);
  }
  to {
    opacity: 0;
    transform: translateX(-50%) scale(0.95) translateY(4px);
  }
}
@keyframes styles-module__shake___jdbWe {
  0%, 100% {
    transform: translateX(-50%) scale(1) translateY(0) translateX(0);
  }
  20% {
    transform: translateX(-50%) scale(1) translateY(0) translateX(-3px);
  }
  40% {
    transform: translateX(-50%) scale(1) translateY(0) translateX(3px);
  }
  60% {
    transform: translateX(-50%) scale(1) translateY(0) translateX(-2px);
  }
  80% {
    transform: translateX(-50%) scale(1) translateY(0) translateX(2px);
  }
}
.styles-module__popup___IhzrD {
  position: fixed;
  transform: translateX(-50%);
  width: 280px;
  padding: 0.75rem 1rem;
  background: #1a1a1a;
  border-radius: 16px;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.08);
  z-index: 100001;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  will-change: transform, opacity;
  opacity: 0;
}
.styles-module__popup___IhzrD.styles-module__enter___L7U7N {
  animation: styles-module__popupEnter___AuQDN 0.2s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}
.styles-module__popup___IhzrD.styles-module__entered___COX-w {
  opacity: 1;
  transform: translateX(-50%) scale(1) translateY(0);
}
.styles-module__popup___IhzrD.styles-module__exit___5eGjE {
  pointer-events: none;
  animation: styles-module__popupExit___JJKQX 0.15s ease-in forwards;
}
.styles-module__popup___IhzrD.styles-module__entered___COX-w.styles-module__shake___jdbWe {
  animation: styles-module__shake___jdbWe 0.25s ease-out;
}

.styles-module__header___wWsSi {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.5625rem;
}

.styles-module__element___fTV2z {
  font-size: 0.75rem;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.5);
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
}

.styles-module__headerToggle___WpW0b {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  background: none;
  border: none;
  padding: 0;
  cursor: pointer;
  flex: 1;
  min-width: 0;
  text-align: left;
}
.styles-module__headerToggle___WpW0b .styles-module__element___fTV2z {
  flex: 1;
}

.styles-module__chevron___ZZJlR {
  color: rgba(255, 255, 255, 0.5);
  transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  flex-shrink: 0;
}
.styles-module__chevron___ZZJlR.styles-module__expanded___2Hxgv {
  transform: rotate(90deg);
}

.styles-module__stylesWrapper___pnHgy {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.styles-module__stylesWrapper___pnHgy.styles-module__expanded___2Hxgv {
  grid-template-rows: 1fr;
}

.styles-module__stylesInner___YYZe2 {
  overflow: hidden;
}

.styles-module__stylesBlock___VfQKn {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 0.375rem;
  padding: 0.5rem 0.625rem;
  margin-bottom: 0.5rem;
  font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  font-size: 0.6875rem;
  line-height: 1.5;
}

.styles-module__styleLine___1YQiD {
  color: rgba(255, 255, 255, 0.85);
  word-break: break-word;
}

.styles-module__styleProperty___84L1i {
  color: #c792ea;
}

.styles-module__styleValue___q51-h {
  color: rgba(255, 255, 255, 0.85);
}

.styles-module__timestamp___Dtpsv {
  font-size: 0.625rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.35);
  font-variant-numeric: tabular-nums;
  margin-left: 0.5rem;
  flex-shrink: 0;
}

.styles-module__quote___mcMmQ {
  font-size: 12px;
  font-style: italic;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 0.5rem;
  padding: 0.4rem 0.5rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 0.25rem;
  line-height: 1.45;
}

.styles-module__textarea___jrSae {
  box-sizing: border-box;
  width: 100%;
  padding: 0.5rem 0.625rem;
  font-size: 0.8125rem;
  font-family: inherit;
  background: rgba(255, 255, 255, 0.05);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 8px;
  resize: none;
  outline: none;
  transition: border-color 0.15s ease;
}
.styles-module__textarea___jrSae:focus {
  border-color: var(--agentation-color-blue);
}
.styles-module__textarea___jrSae.styles-module__green___99l3h:focus {
  border-color: var(--agentation-color-green);
}
.styles-module__textarea___jrSae::placeholder {
  color: rgba(255, 255, 255, 0.35);
}
.styles-module__textarea___jrSae::-webkit-scrollbar {
  width: 6px;
}
.styles-module__textarea___jrSae::-webkit-scrollbar-track {
  background: transparent;
}
.styles-module__textarea___jrSae::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

.styles-module__actions___D6x3f {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 0.375rem;
  margin-top: 0.75rem;
}

.styles-module__sourceAction___EabJb {
  display: block;
  max-width: 100%;
  margin: -2px 0 8px;
  padding: 2px 0;
  background: transparent;
  color: #fff;
  font: inherit;
  font-size: 11px;
  border: 0;
  cursor: pointer;
  opacity: 0.6;
  transition: opacity 0.15s ease;
}
.styles-module__sourceAction___EabJb:hover, .styles-module__sourceAction___EabJb:focus-visible {
  opacity: 1;
}
.styles-module__sourceAction___EabJb:focus-visible {
  outline: 2px solid currentColor;
  outline-offset: 3px;
}

.styles-module__light___6AaSQ .styles-module__sourceAction___EabJb {
  color: #111;
}

.styles-module__cancel___hRjnL,
.styles-module__submit___K-mIR,
.styles-module__deleteButton___4VuAE {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 1.875rem;
  padding: 0.375rem 0.875rem;
  font-size: 0.75rem;
  font-weight: 500;
  border-radius: 1rem;
  border: none;
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease, opacity 0.15s ease;
}

.styles-module__cancel___hRjnL {
  background: transparent;
  color: rgba(255, 255, 255, 0.5);
}
.styles-module__cancel___hRjnL:hover {
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.8);
}

.styles-module__submit___K-mIR {
  color: white;
}
.styles-module__submit___K-mIR:hover:not(:disabled) {
  filter: brightness(0.9);
}
.styles-module__submit___K-mIR:disabled {
  cursor: not-allowed;
}

.styles-module__deleteWrapper___oSjdo {
  display: flex;
  margin-right: auto;
}

.styles-module__deleteButton___4VuAE {
  background: transparent;
  color: rgba(255, 255, 255, 0.4);
  transition: background-color 0.15s ease, color 0.15s ease, transform 0.1s ease;
}
.styles-module__deleteButton___4VuAE:hover {
  background-color: color-mix(in srgb, var(--agentation-color-red) 25%, transparent);
  color: var(--agentation-color-red);
}
.styles-module__deleteButton___4VuAE:active {
  transform: scale(0.92);
}

.styles-module__light___6AaSQ.styles-module__popup___IhzrD {
  background: #fff;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.12), 0 0 0 1px rgba(0, 0, 0, 0.06);
}
.styles-module__light___6AaSQ .styles-module__element___fTV2z {
  color: rgba(0, 0, 0, 0.6);
}
.styles-module__light___6AaSQ .styles-module__timestamp___Dtpsv {
  color: rgba(0, 0, 0, 0.4);
}
.styles-module__light___6AaSQ .styles-module__chevron___ZZJlR {
  color: rgba(0, 0, 0, 0.4);
}
.styles-module__light___6AaSQ .styles-module__stylesBlock___VfQKn {
  background: rgba(0, 0, 0, 0.03);
}
.styles-module__light___6AaSQ .styles-module__styleLine___1YQiD {
  color: rgba(0, 0, 0, 0.75);
}
.styles-module__light___6AaSQ .styles-module__styleProperty___84L1i {
  color: #7c3aed;
}
.styles-module__light___6AaSQ .styles-module__styleValue___q51-h {
  color: rgba(0, 0, 0, 0.75);
}
.styles-module__light___6AaSQ .styles-module__quote___mcMmQ {
  color: rgba(0, 0, 0, 0.55);
  background: rgba(0, 0, 0, 0.04);
}
.styles-module__light___6AaSQ .styles-module__textarea___jrSae {
  background: rgba(0, 0, 0, 0.03);
  color: #1a1a1a;
  border-color: rgba(0, 0, 0, 0.12);
}
.styles-module__light___6AaSQ .styles-module__textarea___jrSae::placeholder {
  color: rgba(0, 0, 0, 0.4);
}
.styles-module__light___6AaSQ .styles-module__textarea___jrSae::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
}
.styles-module__light___6AaSQ .styles-module__cancel___hRjnL {
  color: rgba(0, 0, 0, 0.5);
}
.styles-module__light___6AaSQ .styles-module__cancel___hRjnL:hover {
  background: rgba(0, 0, 0, 0.06);
  color: rgba(0, 0, 0, 0.75);
}
.styles-module__light___6AaSQ .styles-module__deleteButton___4VuAE {
  color: rgba(0, 0, 0, 0.4);
}
.styles-module__light___6AaSQ .styles-module__deleteButton___4VuAE:hover {
  background-color: color-mix(in srgb, var(--agentation-color-red) 25%, transparent);
  color: var(--agentation-color-red);
}

@media (prefers-reduced-motion: reduce) {
  .styles-module__popup___IhzrD.styles-module__enter___L7U7N, .styles-module__popup___IhzrD.styles-module__exit___5eGjE {
    animation-duration: 1ms;
    animation-delay: 0ms !important;
  }
}
.styles-module__sharedForm___8GvQl {
  --card-motion: 200ms cubic-bezier(0.2, 0.8, 0.2, 1);
  padding: 0.75rem 1rem;
  transition: padding var(--card-motion);
}
.styles-module__sharedForm___8GvQl .styles-module__header___wWsSi {
  transition: margin-bottom var(--card-motion);
}
.styles-module__sharedForm___8GvQl .styles-module__element___fTV2z {
  font-style: italic;
  color: rgba(255, 255, 255, 0.6);
}
.styles-module__sharedForm___8GvQl .styles-module__previewExcerpt___DCOIL {
  display: none;
}
.styles-module__sharedForm___8GvQl .styles-module__headerToggle___WpW0b .styles-module__chevron___ZZJlR {
  opacity: 1;
  margin-left: 0;
  transition: margin-left var(--card-motion), opacity 100ms ease-out, transform var(--card-motion);
}
.styles-module__sharedForm___8GvQl .styles-module__sharedNote___OYVi5 {
  position: relative;
  height: var(--editor-field-height, 57px);
  border-radius: 8px;
  overflow: clip;
  transition: height var(--card-motion);
}
.styles-module__sharedForm___8GvQl .styles-module__sharedNote___OYVi5::before {
  content: "";
  position: absolute;
  inset: 0;
  border: 1px solid var(--field-border, rgba(255, 255, 255, 0.15));
  border-radius: inherit;
  background: rgba(255, 255, 255, 0.05);
  pointer-events: none;
  transition: opacity var(--card-motion), border-color var(--card-motion);
}
.styles-module__sharedForm___8GvQl .styles-module__sharedNoteContent___6q3KD {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: clip;
  transition: width var(--card-motion);
}
.styles-module__sharedForm___8GvQl .styles-module__sharedNote___OYVi5[data-truncated]::after {
  content: "\u2026";
  position: absolute;
  right: 0;
  top: 0;
  color: #fff;
  font-size: 13px;
  line-height: 1.4;
  opacity: 0;
  pointer-events: none;
  transition: opacity 80ms ease-out;
}
.styles-module__sharedForm___8GvQl .styles-module__textarea___jrSae {
  display: block;
  width: calc(280px - 2rem);
  max-width: calc(100vw - 24px - 2rem);
  margin: 0;
  background: transparent !important;
  border-color: transparent !important;
  transform: translate(0, 0);
  transition: transform var(--card-motion), color var(--card-motion);
}
.styles-module__sharedForm___8GvQl .styles-module__sharedExtra___RUBKC, .styles-module__sharedForm___8GvQl .styles-module__sharedActions___6Glpl {
  display: grid;
  grid-template-rows: 1fr;
  opacity: 1;
  transition: grid-template-rows var(--card-motion), opacity 80ms ease-out;
}
.styles-module__sharedForm___8GvQl .styles-module__sharedActions___6Glpl {
  transition-delay: 0ms, 120ms;
}
.styles-module__sharedForm___8GvQl .styles-module__sharedExtraInner___EuUh4 {
  min-height: 0;
  overflow: hidden;
}
.styles-module__sharedForm___8GvQl .styles-module__actions___D6x3f {
  min-height: 0;
  overflow: hidden;
  transition: margin-top var(--card-motion);
}
.styles-module__sharedForm___8GvQl[data-preview] {
  padding: 8px 12px;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__header___wWsSi {
  margin-bottom: 5px;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__previewExcerpt___DCOIL {
  display: inline;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__element___fTV2z {
  line-height: 1.4;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__chevron___ZZJlR {
  opacity: 0;
  margin-left: -18px;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__sharedNote___OYVi5 {
  height: 20.2px;
  border-radius: 0;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__sharedNote___OYVi5::before {
  opacity: 0;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__textarea___jrSae {
  transform: translate(-11px, calc(-9px + (1.4em - 1lh) / 2));
  color: #fff;
  overflow: hidden;
  cursor: default;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__sharedExtra___RUBKC, .styles-module__sharedForm___8GvQl[data-preview] .styles-module__sharedActions___6Glpl {
  grid-template-rows: 0fr;
  opacity: 0;
  transition-delay: 0ms;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__actions___D6x3f {
  margin-top: 0;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__stylesWrapper___pnHgy {
  grid-template-rows: 0fr;
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__sharedNote___OYVi5[data-truncated] .styles-module__sharedNoteContent___6q3KD {
  width: calc(100% - 12px);
}
.styles-module__sharedForm___8GvQl[data-preview] .styles-module__sharedNote___OYVi5[data-truncated]::after {
  opacity: 1;
}

.styles-module__light___6AaSQ .styles-module__sharedForm___8GvQl .styles-module__sharedNote___OYVi5::before {
  border-color: var(--field-border, rgba(0, 0, 0, 0.12));
  background: rgba(0, 0, 0, 0.03);
}

.styles-module__light___6AaSQ .styles-module__sharedForm___8GvQl .styles-module__element___fTV2z {
  color: rgba(0, 0, 0, 0.5);
}

.styles-module__light___6AaSQ .styles-module__sharedForm___8GvQl[data-preview] .styles-module__textarea___jrSae, .styles-module__light___6AaSQ .styles-module__sharedForm___8GvQl[data-preview] .styles-module__sharedNote___OYVi5::after {
  color: rgba(0, 0, 0, 0.85);
}

@media (prefers-reduced-motion: reduce) {
  .styles-module__sharedForm___8GvQl {
    --card-motion: 1ms linear;
  }
  .styles-module__sharedForm___8GvQl .styles-module__sharedActions___6Glpl, .styles-module__sharedForm___8GvQl .styles-module__headerToggle___WpW0b .styles-module__chevron___ZZJlR {
    transition: opacity 100ms ease-out;
    transition-delay: 0ms;
  }
}`,rt={popup:"styles-module__popup___IhzrD",enter:"styles-module__enter___L7U7N",popupEnter:"styles-module__popupEnter___AuQDN",entered:"styles-module__entered___COX-w",exit:"styles-module__exit___5eGjE",popupExit:"styles-module__popupExit___JJKQX",shake:"styles-module__shake___jdbWe",header:"styles-module__header___wWsSi",element:"styles-module__element___fTV2z",headerToggle:"styles-module__headerToggle___WpW0b",chevron:"styles-module__chevron___ZZJlR",expanded:"styles-module__expanded___2Hxgv",stylesWrapper:"styles-module__stylesWrapper___pnHgy",stylesInner:"styles-module__stylesInner___YYZe2",stylesBlock:"styles-module__stylesBlock___VfQKn",styleLine:"styles-module__styleLine___1YQiD",styleProperty:"styles-module__styleProperty___84L1i",styleValue:"styles-module__styleValue___q51-h",timestamp:"styles-module__timestamp___Dtpsv",quote:"styles-module__quote___mcMmQ",textarea:"styles-module__textarea___jrSae",green:"styles-module__green___99l3h",actions:"styles-module__actions___D6x3f",sourceAction:"styles-module__sourceAction___EabJb",light:"styles-module__light___6AaSQ",cancel:"styles-module__cancel___hRjnL",submit:"styles-module__submit___K-mIR",deleteButton:"styles-module__deleteButton___4VuAE",deleteWrapper:"styles-module__deleteWrapper___oSjdo",sharedForm:"styles-module__sharedForm___8GvQl",previewExcerpt:"styles-module__previewExcerpt___DCOIL",sharedNote:"styles-module__sharedNote___OYVi5",sharedNoteContent:"styles-module__sharedNoteContent___6q3KD",sharedExtra:"styles-module__sharedExtra___RUBKC",sharedActions:"styles-module__sharedActions___6Glpl",sharedExtraInner:"styles-module__sharedExtraInner___EuUh4"},rb=tn(),v_="data-agentation-styles";function vh(s,i,r){if(!r||!s)return;let u=s.nodeType===9?s.head:s.nodeType===11?s:null;if(!u||typeof u.querySelector!="function"||u.querySelector(`style[${v_}~="toolbar"], style[${v_}~="${i}"]`))return;let _=(s.nodeType===9?s:s.ownerDocument).createElement("style");_.setAttribute(v_,i),_.textContent=r,u.appendChild(_)}function Xc(s,i){return(0,rb.useCallback)(r=>{r&&vh(r.getRootNode(),s,i)},[s,i])}var _l=tn(),Rt=Tn();function wh(s){if(!s)return;let i=r=>r.stopImmediatePropagation();document.addEventListener("focusin",i,!0),document.addEventListener("focusout",i,!0);try{s.focus({preventScroll:!0})}finally{document.removeEventListener("focusin",i,!0),document.removeEventListener("focusout",i,!0)}}var Sh=(0,_l.forwardRef)(function({element:i,timestamp:r,selectedText:u,placeholder:d="\u0427\u0442\u043E \u043D\u0443\u0436\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C?",initialValue:_="",submitLabel:g="\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C",onSubmit:w,onCancel:y,onDelete:E,onOpenSource:M,allowEmpty:S=!1,accentColor:O="#3c82f7",computedStyles:W,disabled:H=!1,preview:te=!1,resetOnPreview:B=!0,variant:K="popup"},Se){let G=K==="card",[P,tt]=(0,_l.useState)(_),[ut,se]=(0,_l.useState)(!1),[Ue,oe]=(0,_l.useState)(!1),ze=(0,_l.useRef)(null),Re=(0,_l.useRef)(null),me=u?` "${u.slice(0,30)}${u.length>30?"...":""}"`:"";(0,_l.useLayoutEffect)(()=>{let ye=Re.current,Le=ze.current;if(!G||!ye||!Le)return;let rn=()=>{ye.style.setProperty("--editor-field-height",`${Le.offsetHeight}px`)};if(rn(),"CanvasRenderingContext2D"in window){let St=document.createElement("canvas").getContext("2d");if(St){let ft=getComputedStyle(Le).fontFamily;St.font=`13px ${ft}`;let Vt=St.measureText(_.replace(/\s+/g," ")).width;St.font=`italic 12px ${ft}`;let qn=St.measureText(i+me).width,go=Math.min(200,Math.max(120,Math.ceil(Math.max(Vt,qn))+24));ye.closest("[data-annotation-card]")?.style.setProperty("--preview-width",`${go}px`);let nt=ye.querySelector("[data-shared-note]");nt&&nt.toggleAttribute("data-truncated",Vt>go-24)}}let _t=typeof ResizeObserver<"u"?new ResizeObserver(rn):null;return _t?.observe(Le),()=>_t?.disconnect()},[G,i,_,me]),(0,_l.useLayoutEffect)(()=>{te&&B&&(tt(_),oe(!1),ze.current&&(ze.current.scrollTop=0,ze.current.scrollLeft=0))},[te,B,_]),(0,_l.useImperativeHandle)(Se,()=>({focus(){let ye=ze.current;wh(ye),ye&&(ye.selectionStart=ye.selectionEnd=ye.value.length,ye.scrollTop=G?0:ye.scrollHeight)}}),[G]);let De=(0,_l.useCallback)(()=>{H||!P.trim()&&!S||w(P.trim())},[H,P,S,w]),xe=ye=>{if(ye.stopPropagation(),!ye.nativeEvent.isComposing){if(ye.key==="Enter"&&(ye.ctrlKey||ye.metaKey)){if(ye.preventDefault(),H)return;(P.trim()||S)&&De(),requestAnimationFrame(()=>window.dispatchEvent(new Event("bb-review-submit-request")));return}ye.key==="Enter"&&!ye.shiftKey&&(ye.preventDefault(),De()),ye.key==="Escape"&&y()}};return(0,Rt.jsxs)("div",{ref:Re,className:G?rt.sharedForm:void 0,style:G?void 0:{display:"contents"},"data-annotation-editor":!0,"data-preview":te||void 0,children:[(0,Rt.jsxs)("div",{className:rt.header,"data-editor-heading":!0,children:[W&&Object.keys(W).length>0?(0,Rt.jsxs)("button",{className:rt.headerToggle,onClick:()=>{let ye=Ue;oe(!Ue),ye&&_e(()=>wh(ze.current),0)},type:"button",children:[(0,Rt.jsx)("svg",{className:`${rt.chevron} ${Ue?rt.expanded:""}`,width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,Rt.jsx)("path",{d:"M5.5 10.25L9 7.25L5.75 4",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})}),(0,Rt.jsxs)("span",{className:rt.element,children:[i,G&&me&&(0,Rt.jsx)("span",{className:rt.previewExcerpt,children:me})]})]}):(0,Rt.jsxs)("span",{className:rt.element,children:[i,G&&me&&(0,Rt.jsx)("span",{className:rt.previewExcerpt,children:me})]}),r&&(0,Rt.jsx)("span",{className:rt.timestamp,children:r})]}),M&&(0,Rt.jsx)("div",{className:G?rt.sharedExtra:void 0,style:G?void 0:{display:"contents"},children:(0,Rt.jsx)("div",{className:G?rt.sharedExtraInner:void 0,style:G?void 0:{display:"contents"},children:(0,Rt.jsx)("button",{type:"button",className:rt.sourceAction,onClick:M,children:"\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435"})})}),W&&Object.keys(W).length>0&&(0,Rt.jsx)("div",{className:`${rt.stylesWrapper} ${Ue?rt.expanded:""}`,children:(0,Rt.jsx)("div",{className:rt.stylesInner,children:(0,Rt.jsx)("div",{className:rt.stylesBlock,children:Object.entries(W).map(([ye,Le])=>(0,Rt.jsxs)("div",{className:rt.styleLine,children:[(0,Rt.jsx)("span",{className:rt.styleProperty,children:ye.replace(/([A-Z])/g,"-$1").toLowerCase()}),": ",(0,Rt.jsx)("span",{className:rt.styleValue,children:Le}),";"]},ye))})})}),u&&(0,Rt.jsx)("div",{className:G?rt.sharedExtra:void 0,style:G?void 0:{display:"contents"},children:(0,Rt.jsx)("div",{className:G?rt.sharedExtraInner:void 0,style:G?void 0:{display:"contents"},children:(0,Rt.jsxs)("div",{className:rt.quote,children:["\u201C",u.slice(0,80),u.length>80?"...":"","\u201D"]})})}),(0,Rt.jsx)("div",{"data-shared-note":!0,className:G?rt.sharedNote:void 0,style:G?{"--field-border":ut?O:void 0}:{display:"contents"},children:(0,Rt.jsx)("div",{className:G?rt.sharedNoteContent:void 0,style:G?void 0:{display:"contents"},children:(0,Rt.jsx)("textarea",{ref:ze,className:rt.textarea,readOnly:te,"aria-hidden":te,style:G?void 0:{borderColor:ut?O:void 0},placeholder:d,value:te?P.replace(/\s+/g," "):P,onChange:ye=>tt(ye.target.value),onFocus:()=>se(!0),onBlur:()=>se(!1),rows:2,onKeyDown:xe})})}),(0,Rt.jsx)("div",{"data-editor-actions":!0,className:G?rt.sharedActions:void 0,style:G?void 0:{display:"contents"},children:(0,Rt.jsxs)("div",{className:rt.actions,children:[E&&(0,Rt.jsx)("div",{className:rt.deleteWrapper,children:(0,Rt.jsx)("button",{className:rt.deleteButton,onClick:E,type:"button","aria-label":"\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435",children:"\u0423\u0434\u0430\u043B\u0438\u0442\u044C"})}),(0,Rt.jsx)("button",{className:rt.cancel,onClick:y,children:"\u041E\u0442\u043C\u0435\u043D\u0430"}),(0,Rt.jsx)("button",{className:rt.submit,style:{backgroundColor:O,opacity:P.trim()||S?1:.4},onClick:De,disabled:H||!P.trim()&&!S,children:g})]})})]})}),kh=Tn(),Qc=(0,Ho.forwardRef)(function({element:i,timestamp:r,selectedText:u,placeholder:d="\u0427\u0442\u043E \u043D\u0443\u0436\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C?",initialValue:_="",submitLabel:g="\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C",onSubmit:w,onCancel:y,onDelete:E,onOpenSource:M,allowEmpty:S=!1,style:O,accentColor:W="#3c82f7",isExiting:H=!1,onExitComplete:te,lightMode:B=!1,computedStyles:K},Se){let[G,P]=(0,Ho.useState)(!1),[tt,ut]=(0,Ho.useState)("initial"),se=(0,Ho.useRef)(null),Ue=(0,Ho.useRef)(null);(0,Ho.useEffect)(()=>{vh(Ue.current?.getRootNode(),"annotation-popup",bh)},[]);let oe=(0,Ho.useRef)(null);(0,Ho.useEffect)(()=>{let xe=_e(()=>{ut(ye=>ye==="initial"?"enter":ye)},0);return()=>{clearTimeout(xe),oe.current&&clearTimeout(oe.current)}},[]),(0,Ho.useEffect)(()=>{if(H)return;let xe=_e(()=>se.current?.focus(),50);return()=>clearTimeout(xe)},[H]);let ze=(0,Ho.useCallback)(()=>{oe.current&&clearTimeout(oe.current),P(!0),oe.current=_e(()=>{P(!1),se.current?.focus()},250)},[]);(0,Ho.useImperativeHandle)(Se,()=>({shake:ze}),[ze]);let Re=(0,Ho.useCallback)(()=>{if(te){y();return}ut("exit")},[y,te]),me=H?"exit":tt;b_(Ue,me==="exit",()=>{H?te?.():y()});let De=[rt.popup,B?rt.light:"",me==="enter"?rt.enter:"",me==="entered"?rt.entered:"",me==="exit"?rt.exit:"",G&&me!=="exit"?rt.shake:""].filter(Boolean).join(" ");return(0,kh.jsx)("div",{ref:Ue,className:De,"data-annotation-popup":!0,style:O,onAnimationEnd:xe=>{xe.target===xe.currentTarget&&xe.animationName.includes("popupEnter")&&!H&&ut("entered")},onKeyDownCapture:xe=>{xe.key!=="Escape"||xe.nativeEvent.isComposing||(xe.preventDefault(),xe.stopPropagation(),Re())},onClick:xe=>xe.stopPropagation(),children:(0,kh.jsx)(Sh,{ref:se,element:i,timestamp:r,selectedText:u,placeholder:d,initialValue:_,submitLabel:g,onSubmit:w,onCancel:Re,onDelete:E,onOpenSource:M,allowEmpty:S,accentColor:W,computedStyles:K,disabled:me==="exit"})})}),rr=`.icon-transitions-module__iconState___uqK9J {
  transition: opacity 0.2s ease, transform 0.2s ease;
  transform-origin: center;
}

.icon-transitions-module__iconStateFast___HxlMm {
  transition: opacity 0.15s ease, transform 0.15s ease;
  transform-origin: center;
}

.icon-transitions-module__iconFade___nPwXg {
  transition: opacity 0.2s ease;
}

.icon-transitions-module__iconFadeFast___Ofb2t {
  transition: opacity 0.15s ease;
}

.icon-transitions-module__visible___PlHsU {
  opacity: 1 !important;
}

.icon-transitions-module__visibleScaled___8Qog- {
  opacity: 1 !important;
  transform: scale(1);
}

.icon-transitions-module__hidden___ETykt {
  opacity: 0 !important;
}

.icon-transitions-module__hiddenScaled___JXn-m {
  opacity: 0 !important;
  transform: scale(0.8);
}

.icon-transitions-module__sending___uaLN- {
  opacity: 0.5 !important;
  transform: scale(0.8);
}`,xt={iconState:"icon-transitions-module__iconState___uqK9J",iconStateFast:"icon-transitions-module__iconStateFast___HxlMm",iconFade:"icon-transitions-module__iconFade___nPwXg",iconFadeFast:"icon-transitions-module__iconFadeFast___Ofb2t",visible:"icon-transitions-module__visible___PlHsU",visibleScaled:"icon-transitions-module__visibleScaled___8Qog-",hidden:"icon-transitions-module__hidden___ETykt",hiddenScaled:"icon-transitions-module__hiddenScaled___JXn-m",sending:"icon-transitions-module__sending___uaLN-"},I=Tn(),cb=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 16 16",fill:"none",children:(0,I.jsx)("path",{d:"M4 4l8 8M12 4l-8 8",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})}),Ch=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 16 16",fill:"none",children:(0,I.jsx)("path",{d:"M8 3v10M3 8h10",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})}),ub=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 16 16",fill:"none",children:(0,I.jsx)("path",{d:"M3 8l3.5 3.5L13 5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})}),db=({size:s=14})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 14 14",fill:"none",children:(0,I.jsx)("path",{d:"M3.9375 7L6.125 9.1875L10.5 4.8125",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})}),_b=({size:s=24,style:i={}})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",style:i,children:[(0,I.jsxs)("g",{clipPath:"url(#clip0_list_sparkle)",children:[(0,I.jsx)("path",{d:"M11.5 12L5.5 12",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M18.5 6.75L5.5 6.75",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M9.25 17.25L5.5 17.25",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M16 12.75L16.5179 13.9677C16.8078 14.6494 17.3506 15.1922 18.0323 15.4821L19.25 16L18.0323 16.5179C17.3506 16.8078 16.8078 17.3506 16.5179 18.0323L16 19.25L15.4821 18.0323C15.1922 17.3506 14.6494 16.8078 13.9677 16.5179L12.75 16L13.9677 15.4821C14.6494 15.1922 15.1922 14.6494 15.4821 13.9677L16 12.75Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinejoin:"round"})]}),(0,I.jsx)("defs",{children:(0,I.jsx)("clipPath",{id:"clip0_list_sparkle",children:(0,I.jsx)("rect",{width:"24",height:"24",fill:"white"})})})]}),jh=({size:s=20,...i})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",...i,children:[(0,I.jsx)("circle",{cx:"10",cy:"10",r:"5.375",stroke:"currentColor",strokeWidth:"1.25"}),(0,I.jsx)("path",{d:"M8.5 8.5C8.73 7.85 9.31 7.49 10 7.5C10.86 7.51 11.5 8.13 11.5 9C11.5 10.08 10 10.5 10 10.5V10.75",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("circle",{cx:"10",cy:"12.625",r:"0.625",fill:"currentColor"})]}),fb=({size:s=14})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 14 14",fill:"none",children:[(0,I.jsx)("style",{children:`
      @keyframes checkDraw {
        0% {
          stroke-dashoffset: 12;
        }
        100% {
          stroke-dashoffset: 0;
        }
      }
      @keyframes checkBounce {
        0% {
          transform: scale(0.5);
          opacity: 0;
        }
        50% {
          transform: scale(1.12);
          opacity: 1;
        }
        75% {
          transform: scale(0.95);
        }
        100% {
          transform: scale(1);
        }
      }
      .check-path-animated {
        stroke-dasharray: 12;
        stroke-dashoffset: 0;
        transform-origin: center;
        animation: checkDraw 0.18s ease-out, checkBounce 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
      }
    `}),(0,I.jsx)("path",{className:"check-path-animated",d:"M3.9375 7L6.125 9.1875L10.5 4.8125",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]}),mb=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("path",{d:"M4.75 11.25C4.75 10.4216 5.42157 9.75 6.25 9.75H12.75C13.5784 9.75 14.25 10.4216 14.25 11.25V17.75C14.25 18.5784 13.5784 19.25 12.75 19.25H6.25C5.42157 19.25 4.75 18.5784 4.75 17.75V11.25Z",stroke:"currentColor",strokeWidth:"1.5"}),(0,I.jsx)("path",{d:"M17.25 14.25H17.75C18.5784 14.25 19.25 13.5784 19.25 12.75V6.25C19.25 5.42157 18.5784 4.75 17.75 4.75H11.25C10.4216 4.75 9.75 5.42157 9.75 6.25V6.75",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})]}),hb=({size:s=24,copied:i=!1,tint:r})=>(0,I.jsxs)("svg",{ref:Xc("icon-transitions",rr),width:s,height:s,viewBox:"0 0 24 24",fill:"none",style:r?{color:r,transition:"color 0.3s ease"}:void 0,children:[(0,I.jsxs)("g",{className:`${xt.iconState} ${i?xt.hiddenScaled:xt.visibleScaled}`,children:[(0,I.jsx)("path",{d:"M4.75 11.25C4.75 10.4216 5.42157 9.75 6.25 9.75H12.75C13.5784 9.75 14.25 10.4216 14.25 11.25V17.75C14.25 18.5784 13.5784 19.25 12.75 19.25H6.25C5.42157 19.25 4.75 18.5784 4.75 17.75V11.25Z",stroke:"currentColor",strokeWidth:"1.5"}),(0,I.jsx)("path",{d:"M17.25 14.25H17.75C18.5784 14.25 19.25 13.5784 19.25 12.75V6.25C19.25 5.42157 18.5784 4.75 17.75 4.75H11.25C10.4216 4.75 9.75 5.42157 9.75 6.25V6.75",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})]}),(0,I.jsxs)("g",{className:`${xt.iconState} ${i?xt.visibleScaled:xt.hiddenScaled}`,children:[(0,I.jsx)("path",{d:"M12 20C7.58172 20 4 16.4182 4 12C4 7.58172 7.58172 4 12 4C16.4182 4 20 7.58172 20 12C20 16.4182 16.4182 20 12 20Z",stroke:"var(--agentation-color-green)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M15 10L11 14.25L9.25 12.25",stroke:"var(--agentation-color-green)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]})]}),gb=({size:s=24,state:i="idle"})=>{let r=i==="idle",u=i==="sent",d=i==="failed",_=i==="sending";return(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("g",{className:`${xt.iconStateFast} ${r?xt.visibleScaled:_?xt.sending:xt.hiddenScaled}`,children:(0,I.jsx)("path",{d:"M9.875 14.125L12.3506 19.6951C12.7184 20.5227 13.9091 20.4741 14.2083 19.6193L18.8139 6.46032C19.0907 5.6695 18.3305 4.90933 17.5397 5.18611L4.38072 9.79174C3.52589 10.0909 3.47731 11.2816 4.30494 11.6494L9.875 14.125ZM9.875 14.125L13.375 10.625",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})}),(0,I.jsxs)("g",{className:`${xt.iconStateFast} ${u?xt.visibleScaled:xt.hiddenScaled}`,children:[(0,I.jsx)("path",{d:"M12 20C7.58172 20 4 16.4182 4 12C4 7.58172 7.58172 4 12 4C16.4182 4 20 7.58172 20 12C20 16.4182 16.4182 20 12 20Z",stroke:"var(--agentation-color-green)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M15 10L11 14.25L9.25 12.25",stroke:"var(--agentation-color-green)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]}),(0,I.jsxs)("g",{className:`${xt.iconStateFast} ${d?xt.visibleScaled:xt.hiddenScaled}`,children:[(0,I.jsx)("path",{d:"M12 20C7.58172 20 4 16.4182 4 12C4 7.58172 7.58172 4 12 4C16.4182 4 20 7.58172 20 12C20 16.4182 16.4182 20 12 20Z",stroke:"var(--agentation-color-red)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M12 8V12",stroke:"var(--agentation-color-red)",strokeWidth:"1.5",strokeLinecap:"round"}),(0,I.jsx)("circle",{cx:"12",cy:"15",r:"0.5",fill:"var(--agentation-color-red)",stroke:"var(--agentation-color-red)",strokeWidth:"1"})]})]})},pb=({size:s=24,sent:i=!1})=>(0,I.jsxs)("svg",{ref:Xc("icon-transitions",rr),width:s,height:s,viewBox:"0 0 22 21",fill:"none",children:[(0,I.jsxs)("g",{className:`${xt.iconState} ${i?xt.hiddenScaled:xt.visibleScaled}`,children:[(0,I.jsx)("path",{d:"M9.5 5H6.5C4.84315 5 3.5 6.34315 3.5 8V15C3.5 16.6569 4.84315 18 6.5 18H13.5C15.1569 18 16.5 16.6569 16.5 15V12",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"}),(0,I.jsx)("path",{d:"M13.5 8.5L18.5 3.5M18.5 3.5L14.4524 3.5M18.5 3.5L18.5 7.54762",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M7.5 13.75H12.5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"}),(0,I.jsx)("path",{d:"M7.5 10.75H10.5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})]}),(0,I.jsxs)("g",{className:`${xt.iconState} ${i?xt.visibleScaled:xt.hiddenScaled}`,children:[(0,I.jsx)("path",{d:"M11 19C6.58172 19 3 15.4182 3 11C3 6.58172 6.58172 3 11 3C15.4182 3 19 6.58172 19 11C19 15.4182 15.4182 19 11 19Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M14 9L10 13.25L8.25 11.25",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]})]}),yb=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("path",{d:"M4.91516 12.7108C4.63794 12.2883 4.63705 11.7565 4.91242 11.3328C5.84146 9.9033 8.30909 6.74994 12 6.74994C15.6909 6.74994 18.1585 9.9033 19.0876 11.3328C19.3629 11.7565 19.3621 12.2883 19.0848 12.7108C18.1537 14.13 15.6873 17.2499 12 17.2499C8.31272 17.2499 5.8463 14.13 4.91516 12.7108Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M12 14.25C13.2426 14.25 14.25 13.2426 14.25 12C14.25 10.7574 13.2426 9.75 12 9.75C10.7574 9.75 9.75 10.7574 9.75 12C9.75 13.2426 10.7574 14.25 12 14.25Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]}),xb=({size:s=24})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("path",{d:"M3.91752 12.7539C3.65127 12.2996 3.65037 11.7515 3.9149 11.2962C4.9042 9.59346 7.72688 5.49994 12 5.49994C16.2731 5.49994 19.0958 9.59346 20.0851 11.2962C20.3496 11.7515 20.3487 12.2996 20.0825 12.7539C19.0908 14.4459 16.2694 18.4999 12 18.4999C7.73064 18.4999 4.90918 14.4459 3.91752 12.7539Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M12 14.8261C13.5608 14.8261 14.8261 13.5608 14.8261 12C14.8261 10.4392 13.5608 9.17392 12 9.17392C10.4392 9.17392 9.17391 10.4392 9.17391 12C9.17391 13.5608 10.4392 14.8261 12 14.8261Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]}),bb=({size:s=24})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("path",{d:"M18.6025 9.28503C18.9174 8.9701 19.4364 8.99481 19.7015 9.35271C20.1484 9.95606 20.4943 10.507 20.7342 10.9199C21.134 11.6086 21.1329 12.4454 20.7303 13.1328C20.2144 14.013 19.2151 15.5225 17.7723 16.8193C16.3293 18.1162 14.3852 19.2497 12.0008 19.25C11.4192 19.25 10.8638 19.1823 10.3355 19.0613C9.77966 18.934 9.63498 18.2525 10.0382 17.8493C10.2412 17.6463 10.5374 17.573 10.8188 17.6302C11.1993 17.7076 11.5935 17.75 12.0008 17.75C13.8848 17.7497 15.4867 16.8568 16.7693 15.7041C18.0522 14.5511 18.9606 13.1867 19.4363 12.375C19.5656 12.1543 19.5659 11.8943 19.4373 11.6729C19.2235 11.3049 18.921 10.8242 18.5364 10.3003C18.3085 9.98991 18.3302 9.5573 18.6025 9.28503ZM12.0008 4.75C12.5814 4.75006 13.1358 4.81803 13.6632 4.93953C14.2182 5.06741 14.362 5.74812 13.9593 6.15091C13.7558 6.35435 13.4589 6.42748 13.1771 6.36984C12.7983 6.29239 12.4061 6.25006 12.0008 6.25C10.1167 6.25 8.51415 7.15145 7.23028 8.31543C5.94678 9.47919 5.03918 10.8555 4.56426 11.6729C4.43551 11.8945 4.43582 12.1542 4.56524 12.375C4.77587 12.7343 5.07189 13.2012 5.44718 13.7105C5.67623 14.0213 5.65493 14.4552 5.38193 14.7282C5.0671 15.0431 4.54833 15.0189 4.28292 14.6614C3.84652 14.0736 3.50813 13.5369 3.27129 13.1328C2.86831 12.4451 2.86717 11.6088 3.26739 10.9199C3.78185 10.0345 4.77959 8.51239 6.22247 7.2041C7.66547 5.89584 9.61202 4.75 12.0008 4.75Z",fill:"currentColor"}),(0,I.jsx)("path",{d:"M5 19L19 5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})]}),vb=({size:s=24,isOpen:i=!0})=>(0,I.jsxs)("svg",{ref:Xc("icon-transitions",rr),width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsxs)("g",{className:`${xt.iconFade} ${i?xt.visible:xt.hidden}`,children:[(0,I.jsx)("path",{d:"M3.91752 12.7539C3.65127 12.2996 3.65037 11.7515 3.9149 11.2962C4.9042 9.59346 7.72688 5.49994 12 5.49994C16.2731 5.49994 19.0958 9.59346 20.0851 11.2962C20.3496 11.7515 20.3487 12.2996 20.0825 12.7539C19.0908 14.4459 16.2694 18.4999 12 18.4999C7.73064 18.4999 4.90918 14.4459 3.91752 12.7539Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M12 14.8261C13.5608 14.8261 14.8261 13.5608 14.8261 12C14.8261 10.4392 13.5608 9.17392 12 9.17392C10.4392 9.17392 9.17391 10.4392 9.17391 12C9.17391 13.5608 10.4392 14.8261 12 14.8261Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]}),(0,I.jsxs)("g",{className:`${xt.iconFade} ${i?xt.hidden:xt.visible}`,children:[(0,I.jsx)("path",{d:"M18.6025 9.28503C18.9174 8.9701 19.4364 8.99481 19.7015 9.35271C20.1484 9.95606 20.4943 10.507 20.7342 10.9199C21.134 11.6086 21.1329 12.4454 20.7303 13.1328C20.2144 14.013 19.2151 15.5225 17.7723 16.8193C16.3293 18.1162 14.3852 19.2497 12.0008 19.25C11.4192 19.25 10.8638 19.1823 10.3355 19.0613C9.77966 18.934 9.63498 18.2525 10.0382 17.8493C10.2412 17.6463 10.5374 17.573 10.8188 17.6302C11.1993 17.7076 11.5935 17.75 12.0008 17.75C13.8848 17.7497 15.4867 16.8568 16.7693 15.7041C18.0522 14.5511 18.9606 13.1867 19.4363 12.375C19.5656 12.1543 19.5659 11.8943 19.4373 11.6729C19.2235 11.3049 18.921 10.8242 18.5364 10.3003C18.3085 9.98991 18.3302 9.5573 18.6025 9.28503ZM12.0008 4.75C12.5814 4.75006 13.1358 4.81803 13.6632 4.93953C14.2182 5.06741 14.362 5.74812 13.9593 6.15091C13.7558 6.35435 13.4589 6.42748 13.1771 6.36984C12.7983 6.29239 12.4061 6.25006 12.0008 6.25C10.1167 6.25 8.51415 7.15145 7.23028 8.31543C5.94678 9.47919 5.03918 10.8555 4.56426 11.6729C4.43551 11.8945 4.43582 12.1542 4.56524 12.375C4.77587 12.7343 5.07189 13.2012 5.44718 13.7105C5.67623 14.0213 5.65493 14.4552 5.38193 14.7282C5.0671 15.0431 4.54833 15.0189 4.28292 14.6614C3.84652 14.0736 3.50813 13.5369 3.27129 13.1328C2.86831 12.4451 2.86717 11.6088 3.26739 10.9199C3.78185 10.0345 4.77959 8.51239 6.22247 7.2041C7.66547 5.89584 9.61202 4.75 12.0008 4.75Z",fill:"currentColor"}),(0,I.jsx)("path",{d:"M5 19L19 5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})]})]}),wb=({size:s=24,isPaused:i=!1})=>(0,I.jsxs)("svg",{ref:Xc("icon-transitions",rr),width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsxs)("g",{className:`${xt.iconFadeFast} ${i?xt.hidden:xt.visible}`,children:[(0,I.jsx)("path",{d:"M8 6L8 18",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"}),(0,I.jsx)("path",{d:"M16 18L16 6",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})]}),(0,I.jsx)("path",{className:`${xt.iconFadeFast} ${i?xt.visible:xt.hidden}`,d:"M17.75 10.701C18.75 11.2783 18.75 12.7217 17.75 13.299L8.75 18.4952C7.75 19.0725 6.5 18.3509 6.5 17.1962L6.5 6.80384C6.5 5.64914 7.75 4.92746 8.75 5.50481L17.75 10.701Z",stroke:"currentColor",strokeWidth:"1.5"})]}),Sb=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("path",{d:"M4.91516 12.7108C4.63794 12.2883 4.63705 11.7565 4.91242 11.3328C5.84146 9.9033 8.30909 6.74994 12 6.74994C15.6909 6.74994 18.1585 9.9033 19.0876 11.3328C19.3629 11.7565 19.3621 12.2883 19.0848 12.7108C18.1537 14.13 15.6873 17.2499 12 17.2499C8.31272 17.2499 5.8463 14.13 4.91516 12.7108Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M9 12H15",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})]}),kb=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("path",{d:"M10.6504 5.81117C10.9939 4.39628 13.0061 4.39628 13.3496 5.81117C13.5715 6.72517 14.6187 7.15891 15.4219 6.66952C16.6652 5.91193 18.0881 7.33479 17.3305 8.57815C16.8411 9.38134 17.2748 10.4285 18.1888 10.6504C19.6037 10.9939 19.6037 13.0061 18.1888 13.3496C17.2748 13.5715 16.8411 14.6187 17.3305 15.4219C18.0881 16.6652 16.6652 18.0881 15.4219 17.3305C14.6187 16.8411 13.5715 17.2748 13.3496 18.1888C13.0061 19.6037 10.9939 19.6037 10.6504 18.1888C10.4285 17.2748 9.38135 16.8411 8.57815 17.3305C7.33479 18.0881 5.91193 16.6652 6.66952 15.4219C7.15891 14.6187 6.72517 13.5715 5.81117 13.3496C4.39628 13.0061 4.39628 10.9939 5.81117 10.6504C6.72517 10.4285 7.15891 9.38134 6.66952 8.57815C5.91193 7.33479 7.33479 5.91192 8.57815 6.66952C9.38135 7.15891 10.4285 6.72517 10.6504 5.81117Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("circle",{cx:"12",cy:"12",r:"2.5",stroke:"currentColor",strokeWidth:"1.5"})]}),Cb=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("path",{d:"M9.25 5.75C9.80228 5.75 10.25 6.19772 10.25 6.75L10.25 17.25C10.25 17.8023 9.80228 18.25 9.25 18.25L6.75 18.25C6.19772 18.25 5.75 17.8023 5.75 17.25L5.75 6.75C5.75 6.19772 6.19772 5.75 6.75 5.75L9.25 5.75Z",stroke:"currentColor",strokeWidth:"1.5"}),(0,I.jsx)("path",{d:"M17.25 5.75C17.8023 5.75 18.25 6.19772 18.25 6.75L18.25 17.25C18.25 17.8023 17.8023 18.25 17.25 18.25L14.75 18.25C14.1977 18.25 13.75 17.8023 13.75 17.25L13.75 6.75C13.75 6.19772 14.1977 5.75 14.75 5.75L17.25 5.75Z",stroke:"currentColor",strokeWidth:"1.5"})]}),jb=({size:s=24})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("path",{d:"M8 6L8 18",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"}),(0,I.jsx)("path",{d:"M16 18L16 6",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round"})]}),Eb=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:(0,I.jsx)("path",{d:"M17.75 10.701C18.75 11.2783 18.75 12.7217 17.75 13.299L8.75 18.4952C7.75 19.0725 6.5 18.3509 6.5 17.1962L6.5 6.80384C6.5 5.64914 7.75 4.92746 8.75 5.50481L17.75 10.701Z",stroke:"currentColor",strokeWidth:"1.5"})}),Mb=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:(0,I.jsx)("path",{d:"M13.5 4C14.7426 4 15.75 5.00736 15.75 6.25V7H18.5C18.9142 7 19.25 7.33579 19.25 7.75C19.25 8.16421 18.9142 8.5 18.5 8.5H17.9678L17.6328 16.2217C17.61 16.7475 17.5912 17.1861 17.5469 17.543C17.5015 17.9087 17.4225 18.2506 17.2461 18.5723C16.9747 19.0671 16.5579 19.4671 16.0518 19.7168C15.7227 19.8791 15.3772 19.9422 15.0098 19.9717C14.6514 20.0004 14.2126 20 13.6865 20H10.3135C9.78735 20 9.34856 20.0004 8.99023 19.9717C8.62278 19.9422 8.27729 19.8791 7.94824 19.7168C7.44205 19.4671 7.02532 19.0671 6.75391 18.5723C6.57751 18.2506 6.49853 17.9087 6.45312 17.543C6.40883 17.1861 6.39005 16.7475 6.36719 16.2217L6.03223 8.5H5.5C5.08579 8.5 4.75 8.16421 4.75 7.75C4.75 7.33579 5.08579 7 5.5 7H8.25V6.25C8.25 5.00736 9.25736 4 10.5 4H13.5ZM7.86621 16.1562C7.89013 16.7063 7.90624 17.0751 7.94141 17.3584C7.97545 17.6326 8.02151 17.7644 8.06934 17.8516C8.19271 18.0763 8.38239 18.2577 8.6123 18.3711C8.70153 18.4151 8.83504 18.4545 9.11035 18.4766C9.39482 18.4994 9.76335 18.5 10.3135 18.5H13.6865C14.2367 18.5 14.6052 18.4994 14.8896 18.4766C15.165 18.4545 15.2985 18.4151 15.3877 18.3711C15.6176 18.2577 15.8073 18.0763 15.9307 17.8516C15.9785 17.7644 16.0245 17.6326 16.0586 17.3584C16.0938 17.0751 16.1099 16.7063 16.1338 16.1562L16.4668 8.5H7.5332L7.86621 16.1562ZM9.97656 10.75C10.3906 10.7371 10.7371 11.0626 10.75 11.4766L10.875 15.4766C10.8879 15.8906 10.5624 16.2371 10.1484 16.25C9.73443 16.2629 9.38794 15.9374 9.375 15.5234L9.25 11.5234C9.23706 11.1094 9.56255 10.7629 9.97656 10.75ZM14.0244 10.75C14.4384 10.7635 14.7635 11.1105 14.75 11.5244L14.6201 15.5244C14.6066 15.9384 14.2596 16.2634 13.8457 16.25C13.4317 16.2365 13.1067 15.8896 13.1201 15.4756L13.251 11.4756C13.2645 11.0617 13.6105 10.7366 14.0244 10.75ZM10.5 5.5C10.0858 5.5 9.75 5.83579 9.75 6.25V7H14.25V6.25C14.25 5.83579 13.9142 5.5 13.5 5.5H10.5Z",fill:"currentColor"})}),Tb=({size:s=16,style:i={}})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",style:i,children:[(0,I.jsx)("path",{d:"M18.8875 19.25L19.6112 19.0533C19.6823 19.3148 19.6068 19.5943 19.4137 19.7844C19.2206 19.9746 18.9399 20.0457 18.6795 19.9706L18.8875 19.25ZM14.9631 18.244L15.263 18.9314L14.9631 18.244ZM18.0914 15.6309L17.4669 15.2156L18.0914 15.6309ZM4.75 11.8041H5.5C5.5 15.2664 8.39065 18.1081 12 18.1081V18.8581V19.6081C7.60123 19.6081 4 16.1334 4 11.8041H4.75ZM19.25 11.8041H18.5C18.5 8.34166 15.6094 5.5 12 5.5V4.75V4C16.3988 4 20 7.47476 20 11.8041H19.25ZM12 4.75V5.5C8.39065 5.5 5.5 8.34166 5.5 11.8041H4.75H4C4 7.47476 7.60123 4 12 4V4.75ZM18.0914 15.6309L17.4669 15.2156C18.1213 14.2315 18.5 13.0612 18.5 11.8041H19.25H20C20 13.3681 19.5276 14.8257 18.716 16.0462L18.0914 15.6309ZM18.8875 19.25L18.1638 19.4467L17.2953 16.2517L18.019 16.055L18.7428 15.8583L19.6112 19.0533L18.8875 19.25ZM12 18.8581V18.1081C12.9509 18.1081 13.8518 17.9105 14.6632 17.5565L14.9631 18.244L15.263 18.9314C14.2652 19.3667 13.1603 19.6081 12 19.6081V18.8581ZM15.3144 18.2188L15.5224 17.4982L19.0955 18.5294L18.8875 19.25L18.6795 19.9706L15.1064 18.9394L15.3144 18.2188ZM14.9631 18.244L14.6632 17.5565C14.925 17.4423 15.2286 17.4134 15.5224 17.4982L15.3144 18.2188L15.1064 18.9394C15.1677 18.957 15.223 18.9489 15.263 18.9314L14.9631 18.244ZM18.0914 15.6309L18.716 16.0462C18.7451 16.0024 18.7636 15.9351 18.7428 15.8583L18.019 16.055L17.2953 16.2517C17.1957 15.8853 17.2716 15.5093 17.4669 15.2156L18.0914 15.6309Z",fill:"currentColor"}),(0,I.jsx)("circle",{cx:"15",cy:"11.75",r:"1",fill:"currentColor"}),(0,I.jsx)("circle",{cx:"12",cy:"11.75",r:"1",fill:"currentColor"}),(0,I.jsx)("circle",{cx:"9",cy:"11.75",r:"1",fill:"currentColor"})]}),Nb=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("g",{clipPath:"url(#clip0_2_45)",children:(0,I.jsx)("path",{d:"M16.25 8.75L10 15.25L7.25 12.25",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})}),(0,I.jsx)("defs",{children:(0,I.jsx)("clipPath",{id:"clip0_2_45",children:(0,I.jsx)("rect",{width:"24",height:"24",fill:"white"})})})]}),Rb=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("g",{clipPath:"url(#clip0_2_37)",children:(0,I.jsx)("path",{d:"M17.5962 7.75L9.42308 16.25L6.15385 12.6538",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})}),(0,I.jsx)("defs",{children:(0,I.jsx)("clipPath",{id:"clip0_2_37",children:(0,I.jsx)("rect",{width:"24",height:"24",fill:"white"})})})]}),Ab=({size:s=24})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsxs)("g",{clipPath:"url(#clip0_checkmark_circle)",children:[(0,I.jsx)("path",{d:"M12 20C7.58172 20 4 16.4182 4 12C4 7.58172 7.58172 4 12 4C16.4182 4 20 7.58172 20 12C20 16.4182 16.4182 20 12 20Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M15 10L11 14.25L9.25 12.25",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]}),(0,I.jsx)("defs",{children:(0,I.jsx)("clipPath",{id:"clip0_checkmark_circle",children:(0,I.jsx)("rect",{width:"24",height:"24",fill:"white"})})})]}),Eh=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsxs)("g",{clipPath:"url(#clip0_2_53)",children:[(0,I.jsx)("path",{d:"M16.25 16.25L7.75 7.75",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M7.75 16.25L16.25 7.75",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})]}),(0,I.jsx)("defs",{children:(0,I.jsx)("clipPath",{id:"clip0_2_53",children:(0,I.jsx)("rect",{width:"24",height:"24",fill:"white"})})})]}),Db=({size:s=24})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:(0,I.jsx)("path",{d:"M16.7198 6.21973C17.0127 5.92683 17.4874 5.92683 17.7803 6.21973C18.0732 6.51262 18.0732 6.9874 17.7803 7.28027L13.0606 12L17.7803 16.7197C18.0732 17.0126 18.0732 17.4874 17.7803 17.7803C17.4875 18.0731 17.0127 18.0731 16.7198 17.7803L12.0001 13.0605L7.28033 17.7803C6.98746 18.0731 6.51268 18.0731 6.21979 17.7803C5.92689 17.4874 5.92689 17.0126 6.21979 16.7197L10.9395 12L6.21979 7.28027C5.92689 6.98738 5.92689 6.51262 6.21979 6.21973C6.51268 5.92683 6.98744 5.92683 7.28033 6.21973L12.0001 10.9395L16.7198 6.21973Z",fill:"currentColor"})}),Mh=({size:s=16})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 20 20",fill:"none",children:[(0,I.jsx)("path",{d:"M9.99999 12.7082C11.4958 12.7082 12.7083 11.4956 12.7083 9.99984C12.7083 8.50407 11.4958 7.2915 9.99999 7.2915C8.50422 7.2915 7.29166 8.50407 7.29166 9.99984C7.29166 11.4956 8.50422 12.7082 9.99999 12.7082Z",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M10 3.9585V5.05698",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M10 14.9429V16.0414",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M5.7269 5.72656L6.50682 6.50649",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M13.4932 13.4932L14.2731 14.2731",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M3.95834 10H5.05683",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M14.9432 10H16.0417",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M5.7269 14.2731L6.50682 13.4932",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"}),(0,I.jsx)("path",{d:"M13.4932 6.50649L14.2731 5.72656",stroke:"currentColor",strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round"})]}),Th=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 20 20",fill:"none",children:(0,I.jsx)("path",{d:"M15.5 10.4955C15.4037 11.5379 15.0124 12.5314 14.3721 13.3596C13.7317 14.1878 12.8688 14.8165 11.8841 15.1722C10.8995 15.5278 9.83397 15.5957 8.81217 15.3679C7.79038 15.1401 6.8546 14.6259 6.11434 13.8857C5.37408 13.1454 4.85995 12.2096 4.63211 11.1878C4.40427 10.166 4.47215 9.10048 4.82781 8.11585C5.18346 7.13123 5.81218 6.26825 6.64039 5.62791C7.4686 4.98756 8.46206 4.59634 9.5045 4.5C8.89418 5.32569 8.60049 6.34302 8.67685 7.36695C8.75321 8.39087 9.19454 9.35339 9.92058 10.0794C10.6466 10.8055 11.6091 11.2468 12.6331 11.3231C13.657 11.3995 14.6743 11.1058 15.5 10.4955Z",stroke:"currentColor",strokeWidth:"1.13793",strokeLinecap:"round",strokeLinejoin:"round"})}),Nh=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,I.jsx)("path",{d:"M11.3799 6.9572L9.05645 4.63375M11.3799 6.9572L6.74949 11.5699C6.61925 11.6996 6.45577 11.791 6.277 11.8339L4.29549 12.3092C3.93194 12.3964 3.60478 12.0683 3.69297 11.705L4.16585 9.75693C4.20893 9.57947 4.29978 9.4172 4.42854 9.28771L9.05645 4.63375M11.3799 6.9572L12.3455 5.98759C12.9839 5.34655 12.9839 4.31002 12.3455 3.66897C11.7033 3.02415 10.6594 3.02415 10.0172 3.66897L9.06126 4.62892L9.05645 4.63375",stroke:"currentColor",strokeWidth:"0.9",strokeLinecap:"round",strokeLinejoin:"round"})}),Ob=({size:s=24})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,I.jsx)("path",{d:"M13.5 4C14.7426 4 15.75 5.00736 15.75 6.25V7H18.5C18.9142 7 19.25 7.33579 19.25 7.75C19.25 8.16421 18.9142 8.5 18.5 8.5H17.9678L17.6328 16.2217C17.61 16.7475 17.5912 17.1861 17.5469 17.543C17.5015 17.9087 17.4225 18.2506 17.2461 18.5723C16.9747 19.0671 16.5579 19.4671 16.0518 19.7168C15.7227 19.8791 15.3772 19.9422 15.0098 19.9717C14.6514 20.0004 14.2126 20 13.6865 20H10.3135C9.78735 20 9.34856 20.0004 8.99023 19.9717C8.62278 19.9422 8.27729 19.8791 7.94824 19.7168C7.44205 19.4671 7.02532 19.0671 6.75391 18.5723C6.57751 18.2506 6.49853 17.9087 6.45312 17.543C6.40883 17.1861 6.39005 16.7475 6.36719 16.2217L6.03223 8.5H5.5C5.08579 8.5 4.75 8.16421 4.75 7.75C4.75 7.33579 5.08579 7 5.5 7H8.25V6.25C8.25 5.00736 9.25736 4 10.5 4H13.5ZM7.86621 16.1562C7.89013 16.7063 7.90624 17.0751 7.94141 17.3584C7.97545 17.6326 8.02151 17.7644 8.06934 17.8516C8.19271 18.0763 8.38239 18.2577 8.6123 18.3711C8.70153 18.4151 8.83504 18.4545 9.11035 18.4766C9.39482 18.4994 9.76335 18.5 10.3135 18.5H13.6865C14.2367 18.5 14.6052 18.4994 14.8896 18.4766C15.165 18.4545 15.2985 18.4151 15.3877 18.3711C15.6176 18.2577 15.8073 18.0763 15.9307 17.8516C15.9785 17.7644 16.0245 17.6326 16.0586 17.3584C16.0938 17.0751 16.1099 16.7063 16.1338 16.1562L16.4668 8.5H7.5332L7.86621 16.1562ZM9.97656 10.75C10.3906 10.7371 10.7371 11.0626 10.75 11.4766L10.875 15.4766C10.8879 15.8906 10.5624 16.2371 10.1484 16.25C9.73443 16.2629 9.38794 15.9374 9.375 15.5234L9.25 11.5234C9.23706 11.1094 9.56255 10.7629 9.97656 10.75ZM14.0244 10.75C14.4383 10.7635 14.7635 11.1105 14.75 11.5244L14.6201 15.5244C14.6066 15.9384 14.2596 16.2634 13.8457 16.25C13.4317 16.2365 13.1067 15.8896 13.1201 15.4756L13.251 11.4756C13.2645 11.0617 13.6105 10.7366 14.0244 10.75ZM10.5 5.5C10.0858 5.5 9.75 5.83579 9.75 6.25V7H14.25V6.25C14.25 5.83579 13.9142 5.5 13.5 5.5H10.5Z",fill:"currentColor"})}),Rh=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,I.jsx)("path",{d:"M8.5 3.5L4 8L8.5 12.5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})}),zb=({size:s=16})=>(0,I.jsx)("svg",{width:s,height:s,viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,I.jsx)("path",{d:"M8.5 11.5L12 8L8.5 4.5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})}),Lb=({size:s=20,color:i="#4C74FF"})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,I.jsx)("style",{children:`
      @keyframes bunnyEnterEar {
        0% { opacity: 0; transform: scale(0.8); }
        100% { opacity: 1; transform: scale(1); }
      }
      @keyframes bunnyEnterFace {
        0% { opacity: 0; transform: scale(0.9); }
        100% { opacity: 1; transform: scale(1); }
      }
      @keyframes bunnyEnterEye {
        0% { opacity: 0; transform: scale(0.5); }
        100% { opacity: 1; transform: scale(1); }
      }
      @keyframes leftEyeLook {
        0%, 8% { transform: translate(0, 0); }
        10%, 18% { transform: translate(1.5px, 0); }
        20%, 22% { transform: translate(1.5px, 0) scaleY(0.1); }
        24%, 32% { transform: translate(1.5px, 0); }
        35%, 48% { transform: translate(-0.8px, -0.6px); }
        52%, 54% { transform: translate(0, 0) scaleY(0.1); }
        56%, 68% { transform: translate(0, 0); }
        72%, 82% { transform: translate(-0.5px, 0.5px); }
        85%, 100% { transform: translate(0, 0); }
      }
      @keyframes rightEyeLook {
        0%, 8% { transform: translate(0, 0); }
        10%, 18% { transform: translate(0.8px, 0); }
        20%, 22% { transform: translate(0.8px, 0) scaleY(0.1); }
        24%, 32% { transform: translate(0.8px, 0); }
        35%, 48% { transform: translate(-1.5px, -0.6px); }
        52%, 54% { transform: translate(0, 0) scaleY(0.1); }
        56%, 68% { transform: translate(0, 0); }
        72%, 82% { transform: translate(-1.2px, 0.5px); }
        85%, 100% { transform: translate(0, 0); }
      }
      @keyframes leftEarTwitch {
        0%, 9% { transform: rotate(0deg); }
        12% { transform: rotate(-8deg); }
        16%, 34% { transform: rotate(0deg); }
        38% { transform: rotate(-12deg); }
        42% { transform: rotate(-6deg); }
        48%, 100% { transform: rotate(0deg); }
      }
      @keyframes rightEarTwitch {
        0%, 9% { transform: rotate(0deg); }
        12% { transform: rotate(6deg); }
        16%, 34% { transform: rotate(0deg); }
        38% { transform: rotate(10deg); }
        42% { transform: rotate(4deg); }
        48%, 71% { transform: rotate(0deg); }
        74% { transform: rotate(8deg); }
        78%, 100% { transform: rotate(0deg); }
      }
      .bunny-eye-left {
        opacity: 0;
        animation: bunnyEnterEye 0.3s ease-out 0.35s forwards, leftEyeLook 5s ease-in-out 0.65s infinite;
        transform-origin: center;
        transform-box: fill-box;
      }
      .bunny-eye-right {
        opacity: 0;
        animation: bunnyEnterEye 0.3s ease-out 0.4s forwards, rightEyeLook 5s ease-in-out 0.7s infinite;
        transform-origin: center;
        transform-box: fill-box;
      }
      .bunny-ear-left {
        opacity: 0;
        animation: bunnyEnterEar 0.3s ease-out 0.1s forwards, leftEarTwitch 5s ease-in-out 0.4s infinite;
        transform-origin: bottom center;
        transform-box: fill-box;
      }
      .bunny-ear-right {
        opacity: 0;
        animation: bunnyEnterEar 0.3s ease-out 0.15s forwards, rightEarTwitch 5s ease-in-out 0.45s infinite;
        transform-origin: bottom center;
        transform-box: fill-box;
      }
      .bunny-face {
        opacity: 0;
        animation: bunnyEnterFace 0.3s ease-out 0.25s forwards;
        transform-origin: center;
        transform-box: fill-box;
      }
      svg:hover .bunny-eye-left,
      svg:hover .bunny-eye-right {
        opacity: 0;
        transition: opacity 0.2s ease;
      }
      .bunny-happy-face {
        opacity: 0;
        transition: opacity 0.2s ease;
      }
      svg:hover .bunny-happy-face {
        opacity: 1;
      }
    `}),(0,I.jsx)("rect",{width:"28",height:"28",fill:"transparent"}),(0,I.jsx)("path",{className:"bunny-ear-left",d:"M3.738 10.2164L7.224 2.007H9.167L5.676 10.2164H3.738ZM10.791 6.42705C10.791 5.90346 10.726 5.42764 10.596 4.99959C10.47 4.57155 10.292 4.16643 10.063 3.78425C9.833 3.39825 9.56 3.01797 9.243 2.64343C8.926 2.26507 8.767 2.07589 8.767 2.07589L10.24 0.957996C10.24 0.957996 10.433 1.17203 10.819 1.60007C11.209 2.0243 11.559 2.49056 11.869 2.99886C12.178 3.50717 12.413 4.04222 12.574 4.60403C12.734 5.16584 12.814 5.77352 12.814 6.42705C12.814 7.10734 12.73 7.7303 12.562 8.29593C12.394 8.85774 12.153 9.3966 11.84 9.9126C11.526 10.4247 11.181 10.8833 10.802 11.2884C10.428 11.6974 10.24 11.9018 10.24 11.9018L8.767 10.7839C8.767 10.7839 8.924 10.5948 9.237 10.2164C9.554 9.8419 9.83 9.4597 10.063 9.06985C10.3 8.6762 10.479 8.26726 10.602 7.84304C10.728 7.41499 10.791 6.943 10.791 6.42705Z",fill:i}),(0,I.jsx)("path",{className:"bunny-ear-right",d:"M15.003 10.2164L18.489 2.007H20.432L16.941 10.2164H15.003ZM22.056 6.42705C22.056 5.90346 21.991 5.42764 21.861 4.99959C21.735 4.57155 21.557 4.16643 21.328 3.78425C21.098 3.39825 20.825 3.01797 20.508 2.64343C20.191 2.26507 20.032 2.07589 20.032 2.07589L21.505 0.957996C21.505 0.957996 21.698 1.17203 22.084 1.60007C22.474 2.0243 22.824 2.49056 23.133 2.99886C23.443 3.50717 23.678 4.04222 23.839 4.60403C23.999 5.16584 24.079 5.77352 24.079 6.42705C24.079 7.10734 23.995 7.7303 23.827 8.29593C23.659 8.85774 23.418 9.3966 23.105 9.9126C22.791 10.4247 22.445 10.8833 22.067 11.2884C21.693 11.6974 21.505 11.9018 21.505 11.9018L20.032 10.7839C20.032 10.7839 20.189 10.5948 20.502 10.2164C20.819 9.8419 21.094 9.4597 21.328 9.06985C21.565 8.6762 21.744 8.26726 21.866 7.84304C21.993 7.41499 22.056 6.943 22.056 6.42705Z",fill:i}),(0,I.jsx)("path",{className:"bunny-face",d:"M2.03 20.4328C2.03 20.9564 2.093 21.4322 2.219 21.8602C2.345 22.2883 2.523 22.6953 2.752 23.0813C2.981 23.4635 3.254 23.8419 3.572 24.2164C3.889 24.5948 4.047 24.7839 4.047 24.7839L2.574 25.9018C2.574 25.9018 2.379 25.6878 1.989 25.2598C1.603 24.8355 1.256 24.3693 0.946 23.861C0.636 23.3527 0.401 22.8176 0.241 22.2558C0.08 21.694 0 21.0863 0 20.4328C0 19.7525 0.084 19.1314 0.252 18.5696C0.421 18.004 0.661 17.4651 0.975 16.953C1.288 16.4371 1.632 15.9765 2.007 15.5714C2.385 15.1625 2.574 14.958 2.574 14.958L4.047 16.0759C4.047 16.0759 3.889 16.2651 3.572 16.6434C3.258 17.018 2.983 17.4021 2.746 17.7957C2.513 18.1855 2.335 18.5945 2.213 19.0225C2.091 19.4467 2.03 19.9168 2.03 20.4328ZM23.687 20.4271C23.687 19.9035 23.622 19.4276 23.492 18.9996C23.366 18.5715 23.188 18.1664 22.959 17.7843C22.729 17.3982 22.456 17.018 22.139 16.6434C21.822 16.2651 21.663 16.0759 21.663 16.0759L23.136 14.958C23.136 14.958 23.329 15.172 23.715 15.6001C24.105 16.0243 24.455 16.4906 24.765 16.9989C25.074 17.5072 25.309 18.0422 25.47 18.604C25.63 19.1658 25.71 19.7735 25.71 20.4271C25.71 21.1073 25.626 21.7303 25.458 22.2959C25.29 22.8577 25.049 23.3966 24.736 23.9126C24.422 24.4247 24.077 24.8833 23.698 25.2884C23.324 25.6974 23.136 25.9018 23.136 25.9018L21.663 24.7839C21.663 24.7839 21.82 24.5948 22.133 24.2164C22.45 23.8419 22.726 23.4597 22.959 23.0698C23.196 22.6762 23.375 22.2673 23.498 21.843C23.624 21.415 23.687 20.943 23.687 20.4271Z",fill:i}),(0,I.jsx)("circle",{className:"bunny-eye-left",cx:"8.277",cy:"20.466",r:"1.8",fill:i}),(0,I.jsx)("circle",{className:"bunny-eye-right",cx:"19.878",cy:"20.466",r:"1.8",fill:i}),(0,I.jsx)("text",{className:"bunny-happy-face",x:"14",y:"26",textAnchor:"middle",fontSize:"12",fontWeight:"bold",fill:i,fontFamily:"system-ui, -apple-system, sans-serif",children:"\u02C3 \u1D55 \u02C2"})]}),Bb=({size:s=24})=>(0,I.jsxs)("svg",{width:s,height:s,viewBox:"0 0 24 24",fill:"none",children:[(0,I.jsx)("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",stroke:"currentColor",strokeWidth:"1.5"}),(0,I.jsx)("line",{x1:"3",y1:"9",x2:"21",y2:"9",stroke:"currentColor",strokeWidth:"1.5"}),(0,I.jsx)("line",{x1:"9",y1:"9",x2:"9",y2:"21",stroke:"currentColor",strokeWidth:"1.5"})]}),ls=tn(),Hb=Br(),Gc=Tn(),Ub=({content:s,children:i,...r})=>{let[u,d]=(0,ls.useState)(!1),[_,g]=(0,ls.useState)(!1),[w,y]=(0,ls.useState)({top:0,right:0}),E=(0,ls.useRef)(null),M=(0,ls.useRef)(null),S=(0,ls.useRef)(null),O=()=>{if(E.current){let te=E.current.getBoundingClientRect();y({top:te.top+te.height/2,right:window.innerWidth-te.left+8})}},W=()=>{g(!0),S.current&&(clearTimeout(S.current),S.current=null),O(),M.current=_e(()=>{d(!0)},500)},H=()=>{M.current&&(clearTimeout(M.current),M.current=null),d(!1),S.current=_e(()=>{g(!1)},150)};return(0,ls.useEffect)(()=>()=>{M.current&&clearTimeout(M.current),S.current&&clearTimeout(S.current)},[]),(0,Gc.jsxs)(Gc.Fragment,{children:[(0,Gc.jsx)("span",{ref:E,onMouseEnter:W,onMouseLeave:H,...r,children:i}),_&&(0,Hb.createPortal)((0,Gc.jsx)("div",{"data-feedback-toolbar":!0,style:{position:"fixed",top:w.top,right:w.right,transform:"translateY(-50%)",padding:"6px 10px",background:"#383838",color:"rgba(255, 255, 255, 0.7)",fontSize:"11px",fontWeight:400,lineHeight:"14px",borderRadius:"10px",width:"180px",textAlign:"left",zIndex:100020,pointerEvents:"none",boxShadow:"0px 1px 8px rgba(0, 0, 0, 0.28)",opacity:u?1:0,transition:"opacity 0.15s ease"},children:s}),document.body)]})},$b=`.styles-module__tooltip___mcXL2 {
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: help;
}

.styles-module__tooltipIcon___Nq2nD {
  transform: translateY(0.5px);
  color: #fff;
  opacity: 0.2;
  transition: opacity 0.15s ease;
  will-change: transform;
}
.styles-module__tooltip___mcXL2:hover .styles-module__tooltipIcon___Nq2nD {
  opacity: 0.5;
}
[data-agentation-theme=light] .styles-module__tooltipIcon___Nq2nD {
  color: #000;
}`,Ah={tooltip:"styles-module__tooltip___mcXL2",tooltipIcon:"styles-module__tooltipIcon___Nq2nD"},Dh=Tn(),as=({content:s})=>(0,Dh.jsx)(Ub,{className:Ah.tooltip,content:s,children:(0,Dh.jsx)(jh,{className:Ah.tooltipIcon})}),Ib=`.styles-module__toolbar___wNsdK svg[fill=none],
.styles-module__markersLayer___-25j1 svg[fill=none],
.styles-module__fixedMarkersLayer___ffyX6 svg[fill=none] {
  fill: none !important;
}
.styles-module__toolbar___wNsdK svg[fill=none] :not([fill]),
.styles-module__markersLayer___-25j1 svg[fill=none] :not([fill]),
.styles-module__fixedMarkersLayer___ffyX6 svg[fill=none] :not([fill]) {
  fill: none !important;
}

.styles-module__controlsContent___9GJWU :where(button, input, select, textarea, label) {
  background: unset;
  border: unset;
  border-radius: unset;
  padding: unset;
  margin: unset;
  color: unset;
  font-family: unset;
  font-weight: unset;
  font-style: unset;
  line-height: unset;
  letter-spacing: unset;
  text-transform: unset;
  text-decoration: unset;
  box-shadow: unset;
  outline: unset;
}

@keyframes styles-module__toolbarEnter___u8RRu {
  from {
    opacity: 0;
    transform: scale(0.5) rotate(90deg);
  }
  to {
    opacity: 1;
    transform: scale(1) rotate(0deg);
  }
}
@keyframes styles-module__toolbarHide___y8kaT {
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.8);
  }
}
@keyframes styles-module__badgeEnter___mVQLj {
  from {
    opacity: 0;
    transform: scale(0);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes styles-module__scaleIn___c-r1K {
  from {
    opacity: 0;
    transform: scale(0.85);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes styles-module__scaleOut___Wctwz {
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.85);
  }
}
@keyframes styles-module__slideUp___kgD36 {
  from {
    opacity: 0;
    transform: scale(0.85) translateY(8px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}
@keyframes styles-module__slideDown___zcdje {
  from {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
  to {
    opacity: 0;
    transform: scale(0.85) translateY(8px);
  }
}
@keyframes styles-module__fadeIn___b9qmf {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes styles-module__fadeOut___6Ut6- {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
@keyframes styles-module__hoverHighlightIn___6WYHY {
  from {
    opacity: 0;
    transform: scale(0.98);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes styles-module__hoverTooltipIn___FYGQx {
  from {
    opacity: 0;
    transform: scale(0.95) translateY(4px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}
.styles-module__disableTransitions___EopxO :is(*, *::before, *::after) {
  transition: none !important;
}

:host {
  /* Set here rather than inline so a consumer className rule can still hide the toolbar. */
  display: contents;
  position: fixed;
  top: auto;
  left: auto;
  bottom: 1.25rem;
  right: 1.25rem;
  z-index: 100000;
}

.styles-module__positionContext___AZFHE,
.styles-module__toolbar___wNsdK {
  position: inherit;
  top: inherit;
  left: inherit;
  bottom: inherit;
  right: inherit;
  z-index: inherit;
}

.styles-module__toolbar___wNsdK {
  width: 337px;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  pointer-events: none;
  transition: left 0.36s cubic-bezier(0.19, 1, 0.22, 1), top 0s, right 0s, bottom 0s;
}
.styles-module__toolbar___wNsdK[data-dragging=true] {
  transition: none;
}

.styles-module__toolbarContainer___dIhma {
  position: relative;
  -webkit-user-select: none;
  user-select: none;
  margin-left: auto;
  align-self: flex-end;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #1a1a1a;
  color: #fff;
  border: none;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2), 0 4px 16px rgba(0, 0, 0, 0.1);
  pointer-events: auto;
  transition: width 0.36s cubic-bezier(0.19, 1, 0.22, 1), transform 0.36s cubic-bezier(0.19, 1, 0.22, 1);
}
.styles-module__toolbarContainer___dIhma.styles-module__entrance___sgHd8 {
  animation: styles-module__toolbarEnter___u8RRu 0.5s cubic-bezier(0.34, 1.2, 0.64, 1) forwards;
}
.styles-module__toolbarContainer___dIhma.styles-module__hiding___1td44 {
  animation: styles-module__toolbarHide___y8kaT 0.4s cubic-bezier(0.4, 0, 1, 1) forwards;
  pointer-events: none;
}
.styles-module__toolbarContainer___dIhma.styles-module__collapsed___Rydsn {
  width: 44px;
  height: 44px;
  border-radius: 22px;
  padding: 0;
  cursor: pointer;
}
.styles-module__toolbarContainer___dIhma.styles-module__collapsed___Rydsn:hover {
  background: #2a2a2a;
}
.styles-module__toolbarContainer___dIhma.styles-module__collapsed___Rydsn:active {
  transform: scale(0.95);
}
.styles-module__toolbarContainer___dIhma.styles-module__expanded___ofKPx {
  height: 44px;
  border-radius: 22px;
  padding: 5px;
  width: 297px;
}
.styles-module__toolbarContainer___dIhma.styles-module__expanded___ofKPx.styles-module__serverConnected___Gfbou {
  width: 337px;
}

@media (prefers-reduced-motion: reduce) {
  .styles-module__toolbar___wNsdK,
  .styles-module__toolbarContainer___dIhma {
    transition: none;
  }
}
.styles-module__buttonWrapper___rBcdv.styles-module__toggleWrapper___7N0-q {
  position: absolute;
  top: 0;
  right: 0;
  width: 44px;
  height: 44px;
}

.styles-module__togglePlaceholder___wnqrL {
  width: 34px;
  flex: 0 0 34px;
  height: 34px;
}

.styles-module__toggleContent___0yfyP {
  position: absolute;
  top: 0;
  right: 0;
  width: 44px;
  height: 44px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 0;
  border-radius: 50%;
  padding: 0;
  margin: 0;
  background: transparent;
  color: #fff;
  cursor: pointer;
  transition: color 0.15s ease;
}
.styles-module__toggleContent___0yfyP::before {
  content: "";
  position: absolute;
  inset: 5px;
  border-radius: 50%;
  pointer-events: none;
  background: transparent;
  transition: background-color 0.15s ease, transform 0.1s ease;
}
.styles-module__toggleContent___0yfyP.styles-module__expandedToggle___F7SRN {
  color: rgba(255, 255, 255, 0.85);
}
.styles-module__toggleContent___0yfyP.styles-module__expandedToggle___F7SRN:hover {
  color: #fff;
}
.styles-module__toggleContent___0yfyP.styles-module__expandedToggle___F7SRN:hover::before {
  background: rgba(255, 255, 255, 0.12);
}
.styles-module__toggleContent___0yfyP.styles-module__expandedToggle___F7SRN:active::before, .styles-module__toggleContent___0yfyP.styles-module__expandedToggle___F7SRN:active .styles-module__toggleGlyph___R7Oom {
  transform: scale(0.92);
}

.styles-module__toggleIcon___Jbtus {
  transform: translateY(-0.5px);
  transition: transform 0.3s cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.styles-module__expandedToggle___F7SRN .styles-module__toggleIcon___Jbtus {
  transform: none;
}

.styles-module__toggleGlyph___R7Oom {
  overflow: visible;
  transition: transform 0.1s ease;
}
.styles-module__toggleGlyph___R7Oom path {
  transform-box: fill-box;
  transform-origin: center;
  transition: transform 0.3s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.16s ease;
}

.styles-module__toggleTopLine___hQaCm,
.styles-module__toggleMiddleLine___sFFVe {
  vector-effect: non-scaling-stroke;
}

.styles-module__toggleBottomLine___V-jX3 {
  transform-origin: left center;
}

.styles-module__toggleGlyph___R7Oom[data-active=true] .styles-module__toggleTopLine___hQaCm {
  transform: translateY(5.25px) rotate(45deg) scaleX(1.1422494);
}
.styles-module__toggleGlyph___R7Oom[data-active=true] .styles-module__toggleMiddleLine___sFFVe {
  transform: translateX(3.5px) rotate(-45deg) scaleX(2.4748737);
}
.styles-module__toggleGlyph___R7Oom[data-active=true] .styles-module__toggleBottomLine___V-jX3 {
  transform: scaleX(0);
  opacity: 0;
}
.styles-module__toggleGlyph___R7Oom[data-active=true] .styles-module__toggleSparkle___eeF99 {
  transform: scale(0);
  opacity: 0;
}

.styles-module__toggleContent___0yfyP:focus-visible,
.styles-module__controlButton___8Q0jc:focus-visible {
  outline: 2px solid var(--agentation-color-accent);
  outline-offset: 3px;
}

.styles-module__controlsContent___9GJWU {
  display: flex;
  align-items: center;
  gap: 6px;
  transition: filter 0.14s ease-out, opacity 0.14s ease-out, transform 0.36s cubic-bezier(0.19, 1, 0.22, 1);
}
.styles-module__controlsContent___9GJWU.styles-module__visible___KHwEW {
  transition: filter 0.3s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.24s ease-out, transform 0.42s cubic-bezier(0.19, 1, 0.22, 1);
  opacity: 1;
  filter: blur(0px);
  transform: scale(1);
  visibility: visible;
  pointer-events: auto;
}
.styles-module__controlsContent___9GJWU.styles-module__hidden___Ae8H4 {
  pointer-events: none;
  opacity: 0;
  filter: blur(6px);
  transform: scale(0.4);
}

@media (prefers-reduced-motion: reduce) {
  .styles-module__controlsContent___9GJWU,
  .styles-module__controlsContent___9GJWU.styles-module__visible___KHwEW,
  .styles-module__toggleContent___0yfyP,
  .styles-module__toggleContent___0yfyP::before,
  .styles-module__toggleGlyph___R7Oom,
  .styles-module__toggleIcon___Jbtus,
  .styles-module__toggleGlyph___R7Oom path {
    transition: none;
  }
  .styles-module__controlsContent___9GJWU.styles-module__hidden___Ae8H4 {
    filter: none;
    transform: none;
  }
}
.styles-module__badge___2XsgF {
  position: absolute;
  top: -13px;
  right: -13px;
  -webkit-user-select: none;
  user-select: none;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 9px;
  background-color: var(--agentation-color-accent);
  color: white;
  font-size: 0.625rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15), inset 0 0 0 1px rgba(255, 255, 255, 0.04);
  opacity: 1;
  transition: transform 0.3s ease, opacity 0.2s ease;
  transform: scale(1);
}
.styles-module__badge___2XsgF.styles-module__fadeOut___6Ut6- {
  opacity: 0;
  transform: scale(0);
  pointer-events: none;
}
.styles-module__badge___2XsgF.styles-module__entrance___sgHd8 {
  animation: styles-module__badgeEnter___mVQLj 0.3s cubic-bezier(0.34, 1.2, 0.64, 1) 0.4s both;
}

.styles-module__controlButton___8Q0jc {
  position: relative;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 34px;
  height: 34px;
  border-radius: 50%;
  border: none;
  background: transparent;
  color: rgba(255, 255, 255, 0.85);
  transition: background-color 0.15s ease, color 0.15s ease, transform 0.1s ease, opacity 0.2s ease;
}
.styles-module__controlButton___8Q0jc:hover:not(:disabled):not([data-active=true]):not([data-failed=true]):not([data-auto-sync=true]):not([data-error=true]):not([data-no-hover=true]) {
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
}
.styles-module__controlButton___8Q0jc:active:not(:disabled) {
  transform: scale(0.92);
}
.styles-module__controlButton___8Q0jc:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}
.styles-module__controlButton___8Q0jc[data-active=true] {
  color: var(--agentation-color-blue);
  background-color: color-mix(in srgb, var(--agentation-color-blue) 25%, transparent);
}
.styles-module__controlButton___8Q0jc[data-error=true] {
  color: var(--agentation-color-red);
  background-color: color-mix(in srgb, var(--agentation-color-red) 25%, transparent);
}
.styles-module__controlButton___8Q0jc[data-danger]:hover:not(:disabled):not([data-active=true]):not([data-failed=true]) {
  background-color: color-mix(in srgb, var(--agentation-color-red) 25%, transparent);
  color: var(--agentation-color-red);
}
.styles-module__controlButton___8Q0jc[data-no-hover=true], .styles-module__controlButton___8Q0jc.styles-module__statusShowing___te6iu {
  cursor: default;
  pointer-events: none;
  background: transparent !important;
}
.styles-module__controlButton___8Q0jc[data-auto-sync=true] {
  color: var(--agentation-color-green);
  background: transparent;
  cursor: default;
}
.styles-module__controlButton___8Q0jc[data-failed=true] {
  color: var(--agentation-color-red);
  background-color: color-mix(in srgb, var(--agentation-color-red) 25%, transparent);
}

.styles-module__buttonBadge___NeFWb {
  position: absolute;
  top: 0px;
  right: 0px;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 8px;
  background-color: var(--agentation-color-accent);
  color: white;
  font-size: 0.625rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0 0 2px #1a1a1a, 0 1px 3px rgba(0, 0, 0, 0.2);
  pointer-events: none;
}
[data-agentation-theme=light] .styles-module__buttonBadge___NeFWb {
  box-shadow: 0 0 0 2px #fff, 0 1px 3px rgba(0, 0, 0, 0.2);
}

@keyframes styles-module__mcpIndicatorPulseConnected___EDodZ {
  0%, 100% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-green) 50%, transparent);
  }
  50% {
    box-shadow: 0 0 0 5px color-mix(in srgb, var(--agentation-color-green) 0%, transparent);
  }
}
@keyframes styles-module__mcpIndicatorPulseConnecting___cCYte {
  0%, 100% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-yellow) 50%, transparent);
  }
  50% {
    box-shadow: 0 0 0 5px color-mix(in srgb, var(--agentation-color-yellow) 0%, transparent);
  }
}
.styles-module__mcpIndicator___zGJeL {
  position: absolute;
  top: 3px;
  right: 3px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  pointer-events: none;
  transition: background-color 0.3s ease, opacity 0.15s ease, transform 0.15s ease;
  opacity: 1;
  transform: scale(1);
}
.styles-module__mcpIndicator___zGJeL.styles-module__connected___7c28g {
  background-color: var(--agentation-color-green);
  animation: styles-module__mcpIndicatorPulseConnected___EDodZ 2.5s ease-in-out infinite;
}
.styles-module__mcpIndicator___zGJeL.styles-module__connecting___uo-CW {
  background-color: var(--agentation-color-yellow);
  animation: styles-module__mcpIndicatorPulseConnecting___cCYte 1.5s ease-in-out infinite;
}
.styles-module__mcpIndicator___zGJeL.styles-module__hidden___Ae8H4 {
  opacity: 0;
  transform: scale(0);
  animation: none;
}

@keyframes styles-module__connectionPulse___-Zycw {
  0%, 100% {
    opacity: 1;
    transform: scale(1);
  }
  50% {
    opacity: 0.6;
    transform: scale(0.9);
  }
}
.styles-module__connectionIndicatorWrapper___L-e-3 {
  width: 8px;
  height: 34px;
  margin-left: 6px;
  margin-right: 6px;
}

.styles-module__connectionIndicator___afk9p {
  position: relative;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  opacity: 0;
  transition: opacity 0.3s ease, background-color 0.3s ease;
  cursor: default;
}

.styles-module__connectionIndicatorVisible___C-i5B {
  opacity: 1;
}

.styles-module__connectionIndicatorConnected___IY8pR {
  background-color: var(--agentation-color-green);
  animation: styles-module__connectionPulse___-Zycw 2.5s ease-in-out infinite;
}

.styles-module__connectionIndicatorDisconnected___kmpaZ {
  background-color: var(--agentation-color-red);
  animation: none;
}

.styles-module__connectionIndicatorConnecting___QmSLH {
  background-color: var(--agentation-color-yellow);
  animation: styles-module__connectionPulse___-Zycw 1s ease-in-out infinite;
}

.styles-module__buttonWrapper___rBcdv {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}
.styles-module__buttonWrapper___rBcdv:hover .styles-module__buttonTooltip___Burd9 {
  opacity: 1;
  visibility: visible;
  transform: translateX(-50%) scale(1);
  transition-delay: 0.85s;
}
.styles-module__buttonWrapper___rBcdv:has(.styles-module__controlButton___8Q0jc:disabled):hover .styles-module__buttonTooltip___Burd9 {
  opacity: 0;
  visibility: hidden;
}

.styles-module__tooltipsInSession___-0lHH .styles-module__buttonWrapper___rBcdv:hover .styles-module__buttonTooltip___Burd9 {
  transition-delay: 0s;
}

.styles-module__sendButtonWrapper___UUxG6 {
  width: 0;
  opacity: 0;
  overflow: hidden;
  pointer-events: none;
  margin-left: -6px;
  transition: width 0.36s cubic-bezier(0.19, 1, 0.22, 1), opacity 0.2s cubic-bezier(0.19, 1, 0.22, 1), margin 0.36s cubic-bezier(0.19, 1, 0.22, 1);
}
.styles-module__sendButtonWrapper___UUxG6 .styles-module__controlButton___8Q0jc {
  transform: scale(0.8);
  transition: transform 0.36s cubic-bezier(0.19, 1, 0.22, 1);
}
.styles-module__sendButtonWrapper___UUxG6.styles-module__sendButtonVisible___WPSQU {
  width: 34px;
  opacity: 1;
  overflow: visible;
  pointer-events: auto;
  margin-left: 0;
}
.styles-module__sendButtonWrapper___UUxG6.styles-module__sendButtonVisible___WPSQU .styles-module__controlButton___8Q0jc {
  transform: scale(1);
}

.styles-module__buttonTooltip___Burd9 {
  position: absolute;
  bottom: calc(100% + 14px);
  left: 50%;
  transform: translateX(-50%) scale(0.95);
  padding: 6px 10px;
  background: #1a1a1a;
  color: rgba(255, 255, 255, 0.9);
  font-size: 12px;
  font-weight: 500;
  border-radius: 8px;
  white-space: nowrap;
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  z-index: 100001;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
  transition: opacity 0.135s ease, transform 0.135s ease, visibility 0.135s ease;
}
.styles-module__buttonTooltip___Burd9::after {
  content: "";
  position: absolute;
  top: calc(100% - 4px);
  left: 50%;
  transform: translateX(-50%) rotate(45deg);
  width: 8px;
  height: 8px;
  background: #1a1a1a;
  border-radius: 0 0 2px 0;
}

.styles-module__shortcut___lEAQk {
  margin-left: 4px;
  opacity: 0.5;
}

.styles-module__tooltipBelow___m6ats .styles-module__buttonTooltip___Burd9 {
  bottom: auto;
  top: calc(100% + 14px);
  transform: translateX(-50%) scale(0.95);
}
.styles-module__tooltipBelow___m6ats .styles-module__buttonTooltip___Burd9::after {
  top: -4px;
  bottom: auto;
  border-radius: 2px 0 0 0;
}

.styles-module__tooltipBelow___m6ats .styles-module__buttonWrapper___rBcdv:hover .styles-module__buttonTooltip___Burd9 {
  transform: translateX(-50%) scale(1);
}

.styles-module__tooltipsHidden___VtLJG .styles-module__buttonTooltip___Burd9 {
  opacity: 0 !important;
  visibility: hidden !important;
  transition: none !important;
}

.styles-module__tooltipVisible___0jcCv,
.styles-module__tooltipsHidden___VtLJG .styles-module__tooltipVisible___0jcCv {
  opacity: 1 !important;
  visibility: visible !important;
  transform: translateX(-50%) scale(1) !important;
  transition-delay: 0s !important;
}

.styles-module__buttonWrapperAlignLeft___myzIp .styles-module__buttonTooltip___Burd9 {
  left: 50%;
  transform: translateX(-12px) scale(0.95);
}
.styles-module__buttonWrapperAlignLeft___myzIp .styles-module__buttonTooltip___Burd9::after {
  left: 16px;
}
.styles-module__buttonWrapperAlignLeft___myzIp:hover .styles-module__buttonTooltip___Burd9 {
  transform: translateX(-12px) scale(1);
}

.styles-module__tooltipBelow___m6ats .styles-module__buttonWrapperAlignLeft___myzIp .styles-module__buttonTooltip___Burd9 {
  transform: translateX(-12px) scale(0.95);
}
.styles-module__tooltipBelow___m6ats .styles-module__buttonWrapperAlignLeft___myzIp:hover .styles-module__buttonTooltip___Burd9 {
  transform: translateX(-12px) scale(1);
}

.styles-module__buttonWrapperAlignRight___HCQFR .styles-module__buttonTooltip___Burd9 {
  left: 50%;
  transform: translateX(calc(-100% + 12px)) scale(0.95);
}
.styles-module__buttonWrapperAlignRight___HCQFR .styles-module__buttonTooltip___Burd9::after {
  left: auto;
  right: 8px;
}
.styles-module__buttonWrapperAlignRight___HCQFR:hover .styles-module__buttonTooltip___Burd9 {
  transform: translateX(calc(-100% + 12px)) scale(1);
}

.styles-module__tooltipBelow___m6ats .styles-module__buttonWrapperAlignRight___HCQFR .styles-module__buttonTooltip___Burd9 {
  transform: translateX(calc(-100% + 12px)) scale(0.95);
}
.styles-module__tooltipBelow___m6ats .styles-module__buttonWrapperAlignRight___HCQFR:hover .styles-module__buttonTooltip___Burd9 {
  transform: translateX(calc(-100% + 12px)) scale(1);
}

.styles-module__divider___c--s1 {
  width: 1px;
  height: 12px;
  background: rgba(255, 255, 255, 0.15);
  margin: 0 3px;
}

.styles-module__overlay___Q1O9y {
  position: fixed;
  inset: 0;
  z-index: 99997;
  pointer-events: none;
}
.styles-module__overlay___Q1O9y > * {
  pointer-events: auto;
}

.styles-module__hoverHighlight___ogakW {
  position: fixed;
  border: 2px solid color-mix(in srgb, var(--agentation-color-accent) 50%, transparent);
  border-radius: 4px;
  background-color: color-mix(in srgb, var(--agentation-color-accent) 4%, transparent);
  pointer-events: none !important;
  box-sizing: border-box;
  will-change: opacity;
  contain: layout style;
}
.styles-module__hoverHighlight___ogakW.styles-module__enter___WFIki {
  animation: styles-module__hoverHighlightIn___6WYHY 0.12s ease-out forwards;
}

.styles-module__multiSelectOutline___cSJ-m {
  position: fixed;
  border: 2px dashed color-mix(in srgb, var(--agentation-color-green) 60%, transparent);
  border-radius: 4px;
  pointer-events: none !important;
  background-color: color-mix(in srgb, var(--agentation-color-green) 5%, transparent);
  box-sizing: border-box;
  will-change: opacity;
}
.styles-module__multiSelectOutline___cSJ-m.styles-module__enter___WFIki {
  animation: styles-module__fadeIn___b9qmf 0.15s ease-out forwards;
}
.styles-module__multiSelectOutline___cSJ-m.styles-module__exit___fyOJ0 {
  animation: styles-module__fadeOut___6Ut6- 0.15s ease-out forwards;
}

.styles-module__singleSelectOutline___QhX-O {
  position: fixed;
  border: 2px solid color-mix(in srgb, var(--agentation-color-blue) 60%, transparent);
  border-radius: 4px;
  pointer-events: none !important;
  background-color: color-mix(in srgb, var(--agentation-color-blue) 5%, transparent);
  box-sizing: border-box;
  will-change: opacity;
}
.styles-module__singleSelectOutline___QhX-O.styles-module__enter___WFIki {
  animation: styles-module__fadeIn___b9qmf 0.15s ease-out forwards;
}
.styles-module__singleSelectOutline___QhX-O.styles-module__exit___fyOJ0 {
  animation: styles-module__fadeOut___6Ut6- 0.15s ease-out forwards;
}

.styles-module__hoverTooltip___bvLk7 {
  position: fixed;
  z-index: 99999;
  font-size: 0.6875rem;
  font-weight: 500;
  color: #fff;
  background: rgba(0, 0, 0, 0.85);
  padding: 0.35rem 0.6rem;
  border-radius: 0.375rem;
  pointer-events: none !important;
  white-space: nowrap;
  max-width: min(280px, 100vw - 16px - 1.2rem);
  overflow: hidden;
  text-overflow: ellipsis;
}
.styles-module__hoverTooltip___bvLk7.styles-module__enter___WFIki {
  animation: styles-module__hoverTooltipIn___FYGQx 0.1s ease-out forwards;
}

.styles-module__hoverReactPath___gx1IJ {
  font-size: 0.625rem;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 0.15rem;
  overflow: hidden;
  text-overflow: ellipsis;
}

.styles-module__hoverElementName___QMLMl {
  overflow: hidden;
  text-overflow: ellipsis;
}

.styles-module__markersLayer___-25j1 {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 0;
  z-index: 99998;
  pointer-events: none;
}
.styles-module__markersLayer___-25j1 > * {
  pointer-events: auto;
}

.styles-module__fixedMarkersLayer___ffyX6 {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 99998;
  pointer-events: none;
}
.styles-module__fixedMarkersLayer___ffyX6 > * {
  pointer-events: auto;
}

.styles-module__marker___6sQrs {
  position: absolute;
  width: 22px;
  height: 22px;
  background: var(--agentation-color-blue);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.6875rem;
  font-weight: 600;
  transform: translate(-50%, -50%) scale(1);
  opacity: 1;
  cursor: pointer;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2), inset 0 0 0 1px rgba(0, 0, 0, 0.04);
  -webkit-user-select: none;
  user-select: none;
  will-change: transform, opacity;
  contain: layout style;
  z-index: 1;
}
.styles-module__marker___6sQrs:hover {
  z-index: 2;
}
.styles-module__marker___6sQrs:not(.styles-module__enter___WFIki):not(.styles-module__exit___fyOJ0):not(.styles-module__clearing___FQ--7) {
  transition: background-color 0.15s ease, transform 0.1s ease;
}
.styles-module__marker___6sQrs.styles-module__enter___WFIki {
  animation: styles-module__markerIn___5FaAP 0.25s cubic-bezier(0.22, 1, 0.36, 1) both;
}
.styles-module__marker___6sQrs.styles-module__exit___fyOJ0 {
  animation: styles-module__markerOut___GU5jX 0.2s ease-out both;
  pointer-events: none;
}
.styles-module__marker___6sQrs.styles-module__clearing___FQ--7 {
  animation: styles-module__markerOut___GU5jX 0.15s ease-out both;
  pointer-events: none;
}
.styles-module__marker___6sQrs:not(.styles-module__enter___WFIki):not(.styles-module__exit___fyOJ0):not(.styles-module__clearing___FQ--7):hover {
  transform: translate(-50%, -50%) scale(1.1);
}
.styles-module__marker___6sQrs.styles-module__pending___2IHLC {
  position: fixed;
  background-color: var(--agentation-color-blue);
  cursor: default;
}
.styles-module__marker___6sQrs.styles-module__fixed___dBMHC {
  position: fixed;
}
.styles-module__marker___6sQrs.styles-module__multiSelect___YWiuz {
  background-color: var(--agentation-color-green);
  width: 26px;
  height: 26px;
  border-radius: 6px;
  font-size: 0.75rem;
}
.styles-module__marker___6sQrs.styles-module__multiSelect___YWiuz.styles-module__pending___2IHLC {
  background-color: var(--agentation-color-green);
}
.styles-module__marker___6sQrs.styles-module__hovered___ZgXIy {
  background-color: var(--agentation-color-red);
}

.styles-module__renumber___nCTxD {
  display: block;
  animation: styles-module__renumberRoll___Wgbq3 0.2s ease-out;
}

@keyframes styles-module__renumberRoll___Wgbq3 {
  0% {
    transform: translateX(-40%);
    opacity: 0;
  }
  100% {
    transform: translateX(0);
    opacity: 1;
  }
}
.styles-module__markerTooltip___aLJID {
  position: absolute;
  top: calc(100% + 10px);
  left: 50%;
  transform: translateX(-50%) scale(0.909);
  z-index: 100002;
  background: #1a1a1a;
  padding: 8px 0.75rem;
  border-radius: 0.75rem;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  font-weight: 400;
  color: #fff;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.08);
  min-width: 120px;
  max-width: 200px;
  pointer-events: none;
  cursor: default;
}
.styles-module__markerTooltip___aLJID.styles-module__enter___WFIki {
  animation: styles-module__tooltipIn___0N31w 0.1s ease-out forwards;
}

.styles-module__markerQuote___FHmrz {
  display: block;
  font-size: 12px;
  font-style: italic;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 0.3125rem;
  line-height: 1.4;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.styles-module__markerNote___QkrrS {
  display: block;
  font-size: 13px;
  font-weight: 400;
  line-height: 1.4;
  color: #fff;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding-bottom: 2px;
}

.styles-module__markerHint___2iF-6 {
  display: block;
  font-size: 0.625rem;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.6);
  margin-top: 0.375rem;
  white-space: nowrap;
}

.styles-module__settingsPanel___OxX3Y {
  position: absolute;
  right: 5px;
  bottom: calc(100% + 0.5rem);
  z-index: 1;
  overflow: hidden;
  background: #1c1c1c;
  border-radius: 1rem;
  padding: 13px 0 16px;
  min-width: 205px;
  cursor: default;
  opacity: 1;
  box-shadow: 0 1px 8px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(0, 0, 0, 0.04);
  transition: background-color 0.25s ease, box-shadow 0.25s ease;
}
.styles-module__settingsPanel___OxX3Y::before, .styles-module__settingsPanel___OxX3Y::after {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  width: 16px;
  z-index: 2;
  pointer-events: none;
}
.styles-module__settingsPanel___OxX3Y::before {
  left: 0;
  background: linear-gradient(to right, #1c1c1c 0%, transparent 100%);
}
.styles-module__settingsPanel___OxX3Y::after {
  right: 0;
  background: linear-gradient(to left, #1c1c1c 0%, transparent 100%);
}
.styles-module__settingsPanel___OxX3Y .styles-module__settingsHeader___pwDY9,
.styles-module__settingsPanel___OxX3Y .styles-module__settingsBrand___0gJeM,
.styles-module__settingsPanel___OxX3Y .styles-module__settingsBrandSlash___uTG18,
.styles-module__settingsPanel___OxX3Y .styles-module__settingsVersion___TUcFq,
.styles-module__settingsPanel___OxX3Y .styles-module__settingsSection___m-YM2,
.styles-module__settingsPanel___OxX3Y .styles-module__settingsLabel___8UjfX,
.styles-module__settingsPanel___OxX3Y .styles-module__cycleButton___FMKfw,
.styles-module__settingsPanel___OxX3Y .styles-module__cycleDot___nPgLY,
.styles-module__settingsPanel___OxX3Y .styles-module__dropdownButton___16NPz,
.styles-module__settingsPanel___OxX3Y .styles-module__toggleLabel___Xm8Aa,
.styles-module__settingsPanel___OxX3Y .styles-module__customCheckbox___U39ax,
.styles-module__settingsPanel___OxX3Y .styles-module__sliderLabel___U8sPr,
.styles-module__settingsPanel___OxX3Y .styles-module__slider___GLdxp,
.styles-module__settingsPanel___OxX3Y .styles-module__themeToggle___2rUjA {
  transition: background-color 0.25s ease, color 0.25s ease, border-color 0.25s ease;
}
.styles-module__settingsPanel___OxX3Y.styles-module__enter___WFIki {
  opacity: 1;
  transform: translateY(0) scale(1);
  filter: blur(0px);
  transition: opacity 0.2s ease, transform 0.2s ease, filter 0.2s ease;
}
.styles-module__settingsPanel___OxX3Y.styles-module__exit___fyOJ0 {
  opacity: 0;
  transform: translateY(8px) scale(0.95);
  filter: blur(5px);
  pointer-events: none;
  transition: opacity 0.1s ease, transform 0.1s ease, filter 0.1s ease;
}
[data-agentation-theme=dark] .styles-module__settingsPanel___OxX3Y {
  background: #1a1a1a;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.08);
}
[data-agentation-theme=dark] .styles-module__settingsPanel___OxX3Y .styles-module__settingsLabel___8UjfX {
  color: rgba(255, 255, 255, 0.6);
}
[data-agentation-theme=dark] .styles-module__settingsPanel___OxX3Y .styles-module__settingsOption___UNa12 {
  color: rgba(255, 255, 255, 0.85);
}
[data-agentation-theme=dark] .styles-module__settingsPanel___OxX3Y .styles-module__settingsOption___UNa12:hover {
  background: rgba(255, 255, 255, 0.1);
}
[data-agentation-theme=dark] .styles-module__settingsPanel___OxX3Y .styles-module__settingsOption___UNa12.styles-module__selected___OwRqP {
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}
[data-agentation-theme=dark] .styles-module__settingsPanel___OxX3Y .styles-module__toggleLabel___Xm8Aa {
  color: rgba(255, 255, 255, 0.85);
}

.styles-module__settingsPanelContainer___Xksv8 {
  overflow: visible;
  position: relative;
  display: flex;
  padding: 0 1rem;
}

.styles-module__settingsPage___6YfHH {
  min-width: 100%;
  flex-shrink: 0;
  transition: transform 0.2s ease, opacity 0.2s ease;
  transition-delay: 0s;
  opacity: 1;
}

.styles-module__settingsPage___6YfHH.styles-module__slideLeft___Ps01J {
  transform: translateX(-24px);
  opacity: 0;
  pointer-events: none;
}

.styles-module__automationsPage___uvCq6 {
  position: absolute;
  top: 0;
  left: 24px;
  width: 100%;
  height: 100%;
  padding: 3px 1rem 0;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  transition: transform 0.2s ease, opacity 0.2s ease;
  opacity: 0;
  pointer-events: none;
}

.styles-module__automationsPage___uvCq6.styles-module__slideIn___4-qXe {
  transform: translateX(-24px);
  opacity: 1;
  pointer-events: auto;
}

.styles-module__settingsNavLink___wCzJt {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 0;
  border: none;
  background: transparent;
  font-family: inherit;
  font-size: 0.8125rem;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.5);
  cursor: pointer;
  transition: color 0.15s ease;
}
.styles-module__settingsNavLink___wCzJt:hover {
  color: rgba(255, 255, 255, 0.9);
}
[data-agentation-theme=light] .styles-module__settingsNavLink___wCzJt {
  color: rgba(0, 0, 0, 0.5);
}
[data-agentation-theme=light] .styles-module__settingsNavLink___wCzJt:hover {
  color: rgba(0, 0, 0, 0.8);
}
.styles-module__settingsNavLink___wCzJt svg {
  color: rgba(255, 255, 255, 0.4);
  transition: color 0.15s ease;
}
.styles-module__settingsNavLink___wCzJt:hover svg {
  color: #fff;
}
[data-agentation-theme=light] .styles-module__settingsNavLink___wCzJt svg {
  color: rgba(0, 0, 0, 0.25);
}
[data-agentation-theme=light] .styles-module__settingsNavLink___wCzJt:hover svg {
  color: rgba(0, 0, 0, 0.8);
}

.styles-module__settingsNavLinkRight___ZWwhj {
  display: flex;
  align-items: center;
  gap: 6px;
}

.styles-module__mcpNavIndicator___cl9pO {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}
.styles-module__mcpNavIndicator___cl9pO.styles-module__connected___7c28g {
  background-color: var(--agentation-color-green);
  animation: styles-module__mcpPulse___uNggr 2.5s ease-in-out infinite;
}
.styles-module__mcpNavIndicator___cl9pO.styles-module__connecting___uo-CW {
  background-color: var(--agentation-color-yellow);
  animation: styles-module__mcpPulse___uNggr 1.5s ease-in-out infinite;
}

.styles-module__settingsBackButton___bIe2j {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 0 12px 0;
  margin: -6px 0 0.5rem 0;
  border: none;
  border-bottom: 1px solid rgba(255, 255, 255, 0.07);
  border-radius: 0;
  background: transparent;
  font-family: inherit;
  font-size: 0.8125rem;
  font-weight: 500;
  letter-spacing: -0.15px;
  color: #fff;
  cursor: pointer;
  transition: transform 0.12s cubic-bezier(0.32, 0.72, 0, 1);
}
.styles-module__settingsBackButton___bIe2j svg {
  opacity: 0.4;
  flex-shrink: 0;
  transition: opacity 0.15s ease, transform 0.18s cubic-bezier(0.32, 0.72, 0, 1);
}
.styles-module__settingsBackButton___bIe2j:hover {
  border-bottom-color: rgba(255, 255, 255, 0.07);
}
.styles-module__settingsBackButton___bIe2j:hover svg {
  opacity: 1;
}
[data-agentation-theme=light] .styles-module__settingsBackButton___bIe2j {
  color: rgba(0, 0, 0, 0.85);
  border-bottom-color: rgba(0, 0, 0, 0.08);
}
[data-agentation-theme=light] .styles-module__settingsBackButton___bIe2j:hover {
  border-bottom-color: rgba(0, 0, 0, 0.08);
}

.styles-module__automationHeader___InP0r {
  display: flex;
  align-items: center;
  gap: 0.125rem;
  font-size: 0.8125rem;
  font-weight: 400;
  color: #fff;
}
[data-agentation-theme=light] .styles-module__automationHeader___InP0r {
  color: rgba(0, 0, 0, 0.85);
}

.styles-module__automationDescription___NKlmo {
  font-size: 0.6875rem;
  font-weight: 300;
  color: rgba(255, 255, 255, 0.5);
  margin-top: 2px;
  line-height: 14px;
}
[data-agentation-theme=light] .styles-module__automationDescription___NKlmo {
  color: rgba(0, 0, 0, 0.5);
}

.styles-module__learnMoreLink___8xv-x {
  color: rgba(255, 255, 255, 0.8);
  text-decoration: underline dotted;
  text-decoration-color: rgba(255, 255, 255, 0.2);
  text-underline-offset: 2px;
  transition: color 0.15s ease;
}
.styles-module__learnMoreLink___8xv-x:hover {
  color: #fff;
}
[data-agentation-theme=light] .styles-module__learnMoreLink___8xv-x {
  color: rgba(0, 0, 0, 0.6);
  text-decoration-color: rgba(0, 0, 0, 0.2);
}
[data-agentation-theme=light] .styles-module__learnMoreLink___8xv-x:hover {
  color: rgba(0, 0, 0, 0.85);
}

.styles-module__autoSendRow___UblX5 {
  display: flex;
  align-items: center;
  gap: 8px;
}

.styles-module__autoSendLabel___icDc2 {
  font-size: 0.6875rem;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.4);
  transition: color 0.15s ease;
}
.styles-module__autoSendLabel___icDc2.styles-module__active___-zoN6 {
  color: #66b8ff;
  color: color(display-p3 0.4 0.72 1);
}
[data-agentation-theme=light] .styles-module__autoSendLabel___icDc2 {
  color: rgba(0, 0, 0, 0.4);
}
[data-agentation-theme=light] .styles-module__autoSendLabel___icDc2.styles-module__active___-zoN6 {
  color: var(--agentation-color-blue);
}

.styles-module__webhookUrlInput___2375C {
  display: block;
  width: 100%;
  flex: 1;
  min-height: 60px;
  box-sizing: border-box;
  margin-top: 11px;
  padding: 8px 10px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 6px;
  background: rgba(255, 255, 255, 0.03);
  font-family: inherit;
  font-size: 0.75rem;
  font-weight: 400;
  color: #fff;
  outline: none;
  resize: none;
  user-select: text;
  transition: border-color 0.15s ease, background-color 0.15s ease, box-shadow 0.15s ease;
}
.styles-module__webhookUrlInput___2375C::placeholder {
  color: rgba(255, 255, 255, 0.3);
}
.styles-module__webhookUrlInput___2375C:focus {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.08);
}
[data-agentation-theme=light] .styles-module__webhookUrlInput___2375C {
  border-color: rgba(0, 0, 0, 0.1);
  background: rgba(0, 0, 0, 0.03);
  color: rgba(0, 0, 0, 0.85);
}
[data-agentation-theme=light] .styles-module__webhookUrlInput___2375C::placeholder {
  color: rgba(0, 0, 0, 0.3);
}
[data-agentation-theme=light] .styles-module__webhookUrlInput___2375C:focus {
  border-color: rgba(0, 0, 0, 0.25);
  background: rgba(0, 0, 0, 0.05);
}

.styles-module__settingsHeader___pwDY9 {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 24px;
  margin-bottom: 0.5rem;
  padding-bottom: 9px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.07);
}

.styles-module__settingsBrand___0gJeM {
  font-size: 0.8125rem;
  font-weight: 600;
  letter-spacing: -0.0094em;
  color: #fff;
  text-decoration: none;
}

.styles-module__settingsBrandSlash___uTG18 {
  color: var(--agentation-color-accent);
  transition: color 0.2s ease;
}

.styles-module__settingsVersion___TUcFq {
  font-size: 11px;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.4);
  margin-left: auto;
  letter-spacing: -0.0094em;
}

.styles-module__settingsSection___m-YM2 + .styles-module__settingsSection___m-YM2 {
  margin-top: 0.5rem;
  padding-top: 0.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.07);
}
.styles-module__settingsSection___m-YM2.styles-module__settingsSectionExtraPadding___jdhFV {
  padding-top: calc(0.5rem + 4px);
}

.styles-module__settingsSectionGrow___h-5HZ {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.styles-module__settingsRow___3sdhc {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 24px;
}
.styles-module__settingsRow___3sdhc.styles-module__settingsRowMarginTop___zA0Sp {
  margin-top: 8px;
}

.styles-module__dropdownContainer___BVnxe {
  position: relative;
}

.styles-module__dropdownButton___16NPz {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.25rem 0.5rem;
  border: none;
  border-radius: 0.375rem;
  background: transparent;
  font-size: 0.8125rem;
  font-weight: 600;
  color: #fff;
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
  letter-spacing: -0.0094em;
}
.styles-module__dropdownButton___16NPz:hover {
  background: rgba(255, 255, 255, 0.08);
}
.styles-module__dropdownButton___16NPz svg {
  opacity: 0.6;
}

.styles-module__cycleButton___FMKfw {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0;
  border: none;
  background: transparent;
  font-size: 0.8125rem;
  font-weight: 500;
  color: #fff;
  cursor: pointer;
  letter-spacing: -0.0094em;
}
[data-agentation-theme=light] .styles-module__cycleButton___FMKfw {
  color: rgba(0, 0, 0, 0.85);
}
.styles-module__cycleButton___FMKfw:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}

.styles-module__settingsRowDisabled___EgS0V .styles-module__settingsLabel___8UjfX {
  color: rgba(255, 255, 255, 0.2);
}
[data-agentation-theme=light] .styles-module__settingsRowDisabled___EgS0V .styles-module__settingsLabel___8UjfX {
  color: rgba(0, 0, 0, 0.2);
}
.styles-module__settingsRowDisabled___EgS0V .styles-module__toggleSwitch___l4Ygm {
  opacity: 0.4;
  cursor: not-allowed;
}

@keyframes styles-module__cycleTextIn___Q6zJf {
  0% {
    opacity: 0;
    transform: translateY(-6px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
.styles-module__cycleButtonText___fD1LR {
  display: inline-block;
  animation: styles-module__cycleTextIn___Q6zJf 0.2s ease-out;
}

.styles-module__cycleDots___LWuoQ {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.styles-module__cycleDot___nPgLY {
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.3);
  transform: scale(0.667);
  transition: background-color 0.25s ease-out, transform 0.25s ease-out;
}
.styles-module__cycleDot___nPgLY.styles-module__active___-zoN6 {
  background: #fff;
  transform: scale(1);
}
[data-agentation-theme=light] .styles-module__cycleDot___nPgLY {
  background: rgba(0, 0, 0, 0.2);
}
[data-agentation-theme=light] .styles-module__cycleDot___nPgLY.styles-module__active___-zoN6 {
  background: rgba(0, 0, 0, 0.7);
}

.styles-module__dropdownMenu___k73ER {
  position: absolute;
  right: 0;
  top: calc(100% + 0.25rem);
  background: #1a1a1a;
  border-radius: 0.5rem;
  padding: 0.25rem;
  min-width: 120px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.1);
  z-index: 10;
  animation: styles-module__scaleIn___c-r1K 0.15s ease-out;
}

.styles-module__dropdownItem___ylsLj {
  width: 100%;
  display: flex;
  align-items: center;
  padding: 0.5rem 0.625rem;
  border: none;
  border-radius: 0.375rem;
  background: transparent;
  font-size: 0.8125rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.85);
  cursor: pointer;
  text-align: left;
  transition: background-color 0.15s ease, color 0.15s ease;
  letter-spacing: -0.0094em;
}
.styles-module__dropdownItem___ylsLj:hover {
  background: rgba(255, 255, 255, 0.08);
}
.styles-module__dropdownItem___ylsLj.styles-module__selected___OwRqP {
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
  font-weight: 600;
}

.styles-module__settingsLabel___8UjfX {
  font-size: 0.8125rem;
  font-weight: 400;
  letter-spacing: -0.0094em;
  color: rgba(255, 255, 255, 0.5);
  display: flex;
  align-items: center;
  gap: 0.125rem;
}
[data-agentation-theme=light] .styles-module__settingsLabel___8UjfX {
  color: rgba(0, 0, 0, 0.5);
}

.styles-module__settingsLabelMarker___ewdtV {
  padding-top: 3px;
  margin-bottom: 10px;
}

.styles-module__settingsOptions___LyrBA {
  display: flex;
  gap: 0.25rem;
}

.styles-module__settingsOption___UNa12 {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.25rem;
  padding: 0.375rem 0.5rem;
  border: none;
  border-radius: 0.375rem;
  background: transparent;
  font-size: 0.6875rem;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.7);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}
.styles-module__settingsOption___UNa12:hover {
  background: rgba(0, 0, 0, 0.05);
}
.styles-module__settingsOption___UNa12.styles-module__selected___OwRqP {
  background: color-mix(in srgb, var(--agentation-color-blue) 15%, transparent);
  color: var(--agentation-color-blue);
}

.styles-module__sliderContainer___ducXj {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.styles-module__slider___GLdxp {
  -webkit-appearance: none;
  appearance: none;
  width: 100%;
  height: 4px;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 2px;
  outline: none;
  cursor: pointer;
}
.styles-module__slider___GLdxp::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 14px;
  height: 14px;
  background: white;
  border-radius: 50%;
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
}
.styles-module__slider___GLdxp::-moz-range-thumb {
  width: 14px;
  height: 14px;
  background: white;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
}
.styles-module__slider___GLdxp:hover::-webkit-slider-thumb {
  transform: scale(1.15);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
}
.styles-module__slider___GLdxp:hover::-moz-range-thumb {
  transform: scale(1.15);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
}

.styles-module__sliderLabels___FhLDB {
  display: flex;
  justify-content: space-between;
}

.styles-module__sliderLabel___U8sPr {
  font-size: 0.625rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.4);
  cursor: pointer;
  transition: color 0.15s ease;
}
.styles-module__sliderLabel___U8sPr:hover {
  color: rgba(255, 255, 255, 0.7);
}
.styles-module__sliderLabel___U8sPr.styles-module__active___-zoN6 {
  color: rgba(255, 255, 255, 0.9);
}

.styles-module__colorOptions___iHCNX {
  display: flex;
  gap: 0.5rem;
  margin-top: 0.375rem;
  margin-bottom: 1px;
}

.styles-module__colorOption___IodiY {
  display: block;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 2px solid transparent;
  background-color: var(--swatch);
  cursor: pointer;
  transition: transform 0.2s cubic-bezier(0.25, 1, 0.5, 1);
}
@supports (color: color(display-p3 0 0 0)) {
  .styles-module__colorOption___IodiY {
    background-color: var(--swatch-p3);
  }
}
.styles-module__colorOption___IodiY:hover {
  transform: scale(1.15);
}
.styles-module__colorOption___IodiY.styles-module__selected___OwRqP {
  transform: scale(0.83);
}

.styles-module__colorOptionRing___U2xpo {
  display: flex;
  width: 24px;
  height: 24px;
  border: 2px solid transparent;
  border-radius: 50%;
  transition: border-color 0.3s ease;
}
.styles-module__colorOptionRing___U2xpo.styles-module__selected___OwRqP {
  border-color: var(--swatch);
}
@supports (color: color(display-p3 0 0 0)) {
  .styles-module__colorOptionRing___U2xpo.styles-module__selected___OwRqP {
    border-color: var(--swatch-p3);
  }
}

.styles-module__settingsToggle___fBrFn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
}
.styles-module__settingsToggle___fBrFn + .styles-module__settingsToggle___fBrFn {
  margin-top: calc(0.5rem + 6px);
}
.styles-module__settingsToggle___fBrFn input[type=checkbox] {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}
.styles-module__settingsToggle___fBrFn.styles-module__settingsToggleMarginBottom___MZUyF {
  margin-bottom: calc(0.5rem + 6px);
}

@keyframes styles-module__mcpPulse___uNggr {
  0% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-green) 50%, transparent);
  }
  70% {
    box-shadow: 0 0 0 6px color-mix(in srgb, var(--agentation-color-green) 0%, transparent);
  }
  100% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-green) 0%, transparent);
  }
}
@keyframes styles-module__mcpPulseError___fov9B {
  0% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-red) 50%, transparent);
  }
  70% {
    box-shadow: 0 0 0 6px color-mix(in srgb, var(--agentation-color-red) 0%, transparent);
  }
  100% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-red) 0%, transparent);
  }
}
.styles-module__mcpStatusDot___ibgkc {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}
.styles-module__mcpStatusDot___ibgkc.styles-module__connecting___uo-CW {
  background-color: var(--agentation-color-yellow);
  animation: styles-module__mcpPulse___uNggr 1.5s infinite;
}
.styles-module__mcpStatusDot___ibgkc.styles-module__connected___7c28g {
  background-color: var(--agentation-color-green);
  animation: styles-module__mcpPulse___uNggr 2.5s ease-in-out infinite;
}
.styles-module__mcpStatusDot___ibgkc.styles-module__disconnected___cHPxR {
  background-color: var(--agentation-color-red);
  animation: styles-module__mcpPulseError___fov9B 2s infinite;
}

.styles-module__drawCanvas___7cG9U {
  position: fixed;
  inset: 0;
  z-index: 99996;
  pointer-events: none !important;
}
.styles-module__drawCanvas___7cG9U.styles-module__active___-zoN6 {
  pointer-events: auto !important;
  cursor: crosshair !important;
}
.styles-module__drawCanvas___7cG9U.styles-module__active___-zoN6[data-stroke-hover] {
  cursor: pointer !important;
}

.styles-module__dragSelection___kZLq2 {
  position: fixed;
  top: 0;
  left: 0;
  border: 2px solid color-mix(in srgb, var(--agentation-color-green) 60%, transparent);
  border-radius: 4px;
  background-color: color-mix(in srgb, var(--agentation-color-green) 8%, transparent);
  pointer-events: none;
  z-index: 99997;
  will-change: transform, width, height;
  contain: layout style;
}

.styles-module__dragCount___KM90j {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: var(--agentation-color-green);
  color: white;
  font-size: 0.875rem;
  font-weight: 600;
  padding: 0.25rem 0.5rem;
  border-radius: 1rem;
  min-width: 1.5rem;
  text-align: center;
}

.styles-module__highlightsContainer___-0xzG {
  position: fixed;
  top: 0;
  left: 0;
  pointer-events: none;
  z-index: 99996;
}

.styles-module__selectedElementHighlight___fyVlI {
  position: fixed;
  top: 0;
  left: 0;
  border: 2px solid color-mix(in srgb, var(--agentation-color-green) 50%, transparent);
  border-radius: 4px;
  background: color-mix(in srgb, var(--agentation-color-green) 6%, transparent);
  pointer-events: none;
  will-change: transform, width, height;
  contain: layout style;
}

[data-agentation-theme=light] .styles-module__toolbarContainer___dIhma {
  background: #fff;
  color: rgba(0, 0, 0, 0.85);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08), 0 4px 16px rgba(0, 0, 0, 0.06), 0 0 0 1px rgba(0, 0, 0, 0.04);
}
[data-agentation-theme=light] .styles-module__toolbarContainer___dIhma.styles-module__collapsed___Rydsn:hover {
  background: #f5f5f5;
}
[data-agentation-theme=light] .styles-module__toggleContent___0yfyP {
  color: rgba(0, 0, 0, 0.85);
}
[data-agentation-theme=light] .styles-module__toggleContent___0yfyP.styles-module__expandedToggle___F7SRN {
  color: rgba(0, 0, 0, 0.5);
}
[data-agentation-theme=light] .styles-module__toggleContent___0yfyP.styles-module__expandedToggle___F7SRN:hover {
  color: rgba(0, 0, 0, 0.85);
}
[data-agentation-theme=light] .styles-module__toggleContent___0yfyP.styles-module__expandedToggle___F7SRN:hover::before {
  background: rgba(0, 0, 0, 0.06);
}
[data-agentation-theme=light] .styles-module__controlButton___8Q0jc {
  color: rgba(0, 0, 0, 0.5);
}
[data-agentation-theme=light] .styles-module__controlButton___8Q0jc:hover:not(:disabled):not([data-active=true]):not([data-failed=true]):not([data-auto-sync=true]):not([data-error=true]):not([data-no-hover=true]) {
  background: rgba(0, 0, 0, 0.06);
  color: rgba(0, 0, 0, 0.85);
}
[data-agentation-theme=light] .styles-module__controlButton___8Q0jc[data-active=true] {
  color: var(--agentation-color-blue);
  background: color-mix(in srgb, var(--agentation-color-blue) 15%, transparent);
}
[data-agentation-theme=light] .styles-module__controlButton___8Q0jc[data-error=true] {
  color: var(--agentation-color-red);
  background: color-mix(in srgb, var(--agentation-color-red) 15%, transparent);
}
[data-agentation-theme=light] .styles-module__controlButton___8Q0jc[data-danger]:hover:not(:disabled):not([data-active=true]):not([data-failed=true]) {
  color: var(--agentation-color-red);
  background: color-mix(in srgb, var(--agentation-color-red) 15%, transparent);
}
[data-agentation-theme=light] .styles-module__controlButton___8Q0jc[data-auto-sync=true] {
  color: var(--agentation-color-green);
  background: transparent;
}
[data-agentation-theme=light] .styles-module__controlButton___8Q0jc[data-failed=true] {
  color: var(--agentation-color-red);
  background: color-mix(in srgb, var(--agentation-color-red) 15%, transparent);
}
[data-agentation-theme=light] .styles-module__buttonTooltip___Burd9 {
  background: #fff;
  color: rgba(0, 0, 0, 0.85);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08), 0 4px 16px rgba(0, 0, 0, 0.06), 0 0 0 1px rgba(0, 0, 0, 0.04);
}
[data-agentation-theme=light] .styles-module__buttonTooltip___Burd9::after {
  background: #fff;
}
[data-agentation-theme=light] .styles-module__divider___c--s1 {
  background: rgba(0, 0, 0, 0.1);
}`,fe={toolbar:"styles-module__toolbar___wNsdK",markersLayer:"styles-module__markersLayer___-25j1",fixedMarkersLayer:"styles-module__fixedMarkersLayer___ffyX6",controlsContent:"styles-module__controlsContent___9GJWU",disableTransitions:"styles-module__disableTransitions___EopxO",positionContext:"styles-module__positionContext___AZFHE",toolbarContainer:"styles-module__toolbarContainer___dIhma",entrance:"styles-module__entrance___sgHd8",toolbarEnter:"styles-module__toolbarEnter___u8RRu",hiding:"styles-module__hiding___1td44",toolbarHide:"styles-module__toolbarHide___y8kaT",collapsed:"styles-module__collapsed___Rydsn",expanded:"styles-module__expanded___ofKPx",serverConnected:"styles-module__serverConnected___Gfbou",buttonWrapper:"styles-module__buttonWrapper___rBcdv",toggleWrapper:"styles-module__toggleWrapper___7N0-q",togglePlaceholder:"styles-module__togglePlaceholder___wnqrL",toggleContent:"styles-module__toggleContent___0yfyP",expandedToggle:"styles-module__expandedToggle___F7SRN",toggleGlyph:"styles-module__toggleGlyph___R7Oom",toggleIcon:"styles-module__toggleIcon___Jbtus",toggleTopLine:"styles-module__toggleTopLine___hQaCm",toggleMiddleLine:"styles-module__toggleMiddleLine___sFFVe",toggleBottomLine:"styles-module__toggleBottomLine___V-jX3",toggleSparkle:"styles-module__toggleSparkle___eeF99",controlButton:"styles-module__controlButton___8Q0jc",visible:"styles-module__visible___KHwEW",hidden:"styles-module__hidden___Ae8H4",badge:"styles-module__badge___2XsgF",fadeOut:"styles-module__fadeOut___6Ut6-",badgeEnter:"styles-module__badgeEnter___mVQLj",statusShowing:"styles-module__statusShowing___te6iu",buttonBadge:"styles-module__buttonBadge___NeFWb",mcpIndicator:"styles-module__mcpIndicator___zGJeL",connected:"styles-module__connected___7c28g",mcpIndicatorPulseConnected:"styles-module__mcpIndicatorPulseConnected___EDodZ",connecting:"styles-module__connecting___uo-CW",mcpIndicatorPulseConnecting:"styles-module__mcpIndicatorPulseConnecting___cCYte",connectionIndicatorWrapper:"styles-module__connectionIndicatorWrapper___L-e-3",connectionIndicator:"styles-module__connectionIndicator___afk9p",connectionIndicatorVisible:"styles-module__connectionIndicatorVisible___C-i5B",connectionIndicatorConnected:"styles-module__connectionIndicatorConnected___IY8pR",connectionPulse:"styles-module__connectionPulse___-Zycw",connectionIndicatorDisconnected:"styles-module__connectionIndicatorDisconnected___kmpaZ",connectionIndicatorConnecting:"styles-module__connectionIndicatorConnecting___QmSLH",buttonTooltip:"styles-module__buttonTooltip___Burd9",tooltipsInSession:"styles-module__tooltipsInSession___-0lHH",sendButtonWrapper:"styles-module__sendButtonWrapper___UUxG6",sendButtonVisible:"styles-module__sendButtonVisible___WPSQU",shortcut:"styles-module__shortcut___lEAQk",tooltipBelow:"styles-module__tooltipBelow___m6ats",tooltipsHidden:"styles-module__tooltipsHidden___VtLJG",tooltipVisible:"styles-module__tooltipVisible___0jcCv",buttonWrapperAlignLeft:"styles-module__buttonWrapperAlignLeft___myzIp",buttonWrapperAlignRight:"styles-module__buttonWrapperAlignRight___HCQFR",divider:"styles-module__divider___c--s1",overlay:"styles-module__overlay___Q1O9y",hoverHighlight:"styles-module__hoverHighlight___ogakW",enter:"styles-module__enter___WFIki",hoverHighlightIn:"styles-module__hoverHighlightIn___6WYHY",multiSelectOutline:"styles-module__multiSelectOutline___cSJ-m",fadeIn:"styles-module__fadeIn___b9qmf",exit:"styles-module__exit___fyOJ0",singleSelectOutline:"styles-module__singleSelectOutline___QhX-O",hoverTooltip:"styles-module__hoverTooltip___bvLk7",hoverTooltipIn:"styles-module__hoverTooltipIn___FYGQx",hoverReactPath:"styles-module__hoverReactPath___gx1IJ",hoverElementName:"styles-module__hoverElementName___QMLMl",marker:"styles-module__marker___6sQrs",clearing:"styles-module__clearing___FQ--7",markerIn:"styles-module__markerIn___5FaAP",markerOut:"styles-module__markerOut___GU5jX",pending:"styles-module__pending___2IHLC",fixed:"styles-module__fixed___dBMHC",multiSelect:"styles-module__multiSelect___YWiuz",hovered:"styles-module__hovered___ZgXIy",renumber:"styles-module__renumber___nCTxD",renumberRoll:"styles-module__renumberRoll___Wgbq3",markerTooltip:"styles-module__markerTooltip___aLJID",tooltipIn:"styles-module__tooltipIn___0N31w",markerQuote:"styles-module__markerQuote___FHmrz",markerNote:"styles-module__markerNote___QkrrS",markerHint:"styles-module__markerHint___2iF-6",settingsPanel:"styles-module__settingsPanel___OxX3Y",settingsHeader:"styles-module__settingsHeader___pwDY9",settingsBrand:"styles-module__settingsBrand___0gJeM",settingsBrandSlash:"styles-module__settingsBrandSlash___uTG18",settingsVersion:"styles-module__settingsVersion___TUcFq",settingsSection:"styles-module__settingsSection___m-YM2",settingsLabel:"styles-module__settingsLabel___8UjfX",cycleButton:"styles-module__cycleButton___FMKfw",cycleDot:"styles-module__cycleDot___nPgLY",dropdownButton:"styles-module__dropdownButton___16NPz",toggleLabel:"styles-module__toggleLabel___Xm8Aa",customCheckbox:"styles-module__customCheckbox___U39ax",sliderLabel:"styles-module__sliderLabel___U8sPr",slider:"styles-module__slider___GLdxp",themeToggle:"styles-module__themeToggle___2rUjA",settingsOption:"styles-module__settingsOption___UNa12",selected:"styles-module__selected___OwRqP",settingsPanelContainer:"styles-module__settingsPanelContainer___Xksv8",settingsPage:"styles-module__settingsPage___6YfHH",slideLeft:"styles-module__slideLeft___Ps01J",automationsPage:"styles-module__automationsPage___uvCq6",slideIn:"styles-module__slideIn___4-qXe",settingsNavLink:"styles-module__settingsNavLink___wCzJt",settingsNavLinkRight:"styles-module__settingsNavLinkRight___ZWwhj",mcpNavIndicator:"styles-module__mcpNavIndicator___cl9pO",mcpPulse:"styles-module__mcpPulse___uNggr",settingsBackButton:"styles-module__settingsBackButton___bIe2j",automationHeader:"styles-module__automationHeader___InP0r",automationDescription:"styles-module__automationDescription___NKlmo",learnMoreLink:"styles-module__learnMoreLink___8xv-x",autoSendRow:"styles-module__autoSendRow___UblX5",autoSendLabel:"styles-module__autoSendLabel___icDc2",active:"styles-module__active___-zoN6",webhookUrlInput:"styles-module__webhookUrlInput___2375C",settingsSectionExtraPadding:"styles-module__settingsSectionExtraPadding___jdhFV",settingsSectionGrow:"styles-module__settingsSectionGrow___h-5HZ",settingsRow:"styles-module__settingsRow___3sdhc",settingsRowMarginTop:"styles-module__settingsRowMarginTop___zA0Sp",dropdownContainer:"styles-module__dropdownContainer___BVnxe",settingsRowDisabled:"styles-module__settingsRowDisabled___EgS0V",toggleSwitch:"styles-module__toggleSwitch___l4Ygm",cycleButtonText:"styles-module__cycleButtonText___fD1LR",cycleTextIn:"styles-module__cycleTextIn___Q6zJf",cycleDots:"styles-module__cycleDots___LWuoQ",dropdownMenu:"styles-module__dropdownMenu___k73ER",scaleIn:"styles-module__scaleIn___c-r1K",dropdownItem:"styles-module__dropdownItem___ylsLj",settingsLabelMarker:"styles-module__settingsLabelMarker___ewdtV",settingsOptions:"styles-module__settingsOptions___LyrBA",sliderContainer:"styles-module__sliderContainer___ducXj",sliderLabels:"styles-module__sliderLabels___FhLDB",colorOptions:"styles-module__colorOptions___iHCNX",colorOption:"styles-module__colorOption___IodiY",colorOptionRing:"styles-module__colorOptionRing___U2xpo",settingsToggle:"styles-module__settingsToggle___fBrFn",settingsToggleMarginBottom:"styles-module__settingsToggleMarginBottom___MZUyF",mcpStatusDot:"styles-module__mcpStatusDot___ibgkc",disconnected:"styles-module__disconnected___cHPxR",mcpPulseError:"styles-module__mcpPulseError___fov9B",drawCanvas:"styles-module__drawCanvas___7cG9U",dragSelection:"styles-module__dragSelection___kZLq2",dragCount:"styles-module__dragCount___KM90j",highlightsContainer:"styles-module__highlightsContainer___-0xzG",selectedElementHighlight:"styles-module__selectedElementHighlight___fyVlI",scaleOut:"styles-module__scaleOut___Wctwz",slideUp:"styles-module__slideUp___kgD36",slideDown:"styles-module__slideDown___zcdje"},cr=Tn();function Yb({active:s}){return(0,cr.jsxs)("svg",{className:fe.toggleGlyph,"data-active":s,width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[(0,cr.jsx)("path",{className:fe.toggleTopLine,d:"M5.5 6.75H18.5"}),(0,cr.jsx)("path",{className:fe.toggleMiddleLine,d:"M5.5 12H11.5"}),(0,cr.jsx)("path",{className:fe.toggleBottomLine,d:"M5.5 17.25H9.25"}),(0,cr.jsx)("path",{className:fe.toggleSparkle,d:"M16 12.75L16.5179 13.9677C16.8078 14.6494 17.3506 15.1922 18.0323 15.4821L19.25 16L18.0323 16.5179C17.3506 16.8078 16.8078 17.3506 16.5179 18.0323L16 19.25L15.4821 18.0323C15.1922 17.3506 14.6494 16.8078 13.9677 16.5179L12.75 16L13.9677 15.4821C14.6494 15.1922 15.1922 14.6494 15.4821 13.9677L16 12.75Z"})]})}var Gt=tn(),pe={navigation:{width:800,height:56},hero:{width:800,height:320},header:{width:800,height:80},section:{width:800,height:400},sidebar:{width:240,height:400},footer:{width:800,height:160},modal:{width:480,height:300},card:{width:280,height:240},text:{width:400,height:120},image:{width:320,height:200},video:{width:480,height:270},table:{width:560,height:220},grid:{width:600,height:300},list:{width:300,height:180},chart:{width:400,height:240},button:{width:140,height:40},input:{width:280,height:56},form:{width:360,height:320},tabs:{width:480,height:240},dropdown:{width:200,height:200},toggle:{width:44,height:24},search:{width:320,height:44},avatar:{width:48,height:48},badge:{width:80,height:28},breadcrumb:{width:300,height:24},pagination:{width:300,height:36},progress:{width:240,height:8},divider:{width:600,height:1},accordion:{width:400,height:200},carousel:{width:600,height:300},toast:{width:320,height:64},tooltip:{width:180,height:40},pricing:{width:300,height:360},testimonial:{width:360,height:200},cta:{width:600,height:160},alert:{width:400,height:56},banner:{width:800,height:48},stat:{width:200,height:120},stepper:{width:480,height:48},tag:{width:72,height:28},rating:{width:160,height:28},map:{width:480,height:300},timeline:{width:360,height:320},fileUpload:{width:360,height:180},codeBlock:{width:480,height:200},calendar:{width:300,height:300},notification:{width:360,height:72},productCard:{width:280,height:360},profile:{width:280,height:200},drawer:{width:320,height:400},popover:{width:240,height:160},logo:{width:120,height:40},faq:{width:560,height:320},gallery:{width:560,height:360},checkbox:{width:20,height:20},radio:{width:20,height:20},slider:{width:240,height:32},datePicker:{width:300,height:320},skeleton:{width:320,height:120},chip:{width:96,height:32},icon:{width:24,height:24},spinner:{width:32,height:32},feature:{width:360,height:200},team:{width:560,height:280},login:{width:360,height:360},contact:{width:400,height:320}},Oh=[{section:"Layout",items:[{type:"navigation",label:"Navigation",...pe.navigation},{type:"header",label:"Header",...pe.header},{type:"hero",label:"Hero",...pe.hero},{type:"section",label:"Section",...pe.section},{type:"sidebar",label:"Sidebar",...pe.sidebar},{type:"footer",label:"Footer",...pe.footer},{type:"modal",label:"Modal",...pe.modal},{type:"banner",label:"Banner",...pe.banner},{type:"drawer",label:"Drawer",...pe.drawer},{type:"popover",label:"Popover",...pe.popover},{type:"divider",label:"Divider",...pe.divider}]},{section:"Content",items:[{type:"card",label:"Card",...pe.card},{type:"text",label:"Text",...pe.text},{type:"image",label:"Image",...pe.image},{type:"video",label:"Video",...pe.video},{type:"table",label:"Table",...pe.table},{type:"grid",label:"Grid",...pe.grid},{type:"list",label:"List",...pe.list},{type:"chart",label:"Chart",...pe.chart},{type:"codeBlock",label:"Code Block",...pe.codeBlock},{type:"map",label:"Map",...pe.map},{type:"timeline",label:"Timeline",...pe.timeline},{type:"calendar",label:"Calendar",...pe.calendar},{type:"accordion",label:"Accordion",...pe.accordion},{type:"carousel",label:"Carousel",...pe.carousel},{type:"logo",label:"Logo",...pe.logo},{type:"faq",label:"FAQ",...pe.faq},{type:"gallery",label:"Gallery",...pe.gallery}]},{section:"Controls",items:[{type:"button",label:"Button",...pe.button},{type:"input",label:"Input",...pe.input},{type:"search",label:"Search",...pe.search},{type:"form",label:"Form",...pe.form},{type:"tabs",label:"Tabs",...pe.tabs},{type:"dropdown",label:"Dropdown",...pe.dropdown},{type:"toggle",label:"Toggle",...pe.toggle},{type:"stepper",label:"Stepper",...pe.stepper},{type:"rating",label:"Rating",...pe.rating},{type:"fileUpload",label:"File Upload",...pe.fileUpload},{type:"checkbox",label:"Checkbox",...pe.checkbox},{type:"radio",label:"Radio",...pe.radio},{type:"slider",label:"Slider",...pe.slider},{type:"datePicker",label:"Date Picker",...pe.datePicker}]},{section:"Elements",items:[{type:"avatar",label:"Avatar",...pe.avatar},{type:"badge",label:"Badge",...pe.badge},{type:"tag",label:"Tag",...pe.tag},{type:"breadcrumb",label:"Breadcrumb",...pe.breadcrumb},{type:"pagination",label:"Pagination",...pe.pagination},{type:"progress",label:"Progress",...pe.progress},{type:"alert",label:"Alert",...pe.alert},{type:"toast",label:"Toast",...pe.toast},{type:"notification",label:"Notification",...pe.notification},{type:"tooltip",label:"Tooltip",...pe.tooltip},{type:"stat",label:"Stat",...pe.stat},{type:"skeleton",label:"Skeleton",...pe.skeleton},{type:"chip",label:"Chip",...pe.chip},{type:"icon",label:"Icon",...pe.icon},{type:"spinner",label:"Spinner",...pe.spinner}]},{section:"Blocks",items:[{type:"pricing",label:"Pricing",...pe.pricing},{type:"testimonial",label:"Testimonial",...pe.testimonial},{type:"cta",label:"CTA",...pe.cta},{type:"productCard",label:"Product Card",...pe.productCard},{type:"profile",label:"Profile",...pe.profile},{type:"feature",label:"Feature",...pe.feature},{type:"team",label:"Team",...pe.team},{type:"login",label:"Login",...pe.login},{type:"contact",label:"Contact",...pe.contact}]}],el={};for(let s of Oh)for(let i of s.items)el[i.type]=i;var h=Tn();function ne({w:s,h:i=3,strong:r}){return(0,h.jsx)("div",{style:{width:typeof s=="number"?`${s}px`:s,height:i,borderRadius:2,background:r?"var(--agd-bar-strong)":"var(--agd-bar)",flexShrink:0}})}function It({w:s,h:i,radius:r=3,style:u}){return(0,h.jsx)("div",{style:{width:typeof s=="number"?`${s}px`:s,height:typeof i=="number"?`${i}px`:i,borderRadius:r,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",flexShrink:0,...u}})}function so({size:s}){return(0,h.jsx)("div",{style:{width:s,height:s,borderRadius:"50%",border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",flexShrink:0}})}function qb({width:s,height:i}){let r=Math.max(8,i*.2);return(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",height:"100%",padding:`0 ${r}px`,gap:s*.02},children:[(0,h.jsx)(It,{w:Math.max(20,i*.5),h:Math.max(12,i*.4),radius:2}),(0,h.jsxs)("div",{style:{flex:1,display:"flex",gap:s*.03,marginLeft:s*.04},children:[(0,h.jsx)(ne,{w:s*.06}),(0,h.jsx)(ne,{w:s*.07}),(0,h.jsx)(ne,{w:s*.05}),(0,h.jsx)(ne,{w:s*.06})]}),(0,h.jsx)(It,{w:s*.1,h:Math.min(28,i*.5),radius:4})]})}function Xb({width:s,height:i,text:r}){return(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:i*.05},children:[r?(0,h.jsx)("span",{style:{fontSize:Math.min(20,i*.08),fontWeight:600,color:"var(--agd-text-3)",textAlign:"center",maxWidth:"80%"},children:r}):(0,h.jsx)(ne,{w:s*.5,h:Math.max(6,i*.04),strong:!0}),(0,h.jsx)(ne,{w:s*.6}),(0,h.jsx)(ne,{w:s*.4}),(0,h.jsx)(It,{w:Math.min(140,s*.2),h:Math.min(36,i*.12),radius:6,style:{marginTop:i*.06}})]})}function Qb({width:s,height:i}){let r=Math.max(3,Math.floor(i/36));return(0,h.jsxs)("div",{style:{padding:s*.08,display:"flex",flexDirection:"column",gap:i*.03},children:[(0,h.jsx)(ne,{w:s*.6,h:4,strong:!0}),Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:6},children:[(0,h.jsx)(It,{w:10,h:10,radius:2}),(0,h.jsx)(ne,{w:s*(.4+d*17%30/100)})]},d))]})}function Gb({width:s,height:i}){let r=Math.max(2,Math.min(4,Math.floor(s/160)));return(0,h.jsx)("div",{style:{display:"flex",padding:`${i*.12}px ${s*.03}px`,gap:s*.05},children:Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:4},children:[(0,h.jsx)(ne,{w:"60%",h:3,strong:!0}),(0,h.jsx)(ne,{w:"80%",h:2}),(0,h.jsx)(ne,{w:"70%",h:2}),(0,h.jsx)(ne,{w:"60%",h:2})]},d))})}function Vb({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column"},children:[(0,h.jsxs)("div",{style:{padding:"10px 12px",borderBottom:"1px solid var(--agd-stroke)",display:"flex",alignItems:"center",justifyContent:"space-between"},children:[(0,h.jsx)(ne,{w:s*.3,h:4,strong:!0}),(0,h.jsx)("div",{style:{width:14,height:14,border:"1px solid var(--agd-stroke)",borderRadius:3}})]}),(0,h.jsxs)("div",{style:{flex:1,padding:12,display:"flex",flexDirection:"column",gap:6},children:[(0,h.jsx)(ne,{w:"90%"}),(0,h.jsx)(ne,{w:"70%"}),(0,h.jsx)(ne,{w:"80%"})]}),(0,h.jsxs)("div",{style:{padding:"10px 12px",borderTop:"1px solid var(--agd-stroke)",display:"flex",justifyContent:"flex-end",gap:8},children:[(0,h.jsx)(It,{w:70,h:26,radius:4}),(0,h.jsx)(It,{w:70,h:26,radius:4,style:{background:"var(--agd-bar)"}})]})]})}function Wb({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column"},children:[(0,h.jsx)("div",{style:{height:"40%",background:"var(--agd-fill)",borderBottom:"1px dashed var(--agd-stroke)"}}),(0,h.jsxs)("div",{style:{flex:1,padding:10,display:"flex",flexDirection:"column",gap:5},children:[(0,h.jsx)(ne,{w:"70%",h:4,strong:!0}),(0,h.jsx)(ne,{w:"95%",h:2}),(0,h.jsx)(ne,{w:"85%",h:2}),(0,h.jsx)(ne,{w:"50%",h:2})]})]})}function Fb({width:s,height:i,text:r}){if(r)return(0,h.jsx)("div",{style:{padding:4,fontSize:Math.min(14,i*.3),lineHeight:1.5,color:"var(--agd-text-3)",wordBreak:"break-word",overflow:"hidden"},children:r});let u=Math.max(2,Math.floor(i/18));return(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:6,padding:4},children:[(0,h.jsx)(ne,{w:s*.6,h:5,strong:!0}),Array.from({length:u},(d,_)=>(0,h.jsx)(ne,{w:`${70+_*13%25}%`,h:2},_))]})}function Zb({width:s,height:i}){return(0,h.jsx)("div",{style:{height:"100%",position:"relative"},children:(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,preserveAspectRatio:"none",fill:"none",children:[(0,h.jsx)("line",{x1:"0",y1:"0",x2:s,y2:i,stroke:"var(--agd-stroke)",strokeWidth:"1"}),(0,h.jsx)("line",{x1:s,y1:"0",x2:"0",y2:i,stroke:"var(--agd-stroke)",strokeWidth:"1"}),(0,h.jsx)("circle",{cx:s*.3,cy:i*.3,r:Math.min(s,i)*.08,fill:"var(--agd-fill)",stroke:"var(--agd-stroke)",strokeWidth:"0.8"})]})})}function Kb({width:s,height:i}){let r=Math.max(2,Math.min(5,Math.floor(s/100))),u=Math.max(2,Math.min(6,Math.floor(i/32)));return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column"},children:[(0,h.jsx)("div",{style:{display:"flex",borderBottom:"1px solid var(--agd-stroke)",padding:"6px 0"},children:Array.from({length:r},(d,_)=>(0,h.jsx)("div",{style:{flex:1,padding:"0 8px"},children:(0,h.jsx)(ne,{w:"70%",h:3,strong:!0})},_))}),Array.from({length:u},(d,_)=>(0,h.jsx)("div",{style:{display:"flex",borderBottom:"1px solid rgba(255,255,255,0.03)",padding:"6px 0"},children:Array.from({length:r},(g,w)=>(0,h.jsx)("div",{style:{flex:1,padding:"0 8px"},children:(0,h.jsx)(ne,{w:`${50+(_*7+w*13)%40}%`,h:2})},w))},_))]})}function Jb({width:s,height:i}){let r=Math.max(2,Math.floor(i/28));return(0,h.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:4,padding:4},children:Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:8,padding:"4px 0"},children:[(0,h.jsx)(so,{size:8}),(0,h.jsx)(ne,{w:`${55+d*17%35}%`,h:2})]},d))})}function Pb({width:s,height:i,text:r}){return(0,h.jsx)("div",{style:{height:"100%",borderRadius:Math.min(8,i/3),border:"1px solid var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",justifyContent:"center"},children:r?(0,h.jsx)("span",{style:{fontSize:Math.min(13,i*.4),fontWeight:500,color:"var(--agd-text-3)",letterSpacing:"-0.01em"},children:r}):(0,h.jsx)(ne,{w:Math.max(20,s*.5),h:3,strong:!0})})}function ev({width:s,height:i}){return(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:4,height:"100%",justifyContent:"center"},children:[(0,h.jsx)(ne,{w:Math.min(80,s*.3),h:2}),(0,h.jsx)("div",{style:{height:Math.min(36,i*.6),borderRadius:4,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",paddingLeft:8},children:(0,h.jsx)(ne,{w:"40%",h:2})})]})}function tv({width:s,height:i}){let r=Math.max(2,Math.min(5,Math.floor(i/56)));return(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:i*.04,padding:8},children:[Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:4},children:[(0,h.jsx)(ne,{w:60+d*17%30,h:2}),(0,h.jsx)(It,{w:"100%",h:28,radius:4})]},d)),(0,h.jsx)(It,{w:Math.min(120,s*.35),h:30,radius:6,style:{marginTop:8,alignSelf:"flex-end",background:"var(--agd-bar)"}})]})}function nv({width:s,height:i}){let r=Math.max(2,Math.min(4,Math.floor(s/120)));return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column"},children:[(0,h.jsx)("div",{style:{display:"flex",gap:2,borderBottom:"1px solid var(--agd-stroke)"},children:Array.from({length:r},(u,d)=>(0,h.jsx)("div",{style:{padding:"8px 12px",borderBottom:d===0?"2px solid var(--agd-bar-strong)":"none"},children:(0,h.jsx)(ne,{w:60,h:3,strong:d===0})},d))}),(0,h.jsxs)("div",{style:{flex:1,padding:12,display:"flex",flexDirection:"column",gap:6},children:[(0,h.jsx)(ne,{w:"80%",h:2}),(0,h.jsx)(ne,{w:"65%",h:2}),(0,h.jsx)(ne,{w:"75%",h:2})]})]})}function ov({width:s,height:i}){let r=Math.min(s,i)/2;return(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,fill:"none",children:[(0,h.jsx)("circle",{cx:s/2,cy:i/2,r:r-1,stroke:"var(--agd-stroke)",fill:"var(--agd-fill)",strokeWidth:"1.5",strokeDasharray:"3 2"}),(0,h.jsx)("circle",{cx:s/2,cy:i*.38,r:r*.28,stroke:"var(--agd-stroke)",fill:"var(--agd-fill)",strokeWidth:"0.8"}),(0,h.jsx)("path",{d:`M${s/2-r*.55} ${i*.78} C${s/2-r*.55} ${i*.55} ${s/2+r*.55} ${i*.55} ${s/2+r*.55} ${i*.78}`,stroke:"var(--agd-stroke)",fill:"var(--agd-fill)",strokeWidth:"0.8"})]})}function lv({width:s,height:i}){return(0,h.jsx)("div",{style:{height:"100%",borderRadius:i/2,border:"1px solid var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",justifyContent:"center"},children:(0,h.jsx)(ne,{w:Math.max(16,s*.5),h:2,strong:!0})})}function av({width:s,height:i}){return(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:i*.08},children:[(0,h.jsx)(ne,{w:s*.5,h:Math.max(5,i*.06),strong:!0}),(0,h.jsx)(ne,{w:s*.35})]})}function sv({width:s,height:i}){return(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",height:"100%",gap:i*.04,padding:s*.04},children:[(0,h.jsx)(ne,{w:s*.3,h:4,strong:!0}),(0,h.jsx)(ne,{w:s*.7}),(0,h.jsx)(ne,{w:s*.5}),(0,h.jsxs)("div",{style:{flex:1,display:"flex",gap:s*.03,marginTop:i*.06},children:[(0,h.jsx)(It,{w:"33%",h:"100%",radius:4}),(0,h.jsx)(It,{w:"33%",h:"100%",radius:4}),(0,h.jsx)(It,{w:"33%",h:"100%",radius:4})]})]})}function iv({width:s,height:i}){let r=Math.max(2,Math.min(4,Math.floor(s/140))),u=Math.max(1,Math.min(3,Math.floor(i/120)));return(0,h.jsx)("div",{style:{display:"grid",gridTemplateColumns:`repeat(${r}, 1fr)`,gridTemplateRows:`repeat(${u}, 1fr)`,gap:6,height:"100%"},children:Array.from({length:r*u},(d,_)=>(0,h.jsx)(It,{w:"100%",h:"100%",radius:4},_))})}function rv({width:s,height:i}){let r=Math.max(2,Math.floor((i-32)/28));return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column"},children:[(0,h.jsx)("div",{style:{padding:"6px 8px",borderBottom:"1px solid var(--agd-stroke)"},children:(0,h.jsx)(ne,{w:s*.5,h:3,strong:!0})}),(0,h.jsx)("div",{style:{flex:1,padding:4,display:"flex",flexDirection:"column",gap:2},children:Array.from({length:r},(u,d)=>(0,h.jsx)("div",{style:{padding:"4px 6px",borderRadius:3,background:d===0?"var(--agd-fill)":"transparent"},children:(0,h.jsx)(ne,{w:`${50+d*17%35}%`,h:2,strong:d===0})},d))})]})}function cv({width:s,height:i}){let r=Math.min(s,i)/2;return(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,fill:"none",children:[(0,h.jsx)("rect",{x:"1",y:"1",width:s-2,height:i-2,rx:r,stroke:"var(--agd-stroke)",strokeWidth:"1"}),(0,h.jsx)("circle",{cx:s-r,cy:i/2,r:r*.7,fill:"var(--agd-bar)"})]})}function uv({width:s,height:i}){let r=Math.min(i/2,20);return(0,h.jsxs)("div",{style:{height:"100%",borderRadius:r,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",padding:`0 ${r*.6}px`,gap:6},children:[(0,h.jsx)(so,{size:Math.min(14,i*.4)}),(0,h.jsx)(ne,{w:"50%",h:2})]})}function dv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",borderRadius:8,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",padding:"0 10px",gap:8},children:[(0,h.jsx)(so,{size:Math.min(20,i*.5)}),(0,h.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:3},children:[(0,h.jsx)(ne,{w:"60%",h:3,strong:!0}),(0,h.jsx)(ne,{w:"80%",h:2})]}),(0,h.jsx)("div",{style:{width:14,height:14,border:"1px solid var(--agd-stroke)",borderRadius:3,flexShrink:0}})]})}function _v({width:s,height:i}){return(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,fill:"none",children:[(0,h.jsx)("rect",{x:"0",y:"0",width:s,height:i,rx:i/2,stroke:"var(--agd-stroke)",strokeWidth:"0.8"}),(0,h.jsx)("rect",{x:"1",y:"1",width:s*.65,height:i-2,rx:(i-2)/2,fill:"var(--agd-bar)"})]})}function fv({width:s,height:i}){let r=Math.max(3,Math.min(7,Math.floor(s/50))),u=s/(r*2);return(0,h.jsx)("div",{style:{height:"100%",display:"flex",alignItems:"flex-end",justifyContent:"space-around",padding:"0 4px",borderBottom:"1px solid var(--agd-stroke)"},children:Array.from({length:r},(d,_)=>{let g=30+(_*37+17)%55;return(0,h.jsx)(It,{w:u,h:`${g}%`,radius:2},_)})})}function mv({width:s,height:i}){let r=Math.min(s,i)*.12;return(0,h.jsxs)("div",{style:{height:"100%",position:"relative",display:"flex",alignItems:"center",justifyContent:"center"},children:[(0,h.jsx)(It,{w:"100%",h:"100%",radius:4}),(0,h.jsx)("div",{style:{position:"absolute",width:r*2,height:r*2,borderRadius:"50%",border:"1.5px solid var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",justifyContent:"center"},children:(0,h.jsx)("div",{style:{width:0,height:0,borderLeft:`${r*.6}px solid var(--agd-bar-strong)`,borderTop:`${r*.4}px solid transparent`,borderBottom:`${r*.4}px solid transparent`,marginLeft:r*.15}})})]})}function hv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",alignItems:"center"},children:[(0,h.jsx)("div",{style:{flex:1,width:"100%",borderRadius:6,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",justifyContent:"center"},children:(0,h.jsx)(ne,{w:"60%",h:2})}),(0,h.jsx)("div",{style:{width:8,height:8,background:"var(--agd-fill)",border:"1px dashed var(--agd-stroke)",borderTop:"none",borderLeft:"none",transform:"rotate(45deg)",marginTop:-5}})]})}function gv({width:s,height:i}){let r=Math.max(2,Math.min(4,Math.floor(s/80)));return(0,h.jsx)("div",{style:{display:"flex",alignItems:"center",height:"100%",gap:4},children:Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:4},children:[d>0&&(0,h.jsx)("span",{style:{color:"var(--agd-stroke)",fontSize:10},children:"/"}),(0,h.jsx)(ne,{w:40+d*13%20,h:2,strong:d===r-1})]},d))})}function pv({width:s,height:i}){let r=Math.max(3,Math.min(5,Math.floor(s/40))),u=Math.min(28,i*.8);return(0,h.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",gap:4},children:Array.from({length:r},(d,_)=>(0,h.jsx)(It,{w:u,h:u,radius:4,style:_===1?{background:"var(--agd-bar)"}:void 0},_))})}function yv({width:s}){return(0,h.jsx)("div",{style:{display:"flex",alignItems:"center",height:"100%"},children:(0,h.jsx)("div",{style:{width:"100%",height:1,background:"var(--agd-stroke)"}})})}function xv({width:s,height:i}){let r=Math.max(2,Math.min(4,Math.floor(i/40)));return(0,h.jsx)("div",{style:{display:"flex",flexDirection:"column",height:"100%"},children:Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{borderBottom:"1px solid var(--agd-stroke)",padding:"8px 6px",display:"flex",alignItems:"center",justifyContent:"space-between",flex:d===0?2:1},children:[(0,h.jsx)(ne,{w:`${40+d*17%25}%`,h:3,strong:!0}),(0,h.jsx)("span",{style:{fontSize:8,color:"var(--agd-stroke)"},children:d===0?"\u25BC":"\u25B6"})]},d))})}function bv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",gap:6},children:[(0,h.jsxs)("div",{style:{flex:1,display:"flex",gap:6,alignItems:"center"},children:[(0,h.jsx)("span",{style:{fontSize:12,color:"var(--agd-stroke)"},children:"\u2039"}),(0,h.jsx)(It,{w:"100%",h:"100%",radius:4}),(0,h.jsx)("span",{style:{fontSize:12,color:"var(--agd-stroke)"},children:"\u203A"})]}),(0,h.jsxs)("div",{style:{display:"flex",justifyContent:"center",gap:4},children:[(0,h.jsx)(so,{size:5}),(0,h.jsx)(so,{size:5}),(0,h.jsx)(so,{size:5})]})]})}function vv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",alignItems:"center",padding:10,gap:i*.04},children:[(0,h.jsx)(ne,{w:s*.4,h:3,strong:!0}),(0,h.jsx)(ne,{w:s*.3,h:6,strong:!0}),(0,h.jsx)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:4,width:"100%",padding:"8px 0"},children:Array.from({length:4},(r,u)=>(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:4},children:[(0,h.jsx)(so,{size:5}),(0,h.jsx)(ne,{w:`${50+u*17%35}%`,h:2})]},u))}),(0,h.jsx)(It,{w:s*.7,h:Math.min(32,i*.1),radius:6,style:{background:"var(--agd-bar)"}})]})}function wv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",padding:10,gap:8},children:[(0,h.jsx)("span",{style:{fontSize:18,lineHeight:1,color:"var(--agd-stroke)",fontFamily:"serif"},children:"\u201C"}),(0,h.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:4},children:[(0,h.jsx)(ne,{w:"90%",h:2}),(0,h.jsx)(ne,{w:"75%",h:2}),(0,h.jsx)(ne,{w:"60%",h:2})]}),(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:6},children:[(0,h.jsx)(so,{size:20}),(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:2},children:[(0,h.jsx)(ne,{w:60,h:3,strong:!0}),(0,h.jsx)(ne,{w:40,h:2})]})]})]})}function Sv({width:s,height:i}){return(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:i*.08},children:[(0,h.jsx)(ne,{w:s*.5,h:Math.max(4,i*.05),strong:!0}),(0,h.jsx)(ne,{w:s*.35}),(0,h.jsx)(It,{w:Math.min(140,s*.25),h:Math.min(32,i*.15),radius:6,style:{marginTop:i*.04,background:"var(--agd-bar)"}})]})}function kv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",borderRadius:6,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",padding:"0 10px",gap:8},children:[(0,h.jsx)("div",{style:{width:16,height:16,borderRadius:"50%",border:"1.5px solid var(--agd-bar-strong)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0},children:(0,h.jsx)("div",{style:{width:2,height:6,background:"var(--agd-bar-strong)",borderRadius:1}})}),(0,h.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:3},children:[(0,h.jsx)(ne,{w:"40%",h:3,strong:!0}),(0,h.jsx)(ne,{w:"70%",h:2})]})]})}function Cv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",background:"var(--agd-fill)",display:"flex",alignItems:"center",justifyContent:"center",gap:8,padding:"0 12px"},children:[(0,h.jsx)(ne,{w:s*.4,h:3,strong:!0}),(0,h.jsx)(It,{w:60,h:Math.min(24,i*.6),radius:4})]})}function jv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:i*.06},children:[(0,h.jsx)(ne,{w:s*.5,h:2}),(0,h.jsx)(ne,{w:s*.4,h:Math.max(8,i*.18),strong:!0}),(0,h.jsx)(ne,{w:s*.3,h:2})]})}function Ev({width:s,height:i}){let r=Math.max(3,Math.min(5,Math.floor(s/100))),u=Math.min(12,i*.35);return(0,h.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",height:"100%",padding:"0 8px"},children:Array.from({length:r},(d,_)=>(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:0,flex:1},children:[(0,h.jsx)("div",{style:{width:u,height:u,borderRadius:"50%",border:"1.5px solid var(--agd-stroke)",background:_===0?"var(--agd-bar)":"transparent",flexShrink:0}}),_<r-1&&(0,h.jsx)("div",{style:{flex:1,height:1,background:"var(--agd-stroke)",margin:"0 4px"}})]},_))})}function Mv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",borderRadius:4,border:"1px solid var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",justifyContent:"center",gap:4,padding:"0 6px"},children:[(0,h.jsx)(ne,{w:Math.max(16,s*.5),h:2,strong:!0}),(0,h.jsx)("div",{style:{width:8,height:8,borderRadius:"50%",border:"1px solid var(--agd-stroke)",flexShrink:0}})]})}function Tv({width:s,height:i}){let u=Math.min(i*.7,s/7.5);return(0,h.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",gap:u*.2},children:Array.from({length:5},(d,_)=>(0,h.jsx)("svg",{width:u,height:u,viewBox:"0 0 16 16",fill:"none",children:(0,h.jsx)("path",{d:"M8 1.5l2 4 4.5.7-3.25 3.1.75 4.5L8 11.4l-4 2.4.75-4.5L1.5 6.2 6 5.5z",stroke:"var(--agd-stroke)",strokeWidth:"0.8",fill:_<3?"var(--agd-bar)":"none"})},_))})}function Nv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",position:"relative",borderRadius:4,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",overflow:"hidden"},children:[(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,fill:"none",style:{position:"absolute",inset:0},children:[(0,h.jsx)("line",{x1:0,y1:i*.3,x2:s,y2:i*.7,stroke:"var(--agd-stroke)",strokeWidth:"0.5",opacity:".2"}),(0,h.jsx)("line",{x1:0,y1:i*.6,x2:s,y2:i*.2,stroke:"var(--agd-stroke)",strokeWidth:"0.5",opacity:".15"}),(0,h.jsx)("line",{x1:s*.4,y1:0,x2:s*.6,y2:i,stroke:"var(--agd-stroke)",strokeWidth:"0.5",opacity:".15"})]}),(0,h.jsx)("div",{style:{position:"absolute",left:"50%",top:"40%",transform:"translate(-50%, -100%)"},children:(0,h.jsxs)("svg",{width:"16",height:"22",viewBox:"0 0 16 22",fill:"none",children:[(0,h.jsx)("path",{d:"M8 0C3.6 0 0 3.6 0 8c0 6 8 14 8 14s8-8 8-14c0-4.4-3.6-8-8-8z",fill:"var(--agd-bar)",opacity:".4"}),(0,h.jsx)("circle",{cx:"8",cy:"8",r:"3",fill:"var(--agd-fill)"})]})})]})}function Rv({width:s,height:i}){let r=Math.max(3,Math.min(5,Math.floor(i/60)));return(0,h.jsxs)("div",{style:{display:"flex",height:"100%",padding:"8px 0"},children:[(0,h.jsx)("div",{style:{width:16,display:"flex",flexDirection:"column",alignItems:"center"},children:Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",flex:1},children:[(0,h.jsx)(so,{size:8}),d<r-1&&(0,h.jsx)("div",{style:{flex:1,width:1,background:"var(--agd-stroke)"}})]},d))}),(0,h.jsx)("div",{style:{flex:1,display:"flex",flexDirection:"column",justifyContent:"space-around",paddingLeft:8},children:Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:3},children:[(0,h.jsx)(ne,{w:`${35+d*13%25}%`,h:3,strong:!0}),(0,h.jsx)(ne,{w:`${50+d*17%30}%`,h:2})]},d))})]})}function Av({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",borderRadius:8,border:"2px dashed var(--agd-stroke)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:i*.06},children:[(0,h.jsxs)("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",children:[(0,h.jsx)("path",{d:"M12 16V4m0 0l-4 4m4-4l4 4",stroke:"var(--agd-stroke)",strokeWidth:"1.5"}),(0,h.jsx)("path",{d:"M4 17v2a1 1 0 001 1h14a1 1 0 001-1v-2",stroke:"var(--agd-stroke)",strokeWidth:"1.5"})]}),(0,h.jsx)(ne,{w:s*.4,h:2}),(0,h.jsx)(ne,{w:s*.25,h:2})]})}function Dv({width:s,height:i}){let r=Math.max(3,Math.min(8,Math.floor(i/20)));return(0,h.jsxs)("div",{style:{height:"100%",borderRadius:6,background:"var(--agd-fill)",border:"1px solid var(--agd-stroke)",padding:8,display:"flex",flexDirection:"column",gap:4},children:[(0,h.jsxs)("div",{style:{display:"flex",gap:3,marginBottom:4},children:[(0,h.jsx)(so,{size:6}),(0,h.jsx)(so,{size:6}),(0,h.jsx)(so,{size:6})]}),Array.from({length:r},(u,d)=>(0,h.jsx)("div",{style:{display:"flex",gap:6,paddingLeft:d>0&&d<r-1?12:0},children:(0,h.jsx)(ne,{w:`${25+d*23%50}%`,h:2,strong:d===0})},d))]})}function Ov({width:s,height:i}){let d=Math.min((s-16)/7,(i-40)/6);return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column"},children:[(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"6px 8px"},children:[(0,h.jsx)("span",{style:{fontSize:8,color:"var(--agd-stroke)"},children:"\u2039"}),(0,h.jsx)(ne,{w:s*.3,h:3,strong:!0}),(0,h.jsx)("span",{style:{fontSize:8,color:"var(--agd-stroke)"},children:"\u203A"})]}),(0,h.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"repeat(7, 1fr)",gap:2,padding:"0 4px",flex:1},children:[Array.from({length:7},(_,g)=>(0,h.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",height:d*.6},children:(0,h.jsx)(ne,{w:d*.5,h:2})},`h${g}`)),Array.from({length:35},(_,g)=>(0,h.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",height:d},children:(0,h.jsx)("div",{style:{width:d*.6,height:d*.6,borderRadius:"50%",background:g===12?"var(--agd-bar)":"transparent",display:"flex",alignItems:"center",justifyContent:"center"},children:(0,h.jsx)("div",{style:{width:2,height:2,borderRadius:1,background:"var(--agd-bar-strong)",opacity:g===12?1:.3}})})},g))]})]})}function zv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",borderRadius:8,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",padding:"0 10px",gap:8},children:[(0,h.jsx)(so,{size:Math.min(32,i*.55)}),(0,h.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:3},children:[(0,h.jsx)(ne,{w:"50%",h:3,strong:!0}),(0,h.jsx)(ne,{w:"75%",h:2})]}),(0,h.jsx)(ne,{w:30,h:2})]})}function Lv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column"},children:[(0,h.jsx)("div",{style:{height:"50%",background:"var(--agd-fill)",borderBottom:"1px dashed var(--agd-stroke)"}}),(0,h.jsxs)("div",{style:{flex:1,padding:10,display:"flex",flexDirection:"column",gap:5},children:[(0,h.jsx)(ne,{w:"65%",h:4,strong:!0}),(0,h.jsx)(ne,{w:"40%",h:3}),(0,h.jsx)("div",{style:{flex:1}}),(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between"},children:[(0,h.jsx)(ne,{w:"30%",h:5,strong:!0}),(0,h.jsx)(It,{w:Math.min(70,s*.3),h:26,radius:4,style:{background:"var(--agd-bar)"}})]})]})]})}function Bv({width:s,height:i}){let r=Math.min(48,i*.3);return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:i*.06},children:[(0,h.jsx)(so,{size:r}),(0,h.jsx)(ne,{w:s*.45,h:4,strong:!0}),(0,h.jsx)(ne,{w:s*.3,h:2}),(0,h.jsxs)("div",{style:{display:"flex",gap:s*.08,marginTop:i*.04},children:[(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:2},children:[(0,h.jsx)(ne,{w:20,h:3,strong:!0}),(0,h.jsx)(ne,{w:28,h:2})]}),(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:2},children:[(0,h.jsx)(ne,{w:20,h:3,strong:!0}),(0,h.jsx)(ne,{w:28,h:2})]}),(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:2},children:[(0,h.jsx)(ne,{w:20,h:3,strong:!0}),(0,h.jsx)(ne,{w:28,h:2})]})]})]})}function Hv({width:s,height:i}){let r=Math.max(s*.6,80),u=Math.max(3,Math.floor(i/40));return(0,h.jsxs)("div",{style:{height:"100%",display:"flex"},children:[(0,h.jsx)("div",{style:{width:s-r,background:"var(--agd-fill)",opacity:.3}}),(0,h.jsxs)("div",{style:{flex:1,borderLeft:"1px solid var(--agd-stroke)",display:"flex",flexDirection:"column",padding:s*.04},children:[(0,h.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:i*.06},children:[(0,h.jsx)(ne,{w:r*.4,h:4,strong:!0}),(0,h.jsx)("div",{style:{width:12,height:12,border:"1px solid var(--agd-stroke)",borderRadius:3}})]}),Array.from({length:u},(d,_)=>(0,h.jsx)("div",{style:{padding:"6px 0"},children:(0,h.jsx)(ne,{w:`${50+_*17%35}%`,h:2,strong:_===0})},_))]})]})}function Uv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",alignItems:"center"},children:[(0,h.jsxs)("div",{style:{flex:1,width:"100%",borderRadius:8,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",padding:10,display:"flex",flexDirection:"column",gap:5},children:[(0,h.jsx)(ne,{w:"70%",h:3,strong:!0}),(0,h.jsx)(ne,{w:"90%",h:2}),(0,h.jsx)(ne,{w:"60%",h:2})]}),(0,h.jsx)("div",{style:{width:10,height:10,background:"var(--agd-fill)",border:"1px dashed var(--agd-stroke)",borderTop:"none",borderLeft:"none",transform:"rotate(45deg)",marginTop:-6}})]})}function $v({width:s,height:i}){let r=Math.min(i*.7,s*.3);return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",alignItems:"center",gap:s*.08},children:[(0,h.jsx)(It,{w:r,h:r,radius:r*.25}),(0,h.jsx)(ne,{w:s*.45,h:Math.max(4,i*.2),strong:!0})]})}function Iv({width:s,height:i}){let r=Math.max(2,Math.min(5,Math.floor(i/56)));return(0,h.jsx)("div",{style:{display:"flex",flexDirection:"column",height:"100%"},children:Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{borderBottom:"1px solid var(--agd-stroke)",padding:"8px 6px",display:"flex",alignItems:"center",justifyContent:"space-between",flex:d===0?2:1},children:[(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:6},children:[(0,h.jsx)("span",{style:{fontSize:9,fontWeight:700,color:"var(--agd-stroke)"},children:"Q"}),(0,h.jsx)(ne,{w:s*(.3+d*13%25/100),h:3,strong:!0})]}),(0,h.jsx)("span",{style:{fontSize:8,color:"var(--agd-stroke)"},children:d===0?"\u25BC":"\u25B6"})]},d))})}function Yv({width:s,height:i}){let r=Math.max(2,Math.min(4,Math.floor(s/120))),u=Math.max(1,Math.min(3,Math.floor(i/120)));return(0,h.jsx)("div",{style:{display:"grid",gridTemplateColumns:`repeat(${r}, 1fr)`,gridTemplateRows:`repeat(${u}, 1fr)`,gap:4,height:"100%"},children:Array.from({length:r*u},(d,_)=>(0,h.jsx)("div",{style:{borderRadius:4,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",position:"relative",overflow:"hidden"},children:(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:"0 0 100 100",preserveAspectRatio:"none",fill:"none",children:[(0,h.jsx)("line",{x1:"0",y1:"0",x2:"100",y2:"100",stroke:"var(--agd-stroke)",strokeWidth:"0.5"}),(0,h.jsx)("line",{x1:"100",y1:"0",x2:"0",y2:"100",stroke:"var(--agd-stroke)",strokeWidth:"0.5"})]})},_))})}function qv({width:s,height:i}){let r=Math.min(s,i);return(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,fill:"none",children:[(0,h.jsx)("rect",{x:"1",y:(i-r+2)/2,width:r-2,height:r-2,rx:r*.15,stroke:"var(--agd-stroke)",strokeWidth:"1.5"}),(0,h.jsx)("path",{d:`M${r*.25} ${i/2}l${r*.2} ${r*.2} ${r*.3}-${r*.35}`,stroke:"var(--agd-bar)",strokeWidth:"1.5",fill:"none",strokeLinecap:"round",strokeLinejoin:"round"})]})}function Xv({width:s,height:i}){let r=Math.min(s,i)/2-1;return(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,fill:"none",children:[(0,h.jsx)("circle",{cx:s/2,cy:i/2,r,stroke:"var(--agd-stroke)",strokeWidth:"1.5"}),(0,h.jsx)("circle",{cx:s/2,cy:i/2,r:r*.45,fill:"var(--agd-bar)"})]})}function Qv({width:s,height:i}){let r=Math.max(2,i*.12),u=Math.min(i*.35,10),d=s*.55;return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",alignItems:"center",position:"relative"},children:[(0,h.jsx)("div",{style:{width:"100%",height:r,borderRadius:r/2,background:"var(--agd-fill)",border:"1px solid var(--agd-stroke)",position:"relative"},children:(0,h.jsx)("div",{style:{width:d,height:"100%",borderRadius:r/2,background:"var(--agd-bar)"}})}),(0,h.jsx)("div",{style:{position:"absolute",left:d-u,width:u*2,height:u*2,borderRadius:"50%",border:"1.5px solid var(--agd-stroke)",background:"var(--agd-fill)"}})]})}function Gv({width:s,height:i}){let r=Math.min(36,i*.15),u=7,d=4,_=Math.min((s-16)/u,(i-r-40)/(d+1));return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",gap:4},children:[(0,h.jsxs)("div",{style:{height:r,borderRadius:4,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",padding:"0 8px",justifyContent:"space-between"},children:[(0,h.jsx)(ne,{w:"40%",h:2}),(0,h.jsxs)("svg",{width:"12",height:"12",viewBox:"0 0 16 16",fill:"none",children:[(0,h.jsx)("rect",{x:"2",y:"3",width:"12",height:"11",rx:"1",stroke:"var(--agd-stroke)",strokeWidth:"1"}),(0,h.jsx)("line",{x1:"2",y1:"6",x2:"14",y2:"6",stroke:"var(--agd-stroke)",strokeWidth:"0.5"})]})]}),(0,h.jsxs)("div",{style:{flex:1,borderRadius:6,border:"1px dashed var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",flexDirection:"column"},children:[(0,h.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"4px 6px"},children:[(0,h.jsx)("span",{style:{fontSize:7,color:"var(--agd-stroke)"},children:"\u2039"}),(0,h.jsx)(ne,{w:s*.25,h:2,strong:!0}),(0,h.jsx)("span",{style:{fontSize:7,color:"var(--agd-stroke)"},children:"\u203A"})]}),(0,h.jsx)("div",{style:{display:"grid",gridTemplateColumns:`repeat(${u}, 1fr)`,gap:1,padding:"0 4px",flex:1},children:Array.from({length:u*d},(g,w)=>(0,h.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",height:_},children:(0,h.jsx)("div",{style:{width:_*.5,height:_*.5,borderRadius:"50%",background:w===10?"var(--agd-bar)":"transparent"},children:(0,h.jsx)("div",{style:{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center"},children:(0,h.jsx)("div",{style:{width:1.5,height:1.5,borderRadius:1,background:"var(--agd-bar-strong)",opacity:w===10?1:.25}})})})},w))})]})]})}function Vv({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",gap:i*.08,padding:4},children:[(0,h.jsx)("div",{style:{width:"100%",height:i*.2,borderRadius:4,background:"var(--agd-fill)"}}),(0,h.jsx)("div",{style:{width:"70%",height:Math.max(6,i*.1),borderRadius:3,background:"var(--agd-fill)"}}),(0,h.jsx)("div",{style:{width:"90%",height:Math.max(4,i*.06),borderRadius:3,background:"var(--agd-fill)"}}),(0,h.jsx)("div",{style:{width:"50%",height:Math.max(4,i*.06),borderRadius:3,background:"var(--agd-fill)"}})]})}function Wv({width:s,height:i}){return(0,h.jsx)("div",{style:{height:"100%",display:"flex",alignItems:"center",gap:6},children:(0,h.jsxs)("div",{style:{height:"100%",flex:1,borderRadius:i/2,border:"1px solid var(--agd-stroke)",background:"var(--agd-fill)",display:"flex",alignItems:"center",padding:`0 ${i*.3}px`,gap:4},children:[(0,h.jsx)(ne,{w:"60%",h:2,strong:!0}),(0,h.jsx)("div",{style:{width:Math.max(6,i*.3),height:Math.max(6,i*.3),borderRadius:"50%",border:"1px solid var(--agd-stroke)",flexShrink:0,marginLeft:"auto"}})]})})}function Fv({width:s,height:i}){let r=Math.min(s,i);return(0,h.jsx)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,fill:"none",children:(0,h.jsx)("path",{d:`M${s/2} ${(i-r)/2+r*.1}l${r*.12} ${r*.25} ${r*.28} ${r*.04}-${r*.2} ${r*.2} ${r*.05} ${r*.28}-${r*.25}-${r*.12}-${r*.25} ${r*.12} ${r*.05}-${r*.28}-${r*.2}-${r*.2} ${r*.28}-${r*.04}z`,stroke:"var(--agd-stroke)",strokeWidth:"1",fill:"var(--agd-fill)"})})}function Zv({width:s,height:i}){let r=Math.min(s,i)/2-2;return(0,h.jsxs)("svg",{width:"100%",height:"100%",viewBox:`0 0 ${s} ${i}`,fill:"none",children:[(0,h.jsx)("circle",{cx:s/2,cy:i/2,r,stroke:"var(--agd-stroke)",strokeWidth:"1.5",opacity:".2"}),(0,h.jsx)("path",{d:`M${s/2} ${i/2-r}a${r} ${r} 0 0 1 ${r} ${r}`,stroke:"var(--agd-bar-strong)",strokeWidth:"1.5",strokeLinecap:"round"})]})}function Kv({width:s,height:i}){let r=Math.min(36,i*.25,s*.12),u=Math.max(1,Math.min(3,Math.floor(i/80)));return(0,h.jsx)("div",{style:{display:"flex",flexDirection:"column",height:"100%",justifyContent:"space-around",padding:8},children:Array.from({length:u},(d,_)=>(0,h.jsxs)("div",{style:{display:"flex",gap:s*.04,alignItems:"flex-start"},children:[(0,h.jsx)(It,{w:r,h:r,radius:r*.25}),(0,h.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:4},children:[(0,h.jsx)(ne,{w:`${40+_*13%20}%`,h:3,strong:!0}),(0,h.jsx)(ne,{w:`${60+_*17%25}%`,h:2})]})]},_))})}function Jv({width:s,height:i}){let r=Math.max(2,Math.min(4,Math.floor(s/120))),u=Math.min(36,i*.25);return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",alignItems:"center",gap:i*.06,padding:i*.06},children:[(0,h.jsx)(ne,{w:s*.3,h:4,strong:!0}),(0,h.jsx)("div",{style:{display:"flex",gap:s*.06,justifyContent:"center",flex:1,alignItems:"center"},children:Array.from({length:r},(d,_)=>(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:6},children:[(0,h.jsx)(so,{size:u}),(0,h.jsx)(ne,{w:s*.12,h:3,strong:!0}),(0,h.jsx)(ne,{w:s*.08,h:2})]},_))})]})}function Pv({width:s,height:i}){let r=Math.max(2,Math.min(3,Math.floor(i/80)));return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",alignItems:"center",padding:s*.06,gap:i*.04},children:[(0,h.jsx)(ne,{w:s*.5,h:Math.max(5,i*.04),strong:!0}),(0,h.jsx)(ne,{w:s*.35,h:2}),(0,h.jsx)("div",{style:{width:"100%",display:"flex",flexDirection:"column",gap:i*.03,marginTop:i*.04},children:Array.from({length:r},(u,d)=>(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:3},children:[(0,h.jsx)(ne,{w:Math.min(60,s*.2),h:2}),(0,h.jsx)(It,{w:"100%",h:Math.min(32,i*.1),radius:4})]},d))}),(0,h.jsx)(It,{w:"100%",h:Math.min(36,i*.12),radius:6,style:{marginTop:i*.03,background:"var(--agd-bar)"}}),(0,h.jsx)(ne,{w:s*.4,h:2})]})}function ew({width:s,height:i}){return(0,h.jsxs)("div",{style:{height:"100%",display:"flex",flexDirection:"column",padding:s*.04,gap:i*.03},children:[(0,h.jsx)(ne,{w:s*.4,h:4,strong:!0}),(0,h.jsx)(ne,{w:s*.6,h:2}),(0,h.jsxs)("div",{style:{display:"flex",gap:6,marginTop:i*.03},children:[(0,h.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:3},children:[(0,h.jsx)(ne,{w:50,h:2}),(0,h.jsx)(It,{w:"100%",h:Math.min(28,i*.1),radius:4})]}),(0,h.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:3},children:[(0,h.jsx)(ne,{w:40,h:2}),(0,h.jsx)(It,{w:"100%",h:Math.min(28,i*.1),radius:4})]})]}),(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:3},children:[(0,h.jsx)(ne,{w:50,h:2}),(0,h.jsx)(It,{w:"100%",h:Math.min(28,i*.1),radius:4})]}),(0,h.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:3,flex:1},children:[(0,h.jsx)(ne,{w:60,h:2}),(0,h.jsx)(It,{w:"100%",h:"100%",radius:4})]}),(0,h.jsx)(It,{w:Math.min(120,s*.3),h:Math.min(30,i*.1),radius:6,style:{alignSelf:"flex-end",background:"var(--agd-bar)"}})]})}var tw={navigation:qb,hero:Xb,sidebar:Qb,footer:Gb,modal:Vb,card:Wb,text:Fb,image:Zb,table:Kb,list:Jb,button:Pb,input:ev,form:tv,tabs:nv,avatar:ov,badge:lv,header:av,section:sv,grid:iv,dropdown:rv,toggle:cv,search:uv,toast:dv,progress:_v,chart:fv,video:mv,tooltip:hv,breadcrumb:gv,pagination:pv,divider:yv,accordion:xv,carousel:bv,pricing:vv,testimonial:wv,cta:Sv,alert:kv,banner:Cv,stat:jv,stepper:Ev,tag:Mv,rating:Tv,map:Nv,timeline:Rv,fileUpload:Av,codeBlock:Dv,calendar:Ov,notification:zv,productCard:Lv,profile:Bv,drawer:Hv,popover:Uv,logo:$v,faq:Iv,gallery:Yv,checkbox:qv,radio:Xv,slider:Qv,datePicker:Gv,skeleton:Vv,chip:Wv,icon:Fv,spinner:Zv,feature:Kv,team:Jv,login:Pv,contact:ew};function nw({type:s,width:i,height:r,text:u}){let d=tw[s];return d?(0,h.jsx)("div",{style:{width:"100%",height:"100%",padding:8,position:"relative",pointerEvents:"none"},children:(0,h.jsx)(d,{width:i,height:r,text:u})}):(0,h.jsx)("div",{style:{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center"},children:(0,h.jsx)("span",{style:{fontSize:10,fontWeight:600,color:"var(--agd-text-3)",textTransform:"uppercase",letterSpacing:"0.06em",opacity:.5},children:s})})}var ow=`.styles-module__overlay___aWh-q svg[fill=none],
.styles-module__rearrangeOverlay___-3R3t svg[fill=none] {
  fill: none !important;
}
.styles-module__overlay___aWh-q svg[fill=none] :not([fill]),
.styles-module__rearrangeOverlay___-3R3t svg[fill=none] :not([fill]) {
  fill: none !important;
}

.styles-module__overlayExiting___iEmYr {
  opacity: 0 !important;
  transition: opacity 0.25s ease !important;
  pointer-events: none !important;
}

.styles-module__overlay___aWh-q {
  position: fixed;
  inset: 0;
  z-index: 99995;
  pointer-events: auto;
  cursor: default;
  animation: styles-module__overlayFadeIn___aECVy 0.15s ease;
  --agd-stroke: rgba(59, 130, 246, 0.35);
  --agd-fill: rgba(59, 130, 246, 0.06);
  --agd-bar: rgba(59, 130, 246, 0.18);
  --agd-bar-strong: rgba(59, 130, 246, 0.28);
  --agd-text-3: rgba(255, 255, 255, 0.6);
  --agd-surface: #fff;
}
.styles-module__overlay___aWh-q.styles-module__light___ORIft {
  --agd-surface: #fff;
}
.styles-module__overlay___aWh-q:not(.styles-module__light___ORIft) {
  --agd-surface: #141414;
}
.styles-module__overlay___aWh-q.styles-module__wireframe___itvQU {
  --agd-stroke: rgba(249, 115, 22, 0.35);
  --agd-fill: rgba(249, 115, 22, 0.06);
  --agd-bar: rgba(249, 115, 22, 0.18);
  --agd-bar-strong: rgba(249, 115, 22, 0.28);
}
.styles-module__overlay___aWh-q.styles-module__placing___45yD8 {
  cursor: crosshair;
}
.styles-module__overlay___aWh-q.styles-module__passthrough___xaFeE {
  pointer-events: none;
}

.styles-module__blankCanvas___t2Eue {
  position: fixed;
  inset: 0;
  z-index: 99994;
  background: #fff;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.25s ease;
}
.styles-module__blankCanvas___t2Eue.styles-module__visible___OKKqX {
  opacity: var(--canvas-opacity, 1);
  pointer-events: auto;
}
.styles-module__blankCanvas___t2Eue::after {
  content: "";
  position: absolute;
  inset: 0;
  background-image: radial-gradient(circle, rgba(0, 0, 0, 0.08) 1px, transparent 1px);
  background-size: 24px 24px;
  background-position: 12px 12px;
  pointer-events: none;
  transition: opacity 0.2s ease;
}
.styles-module__blankCanvas___t2Eue.styles-module__gridActive___OZ-cf::after {
  opacity: 1;
  background-image: radial-gradient(circle, rgba(0, 0, 0, 0.22) 1px, transparent 1px);
}

.styles-module__paletteHeader___-Q5gQ {
  padding: 0 1rem 0.375rem;
}

.styles-module__paletteHeaderTitle___oHqZC {
  font-size: 0.8125rem;
  font-weight: 500;
  color: #fff;
  letter-spacing: -0.0094em;
}
.styles-module__light___ORIft .styles-module__paletteHeaderTitle___oHqZC {
  color: rgba(0, 0, 0, 0.85);
}

.styles-module__paletteHeaderDesc___6i74T {
  font-size: 0.6875rem;
  font-weight: 300;
  color: rgba(255, 255, 255, 0.45);
  margin-top: 2px;
  line-height: 14px;
}
.styles-module__light___ORIft .styles-module__paletteHeaderDesc___6i74T {
  color: rgba(0, 0, 0, 0.45);
}
.styles-module__paletteHeaderDesc___6i74T a {
  color: rgba(255, 255, 255, 0.8);
  text-decoration: underline dotted;
  text-decoration-color: rgba(255, 255, 255, 0.2);
  text-underline-offset: 2px;
  transition: color 0.15s ease;
}
.styles-module__paletteHeaderDesc___6i74T a:hover {
  color: #fff;
}
.styles-module__light___ORIft .styles-module__paletteHeaderDesc___6i74T a {
  color: rgba(0, 0, 0, 0.6);
  text-decoration-color: rgba(0, 0, 0, 0.2);
}
.styles-module__light___ORIft .styles-module__paletteHeaderDesc___6i74T a:hover {
  color: rgba(0, 0, 0, 0.85);
}

.styles-module__wireframePurposeWrap___To-tS {
  display: grid;
  grid-template-rows: 1fr;
  transition: grid-template-rows 0.2s ease, opacity 0.15s ease;
  opacity: 1;
}
.styles-module__wireframePurposeWrap___To-tS.styles-module__collapsed___Ms9vS {
  grid-template-rows: 0fr;
  opacity: 0;
}

.styles-module__wireframePurposeInner___Lrahs {
  overflow: hidden;
}

.styles-module__wireframePurposeInput___7EtBN {
  display: block;
  width: calc(100% - 2rem);
  margin: 0.25rem 1rem 0.375rem;
  padding: 0.375rem 0.5rem;
  font-size: 0.8125rem;
  font-family: inherit;
  color: rgba(255, 255, 255, 0.85);
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 0.375rem;
  resize: none;
  outline: none;
  transition: border-color 0.15s ease;
  letter-spacing: -0.0094em;
}
.styles-module__wireframePurposeInput___7EtBN::placeholder {
  color: rgba(255, 255, 255, 0.3);
}
.styles-module__wireframePurposeInput___7EtBN:focus {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.05);
}
.styles-module__light___ORIft .styles-module__wireframePurposeInput___7EtBN {
  color: rgba(0, 0, 0, 0.7);
  background: rgba(0, 0, 0, 0.03);
  border-color: rgba(0, 0, 0, 0.1);
}
.styles-module__light___ORIft .styles-module__wireframePurposeInput___7EtBN::placeholder {
  color: rgba(0, 0, 0, 0.3);
}
.styles-module__light___ORIft .styles-module__wireframePurposeInput___7EtBN:focus {
  border-color: rgba(0, 0, 0, 0.25);
  background: rgba(0, 0, 0, 0.05);
}

.styles-module__canvasToggle___-QqSy {
  width: calc(100% - 2rem);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.375rem;
  margin: 0.25rem 1rem 0.25rem;
  padding: 0.375rem 0.5rem;
  border-radius: 0.5rem;
  cursor: pointer;
  border: 1px dashed rgba(255, 255, 255, 0.1);
  background: transparent;
  transition: background 0.15s ease, border-color 0.15s ease;
}
.styles-module__canvasToggle___-QqSy:hover {
  background: rgba(255, 255, 255, 0.04);
  border-color: rgba(255, 255, 255, 0.15);
}
.styles-module__canvasToggle___-QqSy.styles-module__active___hosp7 {
  background: #f97316;
  border-color: transparent;
  border-style: solid;
  box-shadow: none;
}
.styles-module__light___ORIft .styles-module__canvasToggle___-QqSy {
  border-color: rgba(0, 0, 0, 0.08);
}
.styles-module__light___ORIft .styles-module__canvasToggle___-QqSy:hover {
  background: rgba(0, 0, 0, 0.02);
  border-color: rgba(0, 0, 0, 0.12);
}
.styles-module__light___ORIft .styles-module__canvasToggle___-QqSy.styles-module__active___hosp7 {
  background: #f97316;
  border-color: transparent;
  border-style: solid;
  box-shadow: none;
}

.styles-module__canvasToggleIcon___7pJ82 {
  width: 14px;
  height: 14px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255, 255, 255, 0.35);
}
.styles-module__active___hosp7 .styles-module__canvasToggleIcon___7pJ82 {
  color: rgba(255, 255, 255, 0.85);
}
.styles-module__light___ORIft .styles-module__canvasToggleIcon___7pJ82 {
  color: rgba(0, 0, 0, 0.25);
}
.styles-module__light___ORIft .styles-module__active___hosp7 .styles-module__canvasToggleIcon___7pJ82 {
  color: rgba(255, 255, 255, 0.85);
}

.styles-module__canvasToggleLabel___OanpY {
  font-size: 0.8125rem;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.6);
  letter-spacing: -0.0094em;
}
.styles-module__active___hosp7 .styles-module__canvasToggleLabel___OanpY {
  color: #fff;
}
.styles-module__light___ORIft .styles-module__canvasToggleLabel___OanpY {
  color: rgba(0, 0, 0, 0.5);
}
.styles-module__light___ORIft .styles-module__active___hosp7 .styles-module__canvasToggleLabel___OanpY {
  color: #fff;
}

.styles-module__placement___zcxv8 {
  position: absolute;
  border: 1.5px dashed rgba(59, 130, 246, 0.4);
  border-radius: 6px;
  background: rgba(59, 130, 246, 0.08);
  cursor: grab;
  transition: box-shadow 0.15s, border-color 0.15s, opacity 0.15s ease, transform 0.15s ease;
  -webkit-user-select: none;
  user-select: none;
  pointer-events: auto;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  animation: styles-module__placementEnter___TdRhf 0.25s cubic-bezier(0.34, 1.2, 0.64, 1);
}
.styles-module__placement___zcxv8:active {
  cursor: grabbing;
}
.styles-module__placement___zcxv8:hover {
  border-color: rgba(59, 130, 246, 0.5);
  background: rgba(59, 130, 246, 0.1);
  box-shadow: 0 2px 8px rgba(59, 130, 246, 0.12);
}
.styles-module__placement___zcxv8.styles-module__selected___6yrp6 {
  border-color: #3c82f7;
  border-style: solid;
  background: rgba(59, 130, 246, 0.1);
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15), 0 2px 8px rgba(59, 130, 246, 0.15);
}
.styles-module__placement___zcxv8.styles-module__selected___6yrp6:hover {
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15), 0 2px 8px rgba(59, 130, 246, 0.15);
}
.styles-module__wireframe___itvQU .styles-module__placement___zcxv8 {
  border-color: rgba(249, 115, 22, 0.4);
  background: rgba(249, 115, 22, 0.08);
}
.styles-module__wireframe___itvQU .styles-module__placement___zcxv8:hover {
  border-color: rgba(249, 115, 22, 0.5);
  background: rgba(249, 115, 22, 0.1);
  box-shadow: 0 2px 8px rgba(249, 115, 22, 0.12);
}
.styles-module__wireframe___itvQU .styles-module__placement___zcxv8.styles-module__selected___6yrp6 {
  border-color: #f97316;
  background: rgba(249, 115, 22, 0.1);
  box-shadow: 0 0 0 2px rgba(249, 115, 22, 0.15), 0 2px 8px rgba(249, 115, 22, 0.15);
}
.styles-module__wireframe___itvQU .styles-module__placement___zcxv8.styles-module__selected___6yrp6:hover {
  box-shadow: 0 0 0 2px rgba(249, 115, 22, 0.15), 0 2px 8px rgba(249, 115, 22, 0.15);
}
.styles-module__placement___zcxv8.styles-module__dragging___le6KZ {
  opacity: 0.85;
  z-index: 50;
}
.styles-module__placement___zcxv8.styles-module__exiting___YrM8F {
  opacity: 0;
  transform: scale(0.97);
  pointer-events: none;
  animation: none;
  transition: opacity 0.2s ease, transform 0.2s cubic-bezier(0.32, 0.72, 0, 1);
}

.styles-module__placementContent___f64A4 {
  width: 100%;
  height: 100%;
  overflow: hidden;
  pointer-events: none;
}

.styles-module__placementLabel___0KvWl {
  position: absolute;
  top: -18px;
  left: 0;
  font-size: 10px;
  font-weight: 600;
  color: rgba(59, 130, 246, 0.7);
  white-space: nowrap;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  text-shadow: 0 0 4px rgba(255, 255, 255, 0.8), 0 0 8px rgba(255, 255, 255, 0.5);
}
.styles-module__selected___6yrp6 .styles-module__placementLabel___0KvWl {
  color: #3c82f7;
}
.styles-module__wireframe___itvQU .styles-module__placementLabel___0KvWl {
  color: rgba(249, 115, 22, 0.7);
}
.styles-module__wireframe___itvQU .styles-module__selected___6yrp6 .styles-module__placementLabel___0KvWl {
  color: #f97316;
}

.styles-module__placementAnnotation___78pTr {
  position: absolute;
  bottom: -18px;
  left: 0;
  right: 0;
  font-weight: 450;
  color: rgba(0, 0, 0, 0.5);
  font-size: 10px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  text-shadow: 0 0 4px rgba(255, 255, 255, 0.9), 0 0 8px rgba(255, 255, 255, 0.6);
  opacity: 0;
  transform: translateY(-2px);
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.styles-module__placementAnnotation___78pTr.styles-module__annotationVisible___mrUyA {
  opacity: 1;
  transform: translateY(0);
}

.styles-module__sectionAnnotation___aUIs0 {
  position: absolute;
  bottom: -18px;
  left: 0;
  right: 0;
  font-weight: 450;
  color: rgba(59, 130, 246, 0.6);
  font-size: 10px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  text-shadow: 0 0 4px rgba(255, 255, 255, 0.9), 0 0 8px rgba(255, 255, 255, 0.6);
  opacity: 0;
  transform: translateY(-2px);
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.styles-module__sectionAnnotation___aUIs0.styles-module__annotationVisible___mrUyA {
  opacity: 1;
  transform: translateY(0);
}

.styles-module__handle___Ikbxm {
  position: absolute;
  width: 8px;
  height: 8px;
  background: #fff;
  border: 1.5px solid #3c82f7;
  border-radius: 2px;
  z-index: 12;
  box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 1px 2px rgba(0, 0, 0, 0.12);
  opacity: 0;
  transform: scale(0.3);
  pointer-events: none;
  will-change: opacity, transform;
  transition: opacity 0.2s ease-out, transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.styles-module__placement___zcxv8:hover .styles-module__handle___Ikbxm, .styles-module__sectionOutline___s0hy-:hover .styles-module__handle___Ikbxm, .styles-module__ghostOutline___po-kO:hover .styles-module__handle___Ikbxm, .styles-module__placement___zcxv8:active .styles-module__handle___Ikbxm, .styles-module__sectionOutline___s0hy-:active .styles-module__handle___Ikbxm, .styles-module__ghostOutline___po-kO:active .styles-module__handle___Ikbxm, .styles-module__selected___6yrp6 .styles-module__handle___Ikbxm {
  opacity: 1;
  transform: scale(1);
  pointer-events: auto;
}
.styles-module__sectionOutline___s0hy- .styles-module__handle___Ikbxm {
  border-color: inherit;
}
.styles-module__wireframe___itvQU .styles-module__handle___Ikbxm {
  border-color: #f97316;
}

.styles-module__handleNw___4TMIj {
  top: -4px;
  left: -4px;
  cursor: nw-resize;
}

.styles-module__handleNe___mnsTh {
  top: -4px;
  right: -4px;
  cursor: ne-resize;
}

.styles-module__handleSe___oSFnk {
  bottom: -4px;
  right: -4px;
  cursor: se-resize;
}

.styles-module__handleSw___pi--Z {
  bottom: -4px;
  left: -4px;
  cursor: sw-resize;
}

.styles-module__handleN___aBA-Q,
.styles-module__handleE___0hM5u,
.styles-module__handleS___JjDRv,
.styles-module__handleW___ERWGQ {
  opacity: 0 !important;
  pointer-events: none !important;
}

.styles-module__edgeHandle___XxXdT {
  position: absolute;
  z-index: 11;
  display: flex;
  align-items: center;
  justify-content: center;
}
.styles-module__edgeHandle___XxXdT::after {
  content: "";
  position: absolute;
  border-radius: 4px;
  background: #3c82f7;
}
.styles-module__wireframe___itvQU .styles-module__edgeHandle___XxXdT::after {
  background: #f97316;
}
.styles-module__edgeHandle___XxXdT::after {
  opacity: 0;
  transition: opacity 0.1s ease, transform 0.1s ease;
  transform: scale(0.8);
}
.styles-module__edgeHandle___XxXdT:hover::after {
  opacity: 0.85;
  transform: scale(1);
}
.styles-module__edgeHandle___XxXdT svg {
  position: relative;
  z-index: 1;
  opacity: 0;
  transition: opacity 0.1s ease;
  filter: drop-shadow(0 0 2px var(--agd-surface));
}
.styles-module__edgeHandle___XxXdT:hover svg {
  opacity: 1;
}

.styles-module__edgeN___-JJDj,
.styles-module__edgeS___66lMX {
  left: 12px;
  right: 12px;
  height: 12px;
  cursor: n-resize;
}
.styles-module__edgeN___-JJDj::after,
.styles-module__edgeS___66lMX::after {
  width: 24px;
  height: 4px;
}

.styles-module__edgeN___-JJDj {
  top: -6px;
}

.styles-module__edgeS___66lMX {
  bottom: -6px;
  cursor: s-resize;
}

.styles-module__edgeE___1bGDa,
.styles-module__edgeW___lHQNo {
  top: 12px;
  bottom: 12px;
  width: 12px;
  cursor: e-resize;
}
.styles-module__edgeE___1bGDa::after,
.styles-module__edgeW___lHQNo::after {
  width: 4px;
  height: 24px;
}

.styles-module__edgeE___1bGDa {
  right: -6px;
}

.styles-module__edgeW___lHQNo {
  left: -6px;
  cursor: w-resize;
}

.styles-module__deleteButton___LkGCb {
  position: absolute;
  top: -8px;
  right: -8px;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(0, 0, 0, 0.08);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  color: rgba(0, 0, 0, 0.35);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  line-height: 1;
  z-index: 15;
  pointer-events: none;
  opacity: 0;
  transform: scale(0.8);
  will-change: opacity, transform;
  transition: opacity 0.2s ease-out, transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), background 0.12s ease, color 0.12s ease, border-color 0.12s ease, box-shadow 0.12s ease;
}
.styles-module__placement___zcxv8:hover .styles-module__deleteButton___LkGCb, .styles-module__selected___6yrp6 .styles-module__deleteButton___LkGCb, .styles-module__sectionOutline___s0hy-:hover .styles-module__deleteButton___LkGCb, .styles-module__sectionOutline___s0hy-.styles-module__selected___6yrp6 .styles-module__deleteButton___LkGCb, .styles-module__ghostOutline___po-kO:hover .styles-module__deleteButton___LkGCb, .styles-module__ghostOutline___po-kO.styles-module__selected___6yrp6 .styles-module__deleteButton___LkGCb {
  opacity: 1;
  transform: scale(1);
  pointer-events: auto;
}
.styles-module__deleteButton___LkGCb:hover {
  background: #ef4444;
  color: #fff;
  border-color: #ef4444;
  box-shadow: 0 1px 4px rgba(239, 68, 68, 0.3);
  transform: scale(1.1);
}
.styles-module__overlay___aWh-q:not(.styles-module__light___ORIft) .styles-module__deleteButton___LkGCb, .styles-module__rearrangeOverlay___-3R3t:not(.styles-module__light___ORIft) .styles-module__deleteButton___LkGCb {
  background: rgba(40, 40, 40, 0.9);
  border-color: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.5);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
}
.styles-module__overlay___aWh-q:not(.styles-module__light___ORIft) .styles-module__deleteButton___LkGCb:hover, .styles-module__rearrangeOverlay___-3R3t:not(.styles-module__light___ORIft) .styles-module__deleteButton___LkGCb:hover {
  background: #ef4444;
  color: #fff;
  border-color: #ef4444;
}

.styles-module__drawBox___BrVAa {
  position: fixed;
  pointer-events: none;
  z-index: 99996;
  border: 2px solid #3c82f7;
  border-radius: 6px;
  background: rgba(59, 130, 246, 0.15);
}

.styles-module__selectBox___Iu8kB {
  position: fixed;
  pointer-events: none;
  z-index: 99996;
  border: 1px dashed #3c82f7;
  background: rgba(59, 130, 246, 0.08);
  border-radius: 2px;
}

.styles-module__sizeIndicator___7zJ4y {
  position: fixed;
  pointer-events: none;
  z-index: 100001;
  font-size: 10px;
  color: #fff;
  background: #3c82f7;
  padding: 2px 6px;
  border-radius: 4px;
  white-space: nowrap;
  font-weight: 500;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
}

.styles-module__guideLine___DUQY2 {
  pointer-events: none;
  z-index: 100001;
  background: #f0f;
  opacity: 0.5;
}

.styles-module__dragPreview___onPbU {
  position: fixed;
  z-index: 100002;
  pointer-events: none;
  border: 1.5px dashed #3c82f7;
  border-radius: 6px;
  background: rgba(59, 130, 246, 0.1);
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 9px;
  font-weight: 600;
  color: #3c82f7;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  box-shadow: 0 4px 16px rgba(59, 130, 246, 0.15);
  transition: width 0.08s ease, height 0.08s ease, opacity 0.08s ease;
}

.styles-module__dragPreviewWireframe___jsg0G {
  border-color: #f97316;
  background: rgba(249, 115, 22, 0.1);
  color: #f97316;
  box-shadow: 0 4px 16px rgba(249, 115, 22, 0.15);
}

.styles-module__palette___C7iSH {
  position: absolute;
  right: 5px;
  bottom: calc(100% + 0.5rem);
  width: 256px;
  overflow: hidden;
  background: #1c1c1c;
  border: none;
  border-radius: 1rem;
  padding: 13px 0 16px;
  box-shadow: 0 1px 8px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(0, 0, 0, 0.04);
  z-index: 100001;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  cursor: default;
  opacity: 0;
  filter: blur(5px);
}
.styles-module__palette___C7iSH .styles-module__paletteItem___6TlnA,
.styles-module__palette___C7iSH .styles-module__paletteItemLabel___6ncO4,
.styles-module__palette___C7iSH .styles-module__paletteSectionTitle___PqnjX,
.styles-module__palette___C7iSH .styles-module__paletteFooter___QYnAG {
  transition: background 0.25s ease, color 0.25s ease, border-color 0.25s ease;
}
.styles-module__palette___C7iSH {
  opacity: 0;
  transform: translateY(var(--panel-offset-y, 4px)) scale(0.98);
  transform-origin: var(--panel-origin, bottom right);
  filter: blur(2px);
  pointer-events: none;
  visibility: hidden;
  transition: opacity 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.styles-module__palette___C7iSH[data-panel-present=true] {
  visibility: visible;
}
.styles-module__palette___C7iSH[data-panel-open=true] {
  opacity: 1;
  transform: translateY(0) scale(1);
  filter: blur(0);
  pointer-events: auto;
  transition-duration: 160ms;
}
@media (prefers-reduced-motion: reduce) {
  .styles-module__palette___C7iSH {
    transition: none;
    transform: none;
    filter: none;
  }
}
.styles-module__palette___C7iSH.styles-module__light___ORIft {
  background: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08), 0 4px 16px rgba(0, 0, 0, 0.06), 0 0 0 1px rgba(0, 0, 0, 0.04);
}

.styles-module__paletteSection___V8DEA {
  padding: 0 1rem;
}
.styles-module__paletteSection___V8DEA + .styles-module__paletteSection___V8DEA {
  margin-top: 0.5rem;
  padding-top: 0.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.07);
}
.styles-module__light___ORIft .styles-module__paletteSection___V8DEA + .styles-module__paletteSection___V8DEA {
  border-top-color: rgba(0, 0, 0, 0.07);
}

.styles-module__paletteSectionTitle___PqnjX {
  font-size: 0.6875rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.5);
  letter-spacing: -0.0094em;
  padding: 0 0 3px 3px;
}
.styles-module__light___ORIft .styles-module__paletteSectionTitle___PqnjX {
  color: rgba(0, 0, 0, 0.4);
}

.styles-module__paletteItem___6TlnA {
  width: 100%;
  text-align: left;
  background: transparent;
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.25rem 0.25rem;
  margin-bottom: 1px;
  border-radius: 0.375rem;
  cursor: pointer;
  transition: background-color 0.15s ease, border-color 0.15s ease;
  border: 1px solid transparent;
  -webkit-user-select: none;
  user-select: none;
  min-height: 24px;
}
.styles-module__paletteItem___6TlnA:hover {
  background: rgba(255, 255, 255, 0.1);
}
.styles-module__paletteItem___6TlnA.styles-module__active___hosp7 {
  background: #3c82f7;
  border-color: transparent;
}
.styles-module__paletteItem___6TlnA.styles-module__wireframe___itvQU.styles-module__active___hosp7 {
  background: #f97316;
}
.styles-module__light___ORIft .styles-module__paletteItem___6TlnA:hover {
  background: rgba(0, 0, 0, 0.05);
}
.styles-module__light___ORIft .styles-module__paletteItem___6TlnA.styles-module__active___hosp7 {
  background: #3c82f7;
  border-color: transparent;
}
.styles-module__light___ORIft .styles-module__paletteItem___6TlnA.styles-module__wireframe___itvQU.styles-module__active___hosp7 {
  background: #f97316;
}

.styles-module__paletteItemIcon___0NPQK {
  width: 20px;
  height: 16px;
  border-radius: 2px;
  border: 1px dashed rgba(255, 255, 255, 0.15);
  background: rgba(255, 255, 255, 0.04);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
  color: rgba(255, 255, 255, 0.45);
}
.styles-module__paletteItemIcon___0NPQK svg {
  display: block;
  width: 20px;
  height: 16px;
}
.styles-module__active___hosp7 .styles-module__paletteItemIcon___0NPQK {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}
.styles-module__light___ORIft .styles-module__paletteItemIcon___0NPQK {
  border-color: rgba(0, 0, 0, 0.12);
  background: rgba(0, 0, 0, 0.02);
  color: rgba(0, 0, 0, 0.4);
}
.styles-module__light___ORIft .styles-module__active___hosp7 .styles-module__paletteItemIcon___0NPQK {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}

.styles-module__paletteItemLabel___6ncO4 {
  font-size: 0.8125rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.85);
  letter-spacing: -0.0094em;
  line-height: 1;
  min-width: 0;
}
.styles-module__active___hosp7 .styles-module__paletteItemLabel___6ncO4 {
  color: #fff;
  font-weight: 600;
}
.styles-module__light___ORIft .styles-module__paletteItemLabel___6ncO4 {
  color: rgba(0, 0, 0, 0.7);
}
.styles-module__light___ORIft .styles-module__active___hosp7 .styles-module__paletteItemLabel___6ncO4 {
  color: #fff;
  font-weight: 600;
}

.styles-module__placeScroll___7sClM {
  max-height: 240px;
  overflow-y: auto;
  overflow-x: hidden;
  padding-top: 0.25rem;
}
.styles-module__placeScroll___7sClM.styles-module__fadeTop___KT9tF {
  -webkit-mask-image: linear-gradient(to bottom, transparent 0, black 32px);
  mask-image: linear-gradient(to bottom, transparent 0, black 32px);
}
.styles-module__placeScroll___7sClM.styles-module__fadeBottom___x3ShT {
  -webkit-mask-image: linear-gradient(to bottom, black calc(100% - 32px), transparent 100%);
  mask-image: linear-gradient(to bottom, black calc(100% - 32px), transparent 100%);
}
.styles-module__placeScroll___7sClM.styles-module__fadeTop___KT9tF.styles-module__fadeBottom___x3ShT {
  -webkit-mask-image: linear-gradient(to bottom, transparent 0, black 32px, black calc(100% - 32px), transparent 100%);
  mask-image: linear-gradient(to bottom, transparent 0, black 32px, black calc(100% - 32px), transparent 100%);
}
.styles-module__placeScroll___7sClM::-webkit-scrollbar {
  width: 3px;
}
.styles-module__placeScroll___7sClM::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 2px;
}
.styles-module__light___ORIft .styles-module__placeScroll___7sClM::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.1);
}

.styles-module__paletteFooterWrap___71-fI {
  display: grid;
  grid-template-rows: 1fr;
  transition: grid-template-rows 0.25s cubic-bezier(0.32, 0.72, 0, 1);
}
.styles-module__paletteFooterWrap___71-fI.styles-module__footerHidden___fJUik {
  grid-template-rows: 0fr;
}

.styles-module__paletteFooterInnerContent___VC26h {
  opacity: 1;
  transform: translateY(0);
  transition: opacity 0.15s ease, transform 0.15s ease;
}
.styles-module__footerHidden___fJUik .styles-module__paletteFooterInnerContent___VC26h {
  opacity: 0;
  transform: translateY(4px);
}

.styles-module__paletteFooterInner___dfylY {
  overflow: hidden;
}

.styles-module__paletteFooter___QYnAG {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 24px;
  padding: 0 1rem;
  margin-top: 0.5rem;
  padding-top: 0.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.07);
}
.styles-module__light___ORIft .styles-module__paletteFooter___QYnAG {
  border-top-color: rgba(0, 0, 0, 0.07);
}

.styles-module__paletteFooterCount___D3Fia {
  font-size: 0.8125rem;
  font-weight: 400;
  letter-spacing: -0.0094em;
  color: rgba(255, 255, 255, 0.5);
}
.styles-module__light___ORIft .styles-module__paletteFooterCount___D3Fia {
  color: rgba(0, 0, 0, 0.5);
}

.styles-module__paletteFooterClear___ybBoa {
  font-size: 0.8125rem;
  font-weight: 400;
  letter-spacing: -0.0094em;
  color: rgba(255, 255, 255, 0.5);
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  font-family: inherit;
  transition: color 0.15s ease;
}
.styles-module__paletteFooterClear___ybBoa:hover {
  color: rgba(255, 255, 255, 0.7);
}
.styles-module__light___ORIft .styles-module__paletteFooterClear___ybBoa {
  color: rgba(0, 0, 0, 0.5);
}
.styles-module__light___ORIft .styles-module__paletteFooterClear___ybBoa:hover {
  color: rgba(0, 0, 0, 0.6);
}

.styles-module__paletteFooterActions___fLzv8 {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.styles-module__rollingWrap___S75jM {
  display: inline-block;
  overflow: hidden;
  height: 1.15em;
  position: relative;
  vertical-align: bottom;
}

.styles-module__rollingNum___1RKDx {
  position: absolute;
  left: 0;
  top: 0;
}

.styles-module__exitUp___AFDRW {
  animation: styles-module__numExitUp___FRQqx 0.25s cubic-bezier(0.32, 0.72, 0, 1) forwards;
}

.styles-module__enterUp___CPlXb {
  animation: styles-module__numEnterUp___2Yd-w 0.25s cubic-bezier(0.32, 0.72, 0, 1) forwards;
}

.styles-module__exitDown___-1yAy {
  animation: styles-module__numExitDown___xm5by 0.25s cubic-bezier(0.32, 0.72, 0, 1) forwards;
}

.styles-module__enterDown___DDuFR {
  animation: styles-module__numEnterDown___hpxBk 0.25s cubic-bezier(0.32, 0.72, 0, 1) forwards;
}

@keyframes styles-module__numExitUp___FRQqx {
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(-110%);
    opacity: 0;
  }
}
@keyframes styles-module__numEnterUp___2Yd-w {
  from {
    transform: translateY(110%);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
@keyframes styles-module__numExitDown___xm5by {
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(110%);
    opacity: 0;
  }
}
@keyframes styles-module__numEnterDown___hpxBk {
  from {
    transform: translateY(-110%);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
.styles-module__rearrangeOverlay___-3R3t {
  position: fixed;
  inset: 0;
  z-index: 99995;
  pointer-events: none;
  cursor: default;
  -webkit-user-select: none;
  user-select: none;
  animation: styles-module__overlayFadeIn___aECVy 0.15s ease;
}

.styles-module__hoverHighlight___8eT-v {
  position: fixed;
  pointer-events: none;
  z-index: 99994;
  border: 2px dashed rgba(59, 130, 246, 0.5);
  border-radius: 4px;
  background: rgba(59, 130, 246, 0.06);
  animation: styles-module__highlightFadeIn___Lg7KY 0.12s ease;
}

.styles-module__sectionOutline___s0hy- {
  position: fixed;
  border: 2px solid;
  border-radius: 4px;
  cursor: grab;
}
.styles-module__sectionOutline___s0hy-:active {
  cursor: grabbing;
}
.styles-module__sectionOutline___s0hy- {
  transition: box-shadow 0.15s, border-color 0.3s, background-color 0.3s, border-style 0s;
  -webkit-user-select: none;
  user-select: none;
  pointer-events: auto;
  animation: styles-module__sectionEnter___-8BXT 0.2s ease;
}
.styles-module__sectionOutline___s0hy-:hover {
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.1), 0 4px 12px rgba(0, 0, 0, 0.15);
}
.styles-module__sectionOutline___s0hy-.styles-module__selected___6yrp6 {
  border-style: solid;
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15), 0 2px 8px rgba(59, 130, 246, 0.15);
}
.styles-module__sectionOutline___s0hy-.styles-module__selected___6yrp6:hover {
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15), 0 2px 8px rgba(59, 130, 246, 0.15);
}
.styles-module__sectionOutline___s0hy-.styles-module__settled___b5U5o:not(.styles-module__selected___6yrp6) {
  border: 1.5px dashed rgba(150, 150, 150, 0.35);
  background-color: transparent !important;
  box-shadow: none;
}
.styles-module__sectionOutline___s0hy-.styles-module__settled___b5U5o:not(.styles-module__selected___6yrp6):hover {
  border-color: rgba(150, 150, 150, 0.6);
  box-shadow: none;
}
.styles-module__sectionOutline___s0hy-.styles-module__settled___b5U5o:not(.styles-module__selected___6yrp6) .styles-module__sectionLabel___F80HQ {
  opacity: 0;
  transition: opacity 0.15s ease;
}
.styles-module__sectionOutline___s0hy-.styles-module__settled___b5U5o:not(.styles-module__selected___6yrp6):hover .styles-module__sectionLabel___F80HQ {
  opacity: 1;
}
.styles-module__sectionOutline___s0hy-.styles-module__settled___b5U5o:not(.styles-module__selected___6yrp6) .styles-module__movedBadge___s8z-q,
.styles-module__sectionOutline___s0hy-.styles-module__settled___b5U5o:not(.styles-module__selected___6yrp6) .styles-module__sectionDimensions___RcJSL {
  opacity: 0;
  transition: opacity 0.15s ease;
}
.styles-module__sectionOutline___s0hy-.styles-module__settled___b5U5o:not(.styles-module__selected___6yrp6):hover .styles-module__sectionDimensions___RcJSL {
  opacity: 1;
}
.styles-module__sectionOutline___s0hy-.styles-module__exiting___YrM8F {
  opacity: 0;
  transform: scale(0.97);
  pointer-events: none;
  animation: none;
  transition: opacity 0.2s ease, transform 0.2s cubic-bezier(0.32, 0.72, 0, 1);
}

.styles-module__sectionLabel___F80HQ {
  position: absolute;
  top: 4px;
  left: 4px;
  font-size: 10px;
  font-weight: 600;
  color: #fff;
  padding: 2px 8px;
  border-radius: 4px;
  white-space: nowrap;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
  max-width: calc(100% - 8px);
  overflow: hidden;
  text-overflow: ellipsis;
}

.styles-module__movedBadge___s8z-q {
  position: absolute;
  bottom: 22px;
  right: 4px;
  font-size: 9px;
  font-weight: 700;
  color: #fff;
  background: #22c55e;
  padding: 2px 6px;
  border-radius: 4px;
  white-space: nowrap;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
  opacity: 0;
  transform: scale(0.8);
  transition: opacity 0.15s ease, transform 0.15s ease;
}
.styles-module__movedBadge___s8z-q.styles-module__badgeVisible___npbdS {
  opacity: 1;
  transform: scale(1);
  transition: opacity 0.2s cubic-bezier(0.34, 1.2, 0.64, 1), transform 0.2s cubic-bezier(0.34, 1.2, 0.64, 1);
}

.styles-module__resizedBadge___u51V8 {
  background: #3c82f7;
  bottom: 40px;
}

.styles-module__sectionDimensions___RcJSL {
  position: absolute;
  bottom: 4px;
  right: 4px;
  font-size: 9px;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.7);
  background: rgba(0, 0, 0, 0.5);
  padding: 1px 5px;
  border-radius: 3px;
  white-space: nowrap;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}
.styles-module__light___ORIft .styles-module__sectionDimensions___RcJSL {
  color: rgba(0, 0, 0, 0.5);
  background: rgba(255, 255, 255, 0.7);
}

.styles-module__wireframeNotice___4GJyB {
  position: fixed;
  bottom: 16px;
  left: 24px;
  z-index: 99995;
  font-size: 9.5px;
  font-weight: 400;
  color: rgba(0, 0, 0, 0.4);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  pointer-events: auto;
  animation: styles-module__overlayFadeIn___aECVy 0.3s ease;
  line-height: 1.5;
  max-width: 280px;
}

.styles-module__wireframeOpacityRow___CJXzi {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.styles-module__wireframeOpacityLabel___afkfT {
  font-size: 9px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.32);
  letter-spacing: 0.02em;
  white-space: nowrap;
  -webkit-user-select: none;
  user-select: none;
}

.styles-module__wireframeOpacitySlider___YcoEs {
  -webkit-appearance: none;
  appearance: none;
  width: 56px;
  height: 4px;
  background: rgba(0, 0, 0, 0.08);
  border-radius: 2px;
  outline: none;
  cursor: pointer;
  flex-shrink: 0;
  transition: background 0.15s ease;
}
.styles-module__wireframeOpacitySlider___YcoEs:hover {
  background: rgba(0, 0, 0, 0.13);
}
.styles-module__wireframeOpacitySlider___YcoEs::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #f97316;
  cursor: pointer;
  transition: background 0.15s ease;
}
.styles-module__wireframeOpacitySlider___YcoEs::-webkit-slider-thumb:hover {
  background: rgb(88.0082041185%, 37.39404381%, 2.2663056855%);
}
.styles-module__wireframeOpacitySlider___YcoEs::-moz-range-thumb {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #f97316;
  border: none;
  cursor: pointer;
}
.styles-module__wireframeOpacitySlider___YcoEs::-moz-range-track {
  background: rgba(0, 0, 0, 0.08);
  height: 4px;
  border-radius: 2px;
}

.styles-module__wireframeNoticeTitleRow___PJqyG {
  display: flex;
  align-items: center;
  gap: 0;
  margin-bottom: 2px;
}

.styles-module__wireframeNoticeTitle___okr08 {
  font-weight: 600;
  color: rgba(0, 0, 0, 0.55);
}

.styles-module__wireframeNoticeDivider___PNKQ6 {
  width: 1px;
  height: 8px;
  background: rgba(0, 0, 0, 0.12);
  margin: 0 8px;
  flex-shrink: 0;
}

.styles-module__wireframeStartOver___YFk-I {
  font-size: 9.5px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.35);
  cursor: pointer;
  background: none;
  border: none;
  padding: 0;
  font-family: inherit;
  text-decoration: none;
  transition: color 0.12s ease;
  white-space: nowrap;
}
.styles-module__wireframeStartOver___YFk-I:hover {
  color: rgba(0, 0, 0, 0.6);
}

.styles-module__ghostOutline___po-kO {
  position: fixed;
  border: 1.5px dashed rgba(59, 130, 246, 0.4);
  border-radius: 4px;
  background: rgba(59, 130, 246, 0.04);
  cursor: grab;
  opacity: 0.5;
  -webkit-user-select: none;
  user-select: none;
  pointer-events: auto;
  animation: styles-module__ghostEnter___EC3Mb 0.25s ease;
  transition: box-shadow 0.15s, border-color 0.3s, opacity 0.25s;
}
.styles-module__ghostOutline___po-kO:active {
  cursor: grabbing;
}
.styles-module__ghostOutline___po-kO:hover {
  opacity: 0.7;
  box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.1), 0 4px 12px rgba(0, 0, 0, 0.08);
}
.styles-module__ghostOutline___po-kO.styles-module__selected___6yrp6 {
  opacity: 1;
  border-style: solid;
  border-width: 2px;
  border-color: #3c82f7;
  background: rgba(59, 130, 246, 0.08);
  box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.15), 0 2px 8px rgba(59, 130, 246, 0.15);
}
.styles-module__ghostOutline___po-kO.styles-module__exiting___YrM8F {
  opacity: 0;
  transform: scale(0.97);
  pointer-events: none;
  animation: none;
  transition: opacity 0.2s ease, transform 0.2s cubic-bezier(0.32, 0.72, 0, 1);
}

.styles-module__ghostBadge___tsQUK {
  position: absolute;
  bottom: calc(100% + 4px);
  left: -1px;
  font-size: 9px;
  font-weight: 600;
  color: rgba(59, 130, 246, 0.9);
  background: rgba(59, 130, 246, 0.08);
  border: 1px solid rgba(59, 130, 246, 0.2);
  padding: 1px 5px;
  border-radius: 3px;
  white-space: nowrap;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  letter-spacing: 0.02em;
  line-height: 1.2;
  animation: styles-module__badgeSlideIn___typJ7 0.2s ease both;
}

@keyframes styles-module__badgeSlideIn___typJ7 {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.styles-module__ghostBadgeExtra___6CVoD {
  display: inline;
  animation: styles-module__badgeExtraIn___i4W8F 0.2s ease both;
}

@keyframes styles-module__badgeExtraIn___i4W8F {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
.styles-module__originalOutline___Y6DD1 {
  position: fixed;
  border: 1.5px dashed rgba(150, 150, 150, 0.3);
  border-radius: 4px;
  background: transparent;
  pointer-events: none;
  -webkit-user-select: none;
  user-select: none;
  animation: styles-module__sectionEnter___-8BXT 0.2s ease;
}

.styles-module__originalLabel___HqI9g {
  position: absolute;
  top: 4px;
  left: 4px;
  font-size: 9px;
  font-weight: 500;
  color: rgba(150, 150, 150, 0.5);
  padding: 1px 6px;
  border-radius: 3px;
  white-space: nowrap;
  pointer-events: none;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: rgba(150, 150, 150, 0.08);
}

.styles-module__connectorSvg___Lovld {
  position: fixed;
  inset: 0;
  width: 100vw;
  height: 100vh;
  pointer-events: none;
  z-index: 99996;
}

.styles-module__connectorLine___XeWh- {
  transition: opacity 0.2s ease;
  animation: styles-module__connectorDraw___8sK5I 0.3s ease both;
}

.styles-module__connectorDot___yvf7C {
  transform-box: fill-box;
  transform-origin: center;
  animation: styles-module__connectorDotIn___NwTUq 0.25s cubic-bezier(0.34, 1.56, 0.64, 1) 0.15s both;
}

@keyframes styles-module__connectorDraw___8sK5I {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes styles-module__connectorDotIn___NwTUq {
  from {
    transform: scale(0);
    opacity: 0;
  }
  to {
    transform: scale(1);
    opacity: 1;
  }
}
.styles-module__connectorExiting___2lLOs {
  animation: styles-module__connectorOut___5QoPl 0.2s ease forwards;
}
.styles-module__connectorExiting___2lLOs .styles-module__connectorDot___yvf7C {
  animation: styles-module__connectorDotOut___FEq7e 0.2s ease forwards;
}

@keyframes styles-module__connectorOut___5QoPl {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
@keyframes styles-module__connectorDotOut___FEq7e {
  from {
    transform: scale(1);
    opacity: 1;
  }
  to {
    transform: scale(0);
    opacity: 0;
  }
}
@keyframes styles-module__placementEnter___TdRhf {
  from {
    opacity: 0;
    transform: scale(0.85);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes styles-module__sectionEnter___-8BXT {
  from {
    opacity: 0;
    transform: scale(0.96);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes styles-module__highlightFadeIn___Lg7KY {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes styles-module__overlayFadeIn___aECVy {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes styles-module__ghostEnter___EC3Mb {
  from {
    opacity: 0;
    transform: scale(0.96);
  }
  to {
    opacity: 0.6;
    transform: scale(1);
  }
}
.styles-module__canvasToggle___-QqSy:focus-visible,
.styles-module__paletteItem___6TlnA:focus-visible {
  outline: 2px solid var(--agentation-color-accent);
  outline-offset: -2px;
}`,Z={overlay:"styles-module__overlay___aWh-q",rearrangeOverlay:"styles-module__rearrangeOverlay___-3R3t",overlayExiting:"styles-module__overlayExiting___iEmYr",overlayFadeIn:"styles-module__overlayFadeIn___aECVy",light:"styles-module__light___ORIft",wireframe:"styles-module__wireframe___itvQU",placing:"styles-module__placing___45yD8",passthrough:"styles-module__passthrough___xaFeE",blankCanvas:"styles-module__blankCanvas___t2Eue",visible:"styles-module__visible___OKKqX",gridActive:"styles-module__gridActive___OZ-cf",paletteHeader:"styles-module__paletteHeader___-Q5gQ",paletteHeaderTitle:"styles-module__paletteHeaderTitle___oHqZC",paletteHeaderDesc:"styles-module__paletteHeaderDesc___6i74T",wireframePurposeWrap:"styles-module__wireframePurposeWrap___To-tS",collapsed:"styles-module__collapsed___Ms9vS",wireframePurposeInner:"styles-module__wireframePurposeInner___Lrahs",wireframePurposeInput:"styles-module__wireframePurposeInput___7EtBN",canvasToggle:"styles-module__canvasToggle___-QqSy",active:"styles-module__active___hosp7",canvasToggleIcon:"styles-module__canvasToggleIcon___7pJ82",canvasToggleLabel:"styles-module__canvasToggleLabel___OanpY",placement:"styles-module__placement___zcxv8",placementEnter:"styles-module__placementEnter___TdRhf",selected:"styles-module__selected___6yrp6",dragging:"styles-module__dragging___le6KZ",exiting:"styles-module__exiting___YrM8F",placementContent:"styles-module__placementContent___f64A4",placementLabel:"styles-module__placementLabel___0KvWl",placementAnnotation:"styles-module__placementAnnotation___78pTr",annotationVisible:"styles-module__annotationVisible___mrUyA",sectionAnnotation:"styles-module__sectionAnnotation___aUIs0",handle:"styles-module__handle___Ikbxm",sectionOutline:"styles-module__sectionOutline___s0hy-",ghostOutline:"styles-module__ghostOutline___po-kO",handleNw:"styles-module__handleNw___4TMIj",handleNe:"styles-module__handleNe___mnsTh",handleSe:"styles-module__handleSe___oSFnk",handleSw:"styles-module__handleSw___pi--Z",handleN:"styles-module__handleN___aBA-Q",handleE:"styles-module__handleE___0hM5u",handleS:"styles-module__handleS___JjDRv",handleW:"styles-module__handleW___ERWGQ",edgeHandle:"styles-module__edgeHandle___XxXdT",edgeN:"styles-module__edgeN___-JJDj",edgeS:"styles-module__edgeS___66lMX",edgeE:"styles-module__edgeE___1bGDa",edgeW:"styles-module__edgeW___lHQNo",deleteButton:"styles-module__deleteButton___LkGCb",drawBox:"styles-module__drawBox___BrVAa",selectBox:"styles-module__selectBox___Iu8kB",sizeIndicator:"styles-module__sizeIndicator___7zJ4y",guideLine:"styles-module__guideLine___DUQY2",dragPreview:"styles-module__dragPreview___onPbU",dragPreviewWireframe:"styles-module__dragPreviewWireframe___jsg0G",palette:"styles-module__palette___C7iSH",paletteItem:"styles-module__paletteItem___6TlnA",paletteItemLabel:"styles-module__paletteItemLabel___6ncO4",paletteSectionTitle:"styles-module__paletteSectionTitle___PqnjX",paletteFooter:"styles-module__paletteFooter___QYnAG",paletteSection:"styles-module__paletteSection___V8DEA",paletteItemIcon:"styles-module__paletteItemIcon___0NPQK",placeScroll:"styles-module__placeScroll___7sClM",fadeTop:"styles-module__fadeTop___KT9tF",fadeBottom:"styles-module__fadeBottom___x3ShT",paletteFooterWrap:"styles-module__paletteFooterWrap___71-fI",footerHidden:"styles-module__footerHidden___fJUik",paletteFooterInnerContent:"styles-module__paletteFooterInnerContent___VC26h",paletteFooterInner:"styles-module__paletteFooterInner___dfylY",paletteFooterCount:"styles-module__paletteFooterCount___D3Fia",paletteFooterClear:"styles-module__paletteFooterClear___ybBoa",paletteFooterActions:"styles-module__paletteFooterActions___fLzv8",rollingWrap:"styles-module__rollingWrap___S75jM",rollingNum:"styles-module__rollingNum___1RKDx",exitUp:"styles-module__exitUp___AFDRW",numExitUp:"styles-module__numExitUp___FRQqx",enterUp:"styles-module__enterUp___CPlXb",numEnterUp:"styles-module__numEnterUp___2Yd-w",exitDown:"styles-module__exitDown___-1yAy",numExitDown:"styles-module__numExitDown___xm5by",enterDown:"styles-module__enterDown___DDuFR",numEnterDown:"styles-module__numEnterDown___hpxBk",hoverHighlight:"styles-module__hoverHighlight___8eT-v",highlightFadeIn:"styles-module__highlightFadeIn___Lg7KY",sectionEnter:"styles-module__sectionEnter___-8BXT",settled:"styles-module__settled___b5U5o",sectionLabel:"styles-module__sectionLabel___F80HQ",movedBadge:"styles-module__movedBadge___s8z-q",sectionDimensions:"styles-module__sectionDimensions___RcJSL",badgeVisible:"styles-module__badgeVisible___npbdS",resizedBadge:"styles-module__resizedBadge___u51V8",wireframeNotice:"styles-module__wireframeNotice___4GJyB",wireframeOpacityRow:"styles-module__wireframeOpacityRow___CJXzi",wireframeOpacityLabel:"styles-module__wireframeOpacityLabel___afkfT",wireframeOpacitySlider:"styles-module__wireframeOpacitySlider___YcoEs",wireframeNoticeTitleRow:"styles-module__wireframeNoticeTitleRow___PJqyG",wireframeNoticeTitle:"styles-module__wireframeNoticeTitle___okr08",wireframeNoticeDivider:"styles-module__wireframeNoticeDivider___PNKQ6",wireframeStartOver:"styles-module__wireframeStartOver___YFk-I",ghostEnter:"styles-module__ghostEnter___EC3Mb",ghostBadge:"styles-module__ghostBadge___tsQUK",badgeSlideIn:"styles-module__badgeSlideIn___typJ7",ghostBadgeExtra:"styles-module__ghostBadgeExtra___6CVoD",badgeExtraIn:"styles-module__badgeExtraIn___i4W8F",originalOutline:"styles-module__originalOutline___Y6DD1",originalLabel:"styles-module__originalLabel___HqI9g",connectorSvg:"styles-module__connectorSvg___Lovld",connectorLine:"styles-module__connectorLine___XeWh-",connectorDraw:"styles-module__connectorDraw___8sK5I",connectorDot:"styles-module__connectorDot___yvf7C",connectorDotIn:"styles-module__connectorDotIn___NwTUq",connectorExiting:"styles-module__connectorExiting___2lLOs",connectorOut:"styles-module__connectorOut___5QoPl",connectorDotOut:"styles-module__connectorDotOut___FEq7e"},un=Tn(),Vs=24,Vc=5;function zh(s,i,r,u,d){let _=1/0,g=1/0,w=s.x,y=s.x+s.width,E=s.x+s.width/2,M=s.y,S=s.y+s.height,O=s.y+s.height/2,W=!u,H=W?[w,y,E]:[...u.left?[w]:[],...u.right?[y]:[]],te=W?[M,S,O]:[...u.top?[M]:[],...u.bottom?[S]:[]],B=[];for(let Re of i)r.has(Re.id)||B.push(Re);d&&B.push(...d);for(let Re of B){let me=Re.x,De=Re.x+Re.width,xe=Re.x+Re.width/2,ye=Re.y,Le=Re.y+Re.height,rn=Re.y+Re.height/2;for(let _t of H)for(let St of[me,De,xe]){let ft=St-_t;Math.abs(ft)<Vc&&Math.abs(ft)<Math.abs(_)&&(_=ft)}for(let _t of te)for(let St of[ye,Le,rn]){let ft=St-_t;Math.abs(ft)<Vc&&Math.abs(ft)<Math.abs(g)&&(g=ft)}}let K=Math.abs(_)<Vc?_:0,Se=Math.abs(g)<Vc?g:0,G=[],P=new Set,tt=w+K,ut=y+K,se=E+K,Ue=M+Se,oe=S+Se,ze=O+Se;for(let Re of B){let me=Re.x,De=Re.x+Re.width,xe=Re.x+Re.width/2,ye=Re.y,Le=Re.y+Re.height,rn=Re.y+Re.height/2;for(let _t of[me,xe,De])for(let St of[tt,se,ut])if(Math.abs(St-_t)<.5){let ft=`x:${Math.round(_t)}`;P.has(ft)||(P.add(ft),G.push({axis:"x",pos:_t}))}for(let _t of[ye,rn,Le])for(let St of[Ue,ze,oe])if(Math.abs(St-_t)<.5){let ft=`y:${Math.round(_t)}`;P.has(ft)||(P.add(ft),G.push({axis:"y",pos:_t}))}}return{dx:K,dy:Se,guides:G}}function Lh(){return`dp-${Date.now()}-${Math.random().toString(36).slice(2,7)}`}function lw({placements:s,onChange:i,activeComponent:r,onActiveComponentChange:u,isDarkMode:d,exiting:_,onInteractionChange:g,className:w,passthrough:y,extraSnapRects:E,onSelectionChange:M,deselectSignal:S,onDragMove:O,onDragEnd:W,clearingPlacements:H,wireframe:te}){let[B,K]=(0,Gt.useState)(new Set),[Se,G]=(0,Gt.useState)(null),[P,tt]=(0,Gt.useState)(null),[ut,se]=(0,Gt.useState)(null),[Ue,oe]=(0,Gt.useState)([]),[ze,Re]=(0,Gt.useState)(null),[me,De]=(0,Gt.useState)(!1),xe=(0,Gt.useRef)(!1),[ye,Le]=(0,Gt.useState)(new Set),rn=(0,Gt.useRef)(new Map),_t=(0,Gt.useRef)(null),St=(0,Gt.useRef)(null),ft=(0,Gt.useRef)(s);ft.current=s;let Vt=(0,Gt.useRef)(M);Vt.current=M;let qn=(0,Gt.useRef)(O);qn.current=O;let go=(0,Gt.useRef)(W);go.current=W;let nt=(0,Gt.useRef)(S);(0,Gt.useEffect)(()=>{S!==nt.current&&(nt.current=S,K(new Set))},[S]),(0,Gt.useEffect)(()=>{H?.length&&(K(ue=>new Set([...ue].filter(Oe=>!H.some(Ke=>Ke.id===Oe)))),St.current=null)},[H]),(0,Gt.useEffect)(()=>{let ue=Oe=>{let Ke=Oe.composedPath()[0]||Oe.target;if(!(Ke.tagName==="INPUT"||Ke.tagName==="TEXTAREA"||Ke.isContentEditable)){if((Oe.key==="Backspace"||Oe.key==="\u0423\u0434\u0430\u043B\u0438\u0442\u044C")&&B.size>0){Oe.preventDefault();let Xe=new Set(B);Le(Xe),K(new Set),_e(()=>{i(ft.current.filter(kt=>!Xe.has(kt.id))),Le(new Set)},180);return}if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(Oe.key)&&B.size>0){Oe.preventDefault();let Xe=Oe.shiftKey?20:1,kt=Oe.key==="ArrowLeft"?-Xe:Oe.key==="ArrowRight"?Xe:0,mt=Oe.key==="ArrowUp"?-Xe:Oe.key==="ArrowDown"?Xe:0;i(s.map(vt=>B.has(vt.id)?{...vt,x:Math.max(0,vt.x+kt),y:Math.max(0,vt.y+mt)}:vt));return}if(Oe.key==="Escape"){r?u(null):B.size>0&&K(new Set);return}}};return document.addEventListener("keydown",ue),()=>document.removeEventListener("keydown",ue)},[B,r,s,i,u]);let jo=(0,Gt.useCallback)(ue=>{if(ue.button!==0||y||ue.target.closest(`.${Z.placement}`))return;ue.preventDefault(),ue.stopPropagation();let Ke=window.scrollY,We=ue.clientX,Xe=ue.clientY;if(r){St.current="place",g?.(!0);let kt=!1,mt=We,vt=Xe,bt=D=>{mt=D.clientX,vt=D.clientY;let Q=Math.abs(mt-We),ee=Math.abs(vt-Xe);if((Q>5||ee>5)&&(kt=!0),kt){let le=Math.min(We,mt),ge=Math.min(Xe,vt),je=Math.abs(mt-We),ie=Math.abs(vt-Xe);G({x:le,y:ge,w:je,h:ie}),se({x:D.clientX+12,y:D.clientY+12,text:`${Math.round(je)} \xD7 ${Math.round(ie)}`})}},ae=D=>{window.removeEventListener("mousemove",bt),window.removeEventListener("mouseup",ae),G(null),se(null),St.current=null,g?.(!1);let Q=pe[r],ee,le,ge,je;kt?(ee=Math.min(We,mt),le=Math.min(Xe,vt)+Ke,ge=Math.max(Vs,Math.abs(mt-We)),je=Math.max(Vs,Math.abs(vt-Xe))):(ge=Q.width,je=Q.height,ee=We-ge/2,le=Xe+Ke-je/2),ee=Math.max(0,ee),le=Math.max(0,le);let ie={id:Lh(),type:r,x:ee,y:le,width:ge,height:je,scrollY:Ke,timestamp:Date.now()},Ee=[...s,ie];i(Ee),K(new Set([ie.id])),u(null)};window.addEventListener("mousemove",bt),window.addEventListener("mouseup",ae)}else{ue.shiftKey||K(new Set),St.current="select";let kt=!1,mt=bt=>{let ae=Math.abs(bt.clientX-We),D=Math.abs(bt.clientY-Xe);if((ae>4||D>4)&&(kt=!0),kt){let Q=Math.min(We,bt.clientX),ee=Math.min(Xe,bt.clientY);tt({x:Q,y:ee,w:Math.abs(bt.clientX-We),h:Math.abs(bt.clientY-Xe)})}},vt=bt=>{if(window.removeEventListener("mousemove",mt),window.removeEventListener("mouseup",vt),St.current=null,kt){let ae=Math.min(We,bt.clientX),D=Math.min(Xe,bt.clientY)+Ke,Q=Math.abs(bt.clientX-We),ee=Math.abs(bt.clientY-Xe),le=new Set(ue.shiftKey?B:new Set);for(let ge of s){let je=ge.y-Ke;ge.x+ge.width>ae&&ge.x<ae+Q&&ge.y+ge.height>D&&ge.y<D+ee&&le.add(ge.id)}K(le)}tt(null)};window.addEventListener("mousemove",mt),window.addEventListener("mouseup",vt)}},[r,y,s,i,B]),rs=(0,Gt.useCallback)((ue,Oe)=>{if(ue.button!==0)return;let Ke=ue.target;if(Ke.closest(`.${Z.handle}`)||Ke.closest(`.${Z.deleteButton}`))return;ue.preventDefault(),ue.stopPropagation();let We;ue.shiftKey?(We=new Set(B),We.has(Oe)?We.delete(Oe):We.add(Oe)):B.has(Oe)?We=new Set(B):We=new Set([Oe]),K(We),(We.size!==B.size||[...We].some(Ee=>!B.has(Ee)))&&Vt.current?.(We,ue.shiftKey);let kt=window.scrollY,mt=ue.clientX,vt=ue.clientY,bt=new Map;for(let Ee of s)We.has(Ee.id)&&bt.set(Ee.id,{x:Ee.x,y:Ee.y});St.current="move",g?.(!0);let ae=!1,D=!1,Q=s,ee=0,le=0,ge=new Map;for(let Ee of s)bt.has(Ee.id)&&ge.set(Ee.id,{w:Ee.width,h:Ee.height});let je=Ee=>{let Qe=Ee.clientX-mt,ot=Ee.clientY-vt;if((Math.abs(Qe)>2||Math.abs(ot)>2)&&(ae=!0),!ae)return;if(Ee.altKey&&!D){D=!0;let Wt=[];for(let Yt of s)bt.has(Yt.id)&&Wt.push({...Yt,id:Lh(),timestamp:Date.now()});Q=[...s,...Wt]}let Ot=1/0,Ht=1/0,Ct=-1/0,ht=-1/0;for(let[Wt,Yt]of bt){let ke=ge.get(Wt);ke&&(Ot=Math.min(Ot,Yt.x+Qe),Ht=Math.min(Ht,Yt.y+ot),Ct=Math.max(Ct,Yt.x+Qe+ke.w),ht=Math.max(ht,Yt.y+ot+ke.h))}let Je={x:Ot,y:Ht,width:Ct-Ot,height:ht-Ht},{dx:Pt,dy:Zt,guides:Ut}=zh(Je,Q,new Set(bt.keys()),void 0,E);oe(Ut);let it=Qe+Pt,jt=ot+Zt;ee=it,le=jt,i(Q.map(Wt=>{let Yt=bt.get(Wt.id);return Yt?{...Wt,x:Math.max(0,Yt.x+it),y:Math.max(0,Yt.y+jt)}:Wt})),qn.current?.(it,jt)},ie=()=>{window.removeEventListener("mousemove",je),window.removeEventListener("mouseup",ie),St.current=null,g?.(!1),oe([]),go.current?.(ee,le,ae)};window.addEventListener("mousemove",je),window.addEventListener("mouseup",ie)},[B,s,i,g]),Fs=(0,Gt.useCallback)((ue,Oe,Ke)=>{ue.preventDefault(),ue.stopPropagation();let We=s.find(le=>le.id===Oe);if(!We)return;K(new Set([Oe])),St.current="resize",g?.(!0);let Xe=ue.clientX,kt=ue.clientY,mt=We.width,vt=We.height,bt=We.x,ae=We.y,D={left:Ke.includes("w"),right:Ke.includes("e"),top:Ke.includes("n"),bottom:Ke.includes("s")},Q=le=>{let ge=le.clientX-Xe,je=le.clientY-kt,ie=mt,Ee=vt,Qe=bt,ot=ae;Ke.includes("e")&&(ie=Math.max(Vs,mt+ge)),Ke.includes("w")&&(ie=Math.max(Vs,mt-ge),Qe=bt+mt-ie),Ke.includes("s")&&(Ee=Math.max(Vs,vt+je)),Ke.includes("n")&&(Ee=Math.max(Vs,vt-je),ot=ae+vt-Ee);let Ot={x:Qe,y:ot,width:ie,height:Ee},{dx:Ht,dy:Ct,guides:ht}=zh(Ot,ft.current,new Set([Oe]),D,E);oe(ht),Ht!==0&&(D.right?ie+=Ht:D.left&&(Qe+=Ht,ie-=Ht)),Ct!==0&&(D.bottom?Ee+=Ct:D.top&&(ot+=Ct,Ee-=Ct)),i(ft.current.map(Je=>Je.id===Oe?{...Je,x:Qe,y:ot,width:ie,height:Ee}:Je)),se({x:le.clientX+12,y:le.clientY+12,text:`${Math.round(ie)} \xD7 ${Math.round(Ee)}`})},ee=()=>{window.removeEventListener("mousemove",Q),window.removeEventListener("mouseup",ee),se(null),St.current=null,g?.(!1),oe([])};window.addEventListener("mousemove",Q),window.addEventListener("mouseup",ee)},[s,i,g]),pa=(0,Gt.useCallback)(ue=>{St.current=null,Le(Oe=>{let Ke=new Set(Oe);return Ke.add(ue),Ke}),K(Oe=>{let Ke=new Set(Oe);return Ke.delete(ue),Ke}),_e(()=>{i(ft.current.filter(Oe=>Oe.id!==ue)),Le(Oe=>{let Ke=new Set(Oe);return Ke.delete(ue),Ke})},180)},[i]),Ul=new Set(["text","hero","button","badge","cta","toast","modal","card","navigation","tabs","input","search","breadcrumb","pricing","testimonial","alert","banner","tag","notification","stat","productCard"]),$l={hero:"Headline text",button:"Button label",badge:"Badge label",cta:"Call to action text",toast:"Notification message",modal:"Dialog title",card:"Card title",navigation:"Brand / nav items",tabs:"Tab labels",input:"Placeholder text",search:"Search placeholder",pricing:"Plan name or price",testimonial:"Quote text",alert:"Alert message",banner:"Banner text",tag:"Tag label",notification:"Notification message",stat:"Metric value",productCard:"Product name"},Il=(0,Gt.useCallback)(ue=>{let Oe=s.find(Ke=>Ke.id===ue);Oe&&(xe.current=!!Oe.text,Re(ue),De(!1))},[s]),vn=(0,Gt.useCallback)(()=>{ze&&(De(!0),_e(()=>{Re(null),De(!1)},150))},[ze]);(0,Gt.useEffect)(()=>{_&&ze&&vn()},[_]);let ml=(0,Gt.useCallback)(ue=>{ze&&(i(s.map(Oe=>Oe.id===ze?{...Oe,text:ue.trim()||void 0}:Oe)),vn())},[ze,s,i,vn]),hl=typeof window<"u"?window.scrollY:0,Zs=["nw","ne","se","sw"],Uo=te?"#f97316":"#3c82f7",Yl=[{dir:"n",cls:Z.edgeN,arrow:(0,un.jsx)("svg",{width:"8",height:"6",viewBox:"0 0 8 6",fill:"none",children:(0,un.jsx)("path",{d:"M4 0.5L1 4.5h6z",fill:Uo})})},{dir:"e",cls:Z.edgeE,arrow:(0,un.jsx)("svg",{width:"6",height:"8",viewBox:"0 0 6 8",fill:"none",children:(0,un.jsx)("path",{d:"M5.5 4L1.5 1v6z",fill:Uo})})},{dir:"s",cls:Z.edgeS,arrow:(0,un.jsx)("svg",{width:"8",height:"6",viewBox:"0 0 8 6",fill:"none",children:(0,un.jsx)("path",{d:"M4 5.5L1 1.5h6z",fill:Uo})})},{dir:"w",cls:Z.edgeW,arrow:(0,un.jsx)("svg",{width:"6",height:"8",viewBox:"0 0 6 8",fill:"none",children:(0,un.jsx)("path",{d:"M0.5 4L4.5 1v6z",fill:Uo})})}];return(0,un.jsxs)(un.Fragment,{children:[(0,un.jsx)("div",{ref:_t,className:`${Z.overlay} ${d?"":Z.light} ${r?Z.placing:""} ${y?Z.passthrough:""} ${_?Z.overlayExiting:""} ${te?Z.wireframe:""}${w?` ${w}`:""}`,"data-feedback-toolbar":!0,onMouseDown:jo,children:s.map(ue=>{let Oe=B.has(ue.id),Ke=el[ue.type]?.label||ue.type,We=ue.y-hl;return(0,un.jsxs)("div",{"data-design-placement":ue.id,className:`${Z.placement} ${Oe?Z.selected:""} ${ye.has(ue.id)||H?.includes(ue)?Z.exiting:""}`,style:{left:ue.x,top:We,width:ue.width,height:ue.height,position:"fixed"},onMouseDown:Xe=>rs(Xe,ue.id),onDoubleClick:()=>Il(ue.id),children:[(0,un.jsx)("span",{className:Z.placementLabel,children:Ke}),(0,un.jsx)("span",{className:`${Z.placementAnnotation} ${ue.text?Z.annotationVisible:""}`,children:(ue.text&&rn.current.set(ue.id,ue.text),ue.text||rn.current.get(ue.id)||"")}),(0,un.jsx)("div",{className:Z.placementContent,children:(0,un.jsx)(nw,{type:ue.type,width:ue.width,height:ue.height,text:ue.text})}),(0,un.jsx)("div",{className:Z.deleteButton,onMouseDown:Xe=>Xe.stopPropagation(),onClick:()=>pa(ue.id),children:"\u2715"}),Zs.map(Xe=>(0,un.jsx)("div",{className:`${Z.handle} ${Z[`handle${Xe.charAt(0).toUpperCase()}${Xe.slice(1)}`]}`,onMouseDown:kt=>Fs(kt,ue.id,Xe)},Xe)),Yl.map(({dir:Xe,cls:kt,arrow:mt})=>(0,un.jsx)("div",{className:`${Z.edgeHandle} ${kt}`,onMouseDown:vt=>Fs(vt,ue.id,Xe),children:mt},Xe))]},ue.id)})}),ze&&(()=>{let ue=s.find(ae=>ae.id===ze);if(!ue)return null;let Oe=ue.y-hl,Ke=ue.x+ue.width/2,We=Oe-8,Xe=Oe+ue.height+8,kt=We>200,mt=Xe<window.innerHeight-100,vt=Math.max(160,Math.min(window.innerWidth-160,Ke)),bt;return kt?bt={left:vt,bottom:window.innerHeight-We}:mt?bt={left:vt,top:Xe}:bt={left:vt,top:Math.max(80,window.innerHeight/2-80)},(0,un.jsx)(Qc,{element:el[ue.type]?.label||ue.type,placeholder:$l[ue.type]||"Label or content text",initialValue:ue.text??"",submitLabel:xe.current?"\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C":"Set",onSubmit:ml,onCancel:vn,onDelete:xe.current?()=>{ml("")}:void 0,isExiting:me,lightMode:!d,style:bt})})(),Se&&(0,un.jsx)("div",{className:Z.drawBox,style:{left:Se.x,top:Se.y,width:Se.w,height:Se.h},"data-feedback-toolbar":!0}),P&&(0,un.jsx)("div",{className:Z.selectBox,style:{left:P.x,top:P.y,width:P.w,height:P.h},"data-feedback-toolbar":!0}),ut&&(0,un.jsx)("div",{className:Z.sizeIndicator,style:{left:ut.x,top:ut.y},"data-feedback-toolbar":!0,children:ut.text}),Ue.map((ue,Oe)=>(0,un.jsx)("div",{className:Z.guideLine,style:ue.axis==="x"?{position:"fixed",left:ue.pos,top:0,width:1,bottom:0}:{position:"fixed",left:0,top:ue.pos-hl,right:0,height:1},"data-feedback-toolbar":!0},`${ue.axis}-${ue.pos}-${Oe}`))]})}var io=tn(),ur=tn();function Bh(s,{keepMounted:i=!1,onExited:r}={}){let[u,d]=(0,ur.useState)(i||s),_=(0,ur.useRef)(null),g=(0,ur.useRef)(r);return s&&!u&&d(!0),(0,ur.useLayoutEffect)(()=>{g.current=r},[r]),(0,ur.useLayoutEffect)(()=>{let w=_.current;if(!w||w.dataset.panelOpen==="true"===s)return;getComputedStyle(w).opacity,w.dataset.panelPresent="true",w.dataset.panelOpen=String(s);let y=!1,E=w.getAnimations?.()??[];return Promise.allSettled(E.map(M=>M.finished)).then(()=>{y||s||(delete w.dataset.panelPresent,i||d(!1),g.current?.())}),()=>{y=!0}},[s,u,i]),{ref:_,mounted:u}}var m=Tn();function aw(s){if(!s)return"";let i=s.scrollTop>2,r=s.scrollTop+s.clientHeight<s.scrollHeight-2;return`${i?Z.fadeTop:""} ${r?Z.fadeBottom:""}`}var b="currentColor",F="0.5";function sw({type:s}){switch(s){case"navigation":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"4",width:"18",height:"8",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"2.5",y:"7",width:"3",height:"1.5",rx:".5",fill:b,opacity:".4"}),(0,m.jsx)("rect",{x:"7",y:"7",width:"2.5",height:"1.5",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"11",y:"7",width:"2.5",height:"1.5",rx:".5",fill:b,opacity:".25"})]});case"header":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"2",width:"18",height:"12",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"3",y:"5.5",width:"8",height:"2",rx:".5",fill:b,opacity:".35"}),(0,m.jsx)("rect",{x:"3",y:"9",width:"12",height:"1",rx:".5",fill:b,opacity:".15"})]});case"hero":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"1",width:"18",height:"14",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"5",y:"5",width:"10",height:"1.5",rx:".5",fill:b,opacity:".35"}),(0,m.jsx)("rect",{x:"7",y:"8",width:"6",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"7.5",y:"10.5",width:"5",height:"2.5",rx:"1",stroke:b,strokeWidth:F})]});case"section":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"1",width:"18",height:"14",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"3",y:"4",width:"6",height:"1",rx:".5",fill:b,opacity:".3"}),(0,m.jsx)("rect",{x:"3",y:"6.5",width:"14",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"3",y:"9",width:"10",height:"1",rx:".5",fill:b,opacity:".15"})]});case"sidebar":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"1",width:"7",height:"14",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"2.5",y:"4",width:"4",height:"1",rx:".5",fill:b,opacity:".3"}),(0,m.jsx)("rect",{x:"2.5",y:"6.5",width:"3.5",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"2.5",y:"9",width:"4",height:"1",rx:".5",fill:b,opacity:".15"})]});case"footer":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"7",width:"18",height:"8",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"3",y:"9.5",width:"4",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"9",y:"9.5",width:"4",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"15",y:"9.5",width:"3",height:"1",rx:".5",fill:b,opacity:".2"})]});case"modal":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"2",width:"14",height:"12",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"5",y:"4.5",width:"7",height:"1",rx:".5",fill:b,opacity:".3"}),(0,m.jsx)("rect",{x:"5",y:"7",width:"10",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"11",y:"11",width:"5",height:"2",rx:".75",stroke:b,strokeWidth:F})]});case"divider":return(0,m.jsx)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:(0,m.jsx)("line",{x1:"2",y1:"8",x2:"18",y2:"8",stroke:b,strokeWidth:"0.5",opacity:".3"})});case"card":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"1",width:"16",height:"14",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"2",y:"1",width:"16",height:"5.5",rx:"1",fill:b,opacity:".04"}),(0,m.jsx)("rect",{x:"4",y:"8.5",width:"8",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"4",y:"11",width:"11",height:"1",rx:".5",fill:b,opacity:".12"})]});case"text":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"4",width:"14",height:"1.5",rx:".5",fill:b,opacity:".3"}),(0,m.jsx)("rect",{x:"2",y:"7",width:"11",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"2",y:"9.5",width:"13",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"2",y:"12",width:"8",height:"1",rx:".5",fill:b,opacity:".12"})]});case"image":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"2",width:"16",height:"12",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("line",{x1:"2",y1:"2",x2:"18",y2:"14",stroke:b,strokeWidth:".3",opacity:".25"}),(0,m.jsx)("line",{x1:"18",y1:"2",x2:"2",y2:"14",stroke:b,strokeWidth:".3",opacity:".25"})]});case"video":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"2",width:"16",height:"12",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("path",{d:"M8.5 5.5v5l4.5-2.5z",stroke:b,strokeWidth:F,fill:b,opacity:".15"})]});case"table":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"2",width:"18",height:"12",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("line",{x1:"1",y1:"5.5",x2:"19",y2:"5.5",stroke:b,strokeWidth:".3",opacity:".25"}),(0,m.jsx)("line",{x1:"1",y1:"9",x2:"19",y2:"9",stroke:b,strokeWidth:".3",opacity:".25"}),(0,m.jsx)("line",{x1:"7",y1:"2",x2:"7",y2:"14",stroke:b,strokeWidth:".3",opacity:".25"}),(0,m.jsx)("line",{x1:"13",y1:"2",x2:"13",y2:"14",stroke:b,strokeWidth:".3",opacity:".25"})]});case"grid":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1.5",y:"2",width:"7",height:"5.5",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"11.5",y:"2",width:"7",height:"5.5",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"1.5",y:"9.5",width:"7",height:"5.5",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"11.5",y:"9.5",width:"7",height:"5.5",rx:"1",stroke:b,strokeWidth:F})]});case"list":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("circle",{cx:"3.5",cy:"4.5",r:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6.5",y:"4",width:"10",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"3.5",cy:"8",r:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6.5",y:"7.5",width:"8",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"3.5",cy:"11.5",r:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6.5",y:"11",width:"11",height:"1",rx:".5",fill:b,opacity:".2"})]});case"chart":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"9",width:"2.5",height:"4",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("rect",{x:"7",y:"6",width:"2.5",height:"7",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"11",y:"3",width:"2.5",height:"10",rx:".5",fill:b,opacity:".3"}),(0,m.jsx)("rect",{x:"15",y:"5",width:"2.5",height:"8",rx:".5",fill:b,opacity:".2"})]});case"accordion":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1.5",y:"2",width:"17",height:"4",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"3",y:"3.5",width:"6",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"1.5",y:"7.5",width:"17",height:"3",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"1.5",y:"12",width:"17",height:"3",rx:"1",stroke:b,strokeWidth:F})]});case"carousel":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"2",width:"14",height:"10",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("path",{d:"M1.5 7L3 8.5 1.5 10",stroke:b,strokeWidth:F,opacity:".35"}),(0,m.jsx)("path",{d:"M18.5 7L17 8.5 18.5 10",stroke:b,strokeWidth:F,opacity:".35"}),(0,m.jsx)("circle",{cx:"8.5",cy:"14",r:".6",fill:b,opacity:".35"}),(0,m.jsx)("circle",{cx:"10",cy:"14",r:".6",fill:b,opacity:".15"}),(0,m.jsx)("circle",{cx:"11.5",cy:"14",r:".6",fill:b,opacity:".15"})]});case"button":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"5",width:"14",height:"6",rx:"2",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6.5",y:"7.5",width:"7",height:"1",rx:".5",fill:b,opacity:".25"})]});case"input":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"4",width:"5.5",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"2",y:"6.5",width:"16",height:"5.5",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"3.5",y:"8.5",width:"7",height:"1",rx:".5",fill:b,opacity:".12"})]});case"search":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"4.5",width:"16",height:"7",rx:"3.5",stroke:b,strokeWidth:F}),(0,m.jsx)("circle",{cx:"6",cy:"8",r:"2",stroke:b,strokeWidth:F,opacity:".3"}),(0,m.jsx)("line",{x1:"7.5",y1:"9.5",x2:"9",y2:"11",stroke:b,strokeWidth:F,opacity:".3"}),(0,m.jsx)("rect",{x:"9.5",y:"7.5",width:"6",height:"1",rx:".5",fill:b,opacity:".12"})]});case"form":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"1.5",width:"5.5",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"2",y:"3.5",width:"16",height:"3",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"2",y:"8",width:"7",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"2",y:"10",width:"16",height:"3",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"12",y:"14",width:"6",height:"2",rx:".75",stroke:b,strokeWidth:F})]});case"tabs":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"5",width:"18",height:"10",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"1",y:"2",width:"6",height:"3.5",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"2.5",y:"3.25",width:"3",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"7",y:"2",width:"6",height:"3.5",rx:".75",stroke:b,strokeWidth:F})]});case"dropdown":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"2",width:"16",height:"4",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"3.5",y:"3.5",width:"7",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("path",{d:"M15 3.5l1.5 1.5L18 3.5",stroke:b,strokeWidth:F,opacity:".3"}),(0,m.jsx)("rect",{x:"2",y:"7",width:"16",height:"7",rx:"1",stroke:b,strokeWidth:F,strokeDasharray:"2 1",opacity:".3"})]});case"toggle":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"4",y:"5",width:"12",height:"6",rx:"3",stroke:b,strokeWidth:F}),(0,m.jsx)("circle",{cx:"13",cy:"8",r:"2",fill:b,opacity:".3"})]});case"avatar":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("circle",{cx:"10",cy:"8",r:"6",stroke:b,strokeWidth:F}),(0,m.jsx)("circle",{cx:"10",cy:"6.5",r:"2",stroke:b,strokeWidth:F}),(0,m.jsx)("path",{d:"M6.5 13c0-2 1.5-3.5 3.5-3.5s3.5 1.5 3.5 3.5",stroke:b,strokeWidth:F})]});case"badge":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"5",width:"14",height:"6",rx:"3",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6",y:"7.5",width:"8",height:"1",rx:".5",fill:b,opacity:".25"})]});case"breadcrumb":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1.5",y:"7",width:"3.5",height:"1",rx:".5",fill:b,opacity:".3"}),(0,m.jsx)("path",{d:"M6.5 7l1 1-1 1",stroke:b,strokeWidth:F,opacity:".2"}),(0,m.jsx)("rect",{x:"9",y:"7",width:"3.5",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("path",{d:"M14 7l1 1-1 1",stroke:b,strokeWidth:F,opacity:".2"}),(0,m.jsx)("rect",{x:"16.5",y:"7",width:"2",height:"1",rx:".5",fill:b,opacity:".15"})]});case"pagination":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"5.5",width:"3.5",height:"5",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6.5",y:"5.5",width:"3.5",height:"5",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"11",y:"5.5",width:"3.5",height:"5",rx:"1",fill:b,opacity:".15",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"15.5",y:"5.5",width:"3.5",height:"5",rx:"1",stroke:b,strokeWidth:F})]});case"progress":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"7",width:"16",height:"2",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"2",y:"7",width:"10",height:"2",rx:"1",fill:b,opacity:".2"})]});case"toast":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"4",width:"16",height:"8",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("circle",{cx:"5",cy:"8",r:"1.5",stroke:b,strokeWidth:F,opacity:".3"}),(0,m.jsx)("rect",{x:"8",y:"6.5",width:"7",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"8",y:"9",width:"5",height:"1",rx:".5",fill:b,opacity:".12"})]});case"tooltip":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"3",width:"14",height:"7",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"5.5",y:"5.5",width:"9",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("path",{d:"M9 10l1 2.5 1-2.5",stroke:b,strokeWidth:F})]});case"pricing":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"1",width:"16",height:"14",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6",y:"3",width:"8",height:"1.5",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"7",y:"5.5",width:"6",height:"2",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"5",y:"9",width:"10",height:"1",rx:".5",fill:b,opacity:".1"}),(0,m.jsx)("rect",{x:"5",y:"11",width:"10",height:"1",rx:".5",fill:b,opacity:".1"}),(0,m.jsx)("rect",{x:"6",y:"13",width:"8",height:"1.5",rx:".5",fill:b,opacity:".2"})]});case"testimonial":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"1",width:"16",height:"14",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("text",{x:"4",y:"5.5",fontSize:"4",fill:b,opacity:".2",fontFamily:"serif",children:"\u201C"}),(0,m.jsx)("rect",{x:"4",y:"7",width:"12",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"4",y:"9",width:"9",height:"1",rx:".5",fill:b,opacity:".12"}),(0,m.jsx)("circle",{cx:"5.5",cy:"12.5",r:"1.5",stroke:b,strokeWidth:F,opacity:".25"}),(0,m.jsx)("rect",{x:"8",y:"12",width:"5",height:"1",rx:".5",fill:b,opacity:".15"})]});case"cta":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"2",width:"18",height:"12",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"5",y:"4.5",width:"10",height:"1.5",rx:".5",fill:b,opacity:".3"}),(0,m.jsx)("rect",{x:"6",y:"7.5",width:"8",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"7",y:"10",width:"6",height:"2.5",rx:"1",stroke:b,strokeWidth:F})]});case"alert":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"4",width:"16",height:"8",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("circle",{cx:"6",cy:"8",r:"2",stroke:b,strokeWidth:F,opacity:".3"}),(0,m.jsx)("line",{x1:"6",y1:"7",x2:"6",y2:"8.5",stroke:b,strokeWidth:"0.6",opacity:".5"}),(0,m.jsx)("circle",{cx:"6",cy:"9.3",r:".3",fill:b,opacity:".5"}),(0,m.jsx)("rect",{x:"9.5",y:"7",width:"6",height:"1",rx:".5",fill:b,opacity:".2"})]});case"banner":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"5",width:"18",height:"6",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"4",y:"7.5",width:"8",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"14",y:"7",width:"3.5",height:"2",rx:".75",stroke:b,strokeWidth:F})]});case"stat":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"2",width:"14",height:"12",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6",y:"4.5",width:"8",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"5",y:"7",width:"10",height:"2.5",rx:".5",fill:b,opacity:".3"}),(0,m.jsx)("rect",{x:"7",y:"11",width:"6",height:"1",rx:".5",fill:b,opacity:".12"})]});case"stepper":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("circle",{cx:"4",cy:"8",r:"2",fill:b,opacity:".2",stroke:b,strokeWidth:F}),(0,m.jsx)("line",{x1:"6",y1:"8",x2:"8",y2:"8",stroke:b,strokeWidth:".4",opacity:".3"}),(0,m.jsx)("circle",{cx:"10",cy:"8",r:"2",stroke:b,strokeWidth:F}),(0,m.jsx)("line",{x1:"12",y1:"8",x2:"14",y2:"8",stroke:b,strokeWidth:".4",opacity:".3"}),(0,m.jsx)("circle",{cx:"16",cy:"8",r:"2",stroke:b,strokeWidth:F})]});case"tag":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"5",width:"14",height:"6",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"5.5",y:"7.5",width:"6",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("line",{x1:"14",y1:"6.5",x2:"15.5",y2:"9.5",stroke:b,strokeWidth:F,opacity:".2"}),(0,m.jsx)("line",{x1:"15.5",y1:"6.5",x2:"14",y2:"9.5",stroke:b,strokeWidth:F,opacity:".2"})]});case"rating":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("path",{d:"M4 5.5l1 2 2.2.3-1.6 1.5.4 2.2L4 10.3l-2 1.2.4-2.2L.8 7.8 3 7.5z",fill:b,opacity:".25"}),(0,m.jsx)("path",{d:"M10 5.5l1 2 2.2.3-1.6 1.5.4 2.2L10 10.3l-2 1.2.4-2.2L6.8 7.8 9 7.5z",fill:b,opacity:".25"}),(0,m.jsx)("path",{d:"M16 5.5l1 2 2.2.3-1.6 1.5.4 2.2L16 10.3l-2 1.2.4-2.2-1.6-1.5 2.2-.3z",stroke:b,strokeWidth:F,opacity:".25"})]});case"map":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"2",width:"16",height:"12",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("line",{x1:"2",y1:"6",x2:"18",y2:"10",stroke:b,strokeWidth:".3",opacity:".15"}),(0,m.jsx)("line",{x1:"7",y1:"2",x2:"11",y2:"14",stroke:b,strokeWidth:".3",opacity:".15"}),(0,m.jsx)("path",{d:"M10 5c-1.7 0-3 1.3-3 3 0 2.5 3 5 3 5s3-2.5 3-5c0-1.7-1.3-3-3-3z",fill:b,opacity:".15",stroke:b,strokeWidth:F})]});case"timeline":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("line",{x1:"5",y1:"2",x2:"5",y2:"14",stroke:b,strokeWidth:".4",opacity:".25"}),(0,m.jsx)("circle",{cx:"5",cy:"4",r:"1.5",fill:b,opacity:".2",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"8",y:"3",width:"8",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("circle",{cx:"5",cy:"8.5",r:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"8",y:"7.5",width:"6",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("circle",{cx:"5",cy:"13",r:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"8",y:"12",width:"7",height:"1",rx:".5",fill:b,opacity:".15"})]});case"fileUpload":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"2",width:"14",height:"12",rx:"1.5",stroke:b,strokeWidth:F,strokeDasharray:"2 1"}),(0,m.jsx)("path",{d:"M10 10V5.5m0 0L7.5 8m2.5-2.5L12.5 8",stroke:b,strokeWidth:F,opacity:".3"}),(0,m.jsx)("rect",{x:"7",y:"11.5",width:"6",height:"1",rx:".5",fill:b,opacity:".15"})]});case"codeBlock":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"2",width:"16",height:"12",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("circle",{cx:"4",cy:"4",r:".6",fill:b,opacity:".3"}),(0,m.jsx)("circle",{cx:"5.5",cy:"4",r:".6",fill:b,opacity:".3"}),(0,m.jsx)("circle",{cx:"7",cy:"4",r:".6",fill:b,opacity:".3"}),(0,m.jsx)("rect",{x:"4",y:"7",width:"7",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("rect",{x:"6",y:"9",width:"5",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"4",y:"11",width:"8",height:"1",rx:".5",fill:b,opacity:".12"})]});case"calendar":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"3",width:"16",height:"12",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("line",{x1:"2",y1:"6.5",x2:"18",y2:"6.5",stroke:b,strokeWidth:".4",opacity:".25"}),(0,m.jsx)("rect",{x:"5",y:"4",width:"1",height:"1.5",rx:".3",fill:b,opacity:".2"}),(0,m.jsx)("rect",{x:"14",y:"4",width:"1",height:"1.5",rx:".3",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"7",cy:"9",r:".6",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"10",cy:"9",r:".6",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"13",cy:"9",r:".6",fill:b,opacity:".3"}),(0,m.jsx)("circle",{cx:"7",cy:"12",r:".6",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"10",cy:"12",r:".6",fill:b,opacity:".2"})]});case"notification":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"3",width:"16",height:"10",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("circle",{cx:"5.5",cy:"8",r:"2",stroke:b,strokeWidth:F,opacity:".25"}),(0,m.jsx)("rect",{x:"9",y:"6",width:"6",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"9",y:"8.5",width:"4.5",height:"1",rx:".5",fill:b,opacity:".12"}),(0,m.jsx)("circle",{cx:"16.5",cy:"4.5",r:"1.5",fill:b,opacity:".25"})]});case"productCard":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"1",width:"14",height:"14",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"3",y:"1",width:"14",height:"6",rx:"1",fill:b,opacity:".04"}),(0,m.jsx)("rect",{x:"5",y:"8.5",width:"7",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"5",y:"10.5",width:"4",height:"1.5",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"12",y:"12",width:"4",height:"2",rx:".75",stroke:b,strokeWidth:F})]});case"profile":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("circle",{cx:"10",cy:"5",r:"3",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"5",y:"10",width:"10",height:"1.5",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"7",y:"12.5",width:"6",height:"1",rx:".5",fill:b,opacity:".12"})]});case"drawer":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"9",y:"1",width:"10",height:"14",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"10.5",y:"4",width:"5",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"10.5",y:"6.5",width:"7",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"10.5",y:"9",width:"6",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"1",y:"1",width:"7",height:"14",rx:"1",stroke:b,strokeWidth:F,opacity:".15"})]});case"popover":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"2",width:"14",height:"9",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"5",y:"4.5",width:"8",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"5",y:"7",width:"6",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("path",{d:"M9 11l1 2.5 1-2.5",stroke:b,strokeWidth:F})]});case"logo":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"3",width:"10",height:"10",rx:"2",stroke:b,strokeWidth:F}),(0,m.jsx)("path",{d:"M5 9.5l2-4 2 4",stroke:b,strokeWidth:F,opacity:".3"}),(0,m.jsx)("rect",{x:"14",y:"6",width:"4",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("rect",{x:"14",y:"8.5",width:"3",height:"1",rx:".5",fill:b,opacity:".12"})]});case"faq":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("text",{x:"2.5",y:"5.5",fontSize:"4",fill:b,opacity:".3",fontWeight:"bold",children:"?"}),(0,m.jsx)("rect",{x:"7",y:"3",width:"10",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"7",y:"5.5",width:"8",height:"1",rx:".5",fill:b,opacity:".12"}),(0,m.jsx)("text",{x:"2.5",y:"11.5",fontSize:"4",fill:b,opacity:".3",fontWeight:"bold",children:"?"}),(0,m.jsx)("rect",{x:"7",y:"9",width:"9",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"7",y:"11.5",width:"7",height:"1",rx:".5",fill:b,opacity:".12"})]});case"gallery":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1.5",y:"1.5",width:"5",height:"5",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"7.5",y:"1.5",width:"5",height:"5",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"13.5",y:"1.5",width:"5",height:"5",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"1.5",y:"9.5",width:"5",height:"5",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"7.5",y:"9.5",width:"5",height:"5",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"13.5",y:"9.5",width:"5",height:"5",rx:".75",stroke:b,strokeWidth:F})]});case"checkbox":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"5",y:"4",width:"8",height:"8",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("path",{d:"M7.5 8l1.5 1.5 3-3",stroke:b,strokeWidth:F,opacity:".35"})]});case"radio":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("circle",{cx:"10",cy:"8",r:"4",stroke:b,strokeWidth:F}),(0,m.jsx)("circle",{cx:"10",cy:"8",r:"2",fill:b,opacity:".3"})]});case"slider":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"7.5",width:"16",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"2",y:"7.5",width:"10",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("circle",{cx:"12",cy:"8",r:"2.5",stroke:b,strokeWidth:F})]});case"datePicker":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"1",width:"16",height:"5",rx:"1",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"3.5",y:"3",width:"5",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("rect",{x:"14",y:"2.5",width:"2.5",height:"2",rx:".5",fill:b,opacity:".12"}),(0,m.jsx)("rect",{x:"2",y:"7",width:"16",height:"8",rx:"1",stroke:b,strokeWidth:F,strokeDasharray:"2 1",opacity:".3"}),(0,m.jsx)("circle",{cx:"6",cy:"10",r:".6",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"10",cy:"10",r:".6",fill:b,opacity:".3"}),(0,m.jsx)("circle",{cx:"14",cy:"10",r:".6",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"6",cy:"13",r:".6",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"10",cy:"13",r:".6",fill:b,opacity:".2"})]});case"skeleton":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"2",width:"16",height:"3",rx:"1",fill:b,opacity:".08"}),(0,m.jsx)("rect",{x:"2",y:"7",width:"10",height:"2",rx:".75",fill:b,opacity:".08"}),(0,m.jsx)("rect",{x:"2",y:"11",width:"13",height:"2",rx:".75",fill:b,opacity:".08"})]});case"chip":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"1.5",y:"5",width:"10",height:"6",rx:"3",fill:b,opacity:".08",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"4",y:"7.5",width:"4",height:"1",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("line",{x1:"9.5",y1:"6.5",x2:"10.5",y2:"9.5",stroke:b,strokeWidth:F,opacity:".2"}),(0,m.jsx)("line",{x1:"10.5",y1:"6.5",x2:"9.5",y2:"9.5",stroke:b,strokeWidth:F,opacity:".2"}),(0,m.jsx)("rect",{x:"13",y:"5",width:"5.5",height:"6",rx:"3",stroke:b,strokeWidth:F,opacity:".25"})]});case"icon":return(0,m.jsx)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:(0,m.jsx)("path",{d:"M10 3l1.5 3 3.5.5-2.5 2.5.5 3.5L10 11l-3 1.5.5-3.5L5 6.5l3.5-.5z",stroke:b,strokeWidth:F,opacity:".3"})});case"spinner":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("circle",{cx:"10",cy:"8",r:"5",stroke:b,strokeWidth:F,opacity:".12"}),(0,m.jsx)("path",{d:"M10 3a5 5 0 0 1 5 5",stroke:b,strokeWidth:F,opacity:".35",strokeLinecap:"round"})]});case"feature":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"2",width:"5",height:"5",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("path",{d:"M4.5 3.5v3m-1.5-1.5h3",stroke:b,strokeWidth:F,opacity:".25"}),(0,m.jsx)("rect",{x:"9",y:"2.5",width:"8",height:"1.5",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"9",y:"5.5",width:"6",height:"1",rx:".5",fill:b,opacity:".12"}),(0,m.jsx)("rect",{x:"2",y:"10",width:"5",height:"5",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"9",y:"10.5",width:"7",height:"1.5",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"9",y:"13.5",width:"5",height:"1",rx:".5",fill:b,opacity:".12"})]});case"team":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("circle",{cx:"5",cy:"5",r:"2.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"2.5",y:"9",width:"5",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"15",cy:"5",r:"2.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"12.5",y:"9",width:"5",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("circle",{cx:"10",cy:"5",r:"2.5",stroke:b,strokeWidth:F,opacity:".5"}),(0,m.jsx)("rect",{x:"7.5",y:"9",width:"5",height:"1",rx:".5",fill:b,opacity:".15"}),(0,m.jsx)("rect",{x:"4",y:"12",width:"12",height:"1",rx:".5",fill:b,opacity:".1"})]});case"login":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"3",y:"1",width:"14",height:"14",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6",y:"3",width:"8",height:"1.5",rx:".5",fill:b,opacity:".25"}),(0,m.jsx)("rect",{x:"5",y:"5.5",width:"10",height:"3",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"5",y:"9.5",width:"10",height:"3",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"6.5",y:"13.5",width:"7",height:"2",rx:".75",fill:b,opacity:".2"})]});case"contact":return(0,m.jsxs)("svg",{viewBox:"0 0 20 16",width:"20",height:"16",fill:"none",children:[(0,m.jsx)("rect",{x:"2",y:"1",width:"16",height:"14",rx:"1.5",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"4",y:"3",width:"5",height:"1",rx:".5",fill:b,opacity:".2"}),(0,m.jsx)("rect",{x:"4",y:"5",width:"12",height:"2.5",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"4",y:"8.5",width:"12",height:"4",rx:".75",stroke:b,strokeWidth:F}),(0,m.jsx)("rect",{x:"11",y:"13.5",width:"5",height:"1.5",rx:".5",fill:b,opacity:".2"})]});default:return null}}function iw({activeType:s,onSelect:i,onDragStart:r,scrollRef:u,fadeClass:d,blankCanvas:_}){return(0,m.jsx)("div",{ref:u,className:`${Z.placeScroll} ${d||""}`,children:Oh.map(g=>(0,m.jsxs)("div",{className:Z.paletteSection,children:[(0,m.jsx)("div",{className:Z.paletteSectionTitle,children:g.section}),g.items.map(w=>(0,m.jsxs)("button",{type:"button","aria-pressed":s===w.type,className:`${Z.paletteItem} ${s===w.type?Z.active:""} ${_?Z.wireframe:""}`,onClick:()=>i(w.type),onMouseDown:y=>{y.button===0&&r(w.type,y)},children:[(0,m.jsx)("span",{className:Z.paletteItemIcon,"aria-hidden":"true",children:(0,m.jsx)(sw,{type:w.type})}),(0,m.jsx)("span",{className:Z.paletteItemLabel,children:w.label})]},w.type))]},g.section))})}function rw({value:s,suffix:i}){let[r,u]=(0,io.useState)(null),[d,_]=(0,io.useState)(i),[g,w]=(0,io.useState)("up"),y=(0,io.useRef)(s),E=(0,io.useRef)(i),M=(0,io.useRef)(),S=r!==null&&d!==i;return(0,io.useEffect)(()=>{if(s!==y.current){if(s===0){y.current=s,E.current=i,u(null);return}w(s>y.current?"up":"down"),u(y.current),_(E.current),y.current=s,E.current=i,clearTimeout(M.current),M.current=_e(()=>u(null),250)}else E.current=i},[s,i]),r===null?(0,m.jsxs)(m.Fragment,{children:[s,i?` ${i}`:""]}):S?(0,m.jsxs)("span",{className:Z.rollingWrap,children:[(0,m.jsxs)("span",{style:{visibility:"hidden"},children:[s," ",i]}),(0,m.jsxs)("span",{className:`${Z.rollingNum} ${g==="up"?Z.exitUp:Z.exitDown}`,children:[r," ",d]},`o${r}-${s}`),(0,m.jsxs)("span",{className:`${Z.rollingNum} ${g==="up"?Z.enterUp:Z.enterDown}`,children:[s," ",i]},`n${s}`)]}):(0,m.jsxs)(m.Fragment,{children:[(0,m.jsxs)("span",{className:Z.rollingWrap,children:[(0,m.jsx)("span",{style:{visibility:"hidden"},children:s}),(0,m.jsx)("span",{className:`${Z.rollingNum} ${g==="up"?Z.exitUp:Z.exitDown}`,children:r},`o${r}-${s}`),(0,m.jsx)("span",{className:`${Z.rollingNum} ${g==="up"?Z.enterUp:Z.enterDown}`,children:s},`n${s}`)]}),i?` ${i}`:""]})}function cw({activeType:s,onSelect:i,isDarkMode:r,sectionCount:u,onDetectSections:d,visible:_,onExited:g,placementCount:w,onClearPlacements:y,onDragStart:E,blankCanvas:M,onBlankCanvasChange:S,wireframePurpose:O,onWireframePurposeChange:W,Tooltip:H}){let{ref:te,mounted:B}=Bh(_,{onExited:g}),[K,Se]=(0,io.useState)(!1),[G,P]=(0,io.useState)(!0),tt=(0,io.useRef)(0),ut=(0,io.useRef)(""),se=(0,io.useRef)(null),[Ue,oe]=(0,io.useState)(""),ze=w>0||u>0,Re=w+u;if(Re>0&&(tt.current=Re,ut.current=M?Re===1?"Component":"Components":Re===1?"Change":"Changes"),(0,io.useEffect)(()=>{if(ze)K?P(!1):(P(!0),Se(!0),Ce(()=>{Ce(()=>{P(!1)})}));else{P(!0);let De=_e(()=>Se(!1),300);return()=>clearTimeout(De)}},[ze]),(0,io.useEffect)(()=>{if(!_)return;let De=se.current;if(!De)return;let xe=()=>oe(aw(De));De.addEventListener("scroll",xe,{passive:!0});let ye=new ResizeObserver(xe);return ye.observe(De),()=>{De.removeEventListener("scroll",xe),ye.disconnect()}},[_]),!B)return null;let me=[];return w>0&&me.push("placed"),u>0&&me.push("captured"),(0,m.jsxs)("div",{className:`${Z.palette} ${r?"":Z.light}`,ref:De=>{te.current=De,De?.toggleAttribute("inert",!_)},"aria-hidden":!_,"data-feedback-toolbar":!0,"data-agentation-palette":!0,onClick:De=>De.stopPropagation(),onMouseDown:De=>De.stopPropagation(),children:[(0,m.jsxs)("div",{className:Z.paletteHeader,children:[(0,m.jsx)("div",{className:Z.paletteHeaderTitle,children:"Layout Mode"}),(0,m.jsxs)("div",{className:Z.paletteHeaderDesc,children:["Rearrange and resize existing elements, add new components, and explore layout ideas. Agent results may vary."," ",(0,m.jsx)("a",{href:"https://agentation.com/features#layout-mode",target:"_blank",rel:"noopener noreferrer",children:"Learn more."})]})]}),(0,m.jsxs)("button",{type:"button","aria-pressed":M,className:`${Z.canvasToggle} ${M?Z.active:""}`,onClick:()=>S(!M),children:[(0,m.jsx)("span",{className:Z.canvasToggleIcon,"aria-hidden":"true",children:(0,m.jsxs)("svg",{viewBox:"0 0 14 14",width:"14",height:"14",fill:"none",children:[(0,m.jsx)("rect",{x:"1",y:"1",width:"12",height:"12",rx:"2",stroke:"currentColor",strokeWidth:"1"}),(0,m.jsx)("circle",{cx:"4.5",cy:"4.5",r:"0.8",fill:"currentColor",opacity:".6"}),(0,m.jsx)("circle",{cx:"7",cy:"4.5",r:"0.8",fill:"currentColor",opacity:".6"}),(0,m.jsx)("circle",{cx:"9.5",cy:"4.5",r:"0.8",fill:"currentColor",opacity:".6"}),(0,m.jsx)("circle",{cx:"4.5",cy:"7",r:"0.8",fill:"currentColor",opacity:".6"}),(0,m.jsx)("circle",{cx:"7",cy:"7",r:"0.8",fill:"currentColor",opacity:".6"}),(0,m.jsx)("circle",{cx:"9.5",cy:"7",r:"0.8",fill:"currentColor",opacity:".6"}),(0,m.jsx)("circle",{cx:"4.5",cy:"9.5",r:"0.8",fill:"currentColor",opacity:".6"}),(0,m.jsx)("circle",{cx:"7",cy:"9.5",r:"0.8",fill:"currentColor",opacity:".6"}),(0,m.jsx)("circle",{cx:"9.5",cy:"9.5",r:"0.8",fill:"currentColor",opacity:".6"})]})}),(0,m.jsx)("span",{className:Z.canvasToggleLabel,children:"Wireframe New Page"})]}),(0,m.jsx)("div",{className:`${Z.wireframePurposeWrap} ${M?"":Z.collapsed}`,"aria-hidden":!M,ref:De=>{De?.toggleAttribute("inert",!M)},children:(0,m.jsx)("div",{className:Z.wireframePurposeInner,children:(0,m.jsx)("textarea",{className:Z.wireframePurposeInput,placeholder:"Describe this page to provide additional context for your agent.",value:O,onChange:De=>W(De.target.value),rows:2})})}),(0,m.jsx)(iw,{activeType:s,onSelect:i,onDragStart:E,scrollRef:se,fadeClass:Ue,blankCanvas:M}),K&&(0,m.jsx)("div",{className:`${Z.paletteFooterWrap} ${G?Z.footerHidden:""}`,children:(0,m.jsx)("div",{className:Z.paletteFooterInner,children:(0,m.jsx)("div",{className:Z.paletteFooterInnerContent,children:(0,m.jsxs)("div",{className:Z.paletteFooter,children:[(0,m.jsx)("span",{className:Z.paletteFooterCount,children:(0,m.jsx)(rw,{value:tt.current,suffix:ut.current})}),(0,m.jsx)("button",{className:Z.paletteFooterClear,onClick:y,children:"Clear"})]})})})})]})}var et=tn(),uw=new Set(["nav","header","main","section","article","footer","aside"]),w_={banner:"Header",navigation:"Navigation",main:"Main Content",contentinfo:"Footer",complementary:"Sidebar",region:"Section"},Hh={nav:"Navigation",header:"Header",main:"Main Content",section:"Section",article:"Article",footer:"Footer",aside:"Sidebar"},dw=new Set(["script","style","noscript","link","meta"]),_w=40;function Uh(s){let i=s;for(;i&&i!==document.body&&i!==document.documentElement;){let r=window.getComputedStyle(i).position;if(r==="fixed"||r==="sticky")return!0;i=i.parentElement}return!1}function ss(s){let i=s.tagName.toLowerCase();if(["nav","header","footer","main"].includes(i)&&document.querySelectorAll(i).length===1)return i;if(s.id)return`#${CSS.escape(s.id)}`;if(s.className&&typeof s.className=="string"){let d=s.className.split(/\s+/).filter(_=>_.length>0).find(_=>_.length>2&&!/^[a-zA-Z0-9]{6,}$/.test(_)&&!/^[a-z]{1,2}$/.test(_));if(d){let _=`${i}.${CSS.escape(d)}`;if(document.querySelectorAll(_).length===1)return _}}let r=s.parentElement;if(r){let d=Array.from(r.children).indexOf(s)+1;return`${r===document.body?"body":ss(r)} > ${i}:nth-child(${d})`}return i}function Wc(s){let i=s.tagName.toLowerCase(),r=s.getAttribute("aria-label");if(r)return r;let u=s.getAttribute("role");if(u&&w_[u])return w_[u];if(Hh[i])return Hh[i];let d=s.querySelector("h1, h2, h3, h4, h5, h6");if(d){let g=d.textContent?.trim();if(g&&g.length<=50)return g;if(g)return g.slice(0,47)+"..."}let{name:_}=os(s);return _.charAt(0).toUpperCase()+_.slice(1)}function $h(s){let i=s.className;return typeof i!="string"||!i?null:i.split(/\s+/).map(u=>u.replace(/[_][a-zA-Z0-9]{5,}.*$/,"")).find(u=>u.length>2&&!/^[a-z]{1,2}$/.test(u))||null}function Ih(s){let i=s.textContent?.trim();if(!i)return null;let r=i.replace(/\s+/g," ");return r.length<=30?r:r.slice(0,30)+"\u2026"}function fw(){let s=document.querySelector("main")||document.body,i=Array.from(s.children),r=i;s!==document.body&&i.length<3&&(r=Array.from(document.body.children));let u=[];return r.forEach((d,_)=>{if(!(d instanceof HTMLElement))return;let g=d.tagName.toLowerCase();if(dw.has(g)||d.hasAttribute("data-feedback-toolbar")||d.closest("[data-feedback-toolbar]"))return;let w=window.getComputedStyle(d);if(w.display==="none"||w.visibility==="hidden")return;let y=d.getBoundingClientRect();if(y.height<_w)return;let E=uw.has(g),M=d.getAttribute("role")&&w_[d.getAttribute("role")],S=g==="div"&&y.height>=60;if(!E&&!M&&!S)return;let O=window.scrollY,W=Uh(d),H={x:y.x,y:W?y.y:y.y+O,width:y.width,height:y.height};u.push({id:`rs-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,label:Wc(d),tagName:g,selector:ss(d),role:d.getAttribute("role"),className:$h(d),textSnippet:Ih(d),originalRect:H,currentRect:{...H},originalIndex:_,isFixed:W})}),u}function mw(s){let i=window.scrollY,r=s.getBoundingClientRect(),u=Uh(s),d={x:r.x,y:u?r.y:r.y+i,width:r.width,height:r.height},_=s.parentElement,g=0;return _&&(g=Array.from(_.children).indexOf(s)),{id:`rs-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,label:Wc(s),tagName:s.tagName.toLowerCase(),selector:ss(s),role:s.getAttribute("role"),className:$h(s),textSnippet:Ih(s),originalRect:d,currentRect:{...d},originalIndex:g,isFixed:u}}var At=Tn(),Yh={bg:"rgba(59, 130, 246, 0.08)",border:"rgba(59, 130, 246, 0.5)",pill:"#3b82f6"},qh=["nw","n","ne","e","se","s","sw","w"],Fc=24,Xh=16,Zc=5;function Qh(s,i,r,u){let d=1/0,_=1/0,g=s.x,w=s.x+s.width,y=s.x+s.width/2,E=s.y,M=s.y+s.height,S=s.y+s.height/2,O=[];for(let se of i)r.has(se.id)||O.push(se.currentRect);u&&O.push(...u);for(let se of O){let Ue=se.x,oe=se.x+se.width,ze=se.x+se.width/2,Re=se.y,me=se.y+se.height,De=se.y+se.height/2;for(let xe of[g,w,y])for(let ye of[Ue,oe,ze]){let Le=ye-xe;Math.abs(Le)<Zc&&Math.abs(Le)<Math.abs(d)&&(d=Le)}for(let xe of[E,M,S])for(let ye of[Re,me,De]){let Le=ye-xe;Math.abs(Le)<Zc&&Math.abs(Le)<Math.abs(_)&&(_=Le)}}let W=Math.abs(d)<Zc?d:0,H=Math.abs(_)<Zc?_:0,te=[],B=new Set,K=g+W,Se=w+W,G=y+W,P=E+H,tt=M+H,ut=S+H;for(let se of O){let Ue=se.x,oe=se.x+se.width,ze=se.x+se.width/2,Re=se.y,me=se.y+se.height,De=se.y+se.height/2;for(let xe of[Ue,ze,oe])for(let ye of[K,G,Se])if(Math.abs(ye-xe)<.5){let Le=`x:${Math.round(xe)}`;B.has(Le)||(B.add(Le),te.push({axis:"x",pos:xe}))}for(let xe of[Re,De,me])for(let ye of[P,ut,tt])if(Math.abs(ye-xe)<.5){let Le=`y:${Math.round(xe)}`;B.has(Le)||(B.add(Le),te.push({axis:"y",pos:xe}))}}return{dx:W,dy:H,guides:te}}var hw=new Set(["script","style","noscript","link","meta","br","hr"]);function Gh(s){let i=s;for(;i&&i!==document.body&&i!==document.documentElement;){if(i.closest("[data-feedback-toolbar]"))return null;if(hw.has(i.tagName.toLowerCase())){i=i.parentElement;continue}let r=i.getBoundingClientRect();if(r.width>=Xh&&r.height>=Xh)return i;i=i.parentElement}return null}function gw({rearrangeState:s,onChange:i,isDarkMode:r,exiting:u,className:d,blankCanvas:_,extraSnapRects:g,onSelectionChange:w,deselectSignal:y,onDragMove:E,onDragEnd:M,clearing:S}){let{sections:O}=s,W=(0,et.useRef)(s);W.current=s;let[H,te]=(0,et.useState)(new Set);(0,et.useEffect)(()=>{S&&te(new Set)},[S]);let B=(0,et.useRef)(y);(0,et.useEffect)(()=>{y!==B.current&&(B.current=y,te(new Set))},[y]);let[K,Se]=(0,et.useState)(null),[G,P]=(0,et.useState)(!1),tt=(0,et.useRef)(!1),ut=(0,et.useCallback)(D=>{let Q=O.find(ee=>ee.id===D);Q&&(tt.current=!!Q.note,Se(D),P(!1))},[O]),se=(0,et.useCallback)(()=>{K&&(P(!0),_e(()=>{Se(null),P(!1)},150))},[K]),Ue=(0,et.useCallback)(D=>{K&&(i({...s,sections:O.map(Q=>Q.id===K?{...Q,note:D.trim()||void 0}:Q)}),se())},[K,O,s,i,se]);(0,et.useEffect)(()=>{u&&K&&se()},[u]);let[oe,ze]=(0,et.useState)(new Set),Re=(0,et.useRef)(new Map),[me,De]=(0,et.useState)(null),[xe,ye]=(0,et.useState)(null),[Le,rn]=(0,et.useState)([]),[_t,St]=(0,et.useState)(0),ft=(0,et.useRef)(null),Vt=(0,et.useRef)(new Set),qn=(0,et.useRef)(new Map),[go,nt]=(0,et.useState)(new Map),[jo,rs]=(0,et.useState)(new Map),Fs=(0,et.useRef)(new Set),pa=(0,et.useRef)(new Map),Ul=(0,et.useRef)(w);Ul.current=w;let $l=(0,et.useRef)(E);$l.current=E;let Il=(0,et.useRef)(M);Il.current=M,(0,et.useEffect)(()=>{_&&te(new Set)},[_]);let[vn,ml]=(0,et.useState)(()=>!s.sections.some(D=>{let Q=D.originalRect,ee=D.currentRect;return Math.abs(Q.x-ee.x)>1||Math.abs(Q.y-ee.y)>1||Math.abs(Q.width-ee.width)>1||Math.abs(Q.height-ee.height)>1}));(0,et.useEffect)(()=>{if(!vn){let D=_e(()=>ml(!0),380);return()=>clearTimeout(D)}},[]);let hl=(0,et.useRef)(new Set);(0,et.useEffect)(()=>{hl.current=new Set(O.map(D=>D.selector))},[O]),(0,et.useEffect)(()=>{let D=()=>St(window.scrollY);return D(),window.addEventListener("scroll",D,{passive:!0}),window.addEventListener("resize",D,{passive:!0}),()=>{window.removeEventListener("scroll",D),window.removeEventListener("resize",D)}},[]),(0,et.useEffect)(()=>{let D=Q=>{if(ft.current){De(null);return}let ee=document.elementFromPoint(Q.clientX,Q.clientY);if(!ee){De(null);return}if(ee.closest("[data-feedback-toolbar]")){De(null);return}if(ee.closest("[data-design-placement]")){De(null);return}if(ee.closest("[data-annotation-popup]")){De(null);return}let le=Gh(ee);if(!le){De(null);return}for(let je of hl.current)try{let ie=document.querySelector(je);if(ie&&(ie===le||le.contains(ie))){De(null);return}}catch{}let ge=le.getBoundingClientRect();De({x:ge.x,y:ge.y,w:ge.width,h:ge.height})};return document.addEventListener("mousemove",D,{passive:!0}),()=>document.removeEventListener("mousemove",D)},[O]),(0,et.useEffect)(()=>{let D=document.body.style.userSelect;return document.body.style.webkitUserSelect="none",document.body.style.userSelect="none",()=>{document.body.style.webkitUserSelect=D,document.body.style.userSelect=D}},[]),(0,et.useEffect)(()=>{let D=Q=>{if(ft.current||Q.button!==0)return;let ee=Q.composedPath()[0]??Q.target;if(!ee||ee.closest("[data-feedback-toolbar]")||ee.closest("[data-design-placement]")||ee.closest("[data-annotation-popup]"))return;let le=Gh(ee),ge=!1;if(le)for(let ie of hl.current)try{let Ee=document.querySelector(ie);if(Ee&&(Ee===le||le.contains(Ee))){ge=!0;break}}catch{}let je=!!(Q.shiftKey||Q.metaKey||Q.ctrlKey);if(le&&!ge){Q.preventDefault(),Q.stopPropagation();let ie=mw(le),Ee=[...O,ie],Qe=[...s.originalOrder,ie.id];i({...s,sections:Ee,originalOrder:Qe});let ot=new Set([ie.id]);te(ot),Ul.current?.(ot,je),De(null);let Ot=Q.clientX,Ht=Q.clientY,Ct={x:ie.currentRect.x,y:ie.currentRect.y},ht=ie.originalRect,Je=!1,Pt=0,Zt=0;ft.current="move";let Ut=jt=>{let Wt=jt.clientX-Ot,Yt=jt.clientY-Ht;if(!Je&&(Math.abs(Wt)>2||Math.abs(Yt)>2)&&(Je=!0),!Je)return;let ke={x:Ct.x+Wt,y:Ct.y+Yt,width:ie.currentRect.width,height:ie.currentRect.height},ro=Qh(ke,Ee,new Set([ie.id]),g);rn(ro.guides);let po=Wt+ro.dx,to=Yt+ro.dy;Pt=po,Zt=to;let gl=ae().querySelector(`[data-rearrange-section="${ie.id}"]`);gl&&(gl.style.transform=`translate(${po}px, ${to}px)`),nt(new Map([[ie.id,{x:Ct.x+po,y:Ct.y+to,width:ie.currentRect.width,height:ie.currentRect.height}]])),$l.current?.(po,to)},it=()=>{window.removeEventListener("mousemove",Ut),window.removeEventListener("mouseup",it),ft.current=null,rn([]),nt(new Map);let jt=ae().querySelector(`[data-rearrange-section="${ie.id}"]`);jt&&(jt.style.transform=""),Je&&i({...s,sections:Ee.map(Wt=>Wt.id===ie.id?{...Wt,currentRect:{...Wt.currentRect,x:Math.max(0,Ct.x+Pt),y:Math.max(0,Ct.y+Zt)}}:Wt),originalOrder:Qe}),Il.current?.(Pt,Zt,Je)};window.addEventListener("mousemove",Ut),window.addEventListener("mouseup",it)}else if(ge&&le){Q.preventDefault();for(let ie of O)try{let Ee=document.querySelector(ie.selector);if(Ee&&Ee===le){let Qe=new Set([ie.id]);te(Qe),Ul.current?.(Qe,je);return}}catch{}je||(te(new Set),Ul.current?.(new Set,!1))}else je||(te(new Set),Ul.current?.(new Set,!1))};return document.addEventListener("mousedown",D,!0),()=>document.removeEventListener("mousedown",D,!0)},[O,s,i]),(0,et.useEffect)(()=>{let D=Q=>{let ee=Q.composedPath()[0]||Q.target;if(!(ee.tagName==="INPUT"||ee.tagName==="TEXTAREA"||ee.isContentEditable)){if((Q.key==="Backspace"||Q.key==="\u0423\u0434\u0430\u043B\u0438\u0442\u044C")&&H.size>0){Q.preventDefault();let le=new Set(H);ze(ge=>{let je=new Set(ge);for(let ie of le)je.add(ie);return je}),te(new Set),_e(()=>{let ge=W.current;i({...ge,sections:ge.sections.filter(je=>!le.has(je.id)),originalOrder:ge.originalOrder.filter(je=>!le.has(je))}),ze(je=>{let ie=new Set(je);for(let Ee of le)ie.delete(Ee);return ie})},180);return}if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(Q.key)&&H.size>0){Q.preventDefault();let le=Q.shiftKey?20:1,ge=Q.key==="ArrowLeft"?-le:Q.key==="ArrowRight"?le:0,je=Q.key==="ArrowUp"?-le:Q.key==="ArrowDown"?le:0;i({...s,sections:O.map(ie=>H.has(ie.id)?{...ie,currentRect:{...ie.currentRect,x:Math.max(0,ie.currentRect.x+ge),y:Math.max(0,ie.currentRect.y+je)}}:ie)});return}Q.key==="Escape"&&H.size>0&&te(new Set)}};return document.addEventListener("keydown",D),()=>document.removeEventListener("keydown",D)},[H,O,s,i]);let Zs=(0,et.useCallback)((D,Q)=>{if(D.button!==0)return;let ee=D.target;if(ee.closest(`.${Z.handle}`)||ee.closest(`.${Z.deleteButton}`))return;D.preventDefault(),D.stopPropagation();let le;D.shiftKey||D.metaKey||D.ctrlKey?(le=new Set(H),le.has(Q)?le.delete(Q):le.add(Q)):H.has(Q)?le=new Set(H):le=new Set([Q]),te(le),(le.size!==H.size||[...le].some(Je=>!H.has(Je)))&&Ul.current?.(le,!!(D.shiftKey||D.metaKey||D.ctrlKey));let je=D.clientX,ie=D.clientY,Ee=new Map;for(let Je of O)le.has(Je.id)&&Ee.set(Je.id,{x:Je.currentRect.x,y:Je.currentRect.y});ft.current="move";let Qe=!1,ot=0,Ot=0,Ht=new Map;for(let Je of O)if(le.has(Je.id)){let Pt=ae().querySelector(`[data-rearrange-section="${Je.id}"]`);Ht.set(Je.id,{outlineEl:Pt,curW:Je.currentRect.width,curH:Je.currentRect.height})}let Ct=Je=>{let Pt=Je.clientX-je,Zt=Je.clientY-ie;if(Pt===0&&Zt===0)return;Qe=!0;let Ut=1/0,it=1/0,jt=-1/0,Wt=-1/0;for(let[to,{curW:gl,curH:ql}]of Ht){let tl=Ee.get(to);if(!tl)continue;let $o=tl.x+Pt,xr=tl.y+Zt;Ut=Math.min(Ut,$o),it=Math.min(it,xr),jt=Math.max(jt,$o+gl),Wt=Math.max(Wt,xr+ql)}let Yt=Qh({x:Ut,y:it,width:jt-Ut,height:Wt-it},O,le,g),ke=Pt+Yt.dx,ro=Zt+Yt.dy;ot=ke,Ot=ro,rn(Yt.guides);for(let[,{outlineEl:to}]of Ht)to&&(to.style.transform=`translate(${ke}px, ${ro}px)`);let po=new Map;for(let[to,{curW:gl,curH:ql}]of Ht){let tl=Ee.get(to);if(tl){let $o={x:Math.max(0,tl.x+ke),y:Math.max(0,tl.y+ro),width:gl,height:ql};po.set(to,$o)}}nt(po),$l.current?.(ke,ro)},ht=Je=>{window.removeEventListener("mousemove",Ct),window.removeEventListener("mouseup",ht),ft.current=null,rn([]),nt(new Map);for(let[,{outlineEl:Pt}]of Ht)Pt&&(Pt.style.transform="");if(Qe){let Pt=Je.clientX-je,Zt=Je.clientY-ie;if(Math.abs(Pt)<5&&Math.abs(Zt)<5)i({...s,sections:O.map(Ut=>{let it=Ee.get(Ut.id);return it?{...Ut,currentRect:{...Ut.currentRect,x:it.x,y:it.y}}:Ut})});else{i({...s,sections:O.map(Ut=>{let it=Ee.get(Ut.id);return it?{...Ut,currentRect:{...Ut.currentRect,x:Math.max(0,it.x+ot),y:Math.max(0,it.y+Ot)}}:Ut})}),Il.current?.(ot,Ot,!0);return}}Il.current?.(0,0,!1)};window.addEventListener("mousemove",Ct),window.addEventListener("mouseup",ht)},[H,O,s,i]),Uo=(0,et.useCallback)((D,Q,ee)=>{D.preventDefault(),D.stopPropagation();let le=O.find(ht=>ht.id===Q);if(!le)return;te(new Set([Q])),ft.current="resize";let ge=D.clientX,je=D.clientY,ie={...le.currentRect},Ee=le.originalRect,Qe=ie.width/ie.height,ot={...ie},Ot=ae().querySelector(`[data-rearrange-section="${Q}"]`),Ht=ht=>{let Je=ht.clientX-ge,Pt=ht.clientY-je,Zt=ie.x,Ut=ie.y,it=ie.width,jt=ie.height;if(ee.includes("e")&&(it=Math.max(Fc,ie.width+Je)),ee.includes("w")&&(it=Math.max(Fc,ie.width-Je),Zt=ie.x+ie.width-it),ee.includes("s")&&(jt=Math.max(Fc,ie.height+Pt)),ee.includes("n")&&(jt=Math.max(Fc,ie.height-Pt),Ut=ie.y+ie.height-jt),ht.shiftKey)if(ee.length===2){let Yt=Math.abs(it-ie.width),ke=Math.abs(jt-ie.height);Yt>ke?jt=it/Qe:it=jt*Qe,ee.includes("w")&&(Zt=ie.x+ie.width-it),ee.includes("n")&&(Ut=ie.y+ie.height-jt)}else ee==="e"||ee==="w"?jt=it/Qe:it=jt*Qe,ee==="w"&&(Zt=ie.x+ie.width-it),ee==="n"&&(Ut=ie.y+ie.height-jt);ot={x:Zt,y:Ut,width:it,height:jt},Ot&&(Ot.style.left=`${Zt}px`,Ot.style.top=`${Ut-_t}px`,Ot.style.width=`${it}px`,Ot.style.height=`${jt}px`),ye({x:ht.clientX+12,y:ht.clientY+12,text:`${Math.round(it)} \xD7 ${Math.round(jt)}`}),nt(new Map([[Q,ot]]))},Ct=()=>{window.removeEventListener("mousemove",Ht),window.removeEventListener("mouseup",Ct),ye(null),ft.current=null,nt(new Map),i({...s,sections:O.map(ht=>ht.id===Q?{...ht,currentRect:ot}:ht)})};window.addEventListener("mousemove",Ht),window.addEventListener("mouseup",Ct)},[O,s,i,_t]),Yl=(0,et.useCallback)(D=>{ze(Q=>{let ee=new Set(Q);return ee.add(D),ee}),te(Q=>{let ee=new Set(Q);return ee.delete(D),ee}),_e(()=>{let Q=W.current;i({...Q,sections:Q.sections.filter(ee=>ee.id!==D),originalOrder:Q.originalOrder.filter(ee=>ee!==D)}),ze(ee=>{let le=new Set(ee);return le.delete(D),le})},180)},[i]),ue=D=>{let Q=D.originalRect,ee=D.currentRect;return Math.abs(Q.x-ee.x)>1||Math.abs(Q.y-ee.y)>1||Math.abs(Q.width-ee.width)>1||Math.abs(Q.height-ee.height)>1},Oe=D=>{let Q=D.originalRect,ee=D.currentRect;return Math.abs(Q.x-ee.x)>1||Math.abs(Q.y-ee.y)>1},Ke=D=>{let Q=D.originalRect,ee=D.currentRect;return Math.abs(Q.width-ee.width)>1||Math.abs(Q.height-ee.height)>1};for(let D of O)qn.current.has(D.id)||(Oe(D)?qn.current.set(D.id,"move"):Ke(D)&&qn.current.set(D.id,"resize"));for(let D of qn.current.keys())O.some(Q=>Q.id===D)||qn.current.delete(D);let We=O.filter(D=>{try{if(oe.has(D.id)||H.has(D.id))return!0;let Q=document.querySelector(D.selector);if(!Q)return!1;let ee=Q.getBoundingClientRect(),le=D.originalRect;return Math.abs(ee.width-le.width)+Math.abs(ee.height-le.height)<200}catch{return!1}}),Xe=We.filter(D=>ue(D)),kt=We.filter(D=>!ue(D)),mt=new Set(Xe.map(D=>D.id));for(let D of Vt.current)mt.has(D)||Vt.current.delete(D);let vt=[...mt].sort().join(",");for(let D of Xe)pa.current.set(D.id,{currentRect:D.currentRect,originalRect:D.originalRect,isFixed:D.isFixed});(0,et.useEffect)(()=>{let D=Fs.current;Fs.current=mt;let Q=new Map;for(let ee of D)if(!mt.has(ee)){if(!O.some(ge=>ge.id===ee))continue;let le=pa.current.get(ee);le&&(Q.set(ee,{orig:le.originalRect,target:le.currentRect,isFixed:le.isFixed}),pa.current.delete(ee))}if(Q.size>0){rs(le=>{let ge=new Map(le);for(let[je,ie]of Q)ge.set(je,ie);return ge});let ee=_e(()=>{rs(le=>{let ge=new Map(le);for(let je of Q.keys())ge.delete(je);return ge})},250);return()=>clearTimeout(ee)}},[vt,O]);let bt=(0,et.useRef)(null),ae=()=>bt.current?.getRootNode()??document;return(0,At.jsxs)(At.Fragment,{children:[(0,At.jsxs)("div",{ref:bt,className:`${Z.rearrangeOverlay} ${r?"":Z.light} ${u?Z.overlayExiting:""}${d?` ${d}`:""}`,"data-feedback-toolbar":!0,children:[me&&(0,At.jsx)("div",{className:Z.hoverHighlight,style:{left:me.x,top:me.y,width:me.w,height:me.h}}),kt.map(D=>{let Q=D.currentRect,ee=D.isFixed?Q.y:Q.y-_t,le=Yh,ge=H.has(D.id);return(0,At.jsxs)("div",{"data-rearrange-section":D.id,className:`${Z.sectionOutline} ${ge?Z.selected:""} ${S||u||oe.has(D.id)?Z.exiting:""}`,style:{left:Q.x,top:ee,width:Q.width,height:Q.height,borderColor:le.border,backgroundColor:le.bg,...vn?{}:{opacity:0,animation:"none",transition:"none"}},onMouseDown:je=>Zs(je,D.id),onDoubleClick:()=>ut(D.id),children:[(0,At.jsx)("span",{className:Z.sectionLabel,style:{backgroundColor:le.pill},children:D.label}),(0,At.jsx)("span",{className:`${Z.sectionAnnotation} ${D.note?Z.annotationVisible:""}`,children:(D.note&&Re.current.set(D.id,D.note),D.note||Re.current.get(D.id)||"")}),(0,At.jsxs)("span",{className:Z.sectionDimensions,children:[Math.round(Q.width)," \xD7 ",Math.round(Q.height)]}),(0,At.jsx)("div",{className:Z.deleteButton,onMouseDown:je=>je.stopPropagation(),onClick:()=>Yl(D.id),children:"\u2715"}),qh.map(je=>(0,At.jsx)("div",{className:`${Z.handle} ${Z[`handle${je.charAt(0).toUpperCase()}${je.slice(1)}`]}`,onMouseDown:ie=>Uo(ie,D.id,je)},je))]},D.id)}),Xe.map(D=>{let Q=D.currentRect,ee=D.isFixed?Q.y:Q.y-_t,le=H.has(D.id),ge=Oe(D),je=Ke(D);if(_&&!le)return null;let Ee=!Vt.current.has(D.id);return Ee&&Vt.current.add(D.id),(0,At.jsxs)("div",{"data-rearrange-section":D.id,className:`${Z.ghostOutline} ${le?Z.selected:""} ${S||u||oe.has(D.id)?Z.exiting:""}`,style:{left:Q.x,top:ee,width:Q.width,height:Q.height,...vn?{}:{opacity:0,animation:"none",transition:"none"},...Ee?{}:{animation:"none"}},onMouseDown:Qe=>Zs(Qe,D.id),onDoubleClick:()=>ut(D.id),children:[(0,At.jsx)("span",{className:Z.sectionLabel,style:{backgroundColor:Yh.pill},children:D.label}),(0,At.jsx)("span",{className:`${Z.sectionAnnotation} ${D.note?Z.annotationVisible:""}`,children:(D.note&&Re.current.set(D.id,D.note),D.note||Re.current.get(D.id)||"")}),(0,At.jsxs)("span",{className:Z.sectionDimensions,children:[Math.round(Q.width)," \xD7 ",Math.round(Q.height)]}),(0,At.jsx)("div",{className:Z.deleteButton,onMouseDown:Qe=>Qe.stopPropagation(),onClick:()=>Yl(D.id),children:"\u2715"}),qh.map(Qe=>(0,At.jsx)("div",{className:`${Z.handle} ${Z[`handle${Qe.charAt(0).toUpperCase()}${Qe.slice(1)}`]}`,onMouseDown:ot=>Uo(ot,D.id,Qe)},Qe)),(0,At.jsx)("span",{className:Z.ghostBadge,children:(()=>{let Qe=qn.current.get(D.id);if(ge&&je){let[ot,Ot]=Qe==="resize"?["Resize","Move"]:["Move","Resize"];return(0,At.jsxs)(At.Fragment,{children:["Suggested ",ot," ",(0,At.jsxs)("span",{className:Z.ghostBadgeExtra,children:["& ",Ot]})]})}return`Suggested ${je?"Resize":"Move"}`})()})]},D.id)})]}),!_&&(()=>{let D=[];for(let Q of Xe){let ee=go.get(Q.id);D.push({id:Q.id,orig:Q.originalRect,target:ee||Q.currentRect,isFixed:Q.isFixed,isSelected:H.has(Q.id),isExiting:oe.has(Q.id)})}for(let[Q,ee]of go)if(!D.some(le=>le.id===Q)){let le=O.find(ge=>ge.id===Q);le&&D.push({id:Q,orig:le.originalRect,target:ee,isFixed:le.isFixed,isSelected:H.has(Q)})}for(let[Q,ee]of jo)D.some(le=>le.id===Q)||D.push({id:Q,orig:ee.orig,target:ee.target,isFixed:ee.isFixed,isSelected:!1,isExiting:!0});return D.length===0?null:(0,At.jsxs)("svg",{className:`${Z.connectorSvg} ${S||u?Z.connectorExiting:""}`,children:[D.map(({id:Q,orig:ee,target:le,isFixed:ge,isSelected:je,isExiting:ie})=>{let Ee=ee.x+ee.width/2,Qe=(ge?ee.y:ee.y-_t)+ee.height/2,ot=le.x+le.width/2,Ot=(ge?le.y:le.y-_t)+le.height/2,Ht=ot-Ee,Ct=Ot-Qe,ht=Math.sqrt(Ht*Ht+Ct*Ct);if(ht<2)return null;let Je=Math.min(1,ht/40),Pt=Math.min(ht*.3,60),Zt=ht>0?-Ct/ht:0,Ut=ht>0?Ht/ht:0,it=(Ee+ot)/2+Zt*Pt,jt=(Qe+Ot)/2+Ut*Pt,Wt=go.has(Q),Yt=Wt||je?1:.4,ke=Wt||je?1:.5;return(0,At.jsxs)("g",{className:ie?Z.connectorExiting:"",children:[(0,At.jsx)("path",{className:Z.connectorLine,d:`M ${Ee} ${Qe} Q ${it} ${jt} ${ot} ${Ot}`,fill:"none",stroke:"rgba(59, 130, 246, 0.45)",strokeWidth:"1.5",opacity:Yt*Je}),(0,At.jsx)("circle",{className:Z.connectorDot,cx:Ee,cy:Qe,r:4*Je,fill:"rgba(59, 130, 246, 0.8)",stroke:"#fff",strokeWidth:"1.5",opacity:ke*Je,filter:"url(#connDotShadow)"}),(0,At.jsx)("circle",{className:Z.connectorDot,cx:ot,cy:Ot,r:4*Je,fill:"rgba(59, 130, 246, 0.8)",stroke:"#fff",strokeWidth:"1.5",opacity:ke*Je,filter:"url(#connDotShadow)"})]},`conn-${Q}`)}),(0,At.jsx)("defs",{children:(0,At.jsx)("filter",{id:"connDotShadow",x:"-50%",y:"-50%",width:"200%",height:"200%",children:(0,At.jsx)("feDropShadow",{dx:"0",dy:"0.5",stdDeviation:"1",floodOpacity:"0.15"})})})]})})(),K&&(()=>{let D=O.find(Ot=>Ot.id===K);if(!D)return null;let Q=D.currentRect,ee=D.isFixed?Q.y:Q.y-_t,le=Q.x+Q.width/2,ge=ee-8,je=ee+Q.height+8,ie=ge>200,Ee=je<window.innerHeight-100,Qe=Math.max(160,Math.min(window.innerWidth-160,le)),ot;return ie?ot={left:Qe,bottom:window.innerHeight-ge}:Ee?ot={left:Qe,top:je}:ot={left:Qe,top:Math.max(80,window.innerHeight/2-80)},(0,At.jsx)(Qc,{element:D.label,placeholder:"Add a note about this section",initialValue:D.note??"",submitLabel:tt.current?"\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C":"Set",onSubmit:Ue,onCancel:se,onDelete:tt.current?()=>{Ue("")}:void 0,isExiting:G,lightMode:!r,style:ot})})(),xe&&(0,At.jsx)("div",{className:Z.sizeIndicator,style:{left:xe.x,top:xe.y},"data-feedback-toolbar":!0,children:xe.text}),Le.map((D,Q)=>(0,At.jsx)("div",{className:Z.guideLine,style:D.axis==="x"?{position:"fixed",left:D.pos,top:0,width:1,height:"100vh"}:{position:"fixed",left:0,top:D.pos-_t,width:"100vw",height:1}},`${D.axis}-${D.pos}-${Q}`))]})}var S_=new Set(["script","style","noscript","link","meta","br","hr"]);function pw(){let s=document.querySelector("main")||document.body,i=[],r=Array.from(s.children),u=s!==document.body&&r.length<3?Array.from(document.body.children):r;for(let d of u){if(!(d instanceof HTMLElement)||S_.has(d.tagName.toLowerCase())||d.hasAttribute("data-feedback-toolbar"))continue;let _=window.getComputedStyle(d);if(_.display==="none"||_.visibility==="hidden")continue;let g=d.getBoundingClientRect();if(!(g.height<10||g.width<10)){i.push({label:Wc(d),selector:ss(d),top:g.top,bottom:g.bottom,left:g.left,right:g.right,area:g.width*g.height});for(let w of Array.from(d.children)){if(!(w instanceof HTMLElement)||S_.has(w.tagName.toLowerCase())||w.hasAttribute("data-feedback-toolbar"))continue;let y=window.getComputedStyle(w);if(y.display==="none"||y.visibility==="hidden")continue;let E=w.getBoundingClientRect();E.height<10||E.width<10||i.push({label:Wc(w),selector:ss(w),top:E.top,bottom:E.bottom,left:E.left,right:E.right,area:E.width*E.height})}}}return i}function yw(s){let i=window.scrollY;return s.map(({label:r,selector:u,rect:d})=>{let _=d.y-i;return{label:r,selector:u,top:_,bottom:_+d.height,left:d.x,right:d.x+d.width,area:d.width*d.height}})}function xw(s){let i=window.scrollY,r=s.y-i,u=s.x;return{top:r,bottom:r+s.height,left:u,right:u+s.width,area:s.width*s.height}}function k_(s,i){let r=i?yw(i):pw(),u=xw(s),d=null,_=null,g=null,w=null,y=null;for(let H of r){if(Math.abs(H.left-u.left)<2&&Math.abs(H.top-u.top)<2&&Math.abs(H.right-H.left-s.width)<2&&Math.abs(H.bottom-H.top-s.height)<2)continue;H.left<=u.left+2&&H.right>=u.right-2&&H.top<=u.top+2&&H.bottom>=u.bottom-2&&H.area>u.area*1.5&&(!y||H.area<y._area)&&(y={label:H.label,selector:H.selector,_area:H.area});let te=u.right>H.left+5&&u.left<H.right-5,B=u.bottom>H.top+5&&u.top<H.bottom-5;if(te&&H.bottom<=u.top+5){let K=Math.round(u.top-H.bottom);(!d||K<d._dist)&&(d={label:H.label,selector:H.selector,gap:Math.max(0,K),_dist:K})}if(te&&H.top>=u.bottom-5){let K=Math.round(H.top-u.bottom);(!_||K<_._dist)&&(_={label:H.label,selector:H.selector,gap:Math.max(0,K),_dist:K})}if(B&&H.right<=u.left+5){let K=Math.round(u.left-H.right);(!g||K<g._dist)&&(g={label:H.label,selector:H.selector,gap:Math.max(0,K),_dist:K})}if(B&&H.left>=u.right-5){let K=Math.round(H.left-u.right);(!w||K<w._dist)&&(w={label:H.label,selector:H.selector,gap:Math.max(0,K),_dist:K})}}let E=window.innerWidth,M=window.innerHeight,S=vw(s,E),O=H=>H?{label:H.label,selector:H.selector,gap:H.gap}:null,W=bw(u,s,E,M,y?{label:y.label,selector:y.selector,_area:y._area}:null,r);return{above:O(d),below:O(_),left:O(g),right:O(w),alignment:S,containedIn:y?{label:y.label,selector:y.selector}:null,outOfBounds:W}}function bw(s,i,r,u,d,_){let g={},w=!1,y=[];if(s.left<-2&&y.push("left"),s.right>r+2&&y.push("right"),s.top<-2&&y.push("top"),s.bottom>u+2&&y.push("bottom"),y.length>0&&(g.viewport=y,w=!0),d){let E=_.find(M=>M.label===d.label&&M.selector===d.selector&&Math.abs(M.area-d._area)<10);if(E){let M=[];s.left<E.left-2&&M.push("left"),s.right>E.right+2&&M.push("right"),s.top<E.top-2&&M.push("top"),s.bottom>E.bottom+2&&M.push("bottom"),M.length>0&&(g.container={label:d.label,edges:M},w=!0)}}return w?g:null}function vw(s,i){if(s.width/i>.85)return"full-width";let u=s.x+s.width/2,d=i/2,_=u-d,g=i*.08;return Math.abs(_)<g?"center":_<0?"left":"right"}function Vh(s){switch(s){case"full-width":return"full-width";case"center":return"centered";case"left":return"left-aligned";case"right":return"right-aligned"}}function Wh(s,i={}){let r=[];s.above&&r.push(`Below \`${s.above.label}\`${s.above.gap>0?` (${s.above.gap}px gap)`:""}`),s.below&&r.push(`Above \`${s.below.label}\`${s.below.gap>0?` (${s.below.gap}px gap)`:""}`),i.includeLeftRight&&(s.left&&r.push(`Right of \`${s.left.label}\`${s.left.gap>0?` (${s.left.gap}px gap)`:""}`),s.right&&r.push(`Left of \`${s.right.label}\`${s.right.gap>0?` (${s.right.gap}px gap)`:""}`));let u=Vh(s.alignment);return s.containedIn?r.push(`${u.charAt(0).toUpperCase()+u.slice(1)} in \`${s.containedIn.label}\``):r.push(`${u.charAt(0).toUpperCase()+u.slice(1)} in page`),i.includePixelRef&&i.pixelRef&&r.push(`Pixel ref: \`${i.pixelRef}\``),s.outOfBounds&&(s.outOfBounds.viewport&&r.push(`**Outside viewport** (${s.outOfBounds.viewport.join(", ")} edge${s.outOfBounds.viewport.length>1?"s":""})`),s.outOfBounds.container&&r.push(`**Outside \`${s.outOfBounds.container.label}\`** (${s.outOfBounds.container.edges.join(", ")} edge${s.outOfBounds.container.edges.length>1?"s":""})`)),r}function ww(s,i,r){let u=[];s.above&&u.push(`below \`${s.above.label}\``),s.below&&u.push(`above \`${s.below.label}\``),s.left&&u.push(`right of \`${s.left.label}\``),s.right&&u.push(`left of \`${s.right.label}\``),s.containedIn&&u.push(`inside \`${s.containedIn.label}\``),u.push(Vh(s.alignment)),s.outOfBounds?.viewport&&u.push(`**outside viewport** (${s.outOfBounds.viewport.join(", ")})`),s.outOfBounds?.container&&u.push(`**outside \`${s.outOfBounds.container.label}\`** (${s.outOfBounds.container.edges.join(", ")})`);let d=r?`, ${Math.round(r.width)}\xD7${Math.round(r.height)}px`:"";return`at (${Math.round(i.x)}, ${Math.round(i.y)})${d}: ${u.join(", ")}`}var Fh=15;function Zh(s){if(s.length<2)return[];let i=[],r=new Set;for(let u=0;u<s.length;u++){if(r.has(u))continue;let d=[u];for(let _=u+1;_<s.length;_++)r.has(_)||Math.abs(s[u].rect.y-s[_].rect.y)<Fh&&d.push(_);if(d.length>=2){let _=d.map(y=>s[y]);_.sort((y,E)=>y.rect.x-E.rect.x);let g=[];for(let y=0;y<_.length-1;y++)g.push(Math.round(_[y+1].rect.x-(_[y].rect.x+_[y].rect.width)));let w=Math.round(_.reduce((y,E)=>y+E.rect.y,0)/_.length);i.push({labels:_.map(y=>y.label),type:"row",sharedEdge:w,gaps:g,avgGap:g.length?Math.round(g.reduce((y,E)=>y+E,0)/g.length):0}),d.forEach(y=>r.add(y))}}for(let u=0;u<s.length;u++){if(r.has(u))continue;let d=[u];for(let _=u+1;_<s.length;_++)r.has(_)||Math.abs(s[u].rect.x-s[_].rect.x)<Fh&&d.push(_);if(d.length>=2){let _=d.map(y=>s[y]);_.sort((y,E)=>y.rect.y-E.rect.y);let g=[];for(let y=0;y<_.length-1;y++)g.push(Math.round(_[y+1].rect.y-(_[y].rect.y+_[y].rect.height)));let w=Math.round(_.reduce((y,E)=>y+E.rect.x,0)/_.length);i.push({labels:_.map(y=>y.label),type:"column",sharedEdge:w,gaps:g,avgGap:g.length?Math.round(g.reduce((y,E)=>y+E,0)/g.length):0}),d.forEach(y=>r.add(y))}}return i}function Sw(s){if(s.length<2)return[];let i=Zh(s.map(g=>({label:g.label,rect:g.originalRect}))),r=Zh(s.map(g=>({label:g.label,rect:g.currentRect}))),u=[],d=new Set;for(let g of i){let w=new Set(g.labels),y=null,E=0;for(let M of r){let S=M.labels.filter(O=>w.has(O)).length;S>=2&&S>E&&(y=M,E=S)}if(y){let M=y.labels.filter(O=>w.has(O)),S=M.join(", ");if(y.type!==g.type){let O=g.type==="row"?"y":"x",W=y.type==="row"?"y":"x";u.push(`**${S}**: ${g.type} (${O}\u2248${g.sharedEdge}, ${g.avgGap}px gaps) \u2192 ${y.type} (${W}\u2248${y.sharedEdge}, ${y.avgGap}px gaps)`)}else if(Math.abs(g.sharedEdge-y.sharedEdge)>20||Math.abs(g.avgGap-y.avgGap)>5){let O=g.type==="row"?"y":"x",W=Math.abs(g.sharedEdge-y.sharedEdge)>20?` ${O}: ${g.sharedEdge} \u2192 ${y.sharedEdge}`:"",H=Math.abs(g.avgGap-y.avgGap)>5?` gaps: ${g.avgGap}px \u2192 ${y.avgGap}px`:"";u.push(`**${S}**: ${g.type} shifted \u2014${W}${H}`)}M.forEach(O=>d.add(O))}else{let M=g.labels.join(", "),S=g.type==="row"?"y":"x";u.push(`**${M}**: ${g.type} (${S}\u2248${g.sharedEdge}) dissolved`),g.labels.forEach(O=>d.add(O))}}for(let g of r){if(g.labels.every(E=>d.has(E))||g.labels.filter(E=>!d.has(E)).length<2)continue;if(!i.some(E=>E.labels.filter(S=>g.labels.includes(S)).length>=2)){let E=g.type==="row"?"y":"x";u.push(`**${g.labels.join(", ")}**: new ${g.type} (${E}\u2248${g.sharedEdge}, ${g.avgGap}px gaps)`),g.labels.forEach(M=>d.add(M))}}let _=s.filter(g=>!d.has(g.label));if(_.length>=2){let g={};for(let w of _){let y=Math.round(w.currentRect.x/5)*5;(g[y]??(g[y]=[])).push(w.label)}for(let[w,y]of Object.entries(g))y.length>=2&&u.push(`**${y.join(", ")}**: shared left edge at x\u2248${w}`)}return u}function Kh(s){if(typeof document>"u")return{viewport:s,contentArea:null};let i=[],r=new Set,u=w=>{r.has(w)||w instanceof HTMLElement&&(w.hasAttribute("data-feedback-toolbar")||S_.has(w.tagName.toLowerCase())||(r.add(w),i.push(w)))},d=document.querySelector("main");d&&u(d);let _=document.querySelector("[role='main']");_&&u(_);for(let w of Array.from(document.body.children))if(u(w),w.children){for(let y of Array.from(w.children))if(u(y),y.children)for(let E of Array.from(y.children))u(E)}let g=null;for(let w of i){let y=w.getBoundingClientRect();if(y.height<50)continue;let E=getComputedStyle(w);if(E.maxWidth&&E.maxWidth!=="none"&&E.maxWidth!=="0px"){(!g||y.width<g.rect.width)&&(g={el:w,rect:y});continue}!g&&y.width<s.width-20&&y.width>100&&(g={el:w,rect:y})}if(g){let{el:w,rect:y}=g;return{viewport:s,contentArea:{width:Math.round(y.width),left:Math.round(y.left),right:Math.round(y.right),centerX:Math.round(y.left+y.width/2),selector:ss(w)}}}return{viewport:s,contentArea:null}}function kw(s){if(typeof document>"u")return null;let i=document.querySelector(s);if(!i?.parentElement)return null;let r=getComputedStyle(i.parentElement),u={parentDisplay:r.display,parentSelector:ss(i.parentElement)};return r.display.includes("flex")&&(u.flexDirection=r.flexDirection),r.display.includes("grid")&&r.gridTemplateColumns!=="none"&&(u.gridCols=r.gridTemplateColumns),r.gap&&r.gap!=="normal"&&r.gap!=="0px"&&(u.gap=r.gap),u}function Jh(s,i){let r=i.contentArea,u=r?r.width:i.viewport.width,d=r?r.left:0,_=r?r.centerX:Math.round(i.viewport.width/2),g=Math.round(s.x-d),w=Math.round(d+u-(s.x+s.width)),y=(s.width/u*100).toFixed(1),E=s.x+s.width/2,M=Math.abs(E-_)<20,S=s.width/u>.95,O=[];return S?O.push("`width: 100%` of container"):O.push(`left \`${g}px\` in container, right \`${w}px\`, width \`${y}%\` (\`${Math.round(s.width)}px\`)`),M&&!S&&O.push("centered \u2014 `margin-inline: auto`"),O.join(" \u2014 ")}function Ph(s){let{viewport:i,contentArea:r}=s,u=`### Reference Frame
`;if(u+=`- Viewport: \`${i.width}\xD7${i.height}px\`
`,r){let d=r;u+=`- Content area: \`${d.width}px\` wide, left edge at \`x=${d.left}\`, right at \`x=${d.right}\` (\`${d.selector}\`)
`,u+=`- Pixel \u2192 CSS translation:
`,u+=`  - **Horizontal position in container**: \`element.x - ${d.left}\` \u2192 use as \`margin-left\` or \`left\`
`,u+=`  - **Width as % of container**: \`element.width / ${d.width} \xD7 100\` \u2192 use as \`width: X%\`
`,u+="  - **Vertical gap between elements**: `nextElement.y - (prevElement.y + prevElement.height)` \u2192 use as `margin-top` or `gap`\n",u+=`  - **Centered**: if \`|element.centerX - ${d.centerX}| < 20px\` \u2192 use \`margin-inline: auto\`
`}else u+=`- No distinct content container \u2014 elements positioned relative to full viewport
`,u+=`- Pixel \u2192 CSS translation:
`,u+=`  - **Width as % of viewport**: \`element.width / ${i.width} \xD7 100\` \u2192 use as \`width: X%\`
`,u+=`  - **Centered**: if \`|(element.x + element.width/2) - ${Math.round(i.width/2)}| < 20px\` \u2192 use \`margin-inline: auto\`
`;return u+=`
`,u}function Cw(s){let i=kw(s);if(!i)return null;let r=`\`${i.parentDisplay}\``;return i.flexDirection&&(r+=`, flex-direction: \`${i.flexDirection}\``),i.gridCols&&(r+=`, grid-template-columns: \`${i.gridCols}\``),i.gap&&(r+=`, gap: \`${i.gap}\``),`Parent: ${r} (\`${i.parentSelector}\`)`}function eg(s,i,r,u="standard"){if(s.length===0)return"";let d=[...s].sort((B,K)=>Math.abs(B.y-K.y)<20?B.x-K.x:B.y-K.y),_="";if(r?.blankCanvas?(_+=`## Wireframe: New Page

`,r.wireframePurpose&&(_+=`> **Purpose:** ${r.wireframePurpose}
>
`),_+=`> ${s.length} component${s.length!==1?"s":""} placed \u2014 this is a standalone wireframe, not related to the current page.
>
> This wireframe is a rough sketch for exploring ideas.

`):_+=`## Design Layout

> ${s.length} component${s.length!==1?"s":""} placed

`,u==="compact")return _+=`### Components
`,d.forEach((B,K)=>{let Se=el[B.type]?.label||B.type;_+=`${K+1}. **${Se}** \u2014 \`${Math.round(B.width)}\xD7${Math.round(B.height)}px\` at \`(${Math.round(B.x)}, ${Math.round(B.y)})\`
`,B.text&&(_+=`   - Note: "${B.text}"
`)}),_;let g=Kh(i);_+=Ph(g),_+=`### Components
`,d.forEach((B,K)=>{let Se=el[B.type]?.label||B.type,G={x:B.x,y:B.y,width:B.width,height:B.height};_+=`${K+1}. **${Se}** \u2014 \`${Math.round(B.width)}\xD7${Math.round(B.height)}px\` at \`(${Math.round(B.x)}, ${Math.round(B.y)})\`
`,B.text&&(_+=`   - Note: "${B.text}"
`);let P=k_(G),ut=Wh(P,{includeLeftRight:u==="detailed"||u==="forensic"});for(let Ue of ut)_+=`   - ${Ue}
`;let se=Jh(G,g);se&&(_+=`   - CSS: ${se}
`)}),_+=`
### Layout Analysis
`;let w=[];for(let B of d){let K=w.find(Se=>Math.abs(Se.y-B.y)<30);K?K.items.push(B):w.push({y:B.y,items:[B]})}if(w.sort((B,K)=>B.y-K.y),w.forEach((B,K)=>{B.items.sort((G,P)=>G.x-P.x);let Se=B.items.map(G=>el[G.type]?.label||G.type);if(B.items.length===1){let P=B.items[0].width>i.width*.8;_+=`- Row ${K+1} (y\u2248${Math.round(B.y)}): ${Se[0]}${P?" \u2014 full width":""}
`}else _+=`- Row ${K+1} (y\u2248${Math.round(B.y)}): ${Se.join(" | ")} \u2014 ${B.items.length} items side by side
`}),u==="detailed"||u==="forensic"){_+=`
### Spacing & Gaps
`;for(let B=0;B<d.length-1;B++){let K=d[B],Se=d[B+1],G=el[K.type]?.label||K.type,P=el[Se.type]?.label||Se.type,tt=Math.round(Se.y-(K.y+K.height)),ut=Math.round(Se.x-(K.x+K.width));Math.abs(K.y-Se.y)<30?_+=`- ${G} \u2192 ${P}: \`${ut}px\` horizontal gap
`:_+=`- ${G} \u2192 ${P}: \`${tt}px\` vertical gap
`}if(u==="forensic"&&d.length>2){_+=`
### All Pairwise Gaps
`;for(let B=0;B<d.length;B++)for(let K=B+1;K<d.length;K++){let Se=d[B],G=d[K],P=el[Se.type]?.label||Se.type,tt=el[G.type]?.label||G.type,ut=Math.round(G.y-(Se.y+Se.height)),se=Math.round(G.x-(Se.x+Se.width));_+=`- ${P} \u2194 ${tt}: h=\`${se}px\` v=\`${ut}px\`
`}}u==="forensic"&&(_+=`
### Z-Order (placement order)
`,s.forEach((B,K)=>{let Se=el[B.type]?.label||B.type;_+=`${K}. ${Se} at \`(${Math.round(B.x)}, ${Math.round(B.y)})\`
`}))}_+=`
### Suggested Implementation
`;let y=d.some(B=>B.type==="navigation"),E=d.some(B=>B.type==="hero"),M=d.some(B=>B.type==="sidebar"),S=d.some(B=>B.type==="footer"),O=d.filter(B=>B.type==="card"),W=d.filter(B=>B.type==="form"),H=d.filter(B=>B.type==="table"),te=d.filter(B=>B.type==="modal");if(y&&(_+=`- Top navigation bar with logo + nav links + CTA
`),E&&(_+=`- Hero section with heading, subtext, and call-to-action
`),M&&(_+=`- Sidebar layout \u2014 use CSS Grid with sidebar + main content area
`),O.length>1?_+=`- ${O.length}-column card grid \u2014 use CSS Grid or Flexbox
`:O.length===1&&(_+=`- Card component with image + content area
`),W.length>0&&(_+=`- ${W.length} form${W.length>1?"s":""} \u2014 add proper labels, validation, and submit handling
`),H.length>0&&(_+=`- Data table \u2014 consider sortable columns and pagination
`),te.length>0&&(_+=`- Modal dialog \u2014 add overlay backdrop and focus trapping
`),S&&(_+=`- Multi-column footer with links
`),u==="detailed"||u==="forensic"){if(_+=`
### CSS Suggestions
`,M){let B=d.find(K=>K.type==="sidebar");_+=`- \`display: grid; grid-template-columns: ${Math.round(B.width)}px 1fr;\`
`}if(O.length>1){let B=Math.round(O[0].width);_+=`- \`display: grid; grid-template-columns: repeat(${O.length}, ${B}px); gap: 16px;\`
`}y&&(_+="- Navigation: `position: sticky; top: 0; z-index: 50;`\n")}return _}function tg(s,i="standard",r){let{sections:u}=s,d=[];for(let M of u){let S=M.originalRect,O=M.currentRect,W=Math.abs(S.x-O.x)>1||Math.abs(S.y-O.y)>1,H=Math.abs(S.width-O.width)>1||Math.abs(S.height-O.height)>1,te=!!M.note;if(!W&&!H&&!te){i==="forensic"&&d.push({section:M,posMoved:!1,sizeChanged:!1});continue}d.push({section:M,posMoved:W,sizeChanged:H})}if(d.length===0||i!=="forensic"&&d.every(M=>!M.posMoved&&!M.sizeChanged&&!M.section.note))return"";let _=`## Suggested Layout Changes

`,g=r?r.width:typeof window<"u"?window.innerWidth:0,w=r?r.height:typeof window<"u"?window.innerHeight:0,y=Kh({width:g,height:w});i!=="compact"&&(_+=Ph(y)),i==="forensic"&&(_+=`> Detected at: \`${new Date(s.detectedAt).toISOString()}\`
`,_+=`> Total sections: ${u.length}

`);let E=M=>u.map(S=>({label:S.label,selector:S.selector,rect:M==="original"?S.originalRect:S.currentRect}));_+=`**Changes:**
`;for(let{section:M,posMoved:S,sizeChanged:O}of d){let W=M.originalRect,H=M.currentRect;if(!S&&!O){M.note?(_+=`- **${M.label}** \u2014 note only
`,_+=`  - Note: "${M.note}"
`):_+=`- ${M.label} \u2014 unchanged at (${Math.round(H.x)}, ${Math.round(H.y)}) ${Math.round(H.width)}\xD7${Math.round(H.height)}px
`;continue}if(i==="compact"){S&&O?_+=`- Suggested: move **${M.label}** to (${Math.round(H.x)}, ${Math.round(H.y)}) ${Math.round(H.width)}\xD7${Math.round(H.height)}px
`:S?_+=`- Suggested: move **${M.label}** to (${Math.round(H.x)}, ${Math.round(H.y)})
`:_+=`- Suggested: resize **${M.label}** to ${Math.round(H.width)}\xD7${Math.round(H.height)}px
`,M.note&&(_+=`  - Note: "${M.note}"
`);continue}if(S&&O?_+=`- Suggested: move and resize **${M.label}**
`:S?_+=`- Suggested: move **${M.label}**
`:_+=`- Suggested: resize **${M.label}** from ${Math.round(W.width)}\xD7${Math.round(W.height)}px to ${Math.round(H.width)}\xD7${Math.round(H.height)}px
`,M.note&&(_+=`  - Note: "${M.note}"
`),S){let B=k_(W,E("original")),K=k_(H,E("current")),Se=O?{width:W.width,height:W.height}:void 0;_+=`  - Currently ${ww(B,{x:W.x,y:W.y},Se)}
`;let G=O?{width:H.width,height:H.height}:void 0,P=`at (${Math.round(H.x)}, ${Math.round(H.y)})`,tt=G?`, ${Math.round(G.width)}\xD7${Math.round(G.height)}px`:"",se=Wh(K,{includeLeftRight:i==="detailed"||i==="forensic"});if(se.length>0){_+=`  - Suggested position ${P}${tt}: ${se[0]}
`;for(let oe=1;oe<se.length;oe++)_+=`    ${se[oe]}
`}else _+=`  - Suggested position ${P}${tt}
`;let Ue=Jh(H,y);Ue&&(_+=`  - CSS: ${Ue}
`)}let te=Cw(M.selector);if(te&&(_+=`  - ${te}
`),_+=`  - Selector: \`${M.selector}\`
`,i==="detailed"||i==="forensic"){let B=M.className?`${M.tagName}.${M.className.split(" ")[0]}`:M.tagName;B!==M.selector&&(_+=`  - Element: \`${B}\`
`),M.role&&(_+=`  - Role: \`${M.role}\`
`),i==="forensic"&&M.textSnippet&&(_+=`  - Text: "${M.textSnippet}"
`)}i==="forensic"&&(_+=`  - Original rect: \`{ x: ${Math.round(W.x)}, y: ${Math.round(W.y)}, w: ${Math.round(W.width)}, h: ${Math.round(W.height)} }\`
`,_+=`  - Current rect: \`{ x: ${Math.round(H.x)}, y: ${Math.round(H.y)}, w: ${Math.round(H.width)}, h: ${Math.round(H.height)} }\`
`)}if(i!=="compact"){let M=d.filter(O=>O.posMoved).map(O=>({label:O.section.label,originalRect:O.section.originalRect,currentRect:O.section.currentRect})),S=Sw(M);if(S.length>0){_+=`
### Layout Summary
`;for(let O of S)_+=`- ${O}
`}}if(i!=="compact"&&u.length>1){_+=`
### All Sections (current positions)
`;let M=[...u].sort((S,O)=>Math.abs(S.currentRect.y-O.currentRect.y)<20?S.currentRect.x-O.currentRect.x:S.currentRect.y-O.currentRect.y);for(let S of M){let O=S.currentRect,W=Math.abs(O.x-S.originalRect.x)>1||Math.abs(O.y-S.originalRect.y)>1||Math.abs(O.width-S.originalRect.width)>1||Math.abs(O.height-S.originalRect.height)>1;_+=`- ${S.label}: \`${Math.round(O.width)}\xD7${Math.round(O.height)}px\` at \`(${Math.round(O.x)}, ${Math.round(O.y)})\`${W?" \u2190 suggested":""}
`}}return _}var C_=(t.scope||"bb-review")+"-session-annotations-",ng=Number.POSITIVE_INFINITY;function Kc(s){return`${C_}${s}`}function Hl(s){if(typeof window>"u")return[];try{let i=t.storage.getItem(Kc(s));if(!i)return[];let r=JSON.parse(i),u=Date.now()-ng*24*60*60*1e3;return r.filter(d=>!d.timestamp||d.timestamp>u)}catch{return[]}}function dr(s,i){if(!(typeof window>"u"))try{t.storage.setItem(Kc(s),JSON.stringify(i))}catch{}}function _r(){let s=new Map;if(typeof window>"u")return s;try{let i=Date.now()-ng*24*60*60*1e3;for(let r=0;r<t.storage.length;r++){let u=t.storage.key(r);if(u?.startsWith(C_)){let d=u.slice(C_.length),_=t.storage.getItem(u);if(_){let w=JSON.parse(_).filter(y=>!y.timestamp||y.timestamp>i);w.length>0&&s.set(d,w)}}}}catch{}return s}function j_(s,i,r){let u=i.map(d=>({...d,_syncedTo:r}));dr(s,u)}var E_="agentation-design-";function jw(s){if(typeof window>"u")return[];try{let i=t.storage.getItem(`${E_}${s}`);return i?JSON.parse(i):[]}catch{return[]}}function Ew(s,i){if(!(typeof window>"u"))try{t.storage.setItem(`${E_}${s}`,JSON.stringify(i))}catch{}}function Mw(s){if(!(typeof window>"u"))try{t.storage.removeItem(`${E_}${s}`)}catch{}}var M_="agentation-rearrange-";function Tw(s){if(typeof window>"u")return null;try{let i=t.storage.getItem(`${M_}${s}`);return i?JSON.parse(i):null}catch{return null}}function Nw(s,i){if(!(typeof window>"u"))try{t.storage.setItem(`${M_}${s}`,JSON.stringify(i))}catch{}}function Rw(s){if(!(typeof window>"u"))try{t.storage.removeItem(`${M_}${s}`)}catch{}}var T_="agentation-wireframe-";function Aw(s){if(typeof window>"u")return null;try{let i=t.storage.getItem(`${T_}${s}`);return i?JSON.parse(i):null}catch{return null}}function og(s,i){if(!(typeof window>"u"))try{t.storage.setItem(`${T_}${s}`,JSON.stringify(i))}catch{}}function Jc(s){if(!(typeof window>"u"))try{t.storage.removeItem(`${T_}${s}`)}catch{}}var lg="agentation-session-";function N_(s){return`${lg}${s}`}function Dw(s){if(typeof window>"u")return null;try{return t.storage.getItem(N_(s))}catch{return null}}function R_(s,i){if(!(typeof window>"u"))try{t.storage.setItem(N_(s),i)}catch{}}function Ow(s){if(!(typeof window>"u"))try{t.storage.removeItem(N_(s))}catch{}}var A_=`${lg}toolbar-hidden`;function zw(){if(typeof window>"u")return!1;try{return t.storage.getItem(A_)==="1"}catch{return!1}}function Lw(s){if(!(typeof window>"u"))try{s?t.storage.setItem(A_,"1"):t.storage.removeItem(A_)}catch{}}async function D_(s,i){let r=await fetch(`${s}/sessions`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:i})});if(!r.ok)throw new Error(`Failed to create session: ${r.status}`);return r.json()}async function ag(s,i){let r=await fetch(`${s}/sessions/${i}`);if(!r.ok)throw new Error(`Failed to get session: ${r.status}`);return r.json()}async function sg(s,i,r){!r.elementPath&&(r.element==="body"||r.element==="html")&&(r={...r,elementPath:r.element});let u=await fetch(`${s}/sessions/${i}/annotations`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(r)});if(!u.ok)throw new Error(`Failed to sync annotation: ${u.status}`);return u.json()}async function O_(s,i,r){let u=await fetch(`${s}/annotations/${i}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(r)});if(!u.ok)throw new Error(`Failed to update annotation: ${u.status}`);return u.json()}async function Pc(s,i){let r=await fetch(`${s}/annotations/${i}`,{method:"DELETE"});if(!r.ok)throw new Error(`Failed to delete annotation: ${r.status}`)}var Dt={FunctionComponent:0,ClassComponent:1,IndeterminateComponent:2,HostRoot:3,HostPortal:4,HostComponent:5,HostText:6,Fragment:7,Mode:8,ContextConsumer:9,ContextProvider:10,ForwardRef:11,Profiler:12,SuspenseComponent:13,MemoComponent:14,SimpleMemoComponent:15,LazyComponent:16,IncompleteClassComponent:17,DehydratedFragment:18,SuspenseListComponent:19,ScopeComponent:21,OffscreenComponent:22,LegacyHiddenComponent:23,CacheComponent:24,TracingMarkerComponent:25,HostHoistable:26,HostSingleton:27,IncompleteFunctionComponent:28,Throw:29,ViewTransitionComponent:30,ActivityComponent:31},ig=new Set(["Component","PureComponent","Fragment","Suspense","Profiler","StrictMode","Routes","Route","Outlet","Root","ErrorBoundaryHandler","HotReload","Hot"]),rg=[/Boundary$/,/BoundaryHandler$/,/Provider$/,/Consumer$/,/^(Inner|Outer)/,/Router$/,/^Client(Page|Segment|Root)/,/^Segment(ViewNode|Node)$/,/^LayoutSegment/,/^Server(Root|Component|Render)/,/^RSC/,/Context$/,/^Hot(Reload)?$/,/^(Dev|React)(Overlay|Tools|Root)/,/Overlay$/,/Handler$/,/^With[A-Z]/,/Wrapper$/,/^Root$/],Bw=[/Page$/,/View$/,/Screen$/,/Section$/,/Card$/,/List$/,/Item$/,/Form$/,/Modal$/,/Dialog$/,/Button$/,/Nav$/,/Header$/,/Footer$/,/Layout$/,/Panel$/,/Tab$/,/Menu$/];function Hw(s){let i=s?.mode??"filtered",r=ig;if(s?.skipExact){let u=s.skipExact instanceof Set?s.skipExact:new Set(s.skipExact);r=new Set([...ig,...u])}return{maxComponents:s?.maxComponents??6,maxDepth:s?.maxDepth??30,mode:i,skipExact:r,skipPatterns:s?.skipPatterns?[...rg,...s.skipPatterns]:rg,userPatterns:s?.userPatterns??Bw,filter:s?.filter}}function Uw(s){return s.replace(/([a-z])([A-Z])/g,"$1-$2").replace(/([A-Z])([A-Z][a-z])/g,"$1-$2").toLowerCase()}function $w(s,i=10){let r=new Set,u=s,d=0;for(;u&&d<i;)u.className&&typeof u.className=="string"&&u.className.split(/\s+/).forEach(_=>{if(_.length>1){let g=_.replace(/[_][a-zA-Z0-9]{5,}.*$/,"").toLowerCase();g.length>1&&r.add(g)}}),u=u.parentElement,d++;return r}function Iw(s,i){let r=Uw(s);for(let u of i){if(u===r)return!0;let d=r.split("-").filter(g=>g.length>2),_=u.split("-").filter(g=>g.length>2);for(let g of d)for(let w of _)if(g===w||g.includes(w)||w.includes(g))return!0}return!1}function Yw(s,i,r,u){if(r.filter)return r.filter(s,i);switch(r.mode){case"all":return!0;case"filtered":return!(r.skipExact.has(s)||r.skipPatterns.some(d=>d.test(s)));case"smart":return r.skipExact.has(s)||r.skipPatterns.some(d=>d.test(s))?!1:!!(u&&Iw(s,u)||r.userPatterns.some(d=>d.test(s)));default:return!0}}var Ws=null,qw=new WeakMap;function z_(s){return Object.keys(s).some(i=>i.startsWith("__reactFiber$")||i.startsWith("__reactInternalInstance$")||i.startsWith("__reactProps$"))}function Xw(){if(Ws!==null)return Ws;if(typeof document>"u")return!1;if(document.body&&z_(document.body))return Ws=!0,!0;let s=["#root","#app","#__next","[data-reactroot]"];for(let i of s){let r=document.querySelector(i);if(r&&z_(r))return Ws=!0,!0}if(document.body){for(let i of document.body.children)if(z_(i))return Ws=!0,!0}return Ws=!1,!1}var fr={map:qw};function Qw(s){return Object.keys(s).find(r=>r.startsWith("__reactFiber$")||r.startsWith("__reactInternalInstance$"))||null}function Gw(s){let i=Qw(s);return i?s[i]:null}function is(s){return s?s.displayName?s.displayName:s.name?s.name:null:null}function Vw(s){let{tag:i,type:r,elementType:u}=s;if(i===Dt.HostComponent||i===Dt.HostText||i===Dt.HostHoistable||i===Dt.HostSingleton||i===Dt.Fragment||i===Dt.Mode||i===Dt.Profiler||i===Dt.DehydratedFragment||i===Dt.HostRoot||i===Dt.HostPortal||i===Dt.ScopeComponent||i===Dt.OffscreenComponent||i===Dt.LegacyHiddenComponent||i===Dt.CacheComponent||i===Dt.TracingMarkerComponent||i===Dt.Throw||i===Dt.ViewTransitionComponent||i===Dt.ActivityComponent)return null;if(i===Dt.ForwardRef){let d=u;if(d?.render){let _=is(d.render);if(_)return _}return d?.displayName?d.displayName:is(r)}if(i===Dt.MemoComponent||i===Dt.SimpleMemoComponent){let d=u;if(d?.type){let _=is(d.type);if(_)return _}return d?.displayName?d.displayName:is(r)}if(i===Dt.ContextProvider){let d=r;return d?._context?.displayName?`${d._context.displayName}.Provider`:null}if(i===Dt.ContextConsumer){let d=r;return d?.displayName?`${d.displayName}.Consumer`:null}if(i===Dt.LazyComponent){let d=u;return d?._status===1&&d._result?is(d._result):null}return i===Dt.SuspenseComponent||i===Dt.SuspenseListComponent?null:i===Dt.IncompleteClassComponent||i===Dt.IncompleteFunctionComponent||i===Dt.FunctionComponent||i===Dt.ClassComponent||i===Dt.IndeterminateComponent?is(r):null}function Ww(s){return s.length<=2||s.length<=3&&s===s.toLowerCase()}function Fw(s,i){let r=Hw(i),u=r.mode==="all";if(u){let y=fr.map.get(s);if(y!==void 0)return y}if(!Xw()){let y={path:null,components:[]};return u&&fr.map.set(s,y),y}let d=r.mode==="smart"?$w(s):void 0,_=[];try{let y=Gw(s),E=0;for(;y&&E<r.maxDepth&&_.length<r.maxComponents;){let M=Vw(y);M&&!Ww(M)&&Yw(M,E,r,d)&&_.push(M),y=y.return,E++}}catch{let y={path:null,components:[]};return u&&fr.map.set(s,y),y}if(_.length===0){let y={path:null,components:[]};return u&&fr.map.set(s,y),y}let w={path:_.slice().reverse().map(y=>`<${y}>`).join(" "),components:_};return u&&fr.map.set(s,w),w}var Zw=V(tn()),mr={FunctionComponent:0,ClassComponent:1,IndeterminateComponent:2,HostRoot:3,HostPortal:4,HostComponent:5,HostText:6,Fragment:7,Mode:8,ContextConsumer:9,ContextProvider:10,ForwardRef:11,Profiler:12,SuspenseComponent:13,MemoComponent:14,SimpleMemoComponent:15,LazyComponent:16};function Kw(s){if(!s||typeof s!="object")return null;let i=Object.keys(s),r=i.find(_=>_.startsWith("__reactFiber$"));if(r)return s[r]||null;let u=i.find(_=>_.startsWith("__reactInternalInstance$"));if(u)return s[u]||null;let d=i.find(_=>{if(!_.startsWith("__react"))return!1;let g=s[_];return g&&typeof g=="object"&&"_debugSource"in g});return d&&s[d]||null}function hr(s){if(!s.type||typeof s.type=="string")return null;if(typeof s.type=="object"||typeof s.type=="function"){let i=s.type;if(i.displayName)return i.displayName;if(i.name)return i.name}return null}function Jw(s,i=50){let r=s,u=0;for(;r&&u<i;){if(r._debugSource)return{source:r._debugSource,componentName:hr(r)};if(r._debugOwner?._debugSource)return{source:r._debugOwner._debugSource,componentName:hr(r._debugOwner)};r=r.return,u++}return null}function Pw(s){let i=s,r=0,u=50;for(;i&&r<u;){let d=i,_=["_debugSource","__source","_source","debugSource"];for(let g of _){let w=d[g];if(w&&typeof w=="object"&&"fileName"in w)return{source:w,componentName:hr(i)}}if(i.memoizedProps){let g=i.memoizedProps;if(g.__source&&typeof g.__source=="object"){let w=g.__source;if(w.fileName&&w.lineNumber)return{source:{fileName:w.fileName,lineNumber:w.lineNumber,columnNumber:w.columnNumber},componentName:hr(i)}}}i=i.return,r++}return null}var eu=new Map;function e4(s){let i=s.tag,r=s.type,u=s.elementType;if(typeof r=="string"||r==null||typeof r=="function"&&r.prototype?.isReactComponent)return null;if((i===mr.FunctionComponent||i===mr.IndeterminateComponent)&&typeof r=="function")return r;if(i===mr.ForwardRef&&u){let d=u.render;if(typeof d=="function")return d}if((i===mr.MemoComponent||i===mr.SimpleMemoComponent)&&u){let d=u.type;if(typeof d=="function")return d}return typeof r=="function"?r:null}function t4(){let s=Zw,i=s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;if(i&&"H"in i)return{get:()=>i.H,set:u=>{i.H=u}};let r=s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;if(r){let u=r.ReactCurrentDispatcher;if(u&&"current"in u)return{get:()=>u.current,set:d=>{u.current=d}}}return null}function n4(s,i){let r=s.split(`
`),u=[/source-location/,/\/dist\/index\./,/node_modules\//,/react-dom/,/react\.development/,/react\.production/,/chunk-[A-Z0-9]+/i,/\/_next\/static\/chunks\//,/\/\.vite\/deps\//,/\/_astro\//,/\/assets\/[^\s/]+[-.][\w-]{8,}\.m?js(?:[?:]|$)/,/react-stack-bottom-frame/,/react-reconciler/,/scheduler/,/<anonymous>/],d=/^\s*at\s+(?:.*?\s+\()?(.+?):(\d+):(\d+)\)?$/,_=/^[^@]*@(.+?):(\d+):(\d+)$/;for(let g of r){let w=g.trim();if(!w||u.some(E=>E.test(w)))continue;if(i){let E=i.replace(/^bound /,"").replace(/[.*+?^${}()|[\]\\]/g,"\\$&");if(!new RegExp(`(?:at (?:Object\\.)?|^)${E}(?: \\(|@| \\[)`).test(w))continue}let y=d.exec(w)||_.exec(w);if(y)return{fileName:y[1],line:parseInt(y[2],10),column:parseInt(y[3],10)}}return null}function o4(s){let i=s;return i=i.replace(/[?#].*$/,""),i=i.replace(/^turbopack:\/\/\/\[project\]\//,""),i=i.replace(/^webpack-internal:\/\/\/\.\//,""),i=i.replace(/^webpack-internal:\/\/\//,""),i=i.replace(/^webpack:\/\/\/\.\//,""),i=i.replace(/^webpack:\/\/\//,""),i=i.replace(/^turbopack:\/\/\//,""),i=i.replace(/^https?:\/\/[^/]+\//,""),i=i.replace(/^file:\/\/\//,"/"),i=i.replace(/^\([^)]+\)\/\.\//,""),i=i.replace(/^\.\//,""),i}function l4(s){let i=e4(s);if(!i)return null;if(eu.has(i))return eu.get(i);let r=t4();if(!r)return eu.set(i,null),null;let u=r.get(),d=null;try{let _=new Proxy({},{get(){throw new Error("probe")}});r.set(_);try{i({})}catch(g){if(g instanceof Error&&g.message==="probe"&&g.stack){let w=n4(g.stack,i.name);w&&(d={fileName:o4(w.fileName),lineNumber:w.line,columnNumber:w.column,componentName:hr(s)||void 0})}}}finally{r.set(u)}return eu.set(i,d),d}function a4(s,i=15){let r=s,u=0;for(;r&&u<i;){let d=l4(r);if(d)return d;r=r.return,u++}return null}function L_(s){let i=Kw(s);if(!i)return{found:!1,reason:"no-fiber",isReactApp:!1,isProduction:!1};let r=Jw(i);if(r||(r=Pw(i)),r?.source)return{found:!0,source:{fileName:r.source.fileName,lineNumber:r.source.lineNumber,columnNumber:r.source.columnNumber,componentName:r.componentName||void 0},isReactApp:!0,isProduction:!1};let u=a4(i);return u?{found:!0,source:u,isReactApp:!0,isProduction:!1}:{found:!1,reason:"no-debug-source",isReactApp:!0,isProduction:!1}}function s4(s,i="path"){let{fileName:r,lineNumber:u,columnNumber:d}=s,_=`${r}:${u}`;return d!==void 0&&(_+=`:${d}`),i==="vscode"?`vscode://file${r.startsWith("/")?"":"/"}${_}`:_}function i4(s,i=10){let r=s,u=0;for(;r&&u<i;){let d=L_(r);if(d.found)return d;r=r.parentElement,u++}return L_(s)}var gr=[{value:"compact",label:"Compact"},{value:"standard",label:"Standard"},{value:"detailed",label:"Detailed"},{value:"forensic",label:"Forensic"}];function tu(s,i){let r=`## Page Feedback: ${s}
`,u=i?.replace(/[\r\n\t]+/g," ").trim();return u&&(r+=`**App:** ${u.replace(/[\\`*_\[\]<>]/g,"\\$&")}
`),r}function cg(s,i,r="standard",u={}){if(s.length===0)return"";let d=typeof window<"u"?`${window.innerWidth}\xD7${window.innerHeight}`:"unknown",_=tu(i,u.appName);return r==="forensic"?(_+=`
**Environment:**
`,_+=`- Viewport: ${d}
`,typeof window<"u"&&(_+=`- URL: ${window.location.href}
`,_+=`- User Agent: ${navigator.userAgent}
`,_+=`- Timestamp: ${new Date().toISOString()}
`,_+=`- Device Pixel Ratio: ${window.devicePixelRatio}
`),_+=`
---
`):r!=="compact"&&(_+=`**Viewport:** ${d}
`),_+=`
`,s.forEach((g,w)=>{r==="compact"?(_+=`${w+1}. **${g.element}**${g.sourceFile?` (${g.sourceFile})`:""}: ${g.comment}`,g.selectedText&&(_+=` (re: "${g.selectedText.slice(0,30)}${g.selectedText.length>30?"...":""}")`),_+=`
`):r==="forensic"?(_+=`### ${w+1}. ${g.element}
`,g.isMultiSelect&&g.fullPath&&(_+=`*Forensic data shown for first element of selection*
`),g.fullPath&&(_+=`**Full DOM Path:** ${g.fullPath}
`),g.cssClasses&&(_+=`**CSS Classes:** ${g.cssClasses}
`),g.boundingBox&&(_+=`**Position:** x:${Math.round(g.boundingBox.x)}, y:${Math.round(g.boundingBox.y)} (${Math.round(g.boundingBox.width)}\xD7${Math.round(g.boundingBox.height)}px)
`),_+=`**Annotation at:** ${g.x.toFixed(1)}% from left, ${Math.round(g.y)}px from top
`,g.selectedText&&(_+=`**Selected text:** "${g.selectedText}"
`),g.nearbyText&&!g.selectedText&&(_+=`**Context:** ${g.nearbyText.slice(0,100)}
`),g.computedStyles&&(_+=`**Computed Styles:** ${g.computedStyles}
`),g.accessibility&&(_+=`**Accessibility:** ${g.accessibility}
`),g.nearbyElements&&(_+=`**Nearby Elements:** ${g.nearbyElements}
`),g.sourceFile&&(_+=`**Source:** ${g.sourceFile}
`),g.reactComponents&&(_+=`**React:** ${g.reactComponents}
`),_+=`**Feedback:** ${g.comment}

`):(_+=`### ${w+1}. ${g.element}
`,_+=`**Location:** ${g.elementPath}
`,g.sourceFile&&(_+=`**Source:** ${g.sourceFile}
`),g.reactComponents&&(_+=`**React:** ${g.reactComponents}
`),r==="detailed"&&(g.cssClasses&&(_+=`**Classes:** ${g.cssClasses}
`),g.boundingBox&&(_+=`**Position:** ${Math.round(g.boundingBox.x)}px, ${Math.round(g.boundingBox.y)}px (${Math.round(g.boundingBox.width)}\xD7${Math.round(g.boundingBox.height)}px)
`)),g.selectedText&&(_+=`**Selected text:** "${g.selectedText}"
`),r==="detailed"&&g.nearbyText&&!g.selectedText&&(_+=`**Context:** ${g.nearbyText.slice(0,100)}
`),_+=`**Feedback:** ${g.comment}

`)}),_.trim()}function ug(s,i,r="markdown"){return r==="markdown"?i:[...new Set(s.map(u=>r==="source"?u.sourceFile:r==="classes"?u.cssClasses:u.attributes?.[r.attribute]).filter(u=>typeof u=="string"&&u.length>0))].join(`
`)}async function r4(s){if(typeof window>"u")return!1;try{if(navigator.clipboard?.writeText)return await navigator.clipboard.writeText(s),!0}catch{}return c4(s)}function c4(s){let i=document.createElement("textarea"),r=document.activeElement;for(;r?.shadowRoot?.activeElement;)r=r.shadowRoot.activeElement;let u=r instanceof HTMLInputElement||r instanceof HTMLTextAreaElement?r:null,d=u&&u.selectionStart!==null?{start:u.selectionStart,end:u.selectionEnd,direction:u.selectionDirection}:null,_=document.getSelection(),g=_?Array.from({length:_.rangeCount},(w,y)=>_.getRangeAt(y).cloneRange()):[];try{return i.value=s,i.setAttribute("readonly",""),i.style.cssText="position:fixed;left:-9999px;top:0;opacity:0;pointer-events:none;",document.body.appendChild(i),i.focus({preventScroll:!0}),i.select(),i.setSelectionRange(0,s.length),document.execCommand("copy")}catch{return!1}finally{if(i.remove(),r instanceof HTMLElement&&r.isConnected&&(r.focus({preventScroll:!0}),u&&d&&u.setSelectionRange(d.start,d.end,d.direction)),_){_.removeAllRanges();for(let w of g)_.addRange(w)}}}function dg(s){if(!s)return s;try{let i=new URL(s,"http://agentation.invalid");return i.pathname+i.search+i.hash}catch{return s}}function _g(s,i,r=[]){let u=new Map,d=new Map(r.map(w=>[w.id,w])),_=!1;async function g(w,y){if(_||y.running||y.timer)return;let E=y.desired,M=i.get(w);if(!E&&!M){u.delete(w),i.delete(w);return}let S=E?JSON.stringify(E):void 0;if(!(E&&M&&y.synced===S)){y.running=!0;try{if(!E)await s.remove(M),i.delete(w),y.synced=void 0;else if(M)await s.update(M,E),y.synced=S;else{i.set(w,"");let O=await s.create(E);i.set(w,O.id),y.synced=S}y.retries=0,y.running=!1,!_&&u.get(w)===y&&g(w,y)}catch(O){if(y.running=!1,!_&&u.get(w)===y&&(console.warn("[Agentation] Failed to sync layout feedback:",O),i.get(w)&&y.retries<3)){let W=500*2**y.retries++;y.timer=_e(()=>{y.timer=void 0,g(w,y)},W)}}}}return{replace(w){let y=new Map(w.map(E=>[E.id,E]));for(let[E,M]of y){let S=u.get(E);if(!S){S={running:!1,retries:0},u.set(E,S);let O=[...d.values()].find(W=>W.kind===M.kind&&dg(W.url)===dg(M.url)&&(M.kind==="placement"?W.timestamp===M.timestamp&&W.element===M.element:W.element===M.element));O&&(i.set(E,O.id),d.delete(O.id))}JSON.stringify(S.desired)!==JSON.stringify(M)&&(S.retries=0,S.timer&&clearTimeout(S.timer),S.timer=void 0),S.desired=M}for(let[E,M]of u)y.has(E)||(M.desired=void 0),g(E,M)},forget(w){let y=u.get(w);y?.timer&&clearTimeout(y.timer),u.delete(w),i.delete(w)},dispose(){_=!0;for(let w of u.values())w.timer&&clearTimeout(w.timer)}}}function u4(s,i,r,u){let d=!1,_,g,w=1e3,y,E=W=>{!d&&(W?.status==="resolved"||W?.status==="dismissed")&&u(W)},M=async()=>{if(d||y||!r())return;let W=new AbortController;y=W;let H=_e(()=>W.abort(),5e3);try{let te=await fetch(`${s}/sessions/${i}`,{signal:W.signal});if(!te.ok)return;let B=await te.json();!d&&!W.signal.aborted&&Array.isArray(B.annotations)&&B.annotations.forEach(E)}catch{}finally{clearTimeout(H),y===W&&(y=void 0)}},S=()=>{if(d)return;let W=new EventSource(`${s}/sessions/${i}/events`),H=()=>{w=1e3,M()},te=K=>{try{E(JSON.parse(K.data).payload)}catch{}},B=()=>{W.readyState!==EventSource.CLOSED||d||g!==void 0||(_?.(),g=_e(()=>{g=void 0,S()},w),w=Math.min(w*2,1e4))};W.addEventListener("open",H),W.addEventListener("annotation.updated",te),W.addEventListener("error",B),_=()=>{W.removeEventListener("open",H),W.removeEventListener("annotation.updated",te),W.removeEventListener("error",B),W.close()}};S();let O=be(()=>{M()},1e4);return()=>{d=!0,_?.(),g!==void 0&&clearTimeout(g),clearInterval(O),y?.abort()}}var fl=tn(),d4=`.styles-module__surface___7qnpJ {
  padding: 0;
  width: var(--preview-width, 200px);
  max-width: calc(100vw - 24px);
  overflow: auto;
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  border-radius: 12px;
  z-index: inherit;
  will-change: auto;
  transform: translateX(-50%);
  transition: left 200ms cubic-bezier(0.2, 0.8, 0.2, 1), top 200ms cubic-bezier(0.2, 0.8, 0.2, 1), transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1), width 200ms cubic-bezier(0.2, 0.8, 0.2, 1), opacity 100ms ease-out, visibility 0s 200ms;
}
.styles-module__surface___7qnpJ[data-positioning] {
  transition: none;
}
.styles-module__surface___7qnpJ[data-direct-entry] *, .styles-module__surface___7qnpJ[data-direct-entry] *::before, .styles-module__surface___7qnpJ[data-direct-entry] *::after {
  transition: none !important;
}
.styles-module__surface___7qnpJ[data-state=preview], .styles-module__surface___7qnpJ[data-state=edit] {
  opacity: 1;
  visibility: visible;
  transition-delay: 0s;
}
.styles-module__surface___7qnpJ[data-state=edit], .styles-module__surface___7qnpJ[data-annotation-popup][data-state=hidden] {
  width: 280px;
  border-radius: 16px;
}
.styles-module__surface___7qnpJ[data-state=edit] {
  pointer-events: auto;
}
.styles-module__surface___7qnpJ[data-state=preview] {
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.08);
}
[data-agentation-theme=light] .styles-module__surface___7qnpJ[data-state=preview] {
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.12), 0 0 0 1px rgba(0, 0, 0, 0.06);
}

@media (prefers-reduced-motion: reduce) {
  .styles-module__surface___7qnpJ {
    transition: opacity 100ms ease-out, visibility 0s 100ms;
  }
}`,_4={surface:"styles-module__surface___7qnpJ"},fg=Tn(),f4=(0,fl.forwardRef)(function({annotation:i,editing:r,exiting:u,restorePreview:d,editorProps:_,lightMode:g,scrollY:w,onExited:y},E){let M=(0,fl.useRef)({annotation:i,editorProps:_}),S=i??M.current.annotation,O=i?_:M.current.editorProps,W=(0,fl.useRef)(null),H=(0,fl.useRef)(null),te=(0,fl.useRef)(),B=(0,fl.useRef)(w),K=r&&!u?"edit":i&&(!r||d)?"preview":"hidden",Se=K==="preview"||!r;return(0,fl.useLayoutEffect)(()=>{i&&(M.current={annotation:i,editorProps:_})},[i,_]),(0,fl.useLayoutEffect)(()=>{let G=W.current;if(!G||!S)return;let P=K==="edit"&&(te.current!==S.id||G.dataset.state==="hidden"&&getComputedStyle(G).opacity==="0");P&&(G.dataset.directEntry="true");let tt=()=>{let Ue=S.x/100*window.innerWidth,oe=S.isFixed?S.y:S.y-w,ze=K==="preview"||!r,Re=parseFloat(G.style.getPropertyValue("--preview-width"))||200,me=Math.min(Re,window.innerWidth-24),De=Math.max(12,Math.min(window.innerWidth-me-12,Ue-me/2)),xe=ze?me:Math.min(280,window.innerWidth-24),ye=Math.min(ze?12:20,(window.innerWidth-xe)/2),Le=oe>window.innerHeight-(ze?101:290);G.style.left=`${Math.max(ye,Math.min(window.innerWidth-xe-ye,De))}px`,G.style.right="auto",G.style.top=`${Math.max(12,Math.min(window.innerHeight-12,oe+(Le?-21:21)))}px`,G.style.bottom="auto",G.style.transform=Le?"translateY(-100%)":"translateY(0)",G.style.maxHeight=`${Math.max(100,Le?oe-33:window.innerHeight-oe-33)}px`},ut=te.current!==S.id||B.current!==w||G.dataset.state==="hidden";ut&&(G.dataset.positioning="true"),tt(),(ut||P)&&G.getBoundingClientRect(),delete G.dataset.positioning,delete G.dataset.directEntry,G.dataset.state=K,G.inert=K!=="edit",te.current=S.id,B.current=w;let se=()=>{G.dataset.positioning="true",tt(),G.getBoundingClientRect(),delete G.dataset.positioning};return window.addEventListener("resize",se),()=>window.removeEventListener("resize",se)},[S?.id,S?.x,S?.y,S?.isFixed,K,r,w,S?.comment]),(0,fl.useLayoutEffect)(()=>{r&&!u&&H.current?.focus()},[r,u,S?.id]),b_(W,u,y),(0,fl.useImperativeHandle)(E,()=>({shake(){W.current?.animate?.([{translate:"0px"},{translate:"-3px"},{translate:"3px"},{translate:"-2px"},{translate:"2px"},{translate:"0px"}],{duration:250}),H.current?.focus()}}),[]),!S||!O?null:(0,fg.jsx)("div",{ref:W,className:`${rt.popup} ${_4.surface} ${g?rt.light:""}`,"data-feedback-toolbar":!0,"data-annotation-card":!0,"data-annotation-popup":r?"":void 0,"data-state":"hidden","aria-hidden":K==="hidden",onClick:G=>G.stopPropagation(),onKeyDownCapture:G=>{G.key!=="Escape"||G.nativeEvent.isComposing||!r||(G.preventDefault(),G.stopPropagation(),O.onCancel())},children:(0,fg.jsx)(Sh,{ref:H,...O,variant:"card",preview:Se,resetOnPreview:!r,disabled:!r||u},S.id)})}),ma=tn(),m4=`@keyframes styles-module__markerIn___x4G8D {
  0% {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.3);
  }
  100% {
    opacity: 1;
    transform: translate(-50%, -50%) scale(1);
  }
}
@keyframes styles-module__markerOut___6VhQN {
  0% {
    opacity: 1;
    transform: translate(-50%, -50%) scale(1);
  }
  100% {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.3);
  }
}
@keyframes styles-module__renumberRoll___akV9B {
  0% {
    transform: translateX(-40%);
    opacity: 0;
  }
  100% {
    transform: translateX(0);
    opacity: 1;
  }
}
.styles-module__marker___9CKF7 {
  padding: 0;
  border: 0;
  box-sizing: border-box;
  font-family: inherit;
  line-height: 1;
  text-align: center;
  appearance: none;
  position: absolute;
  width: 22px;
  height: 22px;
  background: var(--agentation-color-blue);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.6875rem;
  font-weight: 600;
  transform: translate(-50%, -50%) scale(1);
  opacity: 1;
  cursor: pointer;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2), inset 0 0 0 1px rgba(0, 0, 0, 0.04);
  -webkit-user-select: none;
  user-select: none;
  will-change: transform, opacity;
  contain: layout style;
  z-index: 1;
}
.styles-module__marker___9CKF7 > * {
  pointer-events: none;
}
.styles-module__marker___9CKF7:focus-visible {
  outline: 2px solid var(--agentation-color-accent);
  outline-offset: 3px;
}
.styles-module__marker___9CKF7:hover, .styles-module__marker___9CKF7:focus-visible, .styles-module__marker___9CKF7.styles-module__previewVisible___imMag {
  z-index: 2;
}
.styles-module__marker___9CKF7:not(.styles-module__enter___8kI3q):not(.styles-module__exit___KBdR3):not(.styles-module__clearing___8rM7K):not(.styles-module__confirm___BtMvq) {
  transition: background-color 0.15s ease, transform 0.1s ease, z-index 0s 0.1s;
}
.styles-module__marker___9CKF7:not(.styles-module__enter___8kI3q):not(.styles-module__exit___KBdR3):not(.styles-module__clearing___8rM7K):not(.styles-module__confirm___BtMvq):hover, .styles-module__marker___9CKF7:not(.styles-module__enter___8kI3q):not(.styles-module__exit___KBdR3):not(.styles-module__clearing___8rM7K):not(.styles-module__confirm___BtMvq):focus-visible, .styles-module__marker___9CKF7:not(.styles-module__enter___8kI3q):not(.styles-module__exit___KBdR3):not(.styles-module__clearing___8rM7K):not(.styles-module__confirm___BtMvq).styles-module__previewVisible___imMag {
  transition-delay: 0s;
}
.styles-module__marker___9CKF7.styles-module__enter___8kI3q {
  animation: styles-module__markerIn___x4G8D 0.25s cubic-bezier(0.22, 1, 0.36, 1) both;
}
.styles-module__marker___9CKF7.styles-module__confirm___BtMvq {
  animation: styles-module__markerConfirm___RT4Sk 220ms ease-out both;
}
.styles-module__marker___9CKF7.styles-module__exit___KBdR3 {
  animation: styles-module__markerOut___6VhQN 0.2s ease-out both;
  pointer-events: none;
}
.styles-module__marker___9CKF7.styles-module__clearing___8rM7K {
  animation: styles-module__markerOut___6VhQN 0.15s ease-out both;
  pointer-events: none;
}
.styles-module__marker___9CKF7:not(.styles-module__enter___8kI3q):not(.styles-module__exit___KBdR3):not(.styles-module__clearing___8rM7K):not(.styles-module__confirm___BtMvq):hover {
  transform: translate(-50%, -50%) scale(1.1);
}
.styles-module__marker___9CKF7.styles-module__pending___BiY-U {
  background-color: var(--agentation-color-blue);
  cursor: default;
}
.styles-module__marker___9CKF7.styles-module__pending___BiY-U.styles-module__exit___KBdR3 {
  animation-duration: 150ms;
}
.styles-module__marker___9CKF7.styles-module__multiSelect___CPfTC {
  background-color: var(--agentation-color-green);
  width: 26px;
  height: 26px;
  border-radius: 6px;
  font-size: 0.75rem;
}
.styles-module__marker___9CKF7.styles-module__multiSelect___CPfTC.styles-module__pending___BiY-U {
  background-color: var(--agentation-color-green);
}
.styles-module__marker___9CKF7.styles-module__hovered___-mg2N {
  background-color: var(--agentation-color-red);
}

.styles-module__renumber___16lvD {
  display: block;
  animation: styles-module__renumberRoll___akV9B 0.2s ease-out;
}

@keyframes styles-module__markerConfirm___RT4Sk {
  0% {
    transform: translate(-50%, -50%) scale(1);
  }
  25% {
    transform: translate(-50%, -50%) scale(0.94);
  }
  65% {
    transform: translate(-50%, -50%) scale(1.06);
  }
  100% {
    transform: translate(-50%, -50%) scale(1);
  }
}
.styles-module__number___1JFu9 {
  display: block;
}

.styles-module__numberGlyph___qchdk {
  display: block;
  opacity: 1;
  transform: translateY(0);
  filter: blur(0);
  transition: opacity 140ms ease-out, transform 180ms cubic-bezier(0.22, 1, 0.36, 1), filter 140ms ease-out;
}

.styles-module__actionGlyph___AFRt0 {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  opacity: 0;
  transform: translateY(2px) scale(0.8) rotate(-12deg);
  filter: blur(1px);
  transition: opacity 120ms ease-out, transform 160ms cubic-bezier(0.22, 1, 0.36, 1), filter 120ms ease-out;
}

.styles-module__actionVisible___Kb--l .styles-module__numberGlyph___qchdk {
  opacity: 0;
  transform: translateY(-2px) scale(0.8);
  filter: blur(1px);
}
.styles-module__actionVisible___Kb--l .styles-module__actionGlyph___AFRt0 {
  opacity: 1;
  transform: translateY(0) scale(1) rotate(0);
  filter: blur(0);
}

.styles-module__plus___xslMP {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  opacity: 0;
  transform: rotate(-90deg) scale(0.6);
  filter: blur(1px);
  transition: opacity 100ms ease-out, transform 140ms ease-out, filter 100ms ease-out;
  pointer-events: none;
}

.styles-module__pending___BiY-U .styles-module__numberGlyph___qchdk {
  opacity: 0;
  transform: translateY(5px);
  filter: blur(2px);
}
.styles-module__pending___BiY-U .styles-module__plus___xslMP {
  opacity: 1;
  transform: rotate(0) scale(1);
  filter: blur(0);
}

@media (prefers-reduced-motion: reduce) {
  .styles-module__marker___9CKF7.styles-module__enter___8kI3q, .styles-module__marker___9CKF7.styles-module__exit___KBdR3, .styles-module__marker___9CKF7.styles-module__clearing___8rM7K, .styles-module__marker___9CKF7.styles-module__confirm___BtMvq {
    animation-duration: 1ms;
    animation-delay: 0ms !important;
  }
  .styles-module__numberGlyph___qchdk, .styles-module__actionGlyph___AFRt0, .styles-module__plus___xslMP {
    transition: opacity 100ms ease-out;
    transform: none;
    filter: none;
  }
  .styles-module__pending___BiY-U .styles-module__numberGlyph___qchdk, .styles-module__pending___BiY-U .styles-module__plus___xslMP,
  .styles-module__actionVisible___Kb--l .styles-module__numberGlyph___qchdk, .styles-module__actionVisible___Kb--l .styles-module__actionGlyph___AFRt0 {
    transform: none;
    filter: none;
  }
}`,Yn={marker:"styles-module__marker___9CKF7",previewVisible:"styles-module__previewVisible___imMag",enter:"styles-module__enter___8kI3q",exit:"styles-module__exit___KBdR3",clearing:"styles-module__clearing___8rM7K",confirm:"styles-module__confirm___BtMvq",markerIn:"styles-module__markerIn___x4G8D",markerConfirm:"styles-module__markerConfirm___RT4Sk",markerOut:"styles-module__markerOut___6VhQN",pending:"styles-module__pending___BiY-U",multiSelect:"styles-module__multiSelect___CPfTC",hovered:"styles-module__hovered___-mg2N",renumber:"styles-module__renumber___16lvD",renumberRoll:"styles-module__renumberRoll___akV9B",number:"styles-module__number___1JFu9",numberGlyph:"styles-module__numberGlyph___qchdk",actionGlyph:"styles-module__actionGlyph___AFRt0",actionVisible:"styles-module__actionVisible___Kb--l",plus:"styles-module__plus___xslMP"},ha=Tn(),mg=(0,ma.memo)(function({annotation:i,pending:r=!1,globalIndex:u,layerIndex:d,layerSize:_,isExiting:g,isClearing:w,isAnimated:y,isNew:E,isHovered:M,isRemoving:S,onRemoveComplete:O,isEditingAny:W,renumberFrom:H,markerClickBehavior:te,onHoverEnter:B,onEnterComplete:K,onHoverLeave:Se,onClick:G,onContextMenu:P}){let[tt,ut]=(0,ma.useState)(y),se=(0,ma.useRef)(r),[Ue,oe]=(0,ma.useState)(!1),ze=se.current&&!r&&tt&&!Ue;(0,ma.useLayoutEffect)(()=>{g&&ut(!1)},[g]);let Re=(0,ma.useRef)(null),me=(0,ma.useRef)({action:!1,delete:!1}),De=M&&!W,xe=De&&te==="delete";(0,ma.useLayoutEffect)(()=>{S||(me.current={action:De,delete:xe})},[S,De,xe]);let ye=S?me.current.action:De,Le=S?me.current.delete:xe;b_(Re,S,()=>O(i.id));let rn=i.isMultiSelect,_t=rn?"var(--agentation-color-green)":"var(--agentation-color-accent)",St=w?Yn.clearing:g||S?Yn.exit:ze?Yn.confirm:!y&&!tt?Yn.enter:"",ft=w?`${Math.min(d*20,120)}ms`:S||r||ze?"0ms":g?`${(_-1-d)*20}ms`:`${E?0:d*20}ms`;return(0,ha.jsxs)("button",{ref:Re,type:"button","aria-label":r?"\u041D\u043E\u0432\u043E\u0435 \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435":`${te==="delete"?"\u0423\u0434\u0430\u043B\u0438\u0442\u044C":"\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C"} \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435 ${u+1}: ${i.element}`,disabled:r||g||S||w,tabIndex:r||W?-1:0,className:`${Yn.marker} ${r?Yn.pending:""} ${rn?Yn.multiSelect:""} ${St} ${!r&&ye?Yn.actionVisible:""} ${Le?Yn.hovered:""} ${M&&!W&&!S?Yn.previewVisible:""}`,"data-annotation-marker":r?void 0:"","data-annotation-pending":r?"":void 0,style:{left:`${i.x}%`,top:i.y,backgroundColor:Le?void 0:_t,animationDelay:ft},onAnimationEnd:Vt=>{Vt.target===Vt.currentTarget&&(St===Yn.enter||St===Yn.confirm)&&(ut(!0),r||oe(!0),r||K(i.id))},onMouseOver:()=>{r||B(i)},onMouseOut:Vt=>{let qn=Vt.relatedTarget;(!(qn instanceof Node)||!Vt.currentTarget.contains(qn))&&Se(i.id)},onFocus:Vt=>{!r&&Vt.currentTarget.matches(":focus-visible")&&B(i)},onBlur:()=>Se(i.id),onClick:Vt=>{Vt.stopPropagation(),!r&&!g&&!S&&G(i,Vt.currentTarget)},onContextMenu:P?Vt=>{te==="delete"&&(Vt.preventDefault(),Vt.stopPropagation(),!r&&!g&&!S&&P(i,Vt.currentTarget))}:void 0,children:[(0,ha.jsx)("span",{className:`${Yn.number} ${H!==null&&u>=H?Yn.renumber:""}`,"aria-hidden":"true",children:(0,ha.jsx)("span",{className:Yn.numberGlyph,children:u+1})},u),(0,ha.jsx)("span",{className:Yn.actionGlyph,"aria-hidden":"true",children:te==="delete"?(0,ha.jsx)(Eh,{size:rn?18:16}):(0,ha.jsx)(Nh,{size:16})}),se.current&&(0,ha.jsx)("span",{className:Yn.plus,"aria-hidden":"true",children:(0,ha.jsx)(Ch,{size:12})})]})}),pr=tn(),h4=`.styles-module__switchContainer___Ka-AB {
  display: flex;
  align-items: center;
  position: relative;
  padding: 2px;
  width: 24px;
  height: 16px;
  border-radius: 8px;
  background-color: #cdcdcd;
  transition: background-color 0.15s, opacity 0.15s;
}
[data-agentation-theme=dark] .styles-module__switchContainer___Ka-AB {
  background-color: #484848;
}
.styles-module__switchContainer___Ka-AB:has(.styles-module__switchInput___kYDSD:checked) {
  background-color: var(--agentation-color-blue);
}
.styles-module__switchContainer___Ka-AB:has(.styles-module__switchInput___kYDSD:disabled) {
  opacity: 0.3;
}

.styles-module__switchInput___kYDSD {
  position: absolute;
  z-index: 1;
  inset: 0;
  border-radius: inherit;
  opacity: 0;
  cursor: pointer;
}
.styles-module__switchInput___kYDSD:disabled {
  cursor: not-allowed;
}

.styles-module__switchThumb___4sCPH {
  border-radius: 50%;
  width: 12px;
  height: 12px;
  background-color: #fff;
  transition: transform 0.15s;
}
.styles-module__switchContainer___Ka-AB[data-checked] .styles-module__switchThumb___4sCPH {
  transform: translateX(8px);
}`,B_={switchContainer:"styles-module__switchContainer___Ka-AB",switchInput:"styles-module__switchInput___kYDSD",switchThumb:"styles-module__switchThumb___4sCPH"},H_=Tn(),U_=({className:s="",checked:i,onChange:r,...u})=>(0,H_.jsxs)("div",{className:`${B_.switchContainer} ${s}`,"data-checked":i?"":void 0,children:[(0,H_.jsx)("input",{className:B_.switchInput,checked:i,onChange:r,type:"checkbox",...u}),(0,H_.jsx)("div",{className:B_.switchThumb})]}),g4=tn(),p4=`.styles-module__checkboxContainer___joqZk {
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  border: 1px solid rgba(26, 26, 26, 0.2);
  border-radius: 4px;
  width: 14px;
  height: 14px;
  background-color: #fff;
  transition: background-color 0.2s ease;
}
[data-agentation-theme=dark] .styles-module__checkboxContainer___joqZk {
  border-color: rgba(255, 255, 255, 0.2);
  background-color: #252525;
}
.styles-module__checkboxContainer___joqZk:has(.styles-module__checkboxInput___ECzzO:checked) {
  background-color: #1a1a1a;
}
[data-agentation-theme=dark] .styles-module__checkboxContainer___joqZk:has(.styles-module__checkboxInput___ECzzO:checked) {
  background-color: #fff;
}

.styles-module__checkboxInput___ECzzO {
  position: absolute;
  z-index: 1;
  inset: -1px;
  border-radius: inherit;
  opacity: 0;
  cursor: pointer;
}

.styles-module__checkboxCheck___fUXpr {
  color: #fafafa;
}
[data-agentation-theme=dark] .styles-module__checkboxCheck___fUXpr {
  color: #1a1a1a;
}

.styles-module__checkboxCheckPath___cDyh8 {
  stroke-dasharray: 9.29px;
  stroke-dashoffset: 9.29px;
  color: #fafafa;
  transition: stroke-dashoffset 0.1s ease;
}
[data-agentation-theme=dark] .styles-module__checkboxCheckPath___cDyh8 {
  color: #1a1a1a;
}
.styles-module__checkboxContainer___joqZk[data-checked] .styles-module__checkboxCheckPath___cDyh8 {
  transition-duration: 0.2s;
  stroke-dashoffset: 0;
}`,nu={checkboxContainer:"styles-module__checkboxContainer___joqZk",checkboxInput:"styles-module__checkboxInput___ECzzO",checkboxCheck:"styles-module__checkboxCheck___fUXpr",checkboxCheckPath:"styles-module__checkboxCheckPath___cDyh8"},ou=Tn(),y4=({className:s="",checked:i,onChange:r,...u})=>(0,ou.jsxs)("div",{className:`${nu.checkboxContainer} ${s}`,"data-checked":i?"":void 0,children:[(0,ou.jsx)("input",{className:nu.checkboxInput,type:"checkbox",checked:i,onChange:r,...u}),(0,ou.jsx)("svg",{className:nu.checkboxCheck,width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",children:(0,ou.jsx)("path",{className:nu.checkboxCheckPath,d:"M3.94 7L6.13 9.19L10.5 4.81",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})})]}),x4=`.styles-module__container___w8eAF {
  display: flex;
  align-items: center;
  height: 24px;
}

.styles-module__label___J5mxE {
  padding-inline: 8px 2px;
  line-height: 20px;
  font-size: 13px;
  letter-spacing: -0.15px;
  color: rgba(26, 26, 26, 0.5);
  -webkit-user-select: none;
  user-select: none;
  cursor: pointer;
}
[data-agentation-theme=dark] .styles-module__label___J5mxE {
  color: rgba(255, 255, 255, 0.5);
}`,hg={container:"styles-module__container___w8eAF",label:"styles-module__label___J5mxE"},lu=Tn(),gg=({className:s="",label:i,tooltip:r,checked:u,onChange:d,..._})=>{let g=(0,g4.useId)();return(0,lu.jsxs)("div",{className:`${hg.container} ${s}`,..._,children:[(0,lu.jsx)(y4,{id:g,onChange:d,checked:u}),(0,lu.jsx)("label",{className:hg.label,htmlFor:g,children:i}),r&&(0,lu.jsx)(as,{content:r})]})},b4=`@keyframes styles-module__cycleTextIn___VBNTi {
  0% {
    opacity: 0;
    transform: translateY(-6px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
@keyframes styles-module__scaleIn___QpQ8E {
  from {
    opacity: 0;
    transform: scale(0.85);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes styles-module__mcpPulse___5Q3Jj {
  0% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-green) 50%, transparent);
  }
  70% {
    box-shadow: 0 0 0 6px color-mix(in srgb, var(--agentation-color-green) 0%, transparent);
  }
  100% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-green) 0%, transparent);
  }
}
@keyframes styles-module__mcpPulseError___VHxhx {
  0% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-red) 50%, transparent);
  }
  70% {
    box-shadow: 0 0 0 6px color-mix(in srgb, var(--agentation-color-red) 0%, transparent);
  }
  100% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--agentation-color-red) 0%, transparent);
  }
}
@keyframes styles-module__themeIconIn___qUWMV {
  0% {
    opacity: 0;
    transform: scale(0.8) rotate(-30deg);
  }
  100% {
    opacity: 1;
    transform: scale(1) rotate(0deg);
  }
}
.styles-module__settingsPanel___qNkn- :where(button, a, input, select, textarea):focus-visible {
  outline: 2px solid var(--agentation-color-accent);
  outline-offset: 2px;
}
.styles-module__settingsPanel___qNkn- {
  position: absolute;
  right: 5px;
  bottom: calc(100% + 0.5rem);
  z-index: 1;
  overflow: hidden;
  background: #1c1c1c;
  border-radius: 16px;
  padding: 12px 0;
  width: 253px;
  max-width: calc(100vw - 20px);
  cursor: default;
  opacity: 1;
  box-shadow: 0 1px 8px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(0, 0, 0, 0.04);
  transition: background-color 0.25s ease, box-shadow 0.25s ease;
}
.styles-module__settingsPanel___qNkn-::before, .styles-module__settingsPanel___qNkn-::after {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  width: 16px;
  z-index: 2;
  pointer-events: none;
}
.styles-module__settingsPanel___qNkn-::before {
  left: 0;
  background: linear-gradient(to right, #1c1c1c 0%, transparent 100%);
}
.styles-module__settingsPanel___qNkn-::after {
  right: 0;
  background: linear-gradient(to left, #1c1c1c 0%, transparent 100%);
}
.styles-module__settingsPanel___qNkn- .styles-module__settingsHeader___Fn1DP,
.styles-module__settingsPanel___qNkn- .styles-module__settingsBrand___OoKlM,
.styles-module__settingsPanel___qNkn- .styles-module__settingsVersion___rXmL9,
.styles-module__settingsPanel___qNkn- .styles-module__settingsSection___n5V-4,
.styles-module__settingsPanel___qNkn- .styles-module__settingsLabel___VCVOQ,
.styles-module__settingsPanel___qNkn- .styles-module__cycleButton___XMBx3,
.styles-module__settingsPanel___qNkn- .styles-module__cycleDot___zgSXY,
.styles-module__settingsPanel___qNkn- .styles-module__dropdownButton___mKHe8,
.styles-module__settingsPanel___qNkn- .styles-module__sliderLabel___6K5v1,
.styles-module__settingsPanel___qNkn- .styles-module__slider___v5z-c,
.styles-module__settingsPanel___qNkn- .styles-module__themeToggle___3imlT {
  transition: background-color 0.25s ease, color 0.25s ease, border-color 0.25s ease;
}
.styles-module__settingsPanel___qNkn- {
  opacity: 0;
  transform: translateY(var(--panel-offset-y, 4px)) scale(0.98);
  transform-origin: var(--panel-origin, bottom right);
  filter: blur(2px);
  pointer-events: none;
  visibility: hidden;
  transition: opacity 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.styles-module__settingsPanel___qNkn-[data-panel-present=true] {
  visibility: visible;
}
.styles-module__settingsPanel___qNkn-[data-panel-open=true] {
  opacity: 1;
  transform: translateY(0) scale(1);
  filter: blur(0);
  pointer-events: auto;
  transition-duration: 160ms;
}
@media (prefers-reduced-motion: reduce) {
  .styles-module__settingsPanel___qNkn- {
    transition: none;
    transform: none;
    filter: none;
  }
}
.styles-module__settingsPanel___qNkn-.styles-module__below___Vpv-k {
  --panel-offset-y: -4px;
  --panel-origin: top right;
}
[data-agentation-theme=dark] .styles-module__settingsPanel___qNkn- {
  background: #1a1a1a;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.08);
}
[data-agentation-theme=dark] .styles-module__settingsPanel___qNkn- .styles-module__settingsLabel___VCVOQ {
  color: rgba(255, 255, 255, 0.6);
}
[data-agentation-theme=dark] .styles-module__settingsPanel___qNkn- .styles-module__settingsOption___JoyH- {
  color: rgba(255, 255, 255, 0.85);
}
[data-agentation-theme=dark] .styles-module__settingsPanel___qNkn- .styles-module__settingsOption___JoyH-:hover {
  background: rgba(255, 255, 255, 0.1);
}
[data-agentation-theme=dark] .styles-module__settingsPanel___qNkn- .styles-module__settingsOption___JoyH-.styles-module__selected___k1-Vq {
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}

.styles-module__settingsPanelContainer___5it-H {
  overflow: visible;
  position: relative;
  display: flex;
  padding: 0 16px;
}

.styles-module__settingsPage___BMn-3 {
  min-width: 100%;
  flex-basis: 0;
  flex-shrink: 0;
  transition: transform 0.2s ease, opacity 0.2s ease;
  transition-delay: 0s;
  opacity: 1;
}

.styles-module__settingsPage___BMn-3.styles-module__slideLeft___qUvW4 {
  transform: translateX(-24px);
  opacity: 0;
  pointer-events: none;
}

.styles-module__automationsPage___N7By0 {
  position: absolute;
  top: 0;
  left: 24px;
  width: 100%;
  height: 100%;
  padding: 0 16px 4px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  transition: transform 0.2s ease, opacity 0.2s ease;
  opacity: 0;
  pointer-events: none;
}

.styles-module__automationsPage___N7By0.styles-module__slideIn___uXDSu {
  transform: translateX(-24px);
  opacity: 1;
  pointer-events: auto;
}

.styles-module__settingsHeader___Fn1DP {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 24px;
}

.styles-module__settingsBrand___OoKlM {
  display: flex;
  align-items: center;
  font-size: 0.8125rem;
  font-weight: 500;
  letter-spacing: -0.0094em;
  color: #bbb;
  text-decoration: none;
}

.styles-module__settingsVersion___rXmL9 {
  font-size: 11px;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.4);
  margin-left: 6px;
  letter-spacing: -0.0094em;
}

.styles-module__themeToggle___3imlT {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  margin-left: auto;
  border: none;
  border-radius: 6px;
  background: transparent;
  color: rgba(255, 255, 255, 0.4);
  transition: background-color 0.15s ease, color 0.15s ease;
  cursor: pointer;
}
.styles-module__themeToggle___3imlT:hover {
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.8);
}
[data-agentation-theme=light] .styles-module__themeToggle___3imlT {
  color: rgba(0, 0, 0, 0.4);
}
[data-agentation-theme=light] .styles-module__themeToggle___3imlT:hover {
  background: rgba(0, 0, 0, 0.06);
  color: rgba(0, 0, 0, 0.7);
}

.styles-module__themeIconWrapper___pyaYa {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  width: 20px;
  height: 20px;
}

.styles-module__themeIcon___w7lAm {
  display: flex;
  align-items: center;
  justify-content: center;
  animation: styles-module__themeIconIn___qUWMV 0.35s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
}

.styles-module__settingsSectionGrow___eZTRw {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.styles-module__settingsRow___y-tDE {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 24px;
}
.styles-module__settingsRow___y-tDE.styles-module__settingsRowMarginTop___uLpGb {
  margin-top: 8px;
}

.styles-module__settingsRowDisabled___ydl3Q .styles-module__settingsLabel___VCVOQ {
  color: rgba(255, 255, 255, 0.2);
}
[data-agentation-theme=light] .styles-module__settingsRowDisabled___ydl3Q .styles-module__settingsLabel___VCVOQ {
  color: rgba(0, 0, 0, 0.2);
}

.styles-module__settingsLabel___VCVOQ {
  display: flex;
  align-items: center;
  column-gap: 2px;
  line-height: 20px;
  font-size: 13px;
  font-weight: 400;
  letter-spacing: -0.15px;
  color: rgba(255, 255, 255, 0.5);
}
[data-agentation-theme=light] .styles-module__settingsLabel___VCVOQ {
  color: rgba(0, 0, 0, 0.5);
}

.styles-module__cycleButton___XMBx3 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0;
  border: none;
  background: transparent;
  font-size: 0.8125rem;
  font-weight: 500;
  color: #fff;
  cursor: pointer;
  letter-spacing: -0.0094em;
}
[data-agentation-theme=light] .styles-module__cycleButton___XMBx3 {
  color: rgba(0, 0, 0, 0.85);
}
.styles-module__cycleButton___XMBx3:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}

.styles-module__cycleButtonText___mbbnD {
  display: inline-block;
  animation: styles-module__cycleTextIn___VBNTi 0.2s ease-out;
}

.styles-module__cycleDots___ehp6i {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.styles-module__cycleDot___zgSXY {
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.3);
  transform: scale(0.667);
  transition: background-color 0.25s ease-out, transform 0.25s ease-out;
}
.styles-module__cycleDot___zgSXY.styles-module__active___dpAhM {
  background: #fff;
  transform: scale(1);
}
[data-agentation-theme=light] .styles-module__cycleDot___zgSXY {
  background: rgba(0, 0, 0, 0.2);
}
[data-agentation-theme=light] .styles-module__cycleDot___zgSXY.styles-module__active___dpAhM {
  background: rgba(0, 0, 0, 0.7);
}

.styles-module__colorOptions___pbxZx {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 6px;
  height: 26px;
}

.styles-module__colorOption___Co955 {
  padding: 0;
  position: relative;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  background-color: #fff;
  cursor: pointer;
}
[data-agentation-theme=dark] .styles-module__colorOption___Co955 {
  background-color: #1a1a1a;
}
.styles-module__colorOption___Co955::before, .styles-module__colorOption___Co955::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background-color: var(--swatch);
  transition: opacity 0.2s, transform 0.2s;
}
@supports (color: color(display-p3 0 0 0)) {
  .styles-module__colorOption___Co955::before, .styles-module__colorOption___Co955::after {
    --color: var(--swatch-p3);
  }
}
.styles-module__colorOption___Co955::after {
  z-index: -1;
  transform: scale(1.2);
  opacity: 0;
}
.styles-module__colorOption___Co955.styles-module__selected___k1-Vq::before {
  transform: scale(0.8);
}
.styles-module__colorOption___Co955.styles-module__selected___k1-Vq::after {
  opacity: 1;
}

.styles-module__settingsNavLink___uYIwM {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 24px;
  padding: 0;
  border: none;
  background: transparent;
  font-family: inherit;
  line-height: 20px;
  font-size: 13px;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.5);
  transition: color 0.15s ease;
  cursor: pointer;
}
.styles-module__settingsNavLink___uYIwM:hover {
  color: rgba(255, 255, 255, 0.9);
}
.styles-module__settingsNavLink___uYIwM svg {
  color: rgba(255, 255, 255, 0.4);
  transition: color 0.15s ease;
}
.styles-module__settingsNavLink___uYIwM:hover svg {
  color: #fff;
}
[data-agentation-theme=light] .styles-module__settingsNavLink___uYIwM {
  color: rgba(0, 0, 0, 0.5);
}
[data-agentation-theme=light] .styles-module__settingsNavLink___uYIwM:hover {
  color: rgba(0, 0, 0, 0.8);
}
[data-agentation-theme=light] .styles-module__settingsNavLink___uYIwM svg {
  color: rgba(0, 0, 0, 0.25);
}
[data-agentation-theme=light] .styles-module__settingsNavLink___uYIwM:hover svg {
  color: rgba(0, 0, 0, 0.8);
}

.styles-module__settingsNavLinkRight___XBUzC {
  display: flex;
  align-items: center;
  gap: 6px;
}

.styles-module__settingsBackButton___fflll {
  display: flex;
  align-items: center;
  gap: 4px;
  height: 24px;
  border: none;
  background: transparent;
  font-family: inherit;
  line-height: 20px;
  font-size: 13px;
  font-weight: 500;
  letter-spacing: -0.15px;
  color: #fff;
  cursor: pointer;
  transition: transform 0.12s cubic-bezier(0.32, 0.72, 0, 1);
}
.styles-module__settingsBackButton___fflll svg {
  opacity: 0.4;
  flex-shrink: 0;
  transition: opacity 0.15s ease, transform 0.18s cubic-bezier(0.32, 0.72, 0, 1);
}
.styles-module__settingsBackButton___fflll:hover svg {
  opacity: 1;
}
[data-agentation-theme=light] .styles-module__settingsBackButton___fflll {
  color: rgba(0, 0, 0, 0.85);
  border-bottom-color: rgba(0, 0, 0, 0.08);
}

.styles-module__automationHeader___Avra9 {
  display: flex;
  align-items: center;
  gap: 0.125rem;
  font-size: 0.8125rem;
  font-weight: 400;
  color: #fff;
}
[data-agentation-theme=light] .styles-module__automationHeader___Avra9 {
  color: rgba(0, 0, 0, 0.85);
}

.styles-module__automationDescription___vFTmJ {
  font-size: 0.6875rem;
  font-weight: 300;
  color: rgba(255, 255, 255, 0.5);
  margin-top: 2px;
  line-height: 14px;
}
[data-agentation-theme=light] .styles-module__automationDescription___vFTmJ {
  color: rgba(0, 0, 0, 0.5);
}

.styles-module__learnMoreLink___cG7OI {
  color: rgba(255, 255, 255, 0.8);
  text-decoration-line: underline;
  text-decoration-style: dotted;
  text-decoration-color: rgba(255, 255, 255, 0.2);
  text-underline-offset: 2px;
  transition: color 0.15s ease;
}
.styles-module__learnMoreLink___cG7OI:hover {
  color: #fff;
}
[data-agentation-theme=light] .styles-module__learnMoreLink___cG7OI {
  color: rgba(0, 0, 0, 0.6);
  text-decoration-color: rgba(0, 0, 0, 0.2);
}
[data-agentation-theme=light] .styles-module__learnMoreLink___cG7OI:hover {
  color: rgba(0, 0, 0, 0.85);
}

.styles-module__autoSendContainer___VpkXk {
  display: flex;
  align-items: center;
}

.styles-module__autoSendLabel___ngNdC {
  padding-inline-end: 8px;
  font-size: 11px;
  font-weight: 400;
  color: rgba(255, 255, 255, 0.4);
  transition: color 0.15s, opacity 0.15s;
  cursor: pointer;
}
.styles-module__autoSendLabel___ngNdC.styles-module__active___dpAhM {
  color: #66b8ff;
  color: color(display-p3 0.4 0.72 1);
}
[data-agentation-theme=light] .styles-module__autoSendLabel___ngNdC {
  color: rgba(0, 0, 0, 0.4);
}
[data-agentation-theme=light] .styles-module__autoSendLabel___ngNdC.styles-module__active___dpAhM {
  color: var(--agentation-color-blue);
}
.styles-module__autoSendLabel___ngNdC.styles-module__disabled___9AZYS {
  opacity: 0.3;
  cursor: not-allowed;
}

.styles-module__mcpStatusDot___8AMxP {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}
.styles-module__mcpStatusDot___8AMxP.styles-module__connecting___QEO1r {
  background-color: var(--agentation-color-yellow);
  animation: styles-module__mcpPulse___5Q3Jj 1.5s infinite;
}
.styles-module__mcpStatusDot___8AMxP.styles-module__connected___WyFkx {
  background-color: var(--agentation-color-green);
  animation: styles-module__mcpPulse___5Q3Jj 2.5s ease-in-out infinite;
}
.styles-module__mcpStatusDot___8AMxP.styles-module__disconnected___mvmvQ {
  background-color: var(--agentation-color-red);
  animation: styles-module__mcpPulseError___VHxhx 2s infinite;
}

.styles-module__mcpNavIndicator___auBHI {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}
.styles-module__mcpNavIndicator___auBHI.styles-module__connected___WyFkx {
  background-color: var(--agentation-color-green);
  animation: styles-module__mcpPulse___5Q3Jj 2.5s ease-in-out infinite;
}
.styles-module__mcpNavIndicator___auBHI.styles-module__connecting___QEO1r {
  background-color: var(--agentation-color-yellow);
  animation: styles-module__mcpPulse___5Q3Jj 1.5s ease-in-out infinite;
}

.styles-module__webhookUrlInput___WDDDC {
  display: block;
  width: 100%;
  flex: 1;
  min-height: 60px;
  box-sizing: border-box;
  margin-top: 11px;
  padding: 8px 10px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 6px;
  background: rgba(255, 255, 255, 0.03);
  font-family: inherit;
  font-size: 0.75rem;
  font-weight: 400;
  color: #fff;
  outline: none;
  resize: none;
  user-select: text;
  transition: border-color 0.15s ease, background-color 0.15s ease, box-shadow 0.15s ease;
}
.styles-module__webhookUrlInput___WDDDC::placeholder {
  color: rgba(255, 255, 255, 0.3);
}
.styles-module__webhookUrlInput___WDDDC:focus {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.08);
}
[data-agentation-theme=light] .styles-module__webhookUrlInput___WDDDC {
  border-color: rgba(0, 0, 0, 0.1);
  background: rgba(0, 0, 0, 0.03);
  color: rgba(0, 0, 0, 0.85);
}
[data-agentation-theme=light] .styles-module__webhookUrlInput___WDDDC::placeholder {
  color: rgba(0, 0, 0, 0.3);
}
[data-agentation-theme=light] .styles-module__webhookUrlInput___WDDDC:focus {
  border-color: rgba(0, 0, 0, 0.25);
  background: rgba(0, 0, 0, 0.05);
}

[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- {
  background: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08), 0 4px 16px rgba(0, 0, 0, 0.06), 0 0 0 1px rgba(0, 0, 0, 0.04);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn-::before {
  background: linear-gradient(to right, #fff 0%, transparent 100%);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn-::after {
  background: linear-gradient(to left, #fff 0%, transparent 100%);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__settingsHeader___Fn1DP {
  border-bottom-color: rgba(0, 0, 0, 0.08);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__settingsBrand___OoKlM {
  color: #333;
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__settingsVersion___rXmL9 {
  color: rgba(0, 0, 0, 0.4);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__settingsSection___n5V-4 {
  border-top-color: rgba(0, 0, 0, 0.08);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__settingsLabel___VCVOQ {
  color: rgba(0, 0, 0, 0.5);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__cycleButton___XMBx3 {
  color: rgba(0, 0, 0, 0.85);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__cycleDot___zgSXY {
  background: rgba(0, 0, 0, 0.2);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__cycleDot___zgSXY.styles-module__active___dpAhM {
  background: rgba(0, 0, 0, 0.7);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__dropdownButton___mKHe8 {
  color: rgba(0, 0, 0, 0.85);
}
[data-agentation-theme=light] .styles-module__settingsPanel___qNkn- .styles-module__dropdownButton___mKHe8:hover {
  background: rgba(0, 0, 0, 0.05);
}

.styles-module__checkboxField___ZrSqv:not(:first-child) {
  margin-top: 8px;
}

.styles-module__divider___h6Yux {
  margin-block: 8px;
  width: 100%;
  height: 1px;
  background-color: rgba(26, 26, 26, 0.07);
}
[data-agentation-theme=dark] .styles-module__divider___h6Yux {
  background-color: rgba(255, 255, 255, 0.07);
}`,we={settingsPanel:"styles-module__settingsPanel___qNkn-",settingsHeader:"styles-module__settingsHeader___Fn1DP",settingsBrand:"styles-module__settingsBrand___OoKlM",settingsVersion:"styles-module__settingsVersion___rXmL9",settingsSection:"styles-module__settingsSection___n5V-4",settingsLabel:"styles-module__settingsLabel___VCVOQ",cycleButton:"styles-module__cycleButton___XMBx3",cycleDot:"styles-module__cycleDot___zgSXY",dropdownButton:"styles-module__dropdownButton___mKHe8",sliderLabel:"styles-module__sliderLabel___6K5v1",slider:"styles-module__slider___v5z-c",themeToggle:"styles-module__themeToggle___3imlT",below:"styles-module__below___Vpv-k",settingsOption:"styles-module__settingsOption___JoyH-",selected:"styles-module__selected___k1-Vq",settingsPanelContainer:"styles-module__settingsPanelContainer___5it-H",settingsPage:"styles-module__settingsPage___BMn-3",slideLeft:"styles-module__slideLeft___qUvW4",automationsPage:"styles-module__automationsPage___N7By0",slideIn:"styles-module__slideIn___uXDSu",themeIconWrapper:"styles-module__themeIconWrapper___pyaYa",themeIcon:"styles-module__themeIcon___w7lAm",themeIconIn:"styles-module__themeIconIn___qUWMV",settingsSectionGrow:"styles-module__settingsSectionGrow___eZTRw",settingsRow:"styles-module__settingsRow___y-tDE",settingsRowMarginTop:"styles-module__settingsRowMarginTop___uLpGb",settingsRowDisabled:"styles-module__settingsRowDisabled___ydl3Q",cycleButtonText:"styles-module__cycleButtonText___mbbnD",cycleTextIn:"styles-module__cycleTextIn___VBNTi",cycleDots:"styles-module__cycleDots___ehp6i",active:"styles-module__active___dpAhM",colorOptions:"styles-module__colorOptions___pbxZx",colorOption:"styles-module__colorOption___Co955",settingsNavLink:"styles-module__settingsNavLink___uYIwM",settingsNavLinkRight:"styles-module__settingsNavLinkRight___XBUzC",settingsBackButton:"styles-module__settingsBackButton___fflll",automationHeader:"styles-module__automationHeader___Avra9",automationDescription:"styles-module__automationDescription___vFTmJ",learnMoreLink:"styles-module__learnMoreLink___cG7OI",autoSendContainer:"styles-module__autoSendContainer___VpkXk",autoSendLabel:"styles-module__autoSendLabel___ngNdC",disabled:"styles-module__disabled___9AZYS",mcpStatusDot:"styles-module__mcpStatusDot___8AMxP",connecting:"styles-module__connecting___QEO1r",mcpPulse:"styles-module__mcpPulse___5Q3Jj",connected:"styles-module__connected___WyFkx",disconnected:"styles-module__disconnected___mvmvQ",mcpPulseError:"styles-module__mcpPulseError___VHxhx",mcpNavIndicator:"styles-module__mcpNavIndicator___auBHI",webhookUrlInput:"styles-module__webhookUrlInput___WDDDC",checkboxField:"styles-module__checkboxField___ZrSqv",divider:"styles-module__divider___h6Yux",scaleIn:"styles-module__scaleIn___QpQ8E"},ve=Tn(),v4=(0,pr.memo)(function({settings:i,onSettingsChange:r,isDarkMode:u,onToggleTheme:d,isDevMode:_,connectionStatus:g,endpoint:w,onExited:y,isOpen:E,toolbarNearBottom:M,settingsPage:S,onSettingsPageChange:O,onHideToolbar:W}){let{ref:H}=Bh(E,{keepMounted:!0,onExited:y}),te=(0,pr.useRef)(null),B=(0,pr.useRef)(null),K=(0,pr.useRef)(!1);(0,pr.useLayoutEffect)(()=>{!E||!K.current||(K.current=!1,(S==="automations"?B:te).current?.focus())},[E,S]);let Se=u?"Switch to light mode":"Switch to dark mode";return(0,ve.jsx)("div",{className:`${we.settingsPanel} ${M?we.below:""}`,style:M?{bottom:"auto",top:"calc(100% + 0.5rem)"}:void 0,"data-agentation-settings-panel":!0,ref:G=>{H.current=G,G?.toggleAttribute("inert",!E)},role:"group","aria-label":"Feedback settings","aria-hidden":!E,children:(0,ve.jsxs)("div",{className:we.settingsPanelContainer,children:[(0,ve.jsxs)("div",{className:`${we.settingsPage} ${S==="automations"?we.slideLeft:""}`,ref:G=>{G?.toggleAttribute("inert",S!=="main")},"aria-hidden":S!=="main",children:[(0,ve.jsxs)("div",{className:we.settingsHeader,children:[(0,ve.jsx)("a",{className:we.settingsBrand,href:"https://agentation.com",target:"_blank",rel:"noopener noreferrer","aria-label":"Agentation",children:"Agentation"}),(0,ve.jsxs)("p",{className:we.settingsVersion,children:["v","3.1.2"]}),(0,ve.jsx)("button",{className:we.themeToggle,onClick:d,title:Se,"aria-label":Se,children:(0,ve.jsx)("span",{className:we.themeIconWrapper,children:(0,ve.jsx)("span",{className:we.themeIcon,children:u?(0,ve.jsx)(Mh,{size:20}):(0,ve.jsx)(Th,{size:20})},u?"sun":"moon")})})]}),(0,ve.jsx)("div",{className:we.divider}),(0,ve.jsxs)("div",{className:we.settingsSection,children:[(0,ve.jsxs)("div",{className:we.settingsRow,children:[(0,ve.jsxs)("div",{className:we.settingsLabel,children:["Output Detail",(0,ve.jsx)(as,{content:"Controls how much detail is included in the copied output"})]}),(0,ve.jsxs)("button",{className:we.cycleButton,onClick:()=>{let P=(gr.findIndex(tt=>tt.value===i.outputDetail)+1)%gr.length;r({outputDetail:gr[P].value})},children:[(0,ve.jsx)("span",{className:we.cycleButtonText,children:gr.find(G=>G.value===i.outputDetail)?.label},i.outputDetail),(0,ve.jsx)("span",{className:we.cycleDots,children:gr.map(G=>(0,ve.jsx)("span",{className:`${we.cycleDot} ${i.outputDetail===G.value?we.active:""}`},G.value))})]})]}),(0,ve.jsxs)("div",{className:`${we.settingsRow} ${we.settingsRowMarginTop} ${_?"":we.settingsRowDisabled}`,children:[(0,ve.jsxs)("div",{className:we.settingsLabel,children:["React Components",(0,ve.jsx)(as,{content:_?"Include React component names in annotations":"Disabled \u2014 production builds minify component names, making detection unreliable. Use in development mode."})]}),(0,ve.jsx)(U_,{"aria-label":"React Components",checked:_&&i.reactEnabled,onChange:G=>r({reactEnabled:G.target.checked}),disabled:!_})]}),(0,ve.jsxs)("div",{className:`${we.settingsRow} ${we.settingsRowMarginTop}`,children:[(0,ve.jsxs)("div",{className:we.settingsLabel,children:["Hide Until Restart",(0,ve.jsx)(as,{content:"Hides the toolbar until you open a new tab"})]}),(0,ve.jsx)(U_,{"aria-label":"Hide Until Restart",checked:!1,onChange:G=>{G.target.checked&&W()}})]})]}),(0,ve.jsx)("div",{className:we.divider}),(0,ve.jsxs)("div",{className:we.settingsSection,children:[(0,ve.jsx)("div",{className:`${we.settingsLabel} ${we.settingsLabelMarker}`,children:"Marker Color"}),(0,ve.jsx)("div",{className:we.colorOptions,children:su.map(G=>(0,ve.jsx)("button",{className:`${we.colorOption} ${i.annotationColorId===G.id?we.selected:""}`,style:{"--swatch":G.srgb,"--swatch-p3":G.p3},onClick:()=>r({annotationColorId:G.id}),title:G.label,"aria-label":G.label,type:"button"},G.id))})]}),(0,ve.jsx)("div",{className:we.divider}),(0,ve.jsxs)("div",{className:we.settingsSection,children:[(0,ve.jsx)(gg,{className:"checkbox-field",label:"Clear on copy/send",checked:i.autoClearAfterCopy,onChange:G=>r({autoClearAfterCopy:G.target.checked}),tooltip:"Automatically clear annotations after copying"}),(0,ve.jsx)(gg,{className:we.checkboxField,label:"Block page interactions",checked:i.blockInteractions,onChange:G=>r({blockInteractions:G.target.checked})})]}),(0,ve.jsx)("div",{className:we.divider}),(0,ve.jsxs)("button",{className:we.settingsNavLink,ref:te,onClick:G=>{K.current=G.detail===0,G.currentTarget.blur(),O("automations")},children:[(0,ve.jsx)("span",{children:"Manage MCP & Webhooks"}),(0,ve.jsxs)("span",{className:we.settingsNavLinkRight,children:[w&&g!=="disconnected"&&(0,ve.jsx)("span",{className:`${we.mcpNavIndicator} ${we[g]}`}),(0,ve.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,ve.jsx)("path",{d:"M7.5 12.5L12 8L7.5 3.5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})})]})]})]}),(0,ve.jsxs)("div",{className:`${we.settingsPage} ${we.automationsPage} ${S==="automations"?we.slideIn:""}`,ref:G=>{G?.toggleAttribute("inert",S!=="automations")},"aria-hidden":S!=="automations",children:[(0,ve.jsxs)("button",{className:we.settingsBackButton,ref:B,"aria-label":"Back to settings",onClick:G=>{K.current=G.detail===0,G.currentTarget.blur(),O("main")},children:[(0,ve.jsx)(Rh,{size:16}),(0,ve.jsx)("span",{children:"Manage MCP & Webhooks"})]}),(0,ve.jsx)("div",{className:we.divider}),(0,ve.jsxs)("div",{className:we.settingsSection,children:[(0,ve.jsxs)("div",{className:we.settingsRow,children:[(0,ve.jsxs)("span",{className:we.automationHeader,children:["MCP Connection",(0,ve.jsx)(as,{content:"Connect via Model Context Protocol to let AI agents like Claude Code receive annotations in real-time."})]}),w&&(0,ve.jsx)("div",{className:`${we.mcpStatusDot} ${we[g]}`,title:g==="connected"?"Connected":g==="connecting"?"Connecting...":"Disconnected"})]}),(0,ve.jsxs)("p",{className:we.automationDescription,style:{paddingBottom:6},children:["MCP connection allows agents to receive and act on annotations."," ",(0,ve.jsx)("a",{href:"https://agentation.com/mcp",target:"_blank",rel:"noopener noreferrer",className:we.learnMoreLink,children:"Learn more"})]})]}),(0,ve.jsx)("div",{className:we.divider}),(0,ve.jsxs)("div",{className:`${we.settingsSection} ${we.settingsSectionGrow}`,children:[(0,ve.jsxs)("div",{className:we.settingsRow,children:[(0,ve.jsxs)("span",{className:we.automationHeader,children:["Webhooks",(0,ve.jsx)(as,{content:"Send annotation data to any URL endpoint when annotations change. Useful for custom integrations."})]}),(0,ve.jsxs)("div",{className:we.autoSendContainer,children:[(0,ve.jsx)("label",{htmlFor:"agentation-auto-send",className:`${we.autoSendLabel} ${i.webhooksEnabled?we.active:""} ${i.webhookUrl?"":we.disabled}`,children:"Auto-Send"}),(0,ve.jsx)(U_,{id:"agentation-auto-send",checked:i.webhooksEnabled,onChange:G=>r({webhooksEnabled:G.target.checked}),disabled:!i.webhookUrl})]})]}),(0,ve.jsx)("p",{className:we.automationDescription,children:"The webhook URL will receive live annotation changes and annotation data."}),(0,ve.jsx)("textarea",{className:we.webhookUrlInput,placeholder:"Webhook URL","aria-label":"Webhook URL",value:i.webhookUrl,onKeyDown:G=>G.stopPropagation(),onChange:G=>r({webhookUrl:G.target.value})})]})]})]})})}),pg=tn(),$_=Tn();function w4({x:s,y:i,elementName:r,reactComponents:u}){let d=(0,pg.useRef)(null);return(0,pg.useLayoutEffect)(()=>{let _=d.current;if(!_)return;let g=()=>{let w=_.offsetWidth,y=_.offsetHeight;_.style.left=`${Math.max(8,Math.min(s,window.innerWidth-w-8))}px`;let E=i-y-8;_.style.top=`${Math.max(8,Math.min(E,window.innerHeight-y-8))}px`};return g(),window.addEventListener("resize",g),()=>window.removeEventListener("resize",g)},[s,i,r,u]),(0,$_.jsxs)("div",{ref:d,className:`${fe.hoverTooltip} ${fe.enter}`,children:[u&&(0,$_.jsx)("div",{className:fe.hoverReactPath,children:u}),(0,$_.jsx)("div",{className:fe.hoverElementName,children:r})]})}var S4=`@charset "UTF-8";
/* Reset box-model and set borders */
/* ============================================ */
*,
::before,
::after {
  border-width: 0;
  border-style: solid;
  box-sizing: border-box;
}

/* Document */
/* ============================================ */
/**
 * 1. Correct line height in all browsers.
 * 2. Prevent adjustments of font size after orientation changes in iOS.
 * 3. Remove gray overlay on links for iOS.
 * 4. Render kerning consistently in all browsers.
 * 5. Correct font smoothing for macOS.
 */
:host {
  /* Inherited properties cross the shadow boundary, so a host page's
     text-transform, letter-spacing or font would otherwise restyle the UI. */
  font: 400 16px/1.5 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  font-variant: normal;
  color: initial;
  letter-spacing: normal;
  word-spacing: normal;
  text-transform: none;
  text-align: start;
  text-indent: 0;
  text-shadow: none;
  white-space: normal;
  direction: ltr;
  writing-mode: horizontal-tb;
  hyphens: manual;
  word-break: normal;
  overflow-wrap: normal;
  tab-size: 8;
  list-style: none;
  quotes: initial;
  caret-color: auto;
  user-select: auto;
  -webkit-text-fill-color: initial;
  -webkit-text-stroke: 0;
  text-rendering: auto;
  -webkit-text-size-adjust: 100%; /* 2 */
  -webkit-tap-highlight-color: transparent; /* 3 */
  font-feature-settings: "kern"; /* 4 */
  -webkit-font-feature-settings: "kern"; /* 5 */
  -moz-font-feature-settings: "kern"; /* 5 */
  -webkit-font-smoothing: antialiased; /* 5 */
  -moz-osx-font-smoothing: grayscale; /* 5 */
}

/* Vertical rhythm */
/* ============================================ */
p,
table,
blockquote,
address,
pre,
iframe,
form,
figure,
dl {
  margin: 0;
}

/* Headings */
/* ============================================ */
h1,
h2,
h3,
h4,
h5,
h6 {
  margin: 0;
  font-size: inherit;
  font-weight: inherit;
}

/* Lists (enumeration) */
/* ============================================ */
ul,
ol,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/* Lists (definition) */
/* ============================================ */
dd {
  margin-left: 0;
}

/* Grouping content */
/* ============================================ */
/**
 * 1. Add the correct box sizing in Firefox.
 * 2. Show the overflow in Edge and IE.
 */
hr {
  clear: both;
  margin: 0;
  border-top-width: 1px;
  height: 0; /* 1 */
  box-sizing: content-box; /* 1 */
  overflow: visible; /* 2 */
  color: inherit;
}

/**
 * 1. Correct the inheritance and scaling of font size in all browsers.
 * 2. Correct the odd \`em\` font sizing in all browsers.
 * 3. Wrap lines by default instead of overflow.
 */
pre {
  font-family: inherit; /* 1 */
  font-size: inherit; /* 2 */
  white-space: pre-line; /* 3 */
}

address {
  font-style: inherit;
}

/* Text-level semantics */
/* ============================================ */
/**
 * Remove the gray background on active links in IE 10.
 */
a {
  background-color: transparent;
  text-decoration: none;
  color: inherit;
}

/**
 * 1. Remove the bottom border in Chrome 57-
 * 2. Add the correct text decoration in Chrome, Edge, IE, Opera, and Safari.
 */
abbr[title] {
  border-bottom: none; /* 1 */
  text-decoration: none; /* 2 */
}

/**
 * Add the correct font weight in Chrome, Edge, and Safari.
 */
b,
strong {
  font-weight: bolder;
}

/**
 * 1. Correct the inheritance and scaling of font size in all browsers.
 * 2. Correct the odd \`em\` font sizing in all browsers.
 */
code,
kbd,
samp {
  font-family: "Menlo", "Monaco", "Consolas", "Courier New", monospace; /* 1 */
  font-size: inherit; /* 2 */
}

/**
 * Add the correct font size in all browsers.
 */
small {
  font-size: 80%;
}

/**
 * Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
 */
sub,
sup {
  position: relative;
  vertical-align: baseline;
  line-height: 0;
  font-size: 75%;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/* Replaced content */
/* ============================================ */
/**
 * Prevent vertical alignment issues.
 */
svg,
img,
embed,
object,
iframe {
  vertical-align: bottom;
}

/*
 * 1. Remove image default bottom space.
 * 2. Prevent image from overflowing the container.
 */
img {
  display: block;
  max-width: 100%;
}

/**
 * Prevent alignment issues on Safari.
 */
@supports (background: -webkit-named-image(i)) {
  svg {
    will-change: transform;
  }
}
/* Forms */
/* ============================================ */
/**
 * Reset form fields to make them styleable.
 * 1. Make form elements stylable across systems iOS especially.
 * 2. Inherit text-transform from parent.
 */
button,
input,
optgroup,
select,
textarea {
  -webkit-appearance: none; /* 1 */
  appearance: none;
  border-radius: 0;
  margin: 0;
  padding: 0;
  background: transparent;
  vertical-align: middle;
  text-align: inherit;
  text-transform: inherit; /* 2 */
  font: inherit;
  color: inherit;
}

/**
 * Correct cursors for clickable elements.
 */
button,
[type=button],
[type=reset],
[type=submit] {
  cursor: pointer;
}

button:disabled,
[type=button]:disabled,
[type=reset]:disabled,
[type=submit]:disabled {
  cursor: default;
}

/**
 * Clickable labels and selects.
 */
select,
label {
  cursor: pointer;
}

/**
 * Improve outlines for Firefox and unify style with input elements & buttons.
 */
:-moz-focusring {
  outline: auto;
}

select:disabled {
  opacity: inherit;
}

/**
 * 1. Remove padding.
 */
option {
  padding: 0; /* 1 */
}

/**
 * Reset to invisible
 */
fieldset {
  margin: 0;
  padding: 0;
  min-width: 0;
}

legend {
  display: contents;
  padding: 0;
}

/**
 * Add the correct vertical alignment in Chrome, Firefox, and Opera.
 */
progress {
  vertical-align: baseline;
}

/**
 * Remove the default vertical scrollbar in IE 10+.
 */
textarea {
  overflow: auto;
}

/**
 * Remove increment and decrement buttons in Chrome.
 */
[type=number]::-webkit-inner-spin-button,
[type=number]::-webkit-outer-spin-button {
  -webkit-appearance: none;
}

/**
 * Correct the outline style in Safari.
 */
[type=search] {
  outline-offset: -2px;
}

/**
 * Remove the inner padding in Chrome and Safari on macOS.
 */
[type=search]::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
 * Remove the \u2018X\u2019 from Chrome and Safari.
 */
[type=search]::-webkit-search-decoration,
[type=search]::-webkit-search-cancel-button,
[type=search]::-webkit-search-results-button,
[type=search]::-webkit-search-results-decoration {
  display: none;
}

/**
 * 1. Hide file input completely.
 * 2. Remove selected file text.
 * 3. Set cursor to pointer for all browsers.
 */
[type=file] {
  opacity: 0; /* 1 */
  font-size: 0; /* 2 */
  cursor: pointer; /* 3 */
}

/**
	* Fix appearance for Firefox
	*/
[type=number] {
  -moz-appearance: textfield;
}

/**
 * Set cursor to pointer for all browsers.
 */
[type=range] {
  cursor: pointer;
}

/**
 * Reset slider thumbs to make them styleable.
 */
[type=range]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
}

[type=range]::-moz-range-thumb {
  -moz-appearance: none;
  appearance: none;
  border-width: 0;
  border-radius: 0;
  background-color: transparent;
}

/* Interactive */
/* ============================================ */
/*
 * Add the correct display in Edge, IE 10+, and Firefox.
 */
details {
  display: block;
}

/*
 * Add the correct display in all browsers.
 */
summary {
  display: list-item;
}

/*
 * Remove outline for editable content.
 */
[contenteditable]:focus {
  outline: auto;
}

/* Tables */
/* ============================================ */
/**
1. Correct table border color inheritance in all Chrome and Safari.
*/
table {
  border-color: inherit; /* 1 */
  border-collapse: collapse;
}

caption {
  text-align: left;
}

td,
th {
  vertical-align: top;
  padding: 0;
}

th {
  text-align: left;
  font-weight: inherit;
}

/* Misc */
/* ============================================ */
/*
 * Make placeholder style consistent across all browsers.
 */
::placeholder {
  color: #999;
  opacity: 1;
}

/*
 * Hide focus outline but keep it visible for Windows High Contrast Mode.
 */
:focus {
  outline-style: solid;
  outline-color: transparent;
}

/*
 * Hide input arrow when used with datalist.
 */
::-webkit-calendar-picker-indicator {
  display: none !important;
}`,Te=Tn(),k4=tn(),C4=[S4,Ib,bh,p4,ow,$b,rr,m4,d4,x4,b4,h4].join(`
`);function au(s,i="filtered",r){let{name:u,path:d}=os(s,r);if(i==="off")return{name:u,elementName:u,path:d,reactComponents:null};let _=Fw(s,{mode:i});return{name:_.path?`${_.path} ${u}`:u,elementName:u,path:d,reactComponents:_.path}}var yg=!1,j4={outputDetail:"standard",autoClearAfterCopy:!1,annotationColorId:"blue",blockInteractions:!0,reactEnabled:!0,markerClickBehavior:"edit",webhookUrl:"",webhooksEnabled:!0},xg=s=>{if(!s||!s.trim())return!1;try{let i=new URL(s.trim());return i.protocol==="http:"||i.protocol==="https:"}catch{return!1}},E4={compact:"off",standard:"filtered",detailed:"smart",forensic:"all"},ga=s=>s.metaKey||s.ctrlKey,su=[{id:"indigo",label:"Indigo",srgb:"#6155F5",p3:"color(display-p3 0.38 0.33 0.96)"},{id:"blue",label:"Blue",srgb:"#0088FF",p3:"color(display-p3 0.00 0.53 1.00)"},{id:"cyan",label:"Cyan",srgb:"#00C3D0",p3:"color(display-p3 0.00 0.76 0.82)"},{id:"green",label:"Green",srgb:"#34C759",p3:"color(display-p3 0.20 0.78 0.35)"},{id:"yellow",label:"Yellow",srgb:"#FFCC00",p3:"color(display-p3 1.00 0.80 0.00)"},{id:"orange",label:"Orange",srgb:"#FF8D28",p3:"color(display-p3 1.00 0.55 0.16)"},{id:"red",label:"Red",srgb:"#FF383C",p3:"color(display-p3 1.00 0.22 0.24)"}],M4=[...su.map(s=>`
    [data-agentation-accent="${s.id}"] {
      --agentation-color-accent: ${s.srgb};
    }
    @supports (color: color(display-p3 0 0 0)) {
      [data-agentation-accent="${s.id}"] {
        --agentation-color-accent: ${s.p3};
      }
    }
  `),`:host {
    ${su.map(s=>`--agentation-color-${s.id}: ${s.srgb};`).join(`
`)}
  }`,`@supports (color: color(display-p3 0 0 0)) {
    :host {
      ${su.map(s=>`--agentation-color-${s.id}: ${s.p3};`).join(`
`)}
    }
  }`].join("");function I_(s){let i=s;for(let u=$n(i.ownerDocument);u;u=$n(i.ownerDocument))i=u;let r=i;for(;r&&r!==document.body;){let d=window.getComputedStyle(r).position;if(d==="fixed"||d==="sticky")return!0;r=r.parentElement}return!1}function yr(s){return s.kind!=="placement"&&s.kind!=="rearrange"&&s.status!=="resolved"&&s.status!=="dismissed"}function iu(s){let i=L_(s),r=i.found?i:i4(s);if(r.found&&r.source)return s4(r.source,"path")}function bg(s={}){let i=eb(s.useHashLocation??!1),r=(0,j.useState)(!1),u=lb(s.portalContainer);return u?(0,ob.createPortal)((0,k4.createElement)(T4,{...s,key:s.useHashLocation?i:void 0,pathname:i,activeState:r,portalHost:u}),u):null}function T4({pathname:s,activeState:i,portalHost:r,useHashLocation:u=!1,appName:d,enableKeyboardShortcuts:_=!0,identifyingAttributes:g=eo,copyFormat:w="markdown",onOpenSource:y,portalContainer:E,demoAnnotations:M,demoDelay:S=1e3,enableDemoMode:O=!1,onAnnotationAdd:W,onAnnotationDelete:H,onAnnotationUpdate:te,onAnnotationsClear:B,onCopy:K,onSubmit:Se,copyToClipboard:G=!0,endpoint:P,sessionId:tt,onSessionCreated:ut,webhookUrl:se,className:Ue}){let[oe,ze]=i,[,Re]=(0,j.useState)(0),[me]=(0,j.useState)(()=>In(document,()=>Re(p=>p+1)));(0,j.useEffect)(()=>(me.start(),()=>me.stop()),[me]);let De=typeof w=="object"?w.attribute:void 0,xe=(0,j.useMemo)(()=>De?[...g,De]:g,[g,De]),ye=(0,j.useRef)(!0);(0,j.useLayoutEffect)(()=>(ye.current=!0,()=>{ye.current=!1}),[]);let Le=(0,j.useCallback)(p=>u?tb(JSON.stringify([P,s]),p):p(),[P,s,u]),rn=(0,j.useRef)(new Map),_t=(0,j.useRef)(new Set),St=p=>yr(p)&&!_t.current.has(p.id),ft=async(...p)=>{let x=await sg(...p),k=p[2],R=k.id;if(R&&(rn.current.set(R,x.id),_t.current.has(R)&&_t.current.add(x.id)),!u){let q=new URL(k.url||window.location.href).pathname,Y=Hl(q).find(X=>X.id===R);try{if(_t.current.has(R))await Pc(p[0],x.id);else if(Y&&Y.comment!==k.comment)return await O_(p[0],x.id,{comment:Y.comment}),{...x,comment:Y.comment}}catch(X){console.warn("[Agentation] Failed to apply changes made during sync:",X)}}return x},Vt=p=>u?{...p,annotations:p.annotations.filter(x=>!_t.current.has(x.id)&&nb(x.url||p.url,s,window.location.origin))}:p,qn=(0,j.useRef)(s);qn.current=s;let go=(p,x,k,R=s)=>{let q=sr(p,Hl(R),x,rn.current).filter(St);R===qn.current&&ye.current&&jo(q),j_(R,q,k)},[nt,jo]=(0,j.useState)([]),[rs,Fs]=(0,j.useState)(!0),[pa,Ul]=(0,j.useState)(()=>zw()),[$l,Il]=(0,j.useState)(!1);(0,j.useLayoutEffect)(()=>{de()},[]);let vn=(0,j.useRef)(null),ml=(0,j.useRef)(null),hl=(0,j.useRef)(null),Zs=(0,j.useRef)(null),Uo=(0,j.useRef)(!1),Yl=(0,j.useRef)(!1),ue=(0,j.useRef)(!1);(0,j.useLayoutEffect)(()=>{oe&&Uo.current?(Uo.current=!1,hl.current?.querySelector("button:not(:disabled)")?.focus()):!oe&&Yl.current&&(Yl.current=!1,ml.current?.focus())},[oe]),(0,j.useEffect)(()=>{let p=k=>{let R=vn.current;R&&k.composedPath().includes(R)&&k.stopPropagation()},x=["mousedown","click","pointerdown"];return x.forEach(k=>r.addEventListener(k,p)),()=>{x.forEach(k=>r.removeEventListener(k,p))}},[r]);let[Oe,Ke]=(0,j.useState)(!1),[We,Xe]=(0,j.useState)(!1),[kt,mt]=(0,j.useState)(null),[vt,bt]=(0,j.useState)({x:0,y:0}),[ae,D]=(0,j.useState)(null),[Q,ee]=(0,j.useState)(!1),le=Ja(),ge=Ja(),[je,ie]=(0,j.useState)("idle"),[Ee,Qe]=(0,j.useState)(!1),ot=(0,j.useRef)(new Set),Ot=(0,j.useRef)(new Set),Ht=(0,j.useRef)(),Ct=(0,j.useCallback)(()=>{!ot.current.size&&!Ht.current&&Qe(!1)},[]);(0,j.useEffect)(()=>()=>clearTimeout(Ht.current),[]);let[ht,Je]=(0,j.useState)(null),[Pt,Zt]=(0,j.useState)(null),[Ut,it]=(0,j.useState)([]),[jt,Wt]=(0,j.useState)(null),Yt=(0,j.useRef)(null);(0,j.useEffect)(()=>()=>{Yt.current&&clearTimeout(Yt.current)},[]);let[ke,ro]=(0,j.useState)(null),po=(0,j.useRef)(null),to=(0,j.useRef)(!1),[gl,ql]=(0,j.useState)(!1);(0,j.useLayoutEffect)(()=>{if(ke||!po.current)return;let p=po.current;if(po.current=null,ae)return;(oe&&p.isConnected&&!p.disabled?p:ml.current)?.focus({preventScroll:!0})},[ke,oe,ae]);let[tl,$o]=(0,j.useState)(null),[xr,br]=(0,j.useState)([]),[cs,wg]=(0,j.useState)(0),[Sg,kg]=(0,j.useState)(!1),[zt,R4]=(0,j.useState)(!1),[pl,Cg]=(0,j.useState)(!1),[yl,ru]=(0,j.useState)(!1),[A4,jg]=(0,j.useState)("main"),[Eg,Y_]=(0,j.useState)(!1),[dn,q_]=(0,j.useState)(!1),[us,vr]=(0,j.useState)(!1),[Et,ya]=(0,j.useState)([]),[Ks,ds]=(0,j.useState)(null),X_=(0,j.useRef)(!1),[mn,Mg]=(0,j.useState)(!1),[Tg,Q_]=(0,j.useState)(!1),[Ng,D4]=(0,j.useState)(1),[Rg,U7]=(0,j.useState)("new-page"),[no,cu]=(0,j.useState)(""),[O4,z4]=(0,j.useState)(!1),[Ge,Xl]=(0,j.useState)(null),G_=(0,j.useRef)(!1),V_=(0,j.useRef)({rearrange:null,placements:[]}),_s=(0,j.useRef)({rearrange:null,placements:[]}),[L4,Ag]=(0,j.useState)(0),[B4,H4]=(0,j.useState)(0),[Js,Dg]=(0,j.useState)([]),[Ps,Og]=(0,j.useState)(null),zg=(0,j.useRef)({designPlacements:Et,rearrangeState:Ge,blankCanvas:mn,wireframePurpose:no});zg.current={designPlacements:Et,rearrangeState:Ge,blankCanvas:mn,wireframePurpose:no};let ei=(0,j.useRef)({placements:Js,rearrange:Ps}),wr=(0,j.useRef)(new Set),uu=(0,j.useRef)(new Set),nl=(0,j.useRef)(null),ti=(0,j.useRef)(),Lg=dn&&oe&&!us&&mn;(0,j.useEffect)(()=>{if(Lg){Q_(!1);let p=Ce(()=>{Q_(!0)});return()=>cancelAnimationFrame(p)}else Q_(!1)},[Lg]);let W_=(0,j.useRef)(new Map),F_=(0,j.useRef)([]),Z_=(0,j.useRef)(new Map),fs=(0,j.useRef)(null),[xl,U4]=(0,j.useState)(!1),[Ql,$4]=(0,j.useState)([]),K_=(0,j.useRef)(Ql);K_.current=Ql;let[Bg,$7]=(0,j.useState)(null),J_=(0,j.useRef)(null),I7=(0,j.useRef)(!1),Y7=(0,j.useRef)([]),q7=(0,j.useRef)(0),X7=(0,j.useRef)(null),Q7=(0,j.useRef)(null),G7=(0,j.useRef)(1),[P_,Hg]=(0,j.useState)(!1),ni=(0,j.useRef)(null),[yo,Gl]=(0,j.useState)([]),Sr=(0,j.useRef)(!1),du=()=>{Y_(!0)},I4=()=>{Y_(!1)},Ug=()=>{P_||(ni.current=_e(()=>Hg(!0),850))},$g=()=>{ni.current&&(clearTimeout(ni.current),ni.current=null),Hg(!1),I4()};(0,j.useEffect)(()=>()=>{ni.current&&clearTimeout(ni.current)},[]);let[Mt,Y4]=(0,j.useState)(()=>({...j4,...t.settings,markerClickBehavior:"edit",webhookUrl:"",webhooksEnabled:!1})),[Vl,Ig]=(0,j.useState)(!0),[Yg,qg]=(0,j.useState)(!1),q4=(0,j.useCallback)(p=>{Y4(x=>({...x,...p}))},[]),X4=(0,j.useCallback)(()=>{vn.current?.classList.add(fe.disableTransitions),Ig(p=>!p),Ce(()=>{vn.current?.classList.remove(fe.disableTransitions)})},[]),Xg=!1,Wl=Xg&&Mt.reactEnabled?E4[Mt.outputDetail]:"off",[Nn,e0]=(0,j.useState)(u?null:tt??null),Qg=(0,j.useRef)(!1),[_u,ms]=(0,j.useState)(P?"connecting":"disconnected"),[wn,t0]=(0,j.useState)(null),[fu,Gg]=(0,j.useState)(!1),kr=(0,j.useRef)(null),Fl=(0,j.useRef)(!1),hs=(0,j.useRef)(new Set),mu=(0,j.useRef)(new Map),Vg=(0,j.useCallback)(p=>{hs.current.add(p),ol.current===p&&(ol.current=null)},[]),[xa,hu]=(0,j.useState)(new Set),[Io,Cr]=(0,j.useState)(!1),[gs,oi]=(0,j.useState)(!1),[Zl,n0]=(0,j.useState)(!1),ps=(0,j.useRef)(null),Yo=(0,j.useRef)(null),jr=(0,j.useRef)(null),li=(0,j.useRef)(null),Er=(0,j.useRef)(!1),Wg=(0,j.useRef)(0),ol=(0,j.useRef)(null),Fg=(0,j.useRef)(null),o0=8,Q4=50,l0=(0,j.useRef)(null),gu=(0,j.useRef)(null),Mr=(0,j.useRef)(null),G4=(0,j.useCallback)(()=>jg("main"),[]);(0,j.useEffect)(()=>{yl||Y_(!1)},[yl]),(0,j.useLayoutEffect)(()=>{yl&&ue.current&&(ue.current=!1,vn.current?.querySelector("[data-agentation-settings-panel] button")?.focus())},[yl]);let pu=oe&&rs&&!dn;(0,j.useEffect)(()=>{if(pu)Xe(!1),Ke(!0),hs.current.clear();else if(Oe){Xe(!0);let p=_e(()=>{Ke(!1),Xe(!1)},250);return()=>clearTimeout(p)}},[pu]),(0,j.useEffect)(()=>{R4(!0),wg(window.scrollY);let p=Hl(s);jo(p.filter(yr)),yg||(qg(!0),yg=!0,_e(()=>qg(!1),750));try{let x=t.settings?.theme||"dark";x!==null&&Ig(x==="dark")}catch{}try{let x=t.storage.getItem(t.scope+"-toolbar-position");if(x){let k=JSON.parse(x);Number.isFinite(k.x)&&Number.isFinite(k.y)&&t0(k)}}catch{}},[s]),(0,j.useEffect)(()=>{zt&&t.storage.setItem("feedback-toolbar-settings",JSON.stringify(Mt))},[Mt,zt]),(0,j.useEffect)(()=>{zt&&t.storage.setItem("feedback-toolbar-theme",Vl?"dark":"light")},[Vl,zt]);let Zg=(0,j.useRef)(!1);(0,j.useEffect)(()=>{let p=Zg.current;Zg.current=fu,p&&!fu&&wn&&zt&&t.storage.setItem(t.scope+"-toolbar-position",JSON.stringify(wn))},[fu,wn,zt]),(0,j.useEffect)(()=>{if(!P||!zt||Qg.current)return;Qg.current=!0,ms("connecting");let p=window.location.href;Le(async()=>{try{let k=Dw(s),R=tt||k,q=!1;if(R)try{let Y=Hl(s),X=Vt(await ag(P,R));F_.current=X.annotations.filter(He=>He.kind==="placement"||He.kind==="rearrange"),ye.current&&(e0(X.id),ms("connected")),R_(s,X.id),q=!0;let re=Hl(s).filter(yr),Ae=new Set(X.annotations.map(He=>He.id)),Be=re.filter(He=>!Ae.has(He.id));if(Be.length>0){let $e=`${typeof window<"u"?window.location.origin:""}${s}`,ct=(await Promise.allSettled(Be.map(Ye=>ft(P,X.id,{...Ye,sessionId:X.id,url:$e})))).map((Ye,Pe)=>Ye.status==="fulfilled"?Ye.value:(console.warn("[Agentation] Failed to sync annotation:",Ye.reason),Be[Pe])),Me=[...X.annotations,...ct];go(Y,Me,X.id)}else go(Y,X.annotations,X.id)}catch(Y){console.warn("[Agentation] Could not join session, creating new:",Y),Ow(s)}if(!q){let Y=await D_(P,p);R_(s,Y.id),ye.current&&(e0(Y.id),ms("connected"),ut?.(Y.id));let X=u?new Map([[s,Hl(s)]]):_r(),re=typeof window<"u"?window.location.origin:"",Ae=[];for(let[Be,He]of X){let $e=He.filter(Me=>yr(Me)&&!Me._syncedTo);if($e.length===0)continue;let lt=`${re}${Be}`,ct=Be===s;Ae.push((async()=>{try{let Me=ct?Y:await D_(P,lt),Pe=(await Promise.allSettled($e.map(wt=>ft(P,Me.id,{...wt,sessionId:Me.id,url:lt})))).map((wt,cn)=>wt.status==="fulfilled"?wt.value:(console.warn("[Agentation] Failed to sync annotation:",wt.reason),$e[cn]));go($e,Pe,Me.id,Be)}catch(Me){console.warn(`[Agentation] Failed to sync annotations for ${Be}:`,Me)}})())}await Promise.allSettled(Ae)}}catch(k){ye.current&&ms("disconnected"),console.warn("[Agentation] Failed to initialize session, using local storage:",k)}})},[P,tt,zt,ut,s,Le]),(0,j.useEffect)(()=>{if(!P||!zt)return;let p=async()=>{try{(await fetch(`${P}/health`)).ok?ms("connected"):ms("disconnected")}catch{ms("disconnected")}};p();let x=be(p,1e4);return()=>clearInterval(x)},[P,zt]);let yu=(0,j.useRef)(nt),Kg=(0,j.useRef)(!1);(0,j.useLayoutEffect)(()=>{yu.current=nt,Kg.current=nt.length>0||Et.length>0||(Ge?.sections.length??0)>0},[nt,Et.length,Ge?.sections.length]);let a0=(0,j.useCallback)(p=>{let x=ot.current.has(p);if(x&&(Ot.current.delete(p),Ot.current.size))return;let k=x?new Set(ot.current):new Set([p]);x&&(ot.current.clear(),Ct());for(let Y of k)mu.current.delete(Y),hs.current.delete(Y);jo(Y=>Y.filter(X=>!k.has(X.id))),hu(Y=>new Set([...Y].filter(X=>!k.has(X))));let R=x?[]:yu.current.filter(Y=>Y.kind!=="placement"&&Y.kind!=="rearrange"),q=R.findIndex(Y=>Y.id===p);q>=0&&q<R.length-1&&(Wt(Y=>Y===null?q:Math.min(Y,q)),Yt.current&&clearTimeout(Yt.current),Yt.current=_e(()=>Wt(null),200))},[Ct]);(0,j.useEffect)(()=>!P||!zt||!Nn?void 0:u4(P,Nn,()=>Kg.current,k=>{let{id:R,kind:q}=k;if(q==="placement"){for(let[Y,X]of W_.current)if(X===R){fs.current?.placements.forget(Y),ya(re=>re.filter(Ae=>Ae.id!==Y));break}}else if(q==="rearrange"){for(let[Y,X]of Z_.current)if(X===R){fs.current?.rearrange.forget(Y),Xl(re=>{if(!re)return null;let Ae=re.sections.filter(Be=>Be.id!==Y);return Ae.length===0?null:{...re,sections:Ae}});break}}else{if(!yu.current.some(Y=>Y.id===R))return;hu(Y=>new Set(Y).add(R))}}),[P,zt,Nn]),(0,j.useEffect)(()=>{if(!P||!zt)return;let p=Fg.current==="disconnected",x=_u==="connected";Fg.current=_u,p&&x&&Le(async()=>{try{let R=Hl(s).filter(yr);if(R.length===0)return;let Y=`${typeof window<"u"?window.location.origin:""}${s}`,X=Nn,re=[];if(X)try{re=Vt(await ag(P,X)).annotations}catch{X=null}X||(X=(await D_(P,Y)).id,ye.current&&e0(X),R_(s,X));let Ae=new Set(re.map(He=>He.id)),Be=R.filter(He=>!Ae.has(He.id));if(Be.length>0){let $e=(await Promise.allSettled(Be.map(ct=>ft(P,X,{...ct,sessionId:X,url:Y})))).map((ct,Me)=>ct.status==="fulfilled"?ct.value:(console.warn("[Agentation] Failed to sync annotation on reconnect:",ct.reason),Be[Me])),lt=[...re,...$e];go(R,lt,X)}}catch(R){console.warn("[Agentation] Failed to sync on reconnect:",R)}})},[_u,P,zt,Nn,s,Le]);let V4=(0,j.useCallback)(()=>{$l||(Il(!0),ru(!1),ze(!1),_e(()=>{Lw(!0),Ul(!0),Il(!1)},400))},[$l]);(0,j.useEffect)(()=>{if(!O||!zt||!M||M.length===0||nt.length>0)return;let p=[];return p.push(_e(()=>{ze(!0)},S-200)),M.forEach((x,k)=>{let R=S+k*300;p.push(_e(()=>{let q=document.querySelector(x.selector);if(!q)return;let Y=gn(q),{name:X,path:re}=os(q),Ae={id:`demo-${Date.now()}-${k}`,x:(Y.left+Y.width/2)/window.innerWidth*100,y:Y.top+Y.height/2+window.scrollY,comment:x.comment,element:X,elementPath:re,timestamp:Date.now(),selectedText:x.selectedText,boundingBox:{x:Y.left,y:Y.top+window.scrollY,width:Y.width,height:Y.height},nearbyText:Qs(q),cssClasses:Gs(q)};jo(Be=>[...Be,Ae])},R))}),()=>{p.forEach(clearTimeout)}},[O,zt,M,S]),(0,j.useEffect)(()=>{let p=()=>{wg(window.scrollY),Re(x=>x+1),kg(!0),Mr.current&&clearTimeout(Mr.current),Mr.current=_e(()=>{kg(!1)},150)};return me.addEventListener("scroll",p,{passive:!0,capture:!0}),()=>{me.removeEventListener("scroll",p,!0),Mr.current&&clearTimeout(Mr.current)}},[me]),(0,j.useEffect)(()=>{if(!zt)return;let p=nt.filter(x=>!xa.has(x.id));p.length>0?Nn?j_(s,p,Nn):dr(s,p):t.storage.removeItem(Kc(s))},[nt,s,zt,Nn,Ee,xa]),(0,j.useEffect)(()=>{if(zt&&!X_.current){X_.current=!0;let p=jw(s);p.length>0&&ya(p)}},[zt,s]),(0,j.useEffect)(()=>{if(zt&&X_.current&&!mn){let p=Et.filter(x=>!Js.includes(x));p.length>0?Ew(s,p):Mw(s)}},[Et,s,zt,mn,Js]),(0,j.useEffect)(()=>{if(zt&&!G_.current){G_.current=!0;let p=Tw(s);if(p){let x={...p,sections:p.sections.map(k=>({...k,currentRect:k.currentRect??{...k.originalRect}}))};Xl(x)}}},[zt,s]),(0,j.useEffect)(()=>{zt&&G_.current&&!mn&&(Ge&&Ge!==Ps?Nw(s,Ge):Rw(s))},[Ge,s,zt,mn,Ps]);let s0=(0,j.useRef)(!1);(0,j.useEffect)(()=>{if(zt&&!s0.current){s0.current=!0;let p=Aw(s);p&&(_s.current={rearrange:p.rearrange,placements:p.placements||[]},p.purpose&&cu(p.purpose))}},[zt,s]),(0,j.useEffect)(()=>{if(!zt||!s0.current||Ee)return;let p=_s.current;mn?(Ge?.sections?.length??0)>0||Et.length>0||no?og(s,{rearrange:Ge,placements:Et,purpose:no}):Jc(s):(p.rearrange?.sections?.length??0)>0||p.placements.length>0||no?og(s,{rearrange:p.rearrange,placements:p.placements,purpose:no}):Jc(s)},[Ge,Et,no,mn,s,zt,Ee]),(0,j.useEffect)(()=>{dn&&!Ge&&Xl({sections:[],originalOrder:[],detectedAt:Date.now()})},[dn,Ge]),(0,j.useEffect)(()=>{if(!P||!Nn)return;let p={create:k=>Le(()=>sg(P,Nn,k)),update:(k,R)=>Le(()=>O_(P,k,R)),remove:k=>Le(()=>Pc(P,k))};W_.current=new Map,Z_.current=new Map;let x={placements:_g(p,W_.current,F_.current.filter(k=>k.kind==="placement")),rearrange:_g(p,Z_.current,F_.current.filter(k=>k.kind==="rearrange"))};return fs.current=x,()=>{x.placements.dispose(),x.rearrange.dispose(),fs.current===x&&(fs.current=null)}},[P,Nn,s,Le]),(0,j.useEffect)(()=>{let p=window.location.pathname+window.location.search+window.location.hash;fs.current?.placements.replace(Et.filter(x=>!Js.includes(x)).map(x=>({id:x.id,x:x.x/window.innerWidth*100,y:x.y,comment:`Place ${x.type} at (${Math.round(x.x)}, ${Math.round(x.y)}), ${x.width}\xD7${x.height}px${x.text?` \u2014 "${x.text}"`:""}`,element:`[design:${x.type}]`,elementPath:"[placement]",timestamp:x.timestamp,url:p,intent:"change",severity:"important",kind:"placement",placement:{componentType:x.type,width:x.width,height:x.height,scrollY:x.scrollY,text:x.text}})))},[Et,P,Nn,s,Js]),(0,j.useEffect)(()=>{let p=fs.current;if(!p)return;if(Ge===Ps){p.rearrange.replace([]);return}let x=_e(()=>{let k=window.location.pathname+window.location.search+window.location.hash,R=[];for(let q of Ge?.sections??[]){let Y=q.originalRect,X=q.currentRect,re=Math.abs(Y.x-X.x)>1||Math.abs(Y.y-X.y)>1||Math.abs(Y.width-X.width)>1||Math.abs(Y.height-X.height)>1;if(!re&&!q.note)continue;let Ae=q.note?` \u2014 "${q.note}"`:"";R.push({id:q.id,x:X.x/window.innerWidth*100,y:X.y,comment:re?`Move ${q.label} section (${q.tagName}) \u2014 from (${Math.round(Y.x)},${Math.round(Y.y)}) ${Math.round(Y.width)}\xD7${Math.round(Y.height)} to (${Math.round(X.x)},${Math.round(X.y)}) ${Math.round(X.width)}\xD7${Math.round(X.height)}${Ae}`:`Note on ${q.label} section (${q.tagName})${Ae}`,element:q.selector,elementPath:"[rearrange]",timestamp:Ge.detectedAt,url:k,intent:"change",severity:"important",kind:"rearrange",rearrange:{selector:q.selector,label:q.label,tagName:q.tagName,originalRect:Y,currentRect:X}})}p.rearrange.replace(R)},300);return()=>clearTimeout(x)},[Ge,P,Nn,s,Ps]);let W4=(0,j.useCallback)(()=>{clearTimeout(ti.current),vr(!1),q_(!0)},[]);(0,j.useEffect)(()=>()=>clearTimeout(ti.current),[]);let Jg=(0,j.useCallback)(()=>{vr(!0),q_(!1),ds(null),clearTimeout(ti.current),ti.current=_e(()=>{vr(!1)},300)},[]),ai=(0,j.useCallback)(()=>{let p=ml.current?.getRootNode();Yl.current=!!p?.activeElement&&!!vn.current?.contains(p.activeElement),Yl.current&&p?.activeElement?.blur(),ru(!1),dn&&(vr(!0),q_(!1),ds(null),clearTimeout(ti.current),ti.current=_e(()=>{vr(!1)},300)),ze(!1)},[dn]),Pg=(0,j.useCallback)(()=>{pl||(st(),Cg(!0))},[pl]),xu=(0,j.useCallback)(()=>{pl&&(ho(),Cg(!1))},[pl]),e1=(0,j.useCallback)(()=>{pl?xu():Pg()},[pl,Pg,xu]),Tr=(0,j.useCallback)((p=yo)=>{let x=p.filter(X=>X.element.isConnected);if(x.length===0){Gl([]);return}let k=x[0],R=k.element,q=x.length>1,Y=x.map(X=>gn(X.element));if(q){let X={left:Math.min(...Y.map(Pe=>Pe.left)),top:Math.min(...Y.map(Pe=>Pe.top)),right:Math.max(...Y.map(Pe=>Pe.right)),bottom:Math.max(...Y.map(Pe=>Pe.bottom))},re=x.slice(0,5).map(Pe=>Pe.name).join(", "),Ae=x.length>5?` +${x.length-5} more`:"",Be=Y.map(Pe=>({x:Pe.left,y:Pe.top+window.scrollY,width:Pe.width,height:Pe.height})),$e=x[x.length-1].element,lt=Y[Y.length-1],ct=lt.left+lt.width/2,Me=lt.top+lt.height/2,Ye=I_($e);D({id:Date.now().toString(),x:ct/window.innerWidth*100,y:Ye?Me:Me+window.scrollY,clientY:Me,element:`${x.length} elements: ${re}${Ae}`,elementPath:"multi-select",boundingBox:{x:X.left,y:X.top+window.scrollY,width:X.right-X.left,height:X.bottom-X.top},isMultiSelect:!0,isFixed:Ye,elementBoundingBoxes:Be,multiSelectElements:x.map(Pe=>Pe.element),targetElement:$e,fullPath:ir(R),accessibility:$c(R),computedStyles:Uc(R),computedStylesObj:Hc(R),nearbyElements:Bc(R),cssClasses:Gs(R),nearbyText:Qs(R),sourceFile:iu(R),attributes:ns(R,xe)})}else{let X=Y[0],re=I_(R);D({id:Date.now().toString(),x:X.left/window.innerWidth*100,y:re?X.top:X.top+window.scrollY,clientY:X.top,element:k.name,elementPath:k.path,boundingBox:{x:X.left,y:re?X.top:X.top+window.scrollY,width:X.width,height:X.height},isFixed:re,fullPath:ir(R),accessibility:$c(R),computedStyles:Uc(R),computedStylesObj:Hc(R),nearbyElements:Bc(R),cssClasses:Gs(R),nearbyText:Qs(R),reactComponents:k.reactComponents,targetElement:R,sourceFile:iu(R),attributes:ns(R,xe)})}Gl([]),mt(null)},[yo,xe]);(0,j.useEffect)(()=>{oe||(D(null),ro(null),$o(null),br([]),mt(null),ru(!1),Gl([]),Sr.current=!1,pl&&xu())},[oe,pl,xu]),(0,j.useEffect)(()=>()=>{ho()},[]),(0,j.useEffect)(()=>{if(!oe)return;let p=["p","span","h1","h2","h3","h4","h5","h6","li","td","th","label","blockquote","figcaption","caption","legend","dt","dd","pre","code","em","strong","b","i","u","s","a","time","address","cite","q","abbr","dfn","mark","small","sub","sup","[contenteditable]"].join(", "),x=document.createElement("style");return x.id="agentation-cursor",x.textContent=`
      html, body, body * { cursor: default !important; }
      
    `,document.head.appendChild(x),()=>{let k=document.getElementById("agentation-cursor");k&&k.remove()}},[oe]),(0,j.useEffect)(()=>{if(Bg!==null&&oe)return document.documentElement.setAttribute("data-drawing-hover",""),()=>document.documentElement.removeAttribute("data-drawing-hover")},[Bg,oe]),(0,j.useEffect)(()=>{if(!oe||ae||ke||xl||dn)return;let p=null,x=(Y,X,re)=>{let Ae=Ic(Y,X),Be=re?ph(Y,X):Ae;if(!Be||zn(Be,"[data-feedback-toolbar], [data-annotation-popup], [data-annotation-marker]")){mt(null);return}let{name:He,elementName:$e,path:lt,reactComponents:ct}=au(Be,Wl,xe);mt({element:He,elementName:$e,elementPath:lt,rect:gn(Be),reactComponents:ct,isPiercing:re&&Be!==Ae}),bt({x:Y,y:X})},k=Y=>{let X=Y.composedPath()[0]||Y.target;if(zn(X,"[data-feedback-toolbar], [data-annotation-popup], [data-annotation-marker]")){p=null,mt(null);return}p={x:Y.clientX,y:Y.clientY},x(Y.clientX,Y.clientY,ga(Y))},R=Y=>{(Y.key==="Meta"||Y.key==="Control")&&p&&x(p.x,p.y,ga(Y))},q=()=>{p=null,mt(null)};return me.addEventListener("mousemove",k),me.addEventListener("keydown",R),me.addEventListener("keyup",R),me.addEventListener("mouseleave",q),window.addEventListener("blur",q),()=>{me.removeEventListener("mousemove",k),me.removeEventListener("keydown",R),me.removeEventListener("keyup",R),me.removeEventListener("mouseleave",q),window.removeEventListener("blur",q)}},[oe,ae,ke,xl,dn,Wl,xe]);let si=(0,j.useCallback)((p,x)=>{if(ke&&!gs){gu.current?.shake();return}if(ae&&!Io){if(vn.current?.querySelector("[data-annotation-popup]:not([data-annotation-card]) textarea")?.value.trim()){l0.current?.shake();return}Cr(!0)}if(po.current=x??null,to.current=x?.matches(":focus-visible")??!1,ql(!1),oi(!1),ro(p),Je(null),Zt(null),it([]),p.elementBoundingBoxes?.length){let k=[];for(let R of p.elementBoundingBoxes){let q=R.x+R.width/2,Y=R.y+R.height/2-window.scrollY,X=Yc(q,Y,R);X&&k.push(X)}br(k),$o(null)}else if(p.boundingBox){let k=p.boundingBox,R=k.x+k.width/2,q=p.isFixed?k.y+k.height/2:k.y+k.height/2-window.scrollY,Y=Yc(R,q,k);if(Y){let X=gn(Y),re=X.width/k.width,Ae=X.height/k.height;re<.5||Ae<.5?$o(null):$o(Y)}else $o(null);br([])}else $o(null),br([])},[ae,Io,ke,gs]);(0,j.useEffect)(()=>{if(!oe||xl||dn)return;let p=x=>{if(Er.current){Er.current=!1,x.preventDefault(),x.stopPropagation();return}let k=x.composedPath()[0]||x.target;if(zn(k,"[data-feedback-toolbar]")||zn(k,"[data-annotation-popup]")||zn(k,"[data-annotation-marker]"))return;if(ga(x)&&!ae&&!ke){x.preventDefault(),x.stopPropagation(),Sr.current=x.shiftKey;let Pe=ph(x.clientX,x.clientY);if(!Pe)return;let wt=gn(Pe),{name:cn,path:Xn,reactComponents:Fe}=au(Pe,Wl,xe),Ve=yo.findIndex(Tt=>Tt.element===Pe);Ve>=0?Gl(Tt=>Tt.filter((pn,vl)=>vl!==Ve)):Gl(Tt=>[...Tt,{element:Pe,rect:wt,name:cn,path:Xn,reactComponents:Fe??void 0}]);return}let R=zn(k,"button, a, input, select, textarea, [role='button'], [onclick]");if(Mt.blockInteractions&&(x.preventDefault(),x.stopPropagation()),ae&&!Io){if(R&&!Mt.blockInteractions)return;x.preventDefault(),l0.current?.shake();return}if(ke&&!gs){if(R&&!Mt.blockInteractions)return;x.preventDefault(),gu.current?.shake();return}x.preventDefault();let q=Ic(x.clientX,x.clientY);if(!q)return;let{name:Y,path:X,reactComponents:re}=au(q,Wl,xe),Ae=gn(q),Be=x.clientX/window.innerWidth*100,He=I_(q),$e=He?x.clientY:x.clientY+window.scrollY,lt=q.ownerDocument.defaultView?.getSelection(),ct;lt&&lt.toString().trim().length>0&&(ct=lt.toString().trim().slice(0,500));let Me=Hc(q),Ye=Uc(q);Cr(!1),D({id:Date.now().toString(),x:Be,y:$e,clientY:x.clientY,element:Y,elementPath:X,selectedText:ct,boundingBox:{x:Ae.left,y:He?Ae.top:Ae.top+window.scrollY,width:Ae.width,height:Ae.height},nearbyText:Qs(q),cssClasses:Gs(q),isFixed:He,fullPath:ir(q),accessibility:$c(q),computedStyles:Ye,computedStylesObj:Me,nearbyElements:Bc(q),reactComponents:re??void 0,sourceFile:iu(q),attributes:ns(q,xe),frame:Pn(q,x.clientX,x.clientY),targetElement:q}),mt(null)};return me.addEventListener("click",p,!0),()=>me.removeEventListener("click",p,!0)},[oe,xl,dn,ae,Io,ke,gs,Mt.blockInteractions,Wl,xe,yo]),(0,j.useEffect)(()=>{if(!oe)return;let p=k=>{let R=(k.key==="Meta"||k.key==="Control")&&!ga(k),q=k.key==="Shift"&&Sr.current;(R||q)&&!Yo.current&&yo.length>0&&Tr()},x=()=>{Sr.current=!1,Gl([]),mt(null),ps.current=null,Yo.current=null,n0(!1),li.current?.replaceChildren()};return me.addEventListener("keyup",p),window.addEventListener("blur",x),()=>{me.removeEventListener("keyup",p),window.removeEventListener("blur",x)}},[oe,yo,Tr]),(0,j.useEffect)(()=>{if(!oe||ae||xl||dn)return;let p=x=>{if(x.button!==0)return;Er.current=!1;let k=x.composedPath()[0]||x.target;if(zn(k,"[data-feedback-toolbar]")||zn(k,"[data-annotation-marker]")||zn(k,"[data-annotation-popup]"))return;let R=new Set(["P","SPAN","H1","H2","H3","H4","H5","H6","LI","TD","TH","LABEL","BLOCKQUOTE","FIGCAPTION","CAPTION","LEGEND","DT","DD","PRE","CODE","EM","STRONG","B","I","U","S","A","TIME","ADDRESS","CITE","Q","ABBR","DFN","MARK","SMALL","SUB","SUP"]);!ga(x)&&(R.has(k.tagName)||k.isContentEditable)||(x.preventDefault(),ps.current={x:x.clientX,y:x.clientY})};return me.addEventListener("mousedown",p),()=>me.removeEventListener("mousedown",p)},[oe,ae,xl,dn]),(0,j.useEffect)(()=>{if(!oe||ae)return;let p=x=>{if(!ps.current)return;let k=x.clientX-ps.current.x,R=x.clientY-ps.current.y,q=k*k+R*R,Y=o0*o0;if(!Zl&&q>=Y&&(Yo.current=ps.current,n0(!0),x.preventDefault()),(Zl||q>=Y)&&Yo.current){if(jr.current){let Fe=Math.min(Yo.current.x,x.clientX),Ve=Math.min(Yo.current.y,x.clientY),Tt=Math.abs(x.clientX-Yo.current.x),pn=Math.abs(x.clientY-Yo.current.y);jr.current.style.transform=`translate(${Fe}px, ${Ve}px)`,jr.current.style.width=`${Tt}px`,jr.current.style.height=`${pn}px`}let X=Date.now();if(X-Wg.current<Q4)return;Wg.current=X;let re=Yo.current.x,Ae=Yo.current.y,Be=Math.min(re,x.clientX),He=Math.min(Ae,x.clientY),$e=Math.max(re,x.clientX),lt=Math.max(Ae,x.clientY),ct=(Be+$e)/2,Me=(He+lt)/2,Ye=new Set,Pe=[[Be,He],[$e,He],[Be,lt],[$e,lt],[ct,Me],[ct,He],[ct,lt],[Be,Me],[$e,Me]];for(let[Fe,Ve]of Pe){let Tt=document.elementsFromPoint(Fe,Ve);for(let pn of Tt)pn instanceof HTMLElement&&Ye.add(pn)}let wt=me.querySelectorAll("button, a, input, img, p, h1, h2, h3, h4, h5, h6, li, label, td, th, div, span, section, article, aside, nav");for(let Fe of wt)if(Fe instanceof HTMLElement){let Ve=gn(Fe),Tt=Ve.left+Ve.width/2,pn=Ve.top+Ve.height/2,vl=Tt>=Be&&Tt<=$e&&pn>=He&&pn<=lt,ll=Math.min(Ve.right,$e)-Math.max(Ve.left,Be),Rr=Math.min(Ve.bottom,lt)-Math.max(Ve.top,He),ju=ll>0&&Rr>0?ll*Rr:0,Qn=Ve.width*Ve.height,Ar=Qn>0?ju/Qn:0;(vl||Ar>.5)&&Ye.add(Fe)}let cn=[],Xn=new Set(["BUTTON","A","INPUT","IMG","P","H1","H2","H3","H4","H5","H6","LI","LABEL","TD","TH","SECTION","ARTICLE","ASIDE","NAV"]);for(let Fe of Ye){if(zn(Fe,"[data-feedback-toolbar]")||zn(Fe,"[data-annotation-marker]"))continue;let Ve=gn(Fe);if(!(Ve.width>window.innerWidth*.8&&Ve.height>window.innerHeight*.5)&&!(Ve.width<10||Ve.height<10)&&Ve.left<$e&&Ve.right>Be&&Ve.top<lt&&Ve.bottom>He){let Tt=Fe.tagName,pn=Xn.has(Tt);if(!pn&&(Tt==="DIV"||Tt==="SPAN")){let vl=Fe.textContent&&Fe.textContent.trim().length>0,ll=Fe.onclick!==null||Fe.getAttribute("role")==="button"||Fe.getAttribute("role")==="link"||Fe.classList.contains("clickable")||Fe.hasAttribute("data-clickable");(vl||ll)&&!Fe.querySelector("p, h1, h2, h3, h4, h5, h6, button, a")&&(pn=!0)}if(pn){let vl=!1;for(let ll of cn)if(ll.left<=Ve.left&&ll.right>=Ve.right&&ll.top<=Ve.top&&ll.bottom>=Ve.bottom){vl=!0;break}vl||cn.push(Ve)}}}if(li.current){let Fe=li.current;for(;Fe.children.length>cn.length;)Fe.removeChild(Fe.lastChild);cn.forEach((Ve,Tt)=>{let pn=Fe.children[Tt];pn||(pn=document.createElement("div"),pn.className=fe.selectedElementHighlight,Fe.appendChild(pn)),pn.style.transform=`translate(${Ve.left}px, ${Ve.top}px)`,pn.style.width=`${Ve.width}px`,pn.style.height=`${Ve.height}px`})}}};return me.addEventListener("mousemove",p,{passive:!0}),()=>me.removeEventListener("mousemove",p)},[oe,ae,Zl,o0]),(0,j.useEffect)(()=>{if(!oe)return;let p=x=>{let k=Zl,R=Yo.current;if(Zl&&R){Er.current=!0;let q=Math.min(R.x,x.clientX),Y=Math.min(R.y,x.clientY),X=Math.max(R.x,x.clientX),re=Math.max(R.y,x.clientY),Ae=[];me.querySelectorAll("button, a, input, img, p, h1, h2, h3, h4, h5, h6, li, label, td, th").forEach(Me=>{if(!(Me instanceof HTMLElement)||zn(Me,"[data-feedback-toolbar]")||zn(Me,"[data-annotation-marker]"))return;let Ye=gn(Me);Ye.width>window.innerWidth*.8&&Ye.height>window.innerHeight*.5||Ye.width<10||Ye.height<10||Ye.left<X&&Ye.right>q&&Ye.top<re&&Ye.bottom>Y&&Ae.push({element:Me,rect:Ye})});let He=Ae.filter(({element:Me})=>!Ae.some(({element:Ye})=>Ye!==Me&&Me.contains(Ye))),$e=x.clientX/window.innerWidth*100,lt=x.clientY+window.scrollY,ct=(ga(x)||yo.length>0)&&!ae&&!ke;if(He.length>0)if(ct){let Me=[...yo];for(let{element:Ye,rect:Pe}of He){if(Me.some(Fe=>Fe.element===Ye))continue;let{name:wt,path:cn,reactComponents:Xn}=au(Ye,Wl,xe);Me.push({element:Ye,rect:Pe,name:wt,path:cn,reactComponents:Xn??void 0})}Sr.current=x.shiftKey,ga(x)?Gl(Me):Tr(Me)}else{let Me=He.reduce((Fe,{rect:Ve})=>({left:Math.min(Fe.left,Ve.left),top:Math.min(Fe.top,Ve.top),right:Math.max(Fe.right,Ve.right),bottom:Math.max(Fe.bottom,Ve.bottom)}),{left:1/0,top:1/0,right:-1/0,bottom:-1/0}),Ye=He.slice(0,5).map(({element:Fe})=>os(Fe).name).join(", "),Pe=He.length>5?` +${He.length-5} more`:"",wt=He[0].element,cn=Hc(wt),Xn=Uc(wt);D({id:Date.now().toString(),x:$e,y:lt,clientY:x.clientY,element:`${He.length} elements: ${Ye}${Pe}`,elementPath:"multi-select",boundingBox:{x:Me.left,y:Me.top+window.scrollY,width:Me.right-Me.left,height:Me.bottom-Me.top},isMultiSelect:!0,fullPath:ir(wt),accessibility:$c(wt),computedStyles:Xn,computedStylesObj:cn,nearbyElements:Bc(wt),cssClasses:Gs(wt),nearbyText:Qs(wt),sourceFile:iu(wt),attributes:ns(wt,xe)})}else if(ct&&!ga(x))Tr();else if(!ct){let Me=Math.abs(X-q),Ye=Math.abs(re-Y);Me>20&&Ye>20&&D({id:Date.now().toString(),x:$e,y:lt,clientY:x.clientY,element:"\u0412\u044B\u0431\u0440\u0430\u043D\u043D\u0430\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u044C",elementPath:`region at (${Math.round(q)}, ${Math.round(Y)})`,boundingBox:{x:q,y:Y+window.scrollY,width:Me,height:Ye},isMultiSelect:!0})}mt(null)}else k&&(Er.current=!0);ps.current=null,Yo.current=null,n0(!1),li.current&&(li.current.innerHTML="")};return me.addEventListener("mouseup",p),()=>me.removeEventListener("mouseup",p)},[oe,Zl,ae,ke,Wl,xe,yo,Tr]);let bl=(0,j.useCallback)(async(p,x,k)=>{let R=Mt.webhookUrl||se;if(!R||!Mt.webhooksEnabled&&!k)return!1;try{return(await fetch(R,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({event:p,timestamp:Date.now(),url:typeof window<"u"?window.location.href:void 0,...x})})).ok}catch(q){return console.warn("[Agentation] Webhook failed:",q),!1}},[se,Mt.webhookUrl,Mt.webhooksEnabled]),F4=(0,j.useCallback)(p=>{if(!ae||ae.isSubmitted)return;let x={id:ae.id,x:ae.x,y:ae.y,comment:p,element:ae.element,elementPath:ae.elementPath,timestamp:Date.now(),selectedText:ae.selectedText,boundingBox:ae.boundingBox,nearbyText:ae.nearbyText,cssClasses:ae.cssClasses,isMultiSelect:ae.isMultiSelect,isFixed:ae.isFixed,fullPath:ae.fullPath,accessibility:ae.accessibility,computedStyles:ae.computedStyles,nearbyElements:ae.nearbyElements,reactComponents:ae.reactComponents,sourceFile:ae.sourceFile,attributes:ae.attributes,frame:ae.frame,elementBoundingBoxes:ae.elementBoundingBoxes,...P&&Nn?{sessionId:Nn,url:typeof window<"u"?window.location.href:void 0,status:"pending"}:{}};jo(k=>[...k,x]),D({...ae,isSubmitted:!0}),ol.current=x.id,W?.(x),bl("annotation.add",{annotation:x}),Cr(!0),window.getSelection()?.removeAllRanges(),P&&Nn&&Le(async()=>{let k=await ft(P,Nn,x);if(u){let R=Hl(s);j_(s,R.map(q=>q.id===x.id?{...q,id:k.id}:q),Nn)}!ye.current||_t.current.has(x.id)||k.id!==x.id&&(mu.current.set(k.id,x.id),ol.current===x.id&&(ol.current=k.id),jo(R=>R.map(q=>q.id===x.id?{...q,id:k.id}:q)),hs.current.delete(x.id)&&hs.current.add(k.id))}).catch(k=>{console.warn("[Agentation] Failed to sync annotation:",k)})},[ae,W,bl,P,Nn,Le,s,u]),Z4=(0,j.useCallback)(()=>{Cr(!0)},[]),i0=(0,j.useCallback)(()=>{D(null),Cr(!1)},[]),bu=(0,j.useCallback)(p=>{if(_t.current.has(p))return;_t.current.add(p);let x=nt.find(k=>k.id===p);ke?.id===p&&(ql(!1),oi(!0)),hu(k=>new Set(k).add(p)),x&&(H?.(x),bl("annotation.delete",{annotation:x})),P&&Le(()=>Pc(P,rn.current.get(p)??p)).catch(k=>{console.warn("[Agentation] Failed to delete annotation from server:",k)})},[nt,ke,H,bl,P,Le]),vu=(0,j.useCallback)(p=>{if(!p){Je(null),Zt(null),it([]);return}if(Je(p.id),p.elementBoundingBoxes?.length){let x=[];for(let k of p.elementBoundingBoxes){let R=k.x+k.width/2,q=k.y+k.height/2-window.scrollY,Y=Yc(R,q,k);Y&&x.push(Y)}it(x),Zt(null)}else if(p.boundingBox){let x=p.boundingBox,k=x.x+x.width/2,R=p.isFixed?x.y+x.height/2:x.y+x.height/2-window.scrollY,q=Yc(k,R,x);if(q){let Y=gn(q),X=Y.width/x.width,re=Y.height/x.height;X<.5||re<.5?Zt(null):Zt(q)}else Zt(null);it([])}else Zt(null),it([])},[]),K4=(0,j.useCallback)(p=>{if(!ke)return;let x={...ke,comment:p};ro(x),jo(k=>k.map(R=>R.id===ke.id?x:R)),te?.(x),bl("annotation.update",{annotation:x}),P&&Le(()=>O_(P,rn.current.get(ke.id)??ke.id,{comment:p})).catch(k=>{console.warn("[Agentation] Failed to update annotation on server:",k)}),ql(to.current||!!po.current?.matches(":hover")),oi(!0)},[ke,te,bl,P,Le]),J4=(0,j.useCallback)(()=>{ql(to.current||!!po.current?.matches(":hover")),oi(!0)},[]),P4=(0,j.useCallback)(()=>{gl&&ke&&!ae&&Je(ke.id),ro(null),$o(null),br([]),oi(!1)},[gl,ke,ae]),wu=(0,j.useCallback)((p,x)=>{if(!p.length&&!x)return;Qe(!0);let k={placements:[...ei.current.placements,...p],rearrange:x??ei.current.rearrange};ei.current=k,Dg(k.placements),Og(k.rearrange),clearTimeout(Ht.current),Ht.current=_e(()=>{ya(R=>R.filter(q=>!k.placements.includes(q))),Xl(R=>R===k.rearrange?null:R),ei.current={placements:[],rearrange:null},Dg([]),Og(null),Ht.current=void 0,Ct()},200)},[Ct]),Nr=(0,j.useCallback)(()=>{if(!ye.current)return;let p=new Map(yu.current.map(re=>[re.id,re])),x=[];for(let re of nt){let Ae=p.get(rn.current.get(re.id)??re.id)??p.get(re.id);Ae&&Ae.comment===re.comment&&!_t.current.has(Ae.id)&&!x.includes(Ae)&&x.push(Ae)}let k=x.length,R=zg.current,q=Et.filter(re=>R.designPlacements.includes(re)&&!ei.current.placements.includes(re)),Y=Ge===R.rearrangeState&&Ge!==ei.current.rearrange?Ge:null,X=Ql.filter(re=>K_.current.includes(re));if(!(k===0&&X.length===0&&q.length===0&&!Y)){for(let re of x)_t.current.add(re.id),ot.current.add(re.id),Ot.current.add(re.id);if(hu(re=>new Set([...re,...x.map(Ae=>Ae.id)])),B?.(x),bl("annotations.clear",{annotations:x}),P&&Promise.all(x.map(re=>Le(()=>Pc(P,rn.current.get(re.id)??re.id)).catch(Ae=>{console.warn("[Agentation] Failed to delete annotation from server:",Ae)}))),Qe(!0),$4(re=>re.filter(Ae=>!X.includes(Ae))),X.length>0&&X.length===K_.current.length){let re=J_.current;re?.getContext("2d")?.clearRect(0,0,re.width,re.height)}wu(q,Y),mn===R.blankCanvas&&no===R.wireframePurpose&&Et===R.designPlacements&&Ge===R.rearrangeState&&(mn&&Mg(!1),no&&cu(""),_s.current={rearrange:null,placements:[]},Jc(s)),Ct()}},[s,nt,Ql,Et,Ge,mn,no,B,bl,P,Le,Ct,wu]),e3=(0,j.useCallback)(async()=>{let p=le.start(),x=typeof window<"u"?window.location.pathname+window.location.search+window.location.hash:s,k=dn&&mn,R;if(k){if(Et.length===0&&!Ge&&!no)return;R=d?tu(x,d):""}else{if(R=cg(nt,x,Mt.outputDetail,{appName:d}),!R&&Ql.length===0&&Et.length===0&&!Ge)return;R||(R=tu(x,d))}if(!k&&Ql.length>0){let Y=new Set;for(let Be of nt)Be.drawingIndex!=null&&Y.add(Be.drawingIndex);let X=J_.current;X&&(X.style.visibility="hidden");let re=[],Ae=window.scrollY;for(let Be=0;Be<Ql.length;Be++){if(Y.has(Be))continue;let He=Ql[Be];if(He.points.length<2)continue;let $e=He.fixed?He.points:He.points.map(Cn=>({x:Cn.x,y:Cn.y-Ae})),lt=1/0,ct=1/0,Me=-1/0,Ye=-1/0;for(let Cn of $e)lt=Math.min(lt,Cn.x),ct=Math.min(ct,Cn.y),Me=Math.max(Me,Cn.x),Ye=Math.max(Ye,Cn.y);let Pe=Me-lt,wt=Ye-ct,cn=Math.hypot(Pe,wt),Xn=$e[0],Fe=$e[$e.length-1],Ve=Math.hypot(Fe.x-Xn.x,Fe.y-Xn.y),Tt,pn=Ve<cn*.35,vl=Pe/Math.max(wt,1);if(pn&&cn>20){let Cn=Math.max(Pe,wt)*.15,ba=0;for(let ys of $e){let o3=ys.x-lt<Cn,l3=Me-ys.x<Cn,a3=ys.y-ct<Cn,s3=Ye-ys.y<Cn;(o3||l3)&&(a3||s3)&&ba++}Tt=ba>$e.length*.15?"box":"circle"}else vl>3&&wt<40?Tt="underline":Ve>cn*.5?Tt="arrow":Tt="drawing";let ll=Math.min(10,$e.length),Rr=Math.max(1,Math.floor($e.length/ll)),ju=new Set,Qn=[],Ar=[Xn];for(let Cn=Rr;Cn<$e.length-1;Cn+=Rr)Ar.push($e[Cn]);Ar.push(Fe);for(let Cn of Ar){let ba=Ic(Cn.x,Cn.y);if(!ba||ju.has(ba)||zn(ba,"[data-feedback-toolbar]"))continue;ju.add(ba);let{name:ys}=os(ba);Qn.includes(ys)||Qn.push(ys)}let Eu=`${Math.round(lt)},${Math.round(ct)} \u2192 ${Math.round(Me)},${Math.round(Ye)}`,ii;(Tt==="circle"||Tt==="box")&&Qn.length>0?ii=`${Tt==="box"?"Boxed":"Circled"} **${Qn[0]}**${Qn.length>1?` (and ${Qn.slice(1).join(", ")})`:""} (region: ${Eu})`:Tt==="underline"&&Qn.length>0?ii=`Underlined **${Qn[0]}** (${Eu})`:Tt==="arrow"&&Qn.length>=2?ii=`Arrow from **${Qn[0]}** to **${Qn[Qn.length-1]}** (${Math.round(Xn.x)},${Math.round(Xn.y)} \u2192 ${Math.round(Fe.x)},${Math.round(Fe.y)})`:Qn.length>0?ii=`${Tt==="arrow"?"Arrow":"Drawing"} near **${Qn.join("**, **")}** (region: ${Eu})`:ii=`Drawing at ${Eu}`,re.push(ii)}X&&(X.style.visibility=""),re.length>0&&(R+=`
**Drawings:**
`,re.forEach((Be,He)=>{R+=`${He+1}. ${Be}
`}))}if((Et.length>0||k&&no)&&(R+=`
`+eg(Et,{width:window.innerWidth,height:window.innerHeight},{blankCanvas:mn,wireframePurpose:no||void 0},Mt.outputDetail)),Ge){let Y=tg(Ge,Mt.outputDetail,{width:window.innerWidth,height:window.innerHeight});Y&&(R+=`
`+Y)}if(R=ug(nt,R,w),!R){ee(!1);return}let q=!G||await r4(R);K?.(R),le.isCurrent(p)&&(ee(q),q&&(le.schedule(p,()=>ee(!1),2e3),Mt.autoClearAfterCopy&&le.schedule(p,Nr,500)))},[nt,Ql,Et,Ge,mn,dn,Rg,no,s,Mt.outputDetail,Wl,xe,Mt.autoClearAfterCopy,Nr,le,G,w,d,K]),r0=xg(Mt.webhookUrl)||xg(se||""),Su=Se!=null||r0&&!Mt.webhooksEnabled,ku=oe?Math.min(256,window.innerWidth-32):56,t3=(0,j.useCallback)(async()=>{let p=ge.start(),x=typeof window<"u"?window.location.href:s,k=typeof window<"u"?window.location.pathname+window.location.search+window.location.hash:s,R=cg(nt,k,Mt.outputDetail,{appName:d});if(!R&&Et.length===0&&!Ge)return;if(R||(R=tu(k,d)),Et.length>0&&(R+=`
`+eg(Et,{width:window.innerWidth,height:window.innerHeight},{blankCanvas:mn,wireframePurpose:no||void 0},Mt.outputDetail)),Ge){let re=tg(Ge,Mt.outputDetail,{width:window.innerWidth,height:window.innerHeight});re&&(R+=`
`+re)}ie("sending");let q=!0;try{await Se?.(R,nt)}catch(re){console.warn("[Agentation] Submit callback failed:",re),q=!1}if(!ge.isCurrent(p))return;let Y=r0?await bl("submit",{output:R,annotations:nt,url:x},!0):!0,X=q&&Y&&Su;ge.isCurrent(p)&&(ie(X?"sent":"failed"),ge.schedule(p,()=>ie("idle"),2500),X&&Mt.autoClearAfterCopy&&ge.schedule(p,Nr,500))},[Se,d,bl,nt,Et,Ge,mn,Rg,s,Mt.outputDetail,Wl,xe,Mt.autoClearAfterCopy,Nr,r0,Su,ge]);(0,j.useEffect)(()=>{let x=(X=!1)=>{kr.current?.dragging&&(Fl.current=X,Gg(!1)),kr.current=null},k=X=>{let re=kr.current;if(!re)return;if((X.buttons&1)===0){x();return}let Ae=X.clientX-re.x,Be=X.clientY-re.y,He=Math.sqrt(Ae*Ae+Be*Be);if(!re.dragging&&He>10&&(re.dragging=!0,Gg(!0)),re.dragging){let $e=re.toolbarX+Ae,lt=re.toolbarY+Be,ct=20,Me=337,Ye=56,wt=Me-ku,cn=ct-wt,Xn=window.innerWidth-ct-Me;$e=Math.max(cn,Math.min(Xn,$e)),lt=Math.max(ct,Math.min(window.innerHeight-Ye-ct,lt)),t0({x:$e,y:lt})}},R=()=>{x(!0),_e(()=>{Fl.current=!1},250)},q=X=>{Fl.current&&(Fl.current=!1,X.preventDefault(),X.stopImmediatePropagation())};window.addEventListener("click",q,!0);let Y=()=>x();return me.addEventListener("mousemove",k),me.addEventListener("mouseup",R,!0),window.addEventListener("blur",Y),()=>{me.removeEventListener("mousemove",k),me.removeEventListener("mouseup",R,!0),window.removeEventListener("blur",Y),window.removeEventListener("click",q,!0)}},[ku]);let n3=(0,j.useCallback)(p=>{if(Fl.current=!1,kr.current=null,p.button!==0||p.target.closest(".bb-tray-panel, [data-agentation-settings-panel]"))return;let x=p.currentTarget.parentElement;if(!x)return;let k=gn(x);kr.current={x:p.clientX,y:p.clientY,toolbarX:k.left,toolbarY:k.top,dragging:!1}},[oe]);(0,j.useLayoutEffect)(()=>{if(!wn)return;let p=()=>{let q=wn.x,Y=wn.y,Ae=20-(337-ku),Be=window.innerWidth-20-337;q=Math.max(Ae,Math.min(Be,q)),Y=Math.max(20,Math.min(window.innerHeight-56-20,Y)),(q!==wn.x||Y!==wn.y)&&t0({x:q,y:Y})};return p(),window.addEventListener("resize",p),()=>window.removeEventListener("resize",p)},[wn,ku]),(0,j.useEffect)(()=>{if(!_)return;let p=k=>{if(k.defaultPrevented||k.isComposing||k.altKey)return;let R=k.composedPath()[0]||k.target,q=R.tagName==="INPUT"||R.tagName==="TEXTAREA"||R.tagName==="SELECT"||R.isContentEditable;if(k.key==="Escape"){if(E&&!ae&&!ke&&(oe||yl||dn||xl||yo.length)&&(k.preventDefault(),k.stopPropagation()),yl){k.preventDefault(),ru(!1),Zs.current?.focus();return}if(dn){Ks?ds(null):Jg();return}if(xl){U4(!1);return}if(yo.length>0){Gl([]);return}ae||ke||oe&&(du(),ai())}if((k.metaKey||k.ctrlKey)&&k.shiftKey&&(k.key==="f"||k.key==="F")){k.preventDefault(),du(),oe?ai():(ml.current?.blur(),Uo.current=!0,ze(!0));return}!oe||q||k.metaKey||k.ctrlKey||k.repeat},x=!!E;return me.addEventListener("keydown",p,x),()=>me.removeEventListener("keydown",p,x)},[_,E,ke,oe,xl,dn,Ks,Et,Ge,ae,nt.length,Su,je,t3,e1,e3,Nr,yo,yl,ai,W4,Jg]);let V7=nt.length>0,Cu=On(),t1=nt.filter(p=>p.kind!=="placement"&&p.kind!=="rearrange"),n1=t1.flatMap((p,x)=>{let k=Cu(p);return k?[{annotation:k,index:x}]:[]}),o1=ae&&!ae.isSubmitted?Cu({...ae,comment:"",timestamp:0}):null,l1=[...Oe?n1.map(p=>({...p,pending:!1})):[],...o1?[{annotation:o1,index:t1.length,pending:!0}]:[]];(0,j.useEffect)(()=>{let p=new Set(Oe&&!pa?n1.map(({annotation:x})=>x.id):[]);ol.current&&!p.has(ol.current)&&(ol.current=null);for(let x of xa)p.has(x)||a0(x)}),(0,j.useEffect)(()=>{ke&&xa.has(ke.id)&&(ql(!1),oi(!0))},[ke,xa]);let a1=(0,j.useCallback)(p=>{!We&&p.id!==ol.current&&vu(p)},[We,vu]),s1=(0,j.useCallback)(p=>{ht===p&&vu(null)},[ht,vu]),i1=(0,j.useCallback)((p,x)=>{if(ke&&!gs){gu.current?.shake();return}Io&&i0(),Mt.markerClickBehavior==="delete"?bu(p.id):si(p,x)},[Mt.markerClickBehavior,bu,si,Io,i0,ke,gs]),qo=ke??(pu&&!ae&&!Ee?nt.find(p=>p.id===ht&&!xa.has(p.id)):null),W7=pl?"Resume animations":"Pause animations",F7=dn?"Exit layout mode":"Layout mode",Z7=rs?"Hide markers":"Show markers",J7=w!=="markdown"&&!ug(nt,"",w),P7=typeof w=="object"?`Copy ${w.attribute}`:w==="source"?"Copy source paths":w==="classes"?"Copy classes":dn&&mn?"Copy layout":"Copy feedback";(0,j.useEffect)(()=>{let p=x=>{!oe||x.key!=="Escape"||x.isComposing||(x.preventDefault(),x.stopImmediatePropagation(),D(null),ro(null),Gl([]),mt(null),du(),ai())};return window.addEventListener("keydown",p,!0),()=>window.removeEventListener("keydown",p,!0)},[oe,ai]),(0,j.useEffect)(()=>{oe&&t.settings?.freezeAnimations&&!pl&&e1()},[oe]),(0,j.useEffect)(()=>{let p=t.scope+"-edit-on-load",x=t.storage.getItem(p),k=nt.find(R=>R.id===x);if(k){if(!oe){ze(!0);return}t.storage.removeItem(p),si(k)}},[nt,oe]);let r1=vg(nt,s).length,e9=oe?0:-1;return!zt||pa?null:(0,Te.jsxs)(ib,{host:"agentation-toolbar",className:Ue,children:[(0,Te.jsxs)("style",{"data-agentation-styles":"toolbar",children:[C4+`/* Scoped inside Agentation's Shadow DOM; site styles are unaffected. */
[data-agentation-root] {font:16px/1.45 Arial,sans-serif}
[data-agentation-root] *,[data-agentation-root] *::before,[data-agentation-root] *::after {box-sizing:border-box;min-width:0}
[data-agentation-toolbar] {right:16px;bottom:16px;left:auto;top:auto}
[class*='toolbarContainer'],[class*='toolbarContainer'] button {cursor:grab}
[data-agentation-toolbar][data-dragging] {transition:none!important}
[data-agentation-toolbar][data-dragging] *,[data-agentation-toolbar][data-dragging] button {cursor:grabbing!important}
[class*='toolbarContainer'] {height:56px!important;width:56px!important;min-width:56px!important;border-radius:16px!important;overflow:visible!important}
[class*='toolbarContainer'][class*='expanded'] {width:256px!important;max-width:calc(100vw - 32px)!important}
[class*='toolbarContainer'] {transition:none!important}
[class*='controlsContent'] {height:56px!important;padding:8px!important;gap:8px!important}
[class*='controlsContent'][class*='__visible___'] {filter:none!important;transform:none!important;transition:none!important}
[class*='controlsContent'][class*='__hidden___'] {visibility:hidden!important;opacity:0!important;filter:none!important;transform:none!important;transition:none!important;clip-path:inset(0)!important}
[class*='hoverTooltip'] {font:500 14px/20px Arial,sans-serif!important;min-height:32px!important;padding:6px 10px!important;max-width:calc(100vw - 32px)!important}
[class*='hoverTooltip'] * {font-size:inherit!important;line-height:inherit!important}
[class*='toggleContent'] {width:44px!important;height:44px!important;border-radius:12px!important}
[class*='toggleWrapper'] {width:44px!important;height:44px!important;right:6px!important;top:6px!important}
[class*='togglePlaceholder'] {width:44px!important;flex:0 0 44px!important}
[class*='buttonTooltip'] {font-size:14px!important;line-height:20px!important;padding:8px 12px!important}
[class*='shortcut'] {font-size:13px!important}
[data-annotation-popup] {width:380px!important;max-width:calc(100vw - 24px)!important;max-height:calc(100dvh - 24px)!important;overflow:auto!important}
[data-annotation-popup] {animation-duration:1ms!important;animation-delay:0ms!important}
[data-annotation-popup]:not([data-annotation-card]) {transform:translateX(-50%)!important}
[data-annotation-popup] [class*='sharedForm'] {--card-motion:0ms!important}
[data-annotation-popup] [class*='popup'],[data-annotation-popup] [class*='sharedForm'] {padding:16px!important}
[data-annotation-popup] textarea {font:16px/1.5 Arial,sans-serif!important;min-height:96px!important;padding:12px!important;resize:vertical!important;max-width:100%!important;width:100%!important}
[data-annotation-popup] button {font:16px/1.3 Arial,sans-serif!important;min-height:40px!important;padding:8px 12px!important;white-space:normal!important}
[data-annotation-popup] [class*='element'] {font-size:14px!important;line-height:1.4!important;overflow-wrap:anywhere}
[data-annotation-popup] [class*='__styleProperty'],[data-annotation-popup] [class*='__styleValue'],[data-annotation-popup] [class*='__styleLine'] {font-size:13px!important;line-height:1.4!important}
[data-annotation-popup] [class*='sharedNote'] {height:auto!important;min-height:96px!important}
[data-annotation-popup] [class*='actions'] {gap:8px!important;flex-wrap:wrap!important}
[class*='label'] {font-size:13px!important;line-height:18px!important}
.bb-session-tray {font:16px/1.45 Arial,sans-serif;position:static;color:#fff}
.bb-session-tray button {font:16px/1.3 Arial,sans-serif;min-height:40px;border:1px solid #555;border-radius:8px;padding:8px 12px;background:#303030;color:#fff;cursor:pointer}
.bb-session-tray button:hover {background:#454545}
.bb-tray-toggle {width:180px;white-space:nowrap;display:flex;align-items:center;justify-content:center;gap:8px}
.bb-count-label,[class*='toolbarContainer'] [class*='__badge___'] {display:inline-flex!important;align-items:center!important;justify-content:center!important;width:28px!important;height:28px!important;min-width:28px!important;flex:0 0 28px;border-radius:50%!important;font:600 14px/1 Arial,sans-serif!important;background:#0088ff!important;color:#fff!important;padding:0!important}
.bb-tray-panel {position:absolute;width:400px;max-width:calc(100vw - 32px);max-height:calc(100dvh - 110px);overflow:auto;border:1px solid #555;border-radius:16px;padding:16px;background:#202020;color:#fff;box-shadow:0 8px 32px #0005;overflow-wrap:anywhere}
.bb-tray-panel header {display:flex;justify-content:space-between;gap:12px;align-items:center}
.bb-tray-panel p {margin:12px 0;font-size:16px;line-height:1.45}
.bb-tray-panel article {padding:12px 0;border-bottom:1px solid #555}
.bb-tray-panel small,.bb-tray-help {font-size:14px!important;color:#bbb}
.bb-session-tray .bb-disable-widget {display:block;margin-top:24px}
.bb-tray-actions {display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.bb-session-tray button:disabled {opacity:.5;cursor:default}
.bb-session-tray .bb-submit-work {width:100%;margin-top:16px;background:#0088ff;color:#fff;border-color:#0088ff}
[data-agentation-theme='light'] .bb-tray-panel {background:#fff;color:#171717;border-color:#ccc}
[data-agentation-theme='light'] .bb-session-tray button {background:#f2f2f2;color:#171717;border-color:#ccc}
[data-agentation-theme='light'] .bb-tray-panel small,[data-agentation-theme='light'] .bb-tray-help {color:#555}
:host,:host * {cursor:default!important}
[class*='toggleContent']:focus,[class*='toggleContent']:focus-visible {outline:none!important;outline-offset:0!important}
[class*='toggleIcon'] {position:static!important;transform:none!important}
[class*='toolbarContainer'] [class*='__badge___'] {width:22px!important;height:22px!important;min-width:22px!important;top:-12px!important;right:-12px!important;pointer-events:none!important}
`,M4]}),(0,Te.jsxs)("div",{ref:vn,className:fe.positionContext,style:{display:"contents"},"data-agentation-theme":Vl?"dark":"light","data-agentation-accent":Mt.annotationColorId,"data-agentation-root":"",children:[(0,Te.jsx)("div",{className:fe.toolbar,"data-feedback-toolbar":!0,"data-agentation-toolbar":!0,"data-dragging":fu||void 0,style:wn?{left:wn.x,top:wn.y,right:"auto",bottom:"auto"}:void 0,children:(0,Te.jsxs)("div",{className:`${fe.toolbarContainer} ${oe?fe.expanded:fe.collapsed} ${Yg?fe.entrance:""} ${$l?fe.hiding:""} ${Su?fe.serverConnected:""}`,onMouseDown:n3,onClickCapture:p=>{Fl.current&&(Fl.current=!1,p.preventDefault(),p.stopPropagation())},children:[(0,Te.jsxs)("div",{className:`${fe.controlsContent} ${oe?fe.visible:fe.hidden} ${wn&&wn.y<100?fe.tooltipBelow:""} ${Eg||yl?fe.tooltipsHidden:""} ${P_?fe.tooltipsInSession:""}`,ref:p=>{hl.current=p,p?.toggleAttribute("inert",!oe)},role:"group","aria-label":"\u041F\u0430\u043D\u0435\u043B\u044C \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0439","aria-hidden":!oe,onMouseEnter:Ug,onMouseLeave:$g,children:[(0,Te.jsx)(N4,{current:nt,pathname:s,active:oe,toolbarPosition:wn,edit:(p,x)=>si(p,x),remove:p=>bu(p.id),otherDelete:p=>{H?.(p),jo(x=>[...x])},submitted:p=>{let x=new Set(p);for(let[k,R]of _r())dr(k,R.filter(q=>!x.has(String(q.id))));jo(k=>k.filter(R=>!x.has(String(R.id)))),ro(null),D(null)}}),(0,Te.jsx)("div",{className:fe.togglePlaceholder,"aria-hidden":!0})]}),(0,Te.jsxs)("div",{className:`${fe.buttonWrapper} ${fe.toggleWrapper} ${wn&&wn.y<100?fe.tooltipBelow:""} ${!oe||Eg||yl?fe.tooltipsHidden:""} ${P_?fe.tooltipsInSession:""} ${wn&&typeof window<"u"&&wn.x>window.innerWidth-120?fe.buttonWrapperAlignRight:""}`,onMouseEnter:Ug,onMouseLeave:$g,children:[(0,Te.jsx)("button",{ref:ml,type:"button",className:`${fe.toggleContent} ${oe?fe.expandedToggle:""}`,"aria-label":oe?"\u0412\u044B\u0439\u0442\u0438":"\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435","aria-expanded":oe,"aria-keyshortcuts":_?"Meta+Shift+F Control+Shift+F":void 0,title:oe?void 0:_?"\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435 (Ctrl+Shift+F)":"\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435",onClick:p=>{if(Fl.current){Fl.current=!1,p.preventDefault();return}p.stopPropagation(),oe?(du(),ai()):(p.currentTarget.blur(),Uo.current=p.detail===0,ze(!0))},children:(0,Te.jsxs)("span",{className:fe.toggleIcon,children:[(0,Te.jsx)(Yb,{active:oe}),r1>0&&(0,Te.jsx)("span",{className:`${fe.badge} ${oe?fe.fadeOut:""} ${Yg?fe.entrance:""}`,children:r1})]})}),(0,Te.jsxs)("span",{className:fe.buttonTooltip,"aria-hidden":!oe,children:["\u0412\u044B\u0439\u0442\u0438",_&&(0,Te.jsx)("span",{className:fe.shortcut,children:"Esc"})]})]}),(0,Te.jsx)(cw,{visible:dn&&oe,activeType:Ks,onSelect:p=>{ds(Ks===p?null:p)},isDarkMode:Vl,sectionCount:Ge?.sections.length??0,onDetectSections:()=>{let p=fw(),x=Ge?.sections??[],k=new Set(x.map(X=>X.selector)),R=p.filter(X=>!k.has(X.selector)),q=[...x,...R],Y=[...Ge?.originalOrder??[],...R.map(X=>X.id)];Xl({sections:q,originalOrder:Y,detectedAt:Date.now()})},placementCount:Et.length,onClearPlacements:()=>{wu(Et,Ge)},blankCanvas:mn,onBlankCanvasChange:p=>{let x={sections:[],originalOrder:[],detectedAt:Date.now()};p?(V_.current={rearrange:Ge,placements:Et},Xl(_s.current.rearrange||x),ya(_s.current.placements),ds(null)):(_s.current={rearrange:Ge,placements:Et},Xl(V_.current.rearrange||x),ya(V_.current.placements)),Mg(p)},wireframePurpose:no,onWireframePurposeChange:cu,Tooltip:as,onDragStart:(p,x)=>{x.preventDefault();let k=pe[p],R=null,q=!1,Y=x.clientX,X=x.clientY,Ae=x.target.closest("[data-feedback-toolbar]")?.getBoundingClientRect().top??window.innerHeight,Be=$e=>{let lt=$e.clientX-Y,ct=$e.clientY-X;if(!q&&(Math.abs(lt)>4||Math.abs(ct)>4)&&(q=!0,R=document.createElement("div"),R.className=`${Z.dragPreview}${mn?` ${Z.dragPreviewWireframe}`:""}`,vn.current?.appendChild(R)),!R)return;let Me=Math.max(0,Ae-$e.clientY),Ye=Math.min(1,Me/180),Pe=1-Math.pow(1-Ye,2),wt=28,cn=20,Xn=Math.min(140,k.width*.18),Fe=Math.min(90,k.height*.18),Ve=wt+(Xn-wt)*Pe,Tt=cn+(Fe-cn)*Pe;R.style.width=`${Ve}px`,R.style.height=`${Tt}px`,R.style.left=`${$e.clientX-Ve/2}px`,R.style.top=`${$e.clientY-Tt/2}px`,R.style.opacity=`${.5+.5*Pe}`,R.textContent=Pe>.25?p:""},He=$e=>{if(window.removeEventListener("mousemove",Be),window.removeEventListener("mouseup",He),R&&R.remove(),q){let lt=k.width,ct=k.height,Me=window.scrollY,Ye=Math.max(0,$e.clientX-lt/2),Pe=Math.max(0,$e.clientY+Me-ct/2),wt={id:`dp-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,type:p,x:Ye,y:Pe,width:lt,height:ct,scrollY:Me,timestamp:Date.now()};ya(cn=>[...cn,wt]),ds(null),wr.current=new Set,Ag(cn=>cn+1)}};window.addEventListener("mousemove",Be),window.addEventListener("mouseup",He)}}),(0,Te.jsx)(v4,{settings:Mt,onSettingsChange:q4,isDarkMode:Vl,onToggleTheme:X4,isDevMode:Xg,connectionStatus:_u,endpoint:P,onExited:G4,isOpen:oe&&yl,toolbarNearBottom:!!wn&&wn.y<230,settingsPage:A4,onSettingsPageChange:jg,onHideToolbar:V4})]})}),(dn||us)&&(0,Te.jsx)("div",{className:`${Z.blankCanvas} ${Tg?Z.visible:""} ${O4?Z.gridActive:""}`,style:{"--canvas-opacity":Ng},"data-feedback-toolbar":!0}),dn&&mn&&Tg&&(0,Te.jsxs)("div",{className:Z.wireframeNotice,"data-feedback-toolbar":!0,children:[(0,Te.jsxs)("div",{className:Z.wireframeOpacityRow,children:[(0,Te.jsx)("span",{className:Z.wireframeOpacityLabel,children:"Toggle Opacity"}),(0,Te.jsx)("input",{type:"range",className:Z.wireframeOpacitySlider,min:0,max:1,step:.01,value:Ng,onChange:p=>D4(Number(p.target.value))})]}),(0,Te.jsxs)("div",{className:Z.wireframeNoticeTitleRow,children:[(0,Te.jsx)("span",{className:Z.wireframeNoticeTitle,children:"Wireframe Mode"}),(0,Te.jsx)("span",{className:Z.wireframeNoticeDivider}),(0,Te.jsx)("button",{className:Z.wireframeStartOver,onClick:()=>{wu(Et,Ge),_s.current={rearrange:null,placements:[]},cu(""),Jc(s)},children:"Start Over"})]}),"Drag components onto the canvas.",(0,Te.jsx)("br",{}),"Copied output will only include the wireframed layout."]}),(dn||us)&&(0,Te.jsx)(lw,{placements:Et,onChange:ya,activeComponent:us?null:Ks,onActiveComponentChange:ds,isDarkMode:Vl,exiting:us,onInteractionChange:z4,passthrough:!Ks,extraSnapRects:Ge?.sections.map(p=>p.currentRect),deselectSignal:L4,clearingPlacements:Js,wireframe:mn,onSelectionChange:(p,x)=>{wr.current=p,x||(uu.current=new Set,H4(k=>k+1))},onDragMove:(p,x)=>{let k=uu.current;if(!(!k.size||!Ge)){if(!nl.current){nl.current=new Map;for(let R of Ge.sections)k.has(R.id)&&nl.current.set(R.id,{x:R.currentRect.x,y:R.currentRect.y})}for(let R of Ge.sections){if(!k.has(R.id)||!nl.current.get(R.id))continue;let Y=vn.current?.querySelector(`[data-rearrange-section="${R.id}"]`);Y&&(Y.style.transform=`translate(${p}px, ${x}px)`)}}},onDragEnd:(p,x,k)=>{let R=uu.current,q=nl.current;if(nl.current=null,!(!R.size||!Ge||!q)){for(let Y of R){let X=vn.current?.querySelector(`[data-rearrange-section="${Y}"]`);X&&(X.style.transform="")}k&&Xl(Y=>Y&&{...Y,sections:Y.sections.map(X=>{let re=q.get(X.id);return re?{...X,currentRect:{...X.currentRect,x:Math.max(0,re.x+p),y:Math.max(0,re.y+x)}}:X})})}}}),(dn||us)&&Ge&&(0,Te.jsx)(gw,{rearrangeState:Ge,onChange:Xl,isDarkMode:Vl,exiting:us,blankCanvas:mn,extraSnapRects:Et.map(p=>({x:p.x,y:p.y,width:p.width,height:p.height})),clearing:Ge===Ps,deselectSignal:B4,onSelectionChange:(p,x)=>{uu.current=p,x||(wr.current=new Set,Ag(k=>k+1))},onDragMove:(p,x)=>{let k=wr.current;if(k.size){if(!nl.current){nl.current=new Map;for(let R of Et)k.has(R.id)&&nl.current.set(R.id,{x:R.x,y:R.y})}for(let R of k){let q=vn.current?.querySelector(`[data-design-placement="${R}"]`);q&&(q.style.transform=`translate(${p}px, ${x}px)`)}}},onDragEnd:(p,x,k)=>{let R=wr.current,q=nl.current;if(nl.current=null,!(!R.size||!q)){for(let Y of R){let X=vn.current?.querySelector(`[data-design-placement="${Y}"]`);X&&(X.style.transform="")}k&&ya(Y=>Y.map(X=>{let re=q.get(X.id);return re?{...X,x:Math.max(0,re.x+p),y:Math.max(0,re.y+x)}:X}))}}}),(0,Te.jsx)("canvas",{ref:J_,className:`${fe.drawCanvas} ${xl?fe.active:""}`,"aria-hidden":"true",style:{opacity:pu?1:0,transition:"opacity 0.15s ease"},"data-feedback-toolbar":!0}),(0,Te.jsx)("div",{className:fe.markersLayer,"data-feedback-toolbar":!0,children:l1.filter(({annotation:p})=>!p.isFixed).map(({annotation:p,index:x,pending:k},R,q)=>(0,Te.jsx)(mg,{annotation:p,pending:k,globalIndex:x,layerIndex:R,layerSize:q.length,isExiting:k?Io:We,isClearing:ot.current.has(p.id),isAnimated:hs.current.has(p.id),isNew:ol.current===p.id,onEnterComplete:Vg,isHovered:!We&&ht===p.id,isRemoving:xa.has(p.id),onRemoveComplete:a0,isEditingAny:!!ke,renumberFrom:jt,markerClickBehavior:Mt.markerClickBehavior,onHoverEnter:a1,onHoverLeave:s1,onClick:i1,onContextMenu:si},mu.current.get(p.id)??p.id))}),(0,Te.jsx)("div",{className:fe.fixedMarkersLayer,"data-feedback-toolbar":!0,children:l1.filter(({annotation:p})=>p.isFixed).map(({annotation:p,index:x,pending:k},R,q)=>(0,Te.jsx)(mg,{annotation:p,pending:k,globalIndex:x,layerIndex:R,layerSize:q.length,isExiting:k?Io:We,isClearing:ot.current.has(p.id),isAnimated:hs.current.has(p.id),isNew:ol.current===p.id,onEnterComplete:Vg,isHovered:!We&&ht===p.id,isRemoving:xa.has(p.id),onRemoveComplete:a0,isEditingAny:!!ke,renumberFrom:jt,markerClickBehavior:Mt.markerClickBehavior,onHoverEnter:a1,onHoverLeave:s1,onClick:i1,onContextMenu:si},mu.current.get(p.id)??p.id))}),oe&&kt&&!ae&&!ke&&!Sg&&!Zl&&(0,Te.jsx)(w4,{x:vt.x,y:vt.y,elementName:kt.elementName,reactComponents:kt.reactComponents}),oe&&(0,Te.jsxs)("div",{className:fe.overlay,"data-feedback-toolbar":!0,style:ae||ke?{zIndex:"inherit"}:void 0,children:[kt?.rect&&!ae&&!Sg&&!Zl&&(0,Te.jsx)("div",{className:`${fe.hoverHighlight} ${fe.enter}`,style:{left:kt.rect.left,top:kt.rect.top,width:kt.rect.width,height:kt.rect.height,borderColor:"color-mix(in srgb, var(--agentation-color-accent) 50%, transparent)",backgroundColor:"color-mix(in srgb, var(--agentation-color-accent) 4%, transparent)",...kt.isPiercing?{borderStyle:"dashed"}:{}}}),yo.filter(p=>p.element.isConnected).map((p,x)=>{let k=gn(p.element),R=yo.length>1;return(0,Te.jsx)("div",{className:R?fe.multiSelectOutline:fe.singleSelectOutline,style:{position:"fixed",left:k.left,top:k.top,width:k.width,height:k.height,...R?{}:{borderColor:"color-mix(in srgb, var(--agentation-color-accent) 60%, transparent)",backgroundColor:"color-mix(in srgb, var(--agentation-color-accent) 5%, transparent)"}}},x)}),ht&&!ae&&(()=>{let p=nt.find(q=>q.id===ht);if(!p?.boundingBox)return null;if(p.elementBoundingBoxes?.length)return Ut.length>0?Ut.filter(q=>q.isConnected).map((q,Y)=>{let X=gn(q);return(0,Te.jsx)("div",{className:`${fe.multiSelectOutline} ${fe.enter}`,style:{left:X.left,top:X.top,width:X.width,height:X.height}},`hover-outline-live-${Y}`)}):p.elementBoundingBoxes.map((q,Y)=>(0,Te.jsx)("div",{className:`${fe.multiSelectOutline} ${fe.enter}`,style:{left:q.x,top:q.y-cs,width:q.width,height:q.height}},`hover-outline-${Y}`));let x=Pt&&Pt.isConnected?gn(Pt):null,k=x?{x:x.left,y:x.top,width:x.width,height:x.height}:{x:p.boundingBox.x,y:p.isFixed?p.boundingBox.y:p.boundingBox.y-cs,width:p.boundingBox.width,height:p.boundingBox.height},R=p.isMultiSelect;return(0,Te.jsx)("div",{className:`${R?fe.multiSelectOutline:fe.singleSelectOutline} ${fe.enter}`,style:{left:k.x,top:k.y,width:k.width,height:k.height,...R?{}:{borderColor:"color-mix(in srgb, var(--agentation-color-accent) 60%, transparent)",backgroundColor:"color-mix(in srgb, var(--agentation-color-accent) 5%, transparent)"}}})})(),ae&&(0,Te.jsxs)(Te.Fragment,{children:[ae.multiSelectElements?.length?ae.multiSelectElements.filter(p=>p.isConnected).map((p,x)=>{let k=gn(p);return(0,Te.jsx)("div",{className:`${fe.multiSelectOutline} ${Io?fe.exit:fe.enter}`,style:{left:k.left,top:k.top,width:k.width,height:k.height}},`pending-multi-${x}`)}):ae.targetElement&&ae.targetElement.isConnected?(()=>{let p=gn(ae.targetElement);return(0,Te.jsx)("div",{className:`${fe.singleSelectOutline} ${Io?fe.exit:fe.enter}`,style:{left:p.left,top:p.top,width:p.width,height:p.height,borderColor:"color-mix(in srgb, var(--agentation-color-accent) 60%, transparent)",backgroundColor:"color-mix(in srgb, var(--agentation-color-accent) 5%, transparent)"}})})():ae.boundingBox&&(0,Te.jsx)("div",{className:`${ae.isMultiSelect?fe.multiSelectOutline:fe.singleSelectOutline} ${Io?fe.exit:fe.enter}`,style:{left:ae.boundingBox.x,top:ae.boundingBox.y-cs,width:ae.boundingBox.width,height:ae.boundingBox.height,...ae.isMultiSelect?{}:{borderColor:"color-mix(in srgb, var(--agentation-color-accent) 60%, transparent)",backgroundColor:"color-mix(in srgb, var(--agentation-color-accent) 5%, transparent)"}}}),(()=>{let p=Cu(ae)??ae,x=p.x,k=p.isFixed?p.y:p.y-cs;return(0,Te.jsx)(Te.Fragment,{children:(0,Te.jsx)(Qc,{ref:l0,element:ae.element,selectedText:ae.selectedText,allowEmpty:typeof w=="object"&&!!ae.attributes?.[w.attribute],onOpenSource:y&&ae.sourceFile?()=>y(ae.sourceFile):void 0,computedStyles:ae.computedStylesObj,placeholder:typeof w=="object"&&ae.attributes?.[w.attribute]?"\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435":ae.element==="\u0412\u044B\u0431\u0440\u0430\u043D\u043D\u0430\u044F \u043E\u0431\u043B\u0430\u0441\u0442\u044C"?"\u0427\u0442\u043E \u043D\u0443\u0436\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u0432 \u044D\u0442\u043E\u0439 \u043E\u0431\u043B\u0430\u0441\u0442\u0438?":ae.isMultiSelect?"\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435 \u043A \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u043C \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u043C\u2026":"\u0427\u0442\u043E \u043D\u0443\u0436\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C?",onSubmit:F4,onExitComplete:i0,onCancel:Z4,isExiting:Io,lightMode:!Vl,accentColor:ae.isMultiSelect?"var(--agentation-color-green)":"var(--agentation-color-accent)",style:{left:Math.max(Math.min(202,window.innerWidth/2),Math.min(window.innerWidth-Math.min(202,window.innerWidth/2),x/100*window.innerWidth)),...k>window.innerHeight-290?{bottom:window.innerHeight-k+20}:{top:k+20}}},ae.id)})})()]}),ke&&(0,Te.jsx)(Te.Fragment,{children:ke.elementBoundingBoxes?.length?xr.length>0?xr.filter(p=>p.isConnected).map((p,x)=>{let k=gn(p);return(0,Te.jsx)("div",{className:`${fe.multiSelectOutline} ${fe.enter}`,style:{left:k.left,top:k.top,width:k.width,height:k.height}},`edit-multi-live-${x}`)}):ke.elementBoundingBoxes.map((p,x)=>(0,Te.jsx)("div",{className:`${fe.multiSelectOutline} ${fe.enter}`,style:{left:p.x,top:p.y-cs,width:p.width,height:p.height}},`edit-multi-${x}`)):(()=>{let p=tl&&tl.isConnected?gn(tl):null,x=p?{x:p.left,y:p.top,width:p.width,height:p.height}:ke.boundingBox?{x:ke.boundingBox.x,y:ke.isFixed?ke.boundingBox.y:ke.boundingBox.y-cs,width:ke.boundingBox.width,height:ke.boundingBox.height}:null;return x?(0,Te.jsx)("div",{className:`${ke.isMultiSelect?fe.multiSelectOutline:fe.singleSelectOutline} ${fe.enter}`,style:{left:x.x,top:x.y,width:x.width,height:x.height,...ke.isMultiSelect?{}:{borderColor:"color-mix(in srgb, var(--agentation-color-accent) 60%, transparent)",backgroundColor:"color-mix(in srgb, var(--agentation-color-accent) 5%, transparent)"}}}):null})()}),Zl&&(0,Te.jsxs)(Te.Fragment,{children:[(0,Te.jsx)("div",{ref:jr,className:fe.dragSelection}),(0,Te.jsx)("div",{ref:li,className:fe.highlightsContainer})]})]}),(0,Te.jsx)(f4,{ref:gu,annotation:qo?Cu(qo)??ke:null,editing:!!ke,exiting:gs,restorePreview:gl,scrollY:cs,lightMode:!Vl,onExited:P4,editorProps:qo?{element:qo.element,selectedText:qo.selectedText,allowEmpty:typeof w=="object"&&!!qo.attributes?.[w.attribute],onOpenSource:y&&qo.sourceFile?()=>y(qo.sourceFile):void 0,computedStyles:K2(qo.computedStyles),placeholder:"\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u0435 \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435\u2026",initialValue:qo.comment,submitLabel:"\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",onSubmit:K4,onCancel:J4,onDelete:()=>bu(qo.id),accentColor:qo.isMultiSelect?"var(--agentation-color-green)":"var(--agentation-color-accent)"}:void 0})]})]})}function vg(s,i){let r=_r();r.set(i,s);let u=new Map;for(let[d,_]of r)for(let g of _)u.set(String(g.id),{...g,bbPage:d});return[...u.values()].sort((d,_)=>_.timestamp-d.timestamp)}function N4({current:s,pathname:i,edit:r,remove:u,otherDelete:d,submitted:_,active:g,toolbarPosition:w}){let y=tn(),E=y.createElement,[M,S]=y.useState(!1),[,O]=y.useReducer(se=>se+1,0),[W,H]=y.useState(!1),[te,B]=y.useState(""),K=y.useRef(!1),Se=y.useRef(null),G=_r();G.set(i,s);let P=vg(s,i);y.useEffect(()=>{g||S(!1)},[g]),y.useLayoutEffect(()=>{if(!M||!Se.current)return;let se=()=>{let Ue=Se.current,oe=Ue.parentElement.querySelector(".bb-tray-toggle").getBoundingClientRect(),ze=Ue.getBoundingClientRect(),Re=Ue.closest('[class*="toolbarContainer"]').getBoundingClientRect();Ue.style.left=Math.max(16,Math.min(window.innerWidth-ze.width-16,oe.right-ze.width))-Re.left+"px";let me=oe.top-ze.height-12>=16?oe.top-ze.height-12:oe.bottom+12;Ue.style.top=Math.max(16,Math.min(window.innerHeight-ze.height-16,me))-Re.top+"px"};return se(),window.addEventListener("resize",se),()=>window.removeEventListener("resize",se)},[M,w,P.length,te]);let tt=y.useRef(null);tt.current=async()=>{if(K.current||!P.length)return;K.current=!0,H(!0),B("");let se=P.slice();try{await t.submitDrafts(se),_(se.map(Ue=>String(Ue.id))),O()}catch(Ue){B(Ue.message),S(!0),t.reportSubmissionError(Ue)}finally{K.current=!1,H(!1)}},y.useEffect(()=>{let se=oe=>{!g||oe.repeat||oe.isComposing||oe.key!=="Enter"||!(oe.ctrlKey||oe.metaKey)||oe.composedPath().some(ze=>["INPUT","TEXTAREA","SELECT"].includes(ze.tagName))||(oe.preventDefault(),oe.stopImmediatePropagation(),tt.current())},Ue=()=>{g&&tt.current()};return window.addEventListener("keydown",se,!0),window.addEventListener("bb-review-submit-request",Ue),()=>{window.removeEventListener("keydown",se,!0),window.removeEventListener("bb-review-submit-request",Ue)}},[g]);function ut(se){se.bbPage===i?u(se):(dr(se.bbPage,(G.get(se.bbPage)||[]).filter(Ue=>Ue.id!==se.id)),d?.(se)),O()}return E("div",{className:"bb-session-tray"},E("button",{type:"button",className:"bb-tray-toggle","aria-label":P.length?`\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0439: ${P.length}`:"\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0439 \u043F\u043E\u043A\u0430 \u043D\u0435\u0442","aria-expanded":M,onClick:se=>{se.stopPropagation(),S(!M)}},P.length?"\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0439:":"\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u044F",P.length>0&&E("span",{className:"bb-count-label"},P.length)),M&&E("section",{ref:Se,className:"bb-tray-panel","aria-label":"\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u044F \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0441\u0435\u0441\u0441\u0438\u0438"},E("header",null,E("strong",null,"\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0439"),E("button",{type:"button","aria-label":"\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A",onClick:()=>S(!1)},"\xD7")),!P.length&&E("p",null,"\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0439 \u043F\u043E\u043A\u0430 \u043D\u0435\u0442. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u044D\u043B\u0435\u043C\u0435\u043D\u0442 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u0438 \u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439."),E("div",{className:"bb-tray-list"},P.map(se=>E("article",{key:se.id},E("p",null,se.comment),E("small",null,se.bbPage+" \xB7 "+se.element),E("div",{className:"bb-tray-actions"},E("button",{type:"button",disabled:W,onClick:Ue=>{se.bbPage===i?(S(!1),r(se,Ue.currentTarget)):(t.storage.setItem(t.scope+"-edit-on-load",se.id),location.assign(se.bbPage))}},"\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C"),E("button",{type:"button",disabled:W,onClick:()=>ut(se)},"\u0423\u0434\u0430\u043B\u0438\u0442\u044C"))))),te&&E("p",{role:"alert"},te),E("button",{type:"button",className:"bb-submit-work",disabled:W||!P.length,onClick:()=>void tt.current(),"aria-keyshortcuts":"Control+Enter Meta+Enter"},W?"\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u043C\u2026":"\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0432 \u0440\u0430\u0431\u043E\u0442\u0443"),E("p",{className:"bb-tray-help"},"Ctrl+Enter / Cmd+Enter - \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0432 \u0440\u0430\u0431\u043E\u0442\u0443. \u0414\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0435 \u043A\u0430\u043A \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438."),typeof t.logout=="function"&&E("button",{type:"button",className:"bb-disable-widget",disabled:W,onClick:()=>void t.logout()},"\u0412\u044B\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0432\u0438\u0434\u0436\u0435\u0442")))}return n.exports.loadAllAnnotations=_r,n.exports}});var U2=c0(tn(),1),$2=c0(T2(),1),I2=c0(O2(),1);var z2={position:"fixed",bottom:"88px",right:"16px",zIndex:"2147483647",maxWidth:"calc(100vw - 32px)",padding:"10px 14px",borderRadius:"8px",background:"#242424",color:"#fff",font:"14px/1.4 Arial,sans-serif",boxSizing:"border-box",overflowWrap:"anywhere"};function L2(e,t){let n=new URL(e.href),o=n.searchParams.getAll("wishesKey");if(o.length)return n.searchParams.delete("wishesKey"),t.replaceState(t.state,"",n.pathname+n.search+n.hash),o.length===1&&/^[a-f0-9]{64}$/i.test(o[0])?o[0]:null}var Lc,B2=globalThis.setTimeout.bind(globalThis),H2=globalThis.clearTimeout.bind(globalThis);async function p9(e){if(typeof window>"u")throw new Error("Wishes requires a browser");if(Lc)return Lc;let t=e.storage||window.sessionStorage,n=`buro-wishes:${new URL(e.sessionEndpoint).origin}:session`,o=n+":stopped",l,a,c,f,v,N,$,V,A,U,ce,he,Ne=!1,T=t.getItem(o)==="1",C=0,z=new Set,L=(Ie,sn)=>{try{return JSON.parse(t.getItem(Ie))??sn}catch{return sn}},de=Ie=>{e.onError?.(Ie),!(Ne||!f)&&($||($=document.createElement("div"),$.setAttribute("role","status"),Object.assign($.style,z2),V=document.createElement("div"),V.setAttribute("data-feedback-toolbar",""),V.attachShadow({mode:"open"}).append($),document.body.append(V)),$.textContent=Ie,$.hidden=!Ie)},_e=()=>{C++,f?.unmount(),f=null,N?.remove(),N=null,H2(U),V?.remove(),V=null,$=null},be=()=>{_e();for(let Ie of z)Ie.abort();l=null,t.removeItem(n),T=!0};async function Ce(Ie,sn=!1){if(Ne||!sn&&(!l||T))throw new Error("\u0421\u0435\u0441\u0441\u0438\u044F Wishes \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430");if(!sn&&a==="session"&&L(n,{}).expiresAt*1e3<=Date.now())throw be(),new Error("\u0421\u0435\u0441\u0441\u0438\u044F Wishes \u0438\u0441\u0442\u0435\u043A\u043B\u0430");if(!sn&&a==="jwt"&&e.getJwt?.()!==l)throw _e(),new Error("\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0434\u043E\u0441\u0442\u0443\u043F.");let Pn=JSON.stringify(Ie);if(new TextEncoder().encode(Pn).length>7e4)throw new Error("\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435. \u0421\u043E\u043A\u0440\u0430\u0442\u0438\u0442\u0435 \u0442\u0435\u043A\u0441\u0442.");let On=new AbortController;z.add(On);let kn=B2(()=>On.abort(),15e3);try{let bn=await fetch(sn||a==="session"?e.sessionEndpoint:e.jwtEndpoint,{method:"POST",credentials:"omit",cache:"no-store",referrerPolicy:"no-referrer",signal:On.signal,headers:{"Content-Type":"application/json",...sn?{}:{Authorization:`Bearer ${l}`}},body:Pn});if(bn.status===401||bn.status===403)throw a==="jwt"&&(he=l),be(),new Error("\u0414\u043E\u0441\u0442\u0443\u043F Wishes \u0437\u0430\u043A\u0440\u044B\u0442. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0430\u0439\u0442 \u0438\u0437 \u0430\u0434\u043C\u0438\u043D\u043A\u0438.");let In;try{In=await bn.json()}catch{throw new Error("\u0421\u0435\u0440\u0432\u0438\u0441 \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0439 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u0437\u0436\u0435.")}if(!bn.ok||!In.ok)throw new Error(bn.status===400?"\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0435 \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u0435. \u0418\u0441\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u0435\u0433\u043E \u043F\u0435\u0440\u0435\u0434 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0439 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u043E\u0439.":"\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u044F. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0435\u0442\u044C \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435.");return In}catch(bn){throw bn instanceof TypeError||bn.name==="AbortError"?new Error("\u0421\u0435\u0442\u044C \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430. \u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u043E\u0435\u0434\u0438\u043D\u0435\u043D\u0438\u0435 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435."):bn}finally{H2(kn),z.delete(On)}}let an=()=>L(c.scope+"-pending-v1",[]);async function st(){if(A)return A;let Ie=c.scope,sn=C,Pn=()=>L(Ie+"-pending-v1",[]);return A=(async()=>{let On=Pn().length>0;for(;!T&&!Ne&&sn===C&&Pn().length;){let kn=Pn()[0],{operationId:bn,...In}=kn;await Ce(In),t.setItem(Ie+"-pending-v1",JSON.stringify(Pn().filter(eo=>eo.operationId!==bn)))}On&&!T&&!Ne&&de("\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0435")})().finally(()=>{A=null}),A}function ho(Ie){if(!(T||Ne))try{let sn=Ie.id??Ie.annotation?.id,Pn=an().filter(On=>(On.id??On.annotation?.id)!==sn);t.setItem(c.scope+"-pending-v1",JSON.stringify([...Pn,{...Ie,operationId:crypto.randomUUID()}])),st().catch(On=>de(On.message))}catch{de("\u0425\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E. \u0421\u043A\u043E\u043F\u0438\u0440\u0443\u0439\u0442\u0435 \u0442\u0435\u043A\u0441\u0442 \u043F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u044F.")}}function Ja(Ie){let sn=new URL(Ie.url||location.href);sn.searchParams.delete("wishesKey");let Pn=["comment","elementPath","element","timestamp","x","y","boundingBox","selectedText","nearbyText","cssClasses","isFixed","fullPath"],On={id:String(Ie.id),url:sn.href};for(let kn of Pn)Ie[kn]!==void 0&&(On[kn]=Ie[kn]);ho({action:"upsert",annotation:On})}async function sr(){let Ie=++C,sn=await Ce({action:"bootstrap"});if(Ie!==C||Ne||T)return;if(sn.protocolVersion!==1||!sn.scope||!sn.userId)throw new Error("\u041D\u0435\u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u044B\u0439 API Wishes");c={...sn,storage:t,logout:()=>es.logout()},c.submitDrafts=async kn=>{if(await st(),an().length)throw new Error("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0438");let bn=c.scope+"-submission-v1",In=kn.map(h_=>String(h_.id)).sort(),eo=L(bn,null);(!eo||JSON.stringify(eo.ids)!==JSON.stringify(In))&&(eo={action:"submit",ids:In,submissionId:crypto.randomUUID()},t.setItem(bn,JSON.stringify(eo)));let ns=await Ce(eo);t.removeItem(bn),de(ns.delivery?.state==="pending"?"\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B. \u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430 \u0432 \u0440\u0430\u0431\u043E\u0442\u0443 \u043E\u0436\u0438\u0434\u0430\u0435\u0442\u0441\u044F.":"\u041F\u043E\u0436\u0435\u043B\u0430\u043D\u0438\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u044B \u0432 \u0440\u0430\u0431\u043E\u0442\u0443")},c.reportSubmissionError=kn=>de(kn.message),v=(0,I2.default)(c);try{await st();let kn=await Ce({action:"drafts"});if(!Array.isArray(kn.annotations))throw new Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u043E\u0432");if(Ie!==C||Ne||T)return;for(let In of v.loadAllAnnotations().keys())v.saveAnnotations(In,[]);let bn=new Map;for(let In of kn.annotations){let eo=new URL(In.url,location.origin).pathname;bn.set(eo,[...bn.get(eo)||[],In])}for(let[In,eo]of bn)v.saveAnnotations(In,eo)}catch(kn){if(T||Ne)return;de(kn.message)}if(Ie!==C||Ne||T)return;N=document.createElement("div"),N.id="buro-wishes-root",document.body.append(N);let Pn=document.createElement("div");N.append(Pn),f=(0,$2.createRoot)(Pn);let On=v.Agentation;f.render(U2.default.createElement(On,{appName:"Buro Wishes",onAnnotationAdd:Ja,onAnnotationUpdate:Ja,onAnnotationDelete:kn=>ho({action:"delete",id:String(kn.id)})})),a==="session"&&(U=B2(()=>{be(),de("\u0421\u0435\u0441\u0441\u0438\u044F Wishes \u0438\u0441\u0442\u0435\u043A\u043B\u0430. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0430\u0439\u0442 \u0438\u0437 \u0430\u0434\u043C\u0438\u043D\u043A\u0438.")},Math.max(0,L(n,{}).expiresAt*1e3-Date.now())))}async function Pa(){if(a==="jwt"&&he&&e.getJwt?.()!==he&&t.getItem(o)!=="1"&&(T=!1,he=null),!(Ne||T))try{if(a==="jwt"&&l!==e.getJwt?.()){_e(),l=e.getJwt?.(),l&&await sr();return}if(a==="session"&&L(n,{}).expiresAt*1e3<=Date.now()){be();return}!f&&l?await sr():l&&await Ce({action:"bootstrap"})}catch{_e()}}function $n(){return ce||(ce=Pa().finally(()=>{ce=null}),ce)}let fa=()=>{document.visibilityState==="visible"&&$n()},Bl=()=>{c&&!T&&st().catch(Ie=>de(Ie.message))},es={destroy(){Ne=!0,_e();for(let Ie of z)Ie.abort();document.removeEventListener("visibilitychange",fa),window.removeEventListener("online",Bl),V?.remove(),Lc===es&&(Lc=null)},async logout(){let Ie=!1;try{a==="session"&&await Ce({action:"logout"})}catch{Ie=!0}finally{be(),t.setItem(o,"1"),de(Ie?"\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0435\u0441\u0441\u0438\u044F \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430. \u0421\u0435\u0440\u0432\u0435\u0440\u043D\u044B\u0439 \u043E\u0442\u0437\u044B\u0432 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D; \u043E\u0442\u0437\u043E\u0432\u0438\u0442\u0435 \u0434\u043E\u0441\u0442\u0443\u043F \u0432 \u0430\u0434\u043C\u0438\u043D\u043A\u0435.":"\u0421\u0435\u0441\u0441\u0438\u044F Wishes \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430")}},refreshAccess:$n,onNavigation(){window.dispatchEvent(new Event("popstate")),$n()}};Lc=es,document.addEventListener("visibilitychange",fa),window.addEventListener("online",Bl);let ts=Object.hasOwn(window,"__buroWishesLaunch")?window.__buroWishesLaunch:L2(location,history);delete window.__buroWishesLaunch;let gn=ts!==void 0;try{if(ts!==void 0){if(T=!1,t.removeItem(o),t.removeItem(n),!ts)throw new Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0441\u044B\u043B\u043A\u0430. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0430\u0439\u0442 \u0438\u0437 \u0430\u0434\u043C\u0438\u043D\u043A\u0438.");let Ie;try{Ie=await Ce({action:"exchange",wishesKey:ts},!0)}finally{ts=null}if(!/^[a-f0-9]{64}$/i.test(Ie.token)||!Number.isFinite(Ie.expiresAt)||Ie.expiresAt*1e3<=Date.now())throw new Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0441\u0435\u0441\u0441\u0438\u044F Wishes");t.setItem(n,JSON.stringify({token:Ie.token,expiresAt:Ie.expiresAt}))}if(!T){let Ie=L(n,null);Ie&&Ie.expiresAt*1e3>Date.now()?(a="session",l=Ie.token):(t.removeItem(n),a="jwt",l=e.jwtEndpoint?e.getJwt?.():null),l&&await sr()}}catch(Ie){gn&&!l&&(T=!0,t.setItem(o,"1")),de("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C Wishes. "+Ie.message+" \u0415\u0441\u043B\u0438 \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u043B\u0438 \u0438\u0437 \u0430\u0434\u043C\u0438\u043D\u043A\u0438, \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0430\u0439\u0442 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E.")}return es}export{p9 as mountWishes};
/*! Bundled license information:

react/cjs/react.production.js:
  (**
   * @license React
   * react.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

scheduler/cjs/scheduler.production.js:
  (**
   * @license React
   * scheduler.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.js:
  (**
   * @license React
   * react-dom.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom-client.production.js:
  (**
   * @license React
   * react-dom-client.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react-jsx-runtime.production.js:
  (**
   * @license React
   * react-jsx-runtime.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
