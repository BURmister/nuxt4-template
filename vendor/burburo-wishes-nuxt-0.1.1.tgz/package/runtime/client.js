import { defineNuxtPlugin, useRuntimeConfig } from '#app';
import { watch } from 'vue';
import { mountWishes } from './wishes.js';

export function createWishesPlugin(createJwtGetter, dependsOn = []) {
  return defineNuxtPlugin({
    name: 'buro-wishes', dependsOn,
    setup(nuxtApp) {
      const config = useRuntimeConfig().public.wishes;
      const getJwt = createJwtGetter(nuxtApp);
      if (typeof getJwt !== 'function') throw new Error('Wishes: jwtProvider must return a getter.');
      const ready = mountWishes({ ...config, getJwt, storage: window.sessionStorage });
      const update = navigation => {
        void ready.then(handle => navigation ? handle.onNavigation() : handle.refreshAccess())
          .catch(() => console.warn('Wishes: хранилище или конфигурация недоступны'));
      };
      nuxtApp.hook('page:finish', () => update(true));
      const unwatch = watch(getJwt, () => update(false));
      void ready.catch(() => console.warn('Wishes: хранилище или конфигурация недоступны'));
      if (import.meta.hot) import.meta.hot.dispose(() => {
        unwatch(); void ready.then(handle => handle.destroy()).catch(() => {});
      });
    },
  });
}
