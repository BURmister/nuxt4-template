import { defineNuxtPlugin } from '#app';
export default defineNuxtPlugin({
  name: 'wishes-ssr-privacy', order: -50,
  setup(nuxtApp) {
    const context = nuxtApp.ssrContext;
    if (!context) return;
    const url = new URL(context.url, 'https://wishes.invalid');
    if (!url.searchParams.has('wishesKey')) return;
    url.searchParams.delete('wishesKey');
    context.url = url.pathname + url.search;
    nuxtApp.payload.path = context.url;
  },
});
