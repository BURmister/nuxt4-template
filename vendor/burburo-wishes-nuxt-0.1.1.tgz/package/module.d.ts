import type { NuxtModule } from '@nuxt/schema';
export interface ModuleOptions {
  apiBase?: string;
  sessionEndpoint?: string;
  jwtEndpoint?: string;
  /** Path to a default-exported factory called in Nuxt plugin setup; returns a JWT getter. */
  jwtProvider?: string;
  dependsOn?: string[];
}
declare const module: NuxtModule<ModuleOptions>;
export default module;
declare module '@nuxt/schema' {
  interface NuxtConfig { wishes?: ModuleOptions }
  interface NuxtOptions { wishes?: ModuleOptions }
}
