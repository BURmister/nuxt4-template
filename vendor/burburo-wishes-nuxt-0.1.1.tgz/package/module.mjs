import { defineNuxtModule, createResolver, addPlugin, addTemplate, addServerHandler, resolvePath } from '@nuxt/kit';

export default defineNuxtModule({
  meta: { name: '@burburo/wishes-nuxt', configKey: 'wishes', compatibility: { nuxt: '>=4.2.1 <5' } },
  defaults: { apiBase: '', sessionEndpoint: '', jwtEndpoint: '', jwtProvider: '', dependsOn: [] },
  async setup(options, nuxt) {
    const resolver = createResolver(import.meta.url);
    const base = options.apiBase.replace(/\/$/, '');
    const sessionEndpoint = options.sessionEndpoint || (base && `${base}/bitrix/tools/burburo.wishes/headless.php`);
    const jwtEndpoint = options.jwtEndpoint || (options.jwtProvider && base ? `${base}/api/wishes/jwt` : '');
    if (!sessionEndpoint) throw new Error('Wishes: configure apiBase or sessionEndpoint.');
    for (const endpoint of [sessionEndpoint, jwtEndpoint].filter(Boolean)) {
      const url = new URL(endpoint);
      if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
        throw new Error('Wishes: API endpoints must be HTTP(S) URLs without credentials or query parameters.');
      }
    }
    if (options.jwtProvider && !jwtEndpoint) throw new Error('Wishes: configure jwtEndpoint for jwtProvider.');
    nuxt.options.runtimeConfig.public.wishes = {
      sessionEndpoint, jwtEndpoint, ...nuxt.options.runtimeConfig.public.wishes,
    };
    const provider = options.jwtProvider ? await resolvePath(options.jwtProvider) : null;
    const template = addTemplate({
      filename: 'burburo-wishes.client.mjs',
      getContents: () => [
        `import { createWishesPlugin } from ${JSON.stringify(resolver.resolve('./runtime/client.js'))};`,
        provider ? `import createJwtGetter from ${JSON.stringify(provider)};` : 'const createJwtGetter = () => () => null;',
        `export default createWishesPlugin(createJwtGetter, ${JSON.stringify(options.dependsOn)});`,
      ].join('\n'),
    });
    addPlugin({ src: template.dst, mode: 'client' });
    addPlugin({ src: resolver.resolve('./runtime/privacy.server.js'), mode: 'server' });
    addServerHandler({ middleware: true, handler: resolver.resolve('./runtime/privacy.js') });
    nuxt.options.app.head.script ||= [];
    nuxt.options.app.head.script.unshift({
      key: 'burburo-wishes-launch', tagPriority: 'critical',
      innerHTML: `(function(){var u=new URL(location.href),c=u.searchParams.getAll('wishesKey');if(!c.length)return;u.searchParams.delete('wishesKey');history.replaceState(history.state,'',u.pathname+u.search+u.hash);window.__buroWishesLaunch=c.length===1&&/^[a-f0-9]{64}$/i.test(c[0])?c[0]:null;})();`,
    });
  },
});
