# @burburo/wishes-nuxt

Nuxt 4 module with the independent @burburo/wishes browser build included. UI and styles remain in the universal package. No Pinia dependency unless your site uses it.

Install one private package archive (or the package from your private registry):

```sh
pnpm add ./vendor/burburo-wishes-nuxt-0.1.1.tgz
```

Session launched from Bitrix:

```ts
export default defineNuxtConfig({
  modules: ['@burburo/wishes-nuxt'],
  wishes: { apiBase: 'https://api.example.ru' },
});
```

For a site with authorization, add `jwtProvider: '~/wishes-auth.ts'` and (for Pinia) `dependsOn: ['pinia']`. Provider file:

```ts
import { useAuth } from '~/stores/useAuth';
export default function createJwtGetter() {
  const auth = useAuth();
  return () => auth.authToken || null;
}
```

The provider factory runs in Nuxt plugin setup; its getter can read reactive state. Never put JWT values or signing secrets in configuration. Defaults are `/bitrix/tools/burburo.wishes/headless.php` and `/api/wishes/jwt`; override `sessionEndpoint` / `jwtEndpoint` for different routes. Runtime overrides: `NUXT_PUBLIC_WISHES_SESSION_ENDPOINT`, `NUXT_PUBLIC_WISHES_JWT_ENDPOINT`.

The module installs SPA/auth hooks, early launch-key cleanup before analytics, SSR URL cleanup, no-referrer and no-store headers for launch requests. The API must be installed and validate origin, credentials and current rights. Configure CSP nonce/hash for the launch script when required, and redact wishesKey in proxy/access/APM logs. Nitro middleware cannot redact upstream logs. Prerendered/static deployments must configure equivalent response headers at the hosting layer.

Deploy with the site's regular `pnpm install --frozen-lockfile` and `pnpm build`; no separate runtime asset upload. Update the archive and lockfile when publishing a new version. Third-party licenses are included in this package. Build the universal package first, then run this package’s build script and pack it.
